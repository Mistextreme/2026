Locales = {} -- edit translation in config/locales
Config = {}

-- Documentation: https://docs.sky-systems.net/docs/scripts/banking

-- Join our discord for support & updates
-- https://discord.gg/sky-systems

Config.UseBilling = true -- ESX ONLY
Config.ESXCoreResource = "es_extended" -- ESX ONLY
Config.UseSounds = true
Config.UseATMs = true 

Config.Blips = {
    Bank = {
        showBlip = true, --If true the Location will have an Blip
        blip = { --The Blip Settings
            name = "Bank",
            sprite = 108,
            color = 2
        },
    },
}

Config.Locations = {
    Bank = {
        {x = 287.7108, y = -614.4577, z = 43.4296}
    },
}