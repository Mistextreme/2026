# Sky-Systems Scripts

Thank you for purchasing a Sky-Systems script! We are committed to providing high-quality scripts to enhance your FiveM server experience. Below, you'll find essential links to our documentation and support resources to help you get started.

## Installation

For step-by-step installation instructions, please visit our [Installation Docs](https://docs.sky-systems.net/docs/scripts/installation).

## Script-Specific Documentation

For detailed information on configuring and using specific scripts, check out our [Script Documentation](https://docs.sky-systems.net/docs/information).

## Support

If you need any assistance or have further questions, join our Discord community for support:

[Sky-Systems Discord](https://discord.gg/sky-systems)

Thank you for choosing Sky-Systems! We hope you enjoy using our scripts on your server.