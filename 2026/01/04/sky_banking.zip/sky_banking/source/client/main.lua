local L0_1, L1_1, L2_1, L3_1
L0_1 = Locales
L1_1 = Sky
L1_1 = L1_1.Config
L1_1 = L1_1.locale
L0_1 = L0_1[L1_1]
if not L0_1 then
  L0_1 = Locales
  L0_1 = L0_1.en
end
canOpen = true
L1_1 = Citizen
L1_1 = L1_1.CreateThread
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2
  L0_2 = {}
  L1_2 = {}
  L2_2 = pairs
  L3_2 = Config
  L3_2 = L3_2.Locations
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = ipairs
    L9_2 = L7_2
    L8_2, L9_2, L10_2, L11_2 = L8_2(L9_2)
    for L12_2, L13_2 in L8_2, L9_2, L10_2, L11_2 do
      L14_2 = {}
      L15_2 = Config
      L15_2 = L15_2.Blips
      L15_2 = L15_2[L6_2]
      if L15_2 then
        L15_2 = Config
        L15_2 = L15_2.Blips
        L15_2 = L15_2[L6_2]
        L15_2 = L15_2.showBlip
      end
      if L15_2 then
        L16_2 = Config
        L16_2 = L16_2.Blips
        L16_2 = L16_2[L6_2]
        L14_2 = L16_2.blip
      end
      L16_2 = Sky
      L16_2 = L16_2.CreateInteractionPoint
      L17_2 = L13_2
      L18_2 = L0_1.help_notify
      L19_2 = "sky_banking:interaction"
      L20_2 = L6_2
      L21_2 = L1_2
      L22_2 = L0_2
      L23_2 = L14_2
      L24_2 = "sky_banking"
      L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
    end
  end
end
L1_1(L2_1)
L1_1 = Config
L1_1 = L1_1.UseATMs
if L1_1 then
  L1_1 = CreateThread
  function L2_1()
    local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
    L0_2 = {}
    L1_2 = "prop_atm_03"
    L2_2 = "prop_atm_02"
    L3_2 = "prop_atm_01"
    L4_2 = "prop_fleeca_atm"
    L0_2[1] = L1_2
    L0_2[2] = L2_2
    L0_2[3] = L3_2
    L0_2[4] = L4_2
    L1_2 = {}
    while true do
      L2_2 = Wait
      L3_2 = 1000
      L2_2(L3_2)
      L2_2 = GetEntityCoords
      L3_2 = PlayerPedId
      L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L3_2()
      L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
      L3_2 = 1
      L4_2 = #L0_2
      L5_2 = 1
      for L6_2 = L3_2, L4_2, L5_2 do
        L7_2 = GetClosestObjectOfType
        L8_2 = L2_2
        L9_2 = 3.0
        L10_2 = GetHashKey
        L11_2 = L0_2[L6_2]
        L10_2 = L10_2(L11_2)
        L11_2 = false
        L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2)
        L8_2 = DoesEntityExist
        L9_2 = L7_2
        L8_2 = L8_2(L9_2)
        if L8_2 then
          L8_2 = GetEntityCoords
          L9_2 = L7_2
          L8_2 = L8_2(L9_2)
          L9_2 = L2_2 - L8_2
          L9_2 = #L9_2
          if L9_2 < 3 then
            L10_2 = L1_2[L7_2]
            if not L10_2 then
              L1_2[L7_2] = true
              L10_2 = Sky
              L10_2 = L10_2.CreateInteractionPoint
              L11_2 = L8_2
              L12_2 = L0_1.help_notify
              L13_2 = "sky_banking:interaction"
              L14_2 = "atm"
              L15_2 = {}
              L16_2 = {}
              L17_2 = {}
              L18_2 = "sky_banking"
              L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
            end
          end
        end
      end
    end
  end
  L1_1(L2_1)
end
L1_1 = AddEventHandler
L2_1 = "sky_banking:interaction"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = canOpen
  if not L1_2 then
    return
  end
  canOpen = false
  L1_2 = Sky
  L1_2 = L1_2.Ped
  L2_2 = L1_2
  L1_2 = L1_2.new
  L3_2 = PlayerPedId
  L3_2, L4_2, L5_2 = L3_2()
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2)
  player = L1_2
  L1_2 = player
  L2_2 = L1_2
  L1_2 = L1_2.PlayAnim
  L3_2 = "mp_common"
  L4_2 = "givetake1_a"
  L5_2 = 2500
  L1_2(L2_2, L3_2, L4_2, L5_2)
  L1_2 = Sky
  L1_2 = L1_2.Cb
  L1_2 = L1_2.Trigger
  L2_2 = "sky_banking:getAccountInfo"
  L1_2 = L1_2(L2_2)
  user = L1_2
  L1_2 = string
  L1_2 = L1_2.format
  L2_2 = L0_1.title
  L3_2 = user
  L3_2 = L3_2.name
  L1_2 = L1_2(L2_2, L3_2)
  L0_1.title = L1_2
  L1_2 = SendNUIMessage
  L2_2 = {}
  L2_2.type = "open"
  L3_2 = user
  L3_2 = L3_2.name
  L2_2.name = L3_2
  L3_2 = user
  L3_2 = L3_2.balance
  L2_2.balance = L3_2
  L3_2 = user
  L3_2 = L3_2.cash
  L2_2.cash = L3_2
  L3_2 = user
  L3_2 = L3_2.totals
  L2_2.totals = L3_2
  L3_2 = user
  L3_2 = L3_2.account
  L2_2.account = L3_2
  L3_2 = Sky
  L3_2 = L3_2.Config
  L3_2 = L3_2.framework
  L3_2 = Config
  L3_2 = "esx" == L3_2 and L3_2
  L2_2.billing = L3_2
  L3_2 = L0_1
  L2_2.locales = L3_2
  L1_2(L2_2)
  L1_2 = user
  L1_2 = L1_2.stats
  if L1_2 then
    L1_2 = SendNUIMessage
    L2_2 = {}
    L2_2.type = "stats"
    L3_2 = user
    L3_2 = L3_2.stats
    L2_2.stats = L3_2
    L1_2(L2_2)
  end
  L1_2 = user
  L1_2 = L1_2.transactions
  if L1_2 then
    L1_2 = SendNUIMessage
    L2_2 = {}
    L2_2.type = "transactions"
    L3_2 = user
    L3_2 = L3_2.transactions
    L2_2.transactions = L3_2
    L1_2(L2_2)
  end
  L1_2 = user
  L1_2 = L1_2.transfers
  if L1_2 then
    L1_2 = SendNUIMessage
    L2_2 = {}
    L2_2.type = "transfers"
    L3_2 = user
    L3_2 = L3_2.transfers
    L2_2.transfers = L3_2
    L1_2(L2_2)
  end
  L1_2 = Sky
  L1_2 = L1_2.Config
  L1_2 = L1_2.framework
  if "esx" == L1_2 then
    L1_2 = Config
    L1_2 = L1_2.UseBilling
    if L1_2 then
      L1_2 = exports
      L2_2 = Config
      L2_2 = L2_2.ESXCoreResource
      L1_2 = L1_2[L2_2]
      L2_2 = L1_2
      L1_2 = L1_2.getSharedObject
      L1_2 = L1_2(L2_2)
      ESX = L1_2
      L1_2 = ESX
      L1_2 = L1_2.TriggerServerCallback
      L2_2 = "esx_billing:getBills"
      function L3_2(A0_3)
        local L1_3, L2_3
        L1_3 = SendNUIMessage
        L2_3 = {}
        L2_3.type = "bills"
        L2_3.bills = A0_3
        L1_3(L2_3)
      end
      L1_2(L2_2, L3_2)
    end
  end
  L1_2 = SetNuiFocus
  L2_2 = true
  L3_2 = true
  L1_2(L2_2, L3_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "close"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = SetNuiFocus
  L3_2 = false
  L4_2 = false
  L2_2(L3_2, L4_2)
  canOpen = true
  L2_2 = A1_2
  L3_2 = {}
  L2_2(L3_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "deposit"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = Sky
  L2_2 = L2_2.Cooldown
  L3_2 = 3000
  L2_2 = L2_2(L3_2)
  if L2_2 then
    L2_2 = Sky
    L2_2 = L2_2.Cb
    L2_2 = L2_2.Trigger
    L3_2 = "sky_banking:deposit"
    L4_2 = A0_2.amount
    L2_2 = L2_2(L3_2, L4_2)
    if L2_2 then
      L3_2 = playSound
      L4_2 = "money"
      L3_2(L4_2)
    else
      L3_2 = playSound
      L4_2 = "error"
      L3_2(L4_2)
    end
    L3_2 = A1_2
    L4_2 = L2_2
    L3_2(L4_2)
  else
    L2_2 = playSound
    L3_2 = "error"
    L2_2(L3_2)
    L2_2 = A1_2
    L3_2 = false
    L2_2(L3_2)
  end
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "withdraw"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = Sky
  L2_2 = L2_2.Cooldown
  L3_2 = 3000
  L2_2 = L2_2(L3_2)
  if L2_2 then
    L2_2 = Sky
    L2_2 = L2_2.Cb
    L2_2 = L2_2.Trigger
    L3_2 = "sky_banking:withdraw"
    L4_2 = A0_2.amount
    L2_2 = L2_2(L3_2, L4_2)
    if L2_2 then
      L3_2 = playSound
      L4_2 = "money"
      L3_2(L4_2)
    else
      L3_2 = playSound
      L4_2 = "error"
      L3_2(L4_2)
    end
    L3_2 = A1_2
    L4_2 = L2_2
    L3_2(L4_2)
  else
    L2_2 = playSound
    L3_2 = "error"
    L2_2(L3_2)
    L2_2 = A1_2
    L3_2 = false
    L2_2(L3_2)
  end
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "transfer"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = Sky
  L2_2 = L2_2.Cooldown
  L3_2 = 3000
  L2_2 = L2_2(L3_2)
  if L2_2 then
    L2_2 = Sky
    L2_2 = L2_2.Cb
    L2_2 = L2_2.Trigger
    L3_2 = "sky_banking:transfer"
    L4_2 = A0_2
    L2_2 = L2_2(L3_2, L4_2)
    L3_2 = type
    L4_2 = L2_2
    L3_2 = L3_2(L4_2)
    if "number" == L3_2 then
      L3_2 = playSound
      L4_2 = "error"
      L3_2(L4_2)
    else
      L3_2 = playSound
      L4_2 = "money"
      L3_2(L4_2)
    end
    L3_2 = A1_2
    L4_2 = L2_2
    L3_2(L4_2)
  else
    L2_2 = playSound
    L3_2 = "error"
    L2_2(L3_2)
    L2_2 = A1_2
    L3_2 = 2
    L2_2(L3_2)
  end
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "pay-bill"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = Sky
  L2_2 = L2_2.Config
  L2_2 = L2_2.framework
  if "esx" == L2_2 then
    L2_2 = Config
    L2_2 = L2_2.UseBilling
    if L2_2 then
      L2_2 = exports
      L3_2 = Config
      L3_2 = L3_2.ESXCoreResource
      L2_2 = L2_2[L3_2]
      L3_2 = L2_2
      L2_2 = L2_2.getSharedObject
      L2_2 = L2_2(L3_2)
      ESX = L2_2
      L2_2 = ESX
      L2_2 = L2_2.TriggerServerCallback
      L3_2 = "esx_billing:payBill"
      function L4_2()
        local L0_3, L1_3, L2_3, L3_3, L4_3
        L0_3 = playSound
        L1_3 = "money"
        L0_3(L1_3)
        L0_3 = logTransaction
        L1_3 = "bill"
        L2_3 = A0_2.label
        L3_3 = true
        L4_3 = A0_2.amount
        L0_3(L1_3, L2_3, L3_3, L4_3)
      end
      L5_2 = A0_2.id
      L2_2(L3_2, L4_2, L5_2)
    end
  end
  L2_2 = A1_2
  L3_2 = {}
  L2_2(L3_2)
end
L1_1(L2_1, L3_1)
function L1_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L4_2 = TriggerServerEvent
  L5_2 = "sky_banking:transaction"
  L6_2 = A0_2
  L7_2 = A1_2
  L8_2 = A2_2
  L9_2 = A3_2
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
end
logTransaction = L1_1
function L1_1(A0_2)
  local L1_2, L2_2
  L1_2 = Config
  L1_2 = L1_2.UseSounds
  if L1_2 then
    L1_2 = Sky
    L1_2 = L1_2.Show
    L1_2 = L1_2.PlaySound
    L2_2 = A0_2
    L1_2(L2_2)
  end
end
playSound = L1_1
L1_1 = RegisterNetEvent
L2_1 = "sky_banking:update"
function L3_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2
  L5_2 = SendNUIMessage
  L6_2 = {}
  L6_2.type = "update"
  L6_2.balance = A1_2
  L6_2.cash = A0_2
  L5_2(L6_2)
  if A2_2 then
    L5_2 = SendNUIMessage
    L6_2 = {}
    L6_2.type = "transactions"
    L6_2.transactions = A2_2
    L5_2(L6_2)
  end
  if A3_2 then
    L5_2 = SendNUIMessage
    L6_2 = {}
    L6_2.type = "transfers"
    L6_2.transfers = A3_2
    L5_2(L6_2)
  end
  if A4_2 then
    L5_2 = SendNUIMessage
    L6_2 = {}
    L6_2.type = "totals"
    L6_2.totals = A4_2
    L5_2(L6_2)
  end
end
L1_1(L2_1, L3_1)
