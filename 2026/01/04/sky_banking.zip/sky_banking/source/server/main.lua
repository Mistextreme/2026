local L0_1, L1_1, L2_1, L3_1
L0_1 = Sky
L0_1 = L0_1.CheckVersion
L1_1 = GetCurrentResourceName
L1_1, L2_1, L3_1 = L1_1()
L0_1(L1_1, L2_1, L3_1)
L0_1 = Locales
L1_1 = Sky
L1_1 = L1_1.Config
L1_1 = L1_1.locale
L0_1 = L0_1[L1_1]
if not L0_1 then
  L0_1 = Locales
  L0_1 = L0_1.en
end
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = Sky
  L0_2 = L0_2.Math
  L0_2 = L0_2.GetRandomNumbers
  L1_2 = 6
  L0_2 = L0_2(L1_2)
  L1_2 = Sky
  L1_2 = L1_2.Query
  L2_2 = "SELECT * FROM banking_users WHERE bank_number = ?"
  L3_2 = {}
  L4_2 = L0_2
  L3_2[1] = L4_2
  L1_2 = L1_2(L2_2, L3_2)
  L2_2 = L1_2[1]
  if nil ~= L2_2 then
    L2_2 = generateBankNumber
    return L2_2()
  else
    return L0_2
  end
end
generateBankNumber = L1_1
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = nil
  repeat
    L1_2 = Sky
    L1_2 = L1_2.Math
    L1_2 = L1_2.GetRandomNumbers
    L2_2 = 6
    L1_2 = L1_2(L2_2)
    L0_2 = L1_2
    L1_2 = tonumber
    L2_2 = string
    L2_2 = L2_2.sub
    L3_2 = L0_2
    L4_2 = 1
    L5_2 = 1
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2, L4_2, L5_2)
    L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2)
  until 0 ~= L1_2
  L1_2 = Sky
  L1_2 = L1_2.Query
  L2_2 = "SELECT * FROM banking_users WHERE bank_number = ?"
  L3_2 = {}
  L4_2 = L0_2
  L3_2[1] = L4_2
  L1_2 = L1_2(L2_2, L3_2)
  L2_2 = L1_2[1]
  if nil ~= L2_2 then
    L2_2 = generateBankNumber
    return L2_2()
  else
    return L0_2
  end
end
generateBankNumber = L1_1
function L1_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L3_2 = os
  L3_2 = L3_2.date
  L4_2 = "*t"
  L3_2 = L3_2(L4_2)
  L4_2 = tostring
  L5_2 = L3_2.day
  L4_2 = L4_2(L5_2)
  L5_2 = "/"
  L6_2 = tostring
  L7_2 = L3_2.month
  L6_2 = L6_2(L7_2)
  L7_2 = "/"
  L8_2 = tostring
  L9_2 = L3_2.year
  L8_2 = L8_2(L9_2)
  L4_2 = L4_2 .. L5_2 .. L6_2 .. L7_2 .. L8_2
  L5_2 = false
  L6_2 = 1
  L7_2 = #A1_2
  L8_2 = 1
  for L9_2 = L6_2, L7_2, L8_2 do
    L10_2 = A1_2[L9_2]
    L10_2 = L10_2.date
    if L10_2 == L4_2 then
      L5_2 = true
      L10_2 = A1_2[L9_2]
      L10_2 = L10_2.highestBalance
      if A2_2 > L10_2 then
        L10_2 = A1_2[L9_2]
        L10_2.highestBalance = A2_2
      end
    end
  end
  if not L5_2 then
    L6_2 = table
    L6_2 = L6_2.insert
    L7_2 = A1_2
    L8_2 = {}
    L8_2.date = L4_2
    L8_2.highestBalance = A2_2
    L6_2(L7_2, L8_2)
  end
  while true do
    L6_2 = #A1_2
    if not (L6_2 > 7) then
      break
    end
    L6_2 = table
    L6_2 = L6_2.remove
    L7_2 = A1_2
    L8_2 = 1
    L6_2(L7_2, L8_2)
  end
  L6_2 = Sky
  L6_2 = L6_2.Query
  L7_2 = "UPDATE banking_users SET stats = ? WHERE identifier = ?"
  L8_2 = {}
  L9_2 = json
  L9_2 = L9_2.encode
  L10_2 = A1_2
  L9_2 = L9_2(L10_2)
  L10_2 = A0_2
  L8_2[1] = L9_2
  L8_2[2] = L10_2
  L6_2(L7_2, L8_2)
  return A1_2
end
updateStats = L1_1
L1_1 = Sky
L1_1 = L1_1.Cb
L1_1 = L1_1.Register
L2_1 = "sky_banking:getAccountInfo"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = {}
  info = L1_2
  L1_2 = info
  L2_2 = Sky
  L2_2 = L2_2.FW
  L2_2 = L2_2.GetAccountMoney
  L3_2 = A0_2
  L4_2 = "money"
  L2_2 = L2_2(L3_2, L4_2)
  L1_2.cash = L2_2
  L1_2 = info
  L2_2 = Sky
  L2_2 = L2_2.FW
  L2_2 = L2_2.GetAccountMoney
  L3_2 = A0_2
  L4_2 = "bank"
  L2_2 = L2_2(L3_2, L4_2)
  L1_2.balance = L2_2
  L1_2 = info
  L2_2 = Sky
  L2_2 = L2_2.FW
  L2_2 = L2_2.GetName
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L1_2.name = L2_2
  L1_2 = Sky
  L1_2 = L1_2.FW
  L1_2 = L1_2.GetIdentifier
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L2_2 = Sky
  L2_2 = L2_2.Query
  L3_2 = "SELECT * FROM banking_users WHERE identifier = ?"
  L4_2 = {}
  L5_2 = L1_2
  L4_2[1] = L5_2
  L2_2 = L2_2(L3_2, L4_2)
  L3_2 = L2_2[1]
  if nil ~= L3_2 then
    L3_2 = info
    L4_2 = L2_2[1]
    L4_2 = L4_2.bank_number
    L3_2.account = L4_2
    L3_2 = info
    L4_2 = json
    L4_2 = L4_2.decode
    L5_2 = L2_2[1]
    L5_2 = L5_2.last_transactions
    L4_2 = L4_2(L5_2)
    L3_2.transactions = L4_2
    L3_2 = info
    L4_2 = json
    L4_2 = L4_2.decode
    L5_2 = L2_2[1]
    L5_2 = L5_2.last_transfers
    L4_2 = L4_2(L5_2)
    L3_2.transfers = L4_2
    L3_2 = info
    L4_2 = json
    L4_2 = L4_2.decode
    L5_2 = L2_2[1]
    L5_2 = L5_2.totals
    L4_2 = L4_2(L5_2)
    L3_2.totals = L4_2
    L3_2 = info
    L3_2 = L3_2.totals
    if not L3_2 then
      L3_2 = info
      L4_2 = {}
      L4_2.deposit = 0
      L4_2.withdraw = 0
      L4_2.transfer = 0
      L3_2.totals = L4_2
      L3_2 = Sky
      L3_2 = L3_2.Query
      L4_2 = "UPDATE banking_users SET totals = ? WHERE identifier = ?"
      L5_2 = {}
      L6_2 = json
      L6_2 = L6_2.encode
      L7_2 = info
      L7_2 = L7_2.totals
      L6_2 = L6_2(L7_2)
      L7_2 = L1_2
      L5_2[1] = L6_2
      L5_2[2] = L7_2
      L3_2(L4_2, L5_2)
    end
    L3_2 = info
    L4_2 = updateStats
    L5_2 = L1_2
    L6_2 = json
    L6_2 = L6_2.decode
    L7_2 = L2_2[1]
    L7_2 = L7_2.stats
    L6_2 = L6_2(L7_2)
    L7_2 = info
    L7_2 = L7_2.balance
    L4_2 = L4_2(L5_2, L6_2, L7_2)
    L3_2.stats = L4_2
  else
    L3_2 = generateBankNumber
    L3_2 = L3_2()
    L4_2 = Sky
    L4_2 = L4_2.Query
    L5_2 = "INSERT INTO banking_users (identifier, bank_number, last_transactions, last_transfers, stats, totals) VALUES (?, ?, ?, ?, ?, ?)"
    L6_2 = {}
    L7_2 = L1_2
    L8_2 = L3_2
    L9_2 = "[]"
    L10_2 = "[]"
    L11_2 = "[]"
    L12_2 = "{\"deposit\": 0, \"withdraw\": 0, \"transfer\": 0}"
    L6_2[1] = L7_2
    L6_2[2] = L8_2
    L6_2[3] = L9_2
    L6_2[4] = L10_2
    L6_2[5] = L11_2
    L6_2[6] = L12_2
    L4_2(L5_2, L6_2)
    L4_2 = info
    L4_2.account = L3_2
  end
  L3_2 = info
  return L3_2
end
L1_1(L2_1, L3_1)
L1_1 = Sky
L1_1 = L1_1.Cb
L1_1 = L1_1.Register
L2_1 = "sky_banking:deposit"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = Sky
  L2_2 = L2_2.FW
  L2_2 = L2_2.RemoveAccountMoney
  L3_2 = A0_2
  L4_2 = "money"
  L5_2 = A1_2
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if L2_2 then
    L2_2 = Sky
    L2_2 = L2_2.FW
    L2_2 = L2_2.AddAccountMoney
    L3_2 = A0_2
    L4_2 = "bank"
    L5_2 = A1_2
    L2_2(L3_2, L4_2, L5_2)
    L2_2 = logTransaction
    L3_2 = A0_2
    L4_2 = "deposit"
    L5_2 = L0_1.deposit
    L6_2 = false
    L7_2 = A1_2
    L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
    L2_2 = updateFrontend
    L3_2 = A0_2
    L2_2(L3_2)
    L2_2 = true
    return L2_2
  end
  L2_2 = false
  return L2_2
end
L1_1(L2_1, L3_1)
L1_1 = Sky
L1_1 = L1_1.Cb
L1_1 = L1_1.Register
L2_1 = "sky_banking:withdraw"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L2_2 = Sky
  L2_2 = L2_2.FW
  L2_2 = L2_2.RemoveAccountMoney
  L3_2 = A0_2
  L4_2 = "bank"
  L5_2 = A1_2
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  if L2_2 then
    L2_2 = Sky
    L2_2 = L2_2.FW
    L2_2 = L2_2.AddAccountMoney
    L3_2 = A0_2
    L4_2 = "money"
    L5_2 = A1_2
    L2_2(L3_2, L4_2, L5_2)
    L2_2 = logTransaction
    L3_2 = A0_2
    L4_2 = "withdraw"
    L5_2 = L0_1.withdraw
    L6_2 = true
    L7_2 = A1_2
    L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
    L2_2 = updateFrontend
    L3_2 = A0_2
    L2_2(L3_2)
    L2_2 = true
    return L2_2
  end
  L2_2 = false
  return L2_2
end
L1_1(L2_1, L3_1)
L1_1 = Sky
L1_1 = L1_1.Cb
L1_1 = L1_1.Register
L2_1 = "sky_banking:transfer"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L2_2 = Sky
  L2_2 = L2_2.Query
  L3_2 = "SELECT identifier FROM banking_users WHERE bank_number = ?"
  L4_2 = {}
  L5_2 = A1_2.to
  L4_2[1] = L5_2
  L2_2 = L2_2(L3_2, L4_2)
  L3_2 = L2_2[1]
  if nil ~= L3_2 then
    L3_2 = L2_2[1]
    L3_2 = L3_2.identifier
    if L3_2 then
      L3_2 = Sky
      L3_2 = L3_2.FW
      L3_2 = L3_2.IsPlayerOnline
      L4_2 = L2_2[1]
      L4_2 = L4_2.identifier
      L3_2 = L3_2(L4_2)
      if L3_2 then
        L4_2 = Sky
        L4_2 = L4_2.FW
        L4_2 = L4_2.RemoveAccountMoney
        L5_2 = A0_2
        L6_2 = "bank"
        L7_2 = A1_2.amount
        L4_2 = L4_2(L5_2, L6_2, L7_2)
        if L4_2 then
          L4_2 = Sky
          L4_2 = L4_2.FW
          L4_2 = L4_2.AddAccountMoney
          L5_2 = L3_2
          L6_2 = "bank"
          L7_2 = A1_2.amount
          L4_2(L5_2, L6_2, L7_2)
          L4_2 = logTransaction
          L5_2 = A0_2
          L6_2 = "transfer"
          L7_2 = L0_1.transfer
          L8_2 = true
          L9_2 = A1_2.amount
          L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
          L4_2 = logTransaction
          L5_2 = L3_2
          L6_2 = "transfer"
          L7_2 = L0_1.transfer
          L8_2 = false
          L9_2 = A1_2.amount
          L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
          L4_2 = logTransfer
          L5_2 = L3_2
          L6_2 = false
          L7_2 = Sky
          L7_2 = L7_2.FW
          L7_2 = L7_2.GetName
          L8_2 = A0_2
          L7_2 = L7_2(L8_2)
          L8_2 = A1_2.amount
          L4_2(L5_2, L6_2, L7_2, L8_2)
          L4_2 = logTransfer
          L5_2 = A0_2
          L6_2 = true
          L7_2 = Sky
          L7_2 = L7_2.FW
          L7_2 = L7_2.GetName
          L8_2 = L3_2
          L7_2 = L7_2(L8_2)
          L8_2 = A1_2.amount
          L4_2(L5_2, L6_2, L7_2, L8_2)
          L4_2 = updateFrontend
          L5_2 = A0_2
          L4_2(L5_2)
          L4_2 = updateFrontend
          L5_2 = L3_2
          L4_2(L5_2)
          L4_2 = "+"
          L5_2 = A1_2.amount
          L6_2 = L0_1.currency
          L7_2 = " ("
          L8_2 = Sky
          L8_2 = L8_2.FW
          L8_2 = L8_2.GetName
          L9_2 = A0_2
          L8_2 = L8_2(L9_2)
          L9_2 = ")"
          L4_2 = L4_2 .. L5_2 .. L6_2 .. L7_2 .. L8_2 .. L9_2
          L5_2 = TriggerClientEvent
          L6_2 = "sky_base:notification"
          L7_2 = L3_2
          L8_2 = L0_1.transfer
          L9_2 = L4_2
          L10_2 = "success"
          L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
          L5_2 = Sky
          L5_2 = L5_2.FW
          L5_2 = L5_2.GetName
          L6_2 = L3_2
          return L5_2(L6_2)
        end
      else
        L4_2 = 6
        return L4_2
      end
  end
  else
    L3_2 = 5
    return L3_2
  end
end
L1_1(L2_1, L3_1)
function L1_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L1_2 = Sky
  L1_2 = L1_2.FW
  L1_2 = L1_2.GetAccountMoney
  L2_2 = A0_2
  L3_2 = "money"
  L1_2 = L1_2(L2_2, L3_2)
  L2_2 = Sky
  L2_2 = L2_2.FW
  L2_2 = L2_2.GetAccountMoney
  L3_2 = A0_2
  L4_2 = "bank"
  L2_2 = L2_2(L3_2, L4_2)
  L3_2 = nil
  L4_2 = nil
  L5_2 = Sky
  L5_2 = L5_2.FW
  L5_2 = L5_2.GetIdentifier
  L6_2 = A0_2
  L5_2 = L5_2(L6_2)
  L6_2 = Sky
  L6_2 = L6_2.Query
  L7_2 = "SELECT last_transactions, last_transfers, totals FROM banking_users WHERE identifier = ?"
  L8_2 = {}
  L9_2 = L5_2
  L8_2[1] = L9_2
  L6_2 = L6_2(L7_2, L8_2)
  L7_2 = L6_2[1]
  if nil ~= L7_2 then
    L7_2 = json
    L7_2 = L7_2.decode
    L8_2 = L6_2[1]
    L8_2 = L8_2.last_transactions
    L7_2 = L7_2(L8_2)
    L3_2 = L7_2
    L7_2 = json
    L7_2 = L7_2.decode
    L8_2 = L6_2[1]
    L8_2 = L8_2.last_transfers
    L7_2 = L7_2(L8_2)
    L4_2 = L7_2
    L7_2 = json
    L7_2 = L7_2.decode
    L8_2 = L6_2[1]
    L8_2 = L8_2.totals
    L7_2 = L7_2(L8_2)
    totals = L7_2
  end
  L7_2 = TriggerClientEvent
  L8_2 = "sky_banking:update"
  L9_2 = A0_2
  L10_2 = L1_2
  L11_2 = L2_2
  L12_2 = L3_2
  L13_2 = L4_2
  L14_2 = totals
  L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
end
updateFrontend = L1_1
function L1_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L4_2 = Sky
  L4_2 = L4_2.FW
  L4_2 = L4_2.GetIdentifier
  L5_2 = A0_2
  L4_2 = L4_2(L5_2)
  L5_2 = Sky
  L5_2 = L5_2.Query
  L6_2 = "SELECT last_transfers, totals FROM banking_users WHERE identifier = ?"
  L7_2 = {}
  L8_2 = L4_2
  L7_2[1] = L8_2
  L5_2 = L5_2(L6_2, L7_2)
  L6_2 = L5_2[1]
  if L6_2 then
    L6_2 = L5_2[1]
    L6_2 = L6_2.last_transfers
    if L6_2 then
      L6_2 = json
      L6_2 = L6_2.decode
      L7_2 = L5_2[1]
      L7_2 = L7_2.last_transfers
      L6_2 = L6_2(L7_2)
      L7_2 = json
      L7_2 = L7_2.decode
      L8_2 = L5_2[1]
      L8_2 = L8_2.totals
      L7_2 = L7_2(L8_2)
      L8_2 = #L6_2
      if L8_2 >= 3 then
        L8_2 = table
        L8_2 = L8_2.remove
        L9_2 = L6_2
        L10_2 = #L6_2
        L8_2(L9_2, L10_2)
      end
      L8_2 = os
      L8_2 = L8_2.time
      L8_2 = L8_2()
      L9_2 = table
      L9_2 = L9_2.insert
      L10_2 = L6_2
      L11_2 = 1
      L12_2 = {}
      L12_2.name = A2_2
      L12_2.send = A1_2
      L12_2.amount = A3_2
      L12_2.timestamp = L8_2
      L9_2(L10_2, L11_2, L12_2)
      L9_2 = Sky
      L9_2 = L9_2.Query
      L10_2 = "UPDATE banking_users SET last_transfers = ?, totals = ? WHERE identifier = ?"
      L11_2 = {}
      L12_2 = json
      L12_2 = L12_2.encode
      L13_2 = L6_2
      L12_2 = L12_2(L13_2)
      L13_2 = json
      L13_2 = L13_2.encode
      L14_2 = L7_2
      L13_2 = L13_2(L14_2)
      L14_2 = L4_2
      L11_2[1] = L12_2
      L11_2[2] = L13_2
      L11_2[3] = L14_2
      L9_2(L10_2, L11_2)
    end
  end
end
logTransfer = L1_1
function L1_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L5_2 = Sky
  L5_2 = L5_2.FW
  L5_2 = L5_2.GetIdentifier
  L6_2 = A0_2
  L5_2 = L5_2(L6_2)
  L6_2 = Sky
  L6_2 = L6_2.Query
  L7_2 = "SELECT last_transactions, totals FROM banking_users WHERE identifier = ?"
  L8_2 = {}
  L9_2 = L5_2
  L8_2[1] = L9_2
  L6_2 = L6_2(L7_2, L8_2)
  L7_2 = L6_2[1]
  if L7_2 then
    L7_2 = L6_2[1]
    L7_2 = L7_2.last_transactions
    if L7_2 then
      L7_2 = json
      L7_2 = L7_2.decode
      L8_2 = L6_2[1]
      L8_2 = L8_2.last_transactions
      L7_2 = L7_2(L8_2)
      L8_2 = json
      L8_2 = L8_2.decode
      L9_2 = L6_2[1]
      L9_2 = L9_2.totals
      L8_2 = L8_2(L9_2)
      L9_2 = #L7_2
      if L9_2 >= 3 then
        L9_2 = table
        L9_2 = L9_2.remove
        L10_2 = L7_2
        L11_2 = #L7_2
        L9_2(L10_2, L11_2)
      end
      L9_2 = os
      L9_2 = L9_2.time
      L9_2 = L9_2()
      L10_2 = {}
      L10_2.type = A1_2
      L10_2.text = A2_2
      L10_2.negative = A3_2
      L10_2.amount = A4_2
      L10_2.timestamp = L9_2
      if "transfer" == A1_2 then
        if A3_2 then
          L11_2 = L8_2.transfer
          L11_2 = L11_2 + A4_2
          L8_2.transfer = L11_2
        end
      elseif "deposit" == A1_2 or "transfer" == A1_2 or "withdraw" == A1_2 then
        L11_2 = L8_2[A1_2]
        L11_2 = L11_2 + A4_2
        L8_2[A1_2] = L11_2
      end
      L11_2 = table
      L11_2 = L11_2.insert
      L12_2 = L7_2
      L13_2 = 1
      L14_2 = L10_2
      L11_2(L12_2, L13_2, L14_2)
      L11_2 = Sky
      L11_2 = L11_2.Query
      L12_2 = "UPDATE banking_users SET last_transactions = ?, totals = ? WHERE identifier = ?"
      L13_2 = {}
      L14_2 = json
      L14_2 = L14_2.encode
      L15_2 = L7_2
      L14_2 = L14_2(L15_2)
      L15_2 = json
      L15_2 = L15_2.encode
      L16_2 = L8_2
      L15_2 = L15_2(L16_2)
      L16_2 = L5_2
      L13_2[1] = L14_2
      L13_2[2] = L15_2
      L13_2[3] = L16_2
      L11_2(L12_2, L13_2)
      L11_2 = Sky
      L11_2 = L11_2.Discord
      L11_2 = L11_2.Log
      L12_2 = "sky_banking"
      L13_2 = Sky
      L13_2 = L13_2.FW
      L13_2 = L13_2.GetName
      L14_2 = A0_2
      L13_2 = L13_2(L14_2)
      L14_2 = json
      L14_2 = L14_2.encode
      L15_2 = L10_2
      L14_2, L15_2, L16_2 = L14_2(L15_2)
      L11_2(L12_2, L13_2, L14_2, L15_2, L16_2)
    end
  end
end
logTransaction = L1_1
L1_1 = exports
L2_1 = "logTransaction"
L3_1 = logTransaction
L1_1(L2_1, L3_1)
L1_1 = RegisterServerEvent
L2_1 = "sky_banking:transaction"
function L3_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L4_2 = logTransaction
  L5_2 = source
  L6_2 = A0_2
  L7_2 = A1_2
  L8_2 = A2_2
  L9_2 = A3_2
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
end
L1_1(L2_1, L3_1)
L1_1 = GetResourceState
L2_1 = "sky_coinsystem"
L1_1 = L1_1(L2_1)
if "started" ~= L1_1 then
  L1_1 = GetResourceState
  L2_1 = "ak4y-vipSystemv2"
  L1_1 = L1_1(L2_1)
  if "started" ~= L1_1 then
    L1_1 = GetResourceState
    L2_1 = "ak4y-vipSystem"
    L1_1 = L1_1(L2_1)
    if "started" ~= L1_1 then
      goto lbl_96
    end
  end
  L1_1 = print
  L2_1 = "^1[Exclusive Deal] ^3Attention FiveM Server Owner!"
  L1_1(L2_1)
  L1_1 = print
  L2_1 = "^3We noticed you're using a competitor's product. Why settle for less?"
  L1_1(L2_1)
  L1_1 = print
  L2_1 = "^5Coinsystem V2 ^3offers superior features, easy configuration, great performance, industry-leading security, and unmatched reliability!"
  L1_1(L2_1)
  L1_1 = print
  L2_1 = "^2[Limited Time Offer] ^370% OFF Coinsystem V2 for a short time!"
  L1_1(L2_1)
  L1_1 = print
  L2_1 = "^3Upgrade now and experience the difference \226\128\147 claim your exclusive deal by creating a ticket in our Discord!"
  L1_1(L2_1)
  L1_1 = print
  L2_1 = "^4Discord: ^2https://discord.gg/sky-systems"
  L1_1(L2_1)
  L1_1 = print
  L2_1 = "^1Don\226\128\153t miss this opportunity to switch to the best system available!"
  L1_1(L2_1)
end
::lbl_96::
