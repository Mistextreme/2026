local L0_1, L1_1, L2_1, L3_1, L4_1
LaststandTime = 0
isEscorted = false
L0_1 = false
function L1_1(A0_2)
  local L1_2, L2_2
  while true do
    L1_2 = HasAnimDictLoaded
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = RequestAnimDict
    L2_2 = A0_2
    L1_2(L2_2)
    L1_2 = Wait
    L2_2 = 100
    L1_2(L2_2)
  end
end
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = Config
  L2_2 = L2_2.Framework
  if "qb" == L2_2 then
    L2_2 = TriggerServerEvent
    L3_2 = "hospital:server:SetLaststandStatus"
    L4_2 = A0_2
    L2_2(L3_2, L4_2)
  end
  if A0_2 then
    L2_2 = DebugPrint
    L3_2 = "inlaststand"
    L2_2(L3_2)
    L2_2 = isPedMovingCheck
    L3_2 = L1_2
    L2_2(L3_2)
    L2_2 = GetEntityCoords
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    L3_2 = GetEntityHeading
    L4_2 = L1_2
    L3_2 = L3_2(L4_2)
    L4_2 = TriggerServerEvent
    L5_2 = "InteractSound_SV:PlayOnSource"
    L6_2 = "demo"
    L7_2 = 0.1
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = BodyDamage
    L4_2 = L4_2.isDead
    if not L4_2 then
      L4_2 = DebugPrint
      L5_2 = "Setting death screen"
      L4_2(L5_2)
      L4_2 = Config
      L4_2 = L4_2.CustomDeathScreen
      if false == L4_2 then
        L4_2 = SendNUIMessage
        L5_2 = {}
        L5_2.death = 1
        L6_2 = Config
        L6_2 = L6_2.LastStandTime
        L5_2.laststandtime = L6_2
        L6_2 = Config
        L6_2 = L6_2.RespawnTime
        L5_2.respawntime = L6_2
        L5_2.emsnotif = 1
        L4_2(L5_2)
      else
        L4_2 = SendNUIMessage
        L5_2 = {}
        L5_2.emsnotif = 1
        L4_2(L5_2)
      end
    end
    L4_2 = IsPedInAnyVehicle
    L5_2 = L1_2
    L4_2 = L4_2(L5_2)
    if L4_2 then
      L4_2 = DebugPrint
      L5_2 = "in veh"
      L4_2(L5_2)
      L4_2 = GetVehiclePedIsIn
      L5_2 = L1_2
      L4_2 = L4_2(L5_2)
      L5_2 = GetVehicleModelNumberOfSeats
      L6_2 = GetHashKey
      L7_2 = GetEntityModel
      L8_2 = L4_2
      L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L7_2(L8_2)
      L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
      L5_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
      L6_2 = -1
      L7_2 = L5_2
      L8_2 = 1
      for L9_2 = L6_2, L7_2, L8_2 do
        L10_2 = GetPedInVehicleSeat
        L11_2 = L4_2
        L12_2 = L9_2
        L10_2 = L10_2(L11_2, L12_2)
        if L10_2 == L1_2 then
          L11_2 = NetworkResurrectLocalPlayer
          L12_2 = L2_2.x
          L13_2 = L2_2.y
          L14_2 = L2_2.z
          L14_2 = L14_2 + 0.5
          L15_2 = L3_2
          L16_2 = true
          L17_2 = false
          L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
          L11_2 = SetPedIntoVehicle
          L12_2 = L1_2
          L13_2 = L4_2
          L14_2 = L9_2
          L11_2(L12_2, L13_2, L14_2)
        end
      end
    else
      L4_2 = DebugPrint
      L5_2 = "not in veh"
      L4_2(L5_2)
      L4_2 = isInHospitalBed
      if L4_2 then
        L4_2 = NetworkResurrectLocalPlayer
        L5_2 = L2_2.x
        L6_2 = L2_2.y
        L7_2 = L2_2.z
        L8_2 = L3_2 + 90
        L9_2 = true
        L10_2 = false
        L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
      else
        L4_2 = Config
        L4_2 = L4_2.Crawl
        if L4_2 then
          L4_2 = NetworkResurrectLocalPlayer
          L5_2 = L2_2.x
          L6_2 = L2_2.y
          L7_2 = L2_2.z
          L7_2 = L7_2 + 1.0
          L8_2 = L3_2
          L9_2 = true
          L10_2 = false
          L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
        else
          L4_2 = NetworkResurrectLocalPlayer
          L5_2 = L2_2.x
          L6_2 = L2_2.y
          L7_2 = L2_2.z
          L7_2 = L7_2 + 0.5
          L8_2 = L3_2
          L9_2 = true
          L10_2 = false
          L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
        end
      end
    end
    L4_2 = IsPedInAnyVehicle
    L5_2 = L1_2
    L6_2 = false
    L4_2 = L4_2(L5_2, L6_2)
    if L4_2 then
      L4_2 = L1_1
      L5_2 = "veh@low@front_ps@idle_duck"
      L4_2(L5_2)
      L4_2 = TaskPlayAnim
      L5_2 = L1_2
      L6_2 = "veh@low@front_ps@idle_duck"
      L7_2 = "sit"
      L8_2 = 1.0
      L9_2 = 8.0
      L10_2 = -1
      L11_2 = 1
      L12_2 = -1
      L13_2 = false
      L14_2 = false
      L15_2 = false
      L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
    else
      L4_2 = DebugPrint
      L5_2 = "playing anim"
      L4_2(L5_2)
      L4_2 = L1_1
      L5_2 = lastStandDict
      L4_2(L5_2)
      L4_2 = TaskPlayAnim
      L5_2 = L1_2
      L6_2 = lastStandDict
      L7_2 = lastStandAnim
      L8_2 = 1.0
      L9_2 = 8.0
      L10_2 = -1
      L11_2 = 1
      L12_2 = -1
      L13_2 = false
      L14_2 = false
      L15_2 = false
      L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
    end
    L4_2 = instretcher
    if L4_2 then
      L4_2 = ClearPedTasks
      L5_2 = L1_2
      L4_2(L5_2)
      L4_2 = ClearPedTasksImmediately
      L5_2 = L1_2
      L4_2(L5_2)
      L4_2 = GetEntityModel
      L5_2 = stretcherEntity
      L4_2 = L4_2(L5_2)
      L5_2 = GetHashKey
      L6_2 = Config
      L6_2 = L6_2.StretcherModel
      L6_2 = L6_2.regular
      L5_2 = L5_2(L6_2)
      if L4_2 == L5_2 then
        L4_2 = AttachEntityToEntity
        L5_2 = L1_2
        L6_2 = stretcherEntity
        L7_2 = nil
        L8_2 = 0.0
        L9_2 = 0.0
        L10_2 = 2.1
        L11_2 = 0.0
        L12_2 = 0.0
        L13_2 = 100.0
        L14_2 = true
        L15_2 = true
        L16_2 = false
        L17_2 = true
        L18_2 = 1
        L19_2 = true
        L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
        L4_2 = lib
        L4_2 = L4_2.requestAnimDict
        L5_2 = "timetable@jimmy@mics3_ig_15@"
        L6_2 = 100
        L4_2(L5_2, L6_2)
        L4_2 = TaskPlayAnim
        L5_2 = L1_2
        L6_2 = "timetable@jimmy@mics3_ig_15@"
        L7_2 = "mics3_15_base_jimmy"
        L8_2 = 8.0
        L9_2 = 8.0
        L10_2 = -1
        L11_2 = 69
        L12_2 = 1
        L13_2 = false
        L14_2 = false
        L15_2 = false
        L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
      else
        L4_2 = GetEntityModel
        L5_2 = entity
        L4_2 = L4_2(L5_2)
        L5_2 = GetHashKey
        L6_2 = Config
        L6_2 = L6_2.StretcherModel
        L6_2 = L6_2.folded
        L5_2 = L5_2(L6_2)
        if L4_2 == L5_2 then
          L4_2 = AttachEntityToEntity
          L5_2 = L1_2
          L6_2 = stretcherEntity
          L7_2 = nil
          L8_2 = 0.15
          L9_2 = 0.0
          L10_2 = 2.1
          L11_2 = 0.0
          L12_2 = 0.0
          L13_2 = 90.0
          L14_2 = true
          L15_2 = true
          L16_2 = false
          L17_2 = true
          L18_2 = 1
          L19_2 = true
          L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
          L4_2 = lib
          L4_2 = L4_2.requestAnimDict
          L5_2 = "anim@gangops@morgue@table@"
          L6_2 = 100
          L4_2(L5_2, L6_2)
          L4_2 = TaskPlayAnim
          L5_2 = L1_2
          L6_2 = "anim@gangops@morgue@table@"
          L7_2 = "body_search"
          L8_2 = 8.0
          L9_2 = 8.0
          L10_2 = -1
          L11_2 = 69
          L12_2 = 1
          L13_2 = false
          L14_2 = false
          L15_2 = false
          L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
        else
          L4_2 = GetEntityModel
          L5_2 = stretcherEntity
          L4_2 = L4_2(L5_2)
          L5_2 = GetHashKey
          L6_2 = Config
          L6_2 = L6_2.StretcherModel
          L6_2 = L6_2.lowered
          L5_2 = L5_2(L6_2)
          if L4_2 == L5_2 then
            L4_2 = AttachEntityToEntity
            L5_2 = L1_2
            L6_2 = stretcherEntity
            L7_2 = nil
            L8_2 = 0.0
            L9_2 = 0.0
            L10_2 = 2.1
            L11_2 = 0.0
            L12_2 = 0.0
            L13_2 = 90.0
            L14_2 = true
            L15_2 = true
            L16_2 = false
            L17_2 = true
            L18_2 = 1
            L19_2 = true
            L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
            L4_2 = lib
            L4_2 = L4_2.requestAnimDict
            L5_2 = "anim@gangops@morgue@table@"
            L6_2 = 100
            L4_2(L5_2, L6_2)
            L4_2 = TaskPlayAnim
            L5_2 = L1_2
            L6_2 = "anim@gangops@morgue@table@"
            L7_2 = "body_search"
            L8_2 = 8.0
            L9_2 = 8.0
            L10_2 = -1
            L11_2 = 69
            L12_2 = 1
            L13_2 = false
            L14_2 = false
            L15_2 = false
            L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
          end
        end
      end
      L4_2 = insideAmbulance
      if L4_2 then
        L4_2 = DetachEntity
        L5_2 = L1_2
        L6_2 = true
        L7_2 = true
        L4_2(L5_2, L6_2, L7_2)
        L4_2 = DetachEntity
        L5_2 = stretcher
        L6_2 = true
        L7_2 = true
        L4_2(L5_2, L6_2, L7_2)
        L4_2 = DeleteEntity
        L5_2 = stretcher
        L4_2(L5_2)
        L4_2 = Config
        L4_2 = L4_2.StretcherModel
        L4_2 = L4_2.lowered
        L5_2 = lib
        L5_2 = L5_2.requestModel
        L6_2 = L4_2
        L7_2 = 10000
        L5_2(L6_2, L7_2)
        L5_2 = lib
        L5_2 = L5_2.requestAnimDict
        L6_2 = "anim@gangops@morgue@table@"
        L7_2 = 1000
        L5_2(L6_2, L7_2)
        L5_2 = lib
        L5_2 = L5_2.requestModel
        L6_2 = "xm_prop_body_bag"
        L7_2 = 10000
        L5_2(L6_2, L7_2)
        L5_2 = CreateObjectNoOffset
        L6_2 = L4_2
        L7_2 = vector3
        L8_2 = 294.018
        L9_2 = -613.7497
        L10_2 = 42.4297
        L7_2 = L7_2(L8_2, L9_2, L10_2)
        L8_2 = 1
        L9_2 = 1
        L10_2 = 0
        L5_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
        stretcher = L5_2
        L5_2 = Entity
        L6_2 = stretcher
        L5_2 = L5_2(L6_2)
        L5_2 = L5_2.state
        L6_2 = L5_2
        L5_2 = L5_2.set
        L7_2 = "HasPlayer"
        L8_2 = GetPlayerServerId
        L9_2 = NetworkGetPlayerIndexFromPed
        L10_2 = PlayerPedId
        L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L10_2()
        L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
        L8_2 = L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
        L9_2 = true
        L5_2(L6_2, L7_2, L8_2, L9_2)
        L5_2 = GetEntityModel
        L6_2 = stretcherEntity
        L5_2 = L5_2(L6_2)
        L6_2 = GetHashKey
        L7_2 = Config
        L7_2 = L7_2.StretcherModel
        L7_2 = L7_2.folded
        L6_2 = L6_2(L7_2)
        if L5_2 == L6_2 then
          L5_2 = Entity
          L6_2 = stretcher
          L5_2 = L5_2(L6_2)
          L5_2 = L5_2.state
          L6_2 = L5_2
          L5_2 = L5_2.set
          L7_2 = "ifFolded"
          L8_2 = true
          L9_2 = true
          L5_2(L6_2, L7_2, L8_2, L9_2)
        else
          L5_2 = Entity
          L6_2 = stretcher
          L5_2 = L5_2(L6_2)
          L5_2 = L5_2.state
          L6_2 = L5_2
          L5_2 = L5_2.set
          L7_2 = "ifFolded"
          L8_2 = false
          L9_2 = true
          L5_2(L6_2, L7_2, L8_2, L9_2)
        end
        L5_2 = DetachEntity
        L6_2 = L1_2
        L7_2 = true
        L8_2 = true
        L5_2(L6_2, L7_2, L8_2)
        L5_2 = ClearPedTasks
        L6_2 = L1_2
        L5_2(L6_2)
        L5_2 = ClearPedTasksImmediately
        L6_2 = L1_2
        L5_2(L6_2)
        L5_2 = TaskPlayAnim
        L6_2 = L1_2
        L7_2 = "anim@gangops@morgue@table@"
        L8_2 = "body_search"
        L9_2 = 8.0
        L10_2 = 8.0
        L11_2 = -1
        L12_2 = 69
        L13_2 = 1
        L14_2 = false
        L15_2 = false
        L16_2 = false
        L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
        L5_2 = DebugPrint
        L6_2 = "Attaching stretcher to client"
        L7_2 = stretcher
        L5_2(L6_2, L7_2)
        L5_2 = pairs
        L6_2 = Config
        L6_2 = L6_2.Ambulances
        L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
        for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
          L11_2 = IsVehicleModel
          L12_2 = insideAmbulanceEntity
          L13_2 = GetHashKey
          L14_2 = L9_2
          L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L13_2(L14_2)
          L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
          if L11_2 then
            L11_2 = AttachEntityToEntity
            L12_2 = stretcher
            L13_2 = PlayerPedId
            L13_2 = L13_2()
            L14_2 = nil
            L15_2 = L10_2.stretcheroffset
            L16_2 = L10_2.stretcherrotation
            L17_2 = true
            L18_2 = true
            L19_2 = false
            L20_2 = true
            L21_2 = 1
            L22_2 = true
            L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
            L11_2 = DebugPrint
            L12_2 = "Attaching client to vehicle"
            L13_2 = insideAmbulanceEntity
            L11_2(L12_2, L13_2)
            L11_2 = AttachEntityToEntity
            L12_2 = PlayerPedId
            L12_2 = L12_2()
            L13_2 = insideAmbulanceEntity
            L14_2 = nil
            L15_2 = L10_2.playeroffset
            L16_2 = L10_2.playerrotation
            L17_2 = true
            L18_2 = true
            L19_2 = false
            L20_2 = true
            L21_2 = 1
            L22_2 = true
            L11_2(L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
          end
        end
        L5_2 = Wait
        L6_2 = 500
        L5_2(L6_2)
        L5_2 = TriggerServerEvent
        L6_2 = "osp_ambulance:SyncPulloutTargetSv"
        L7_2 = syncPullout
        L8_2 = NetworkGetNetworkIdFromEntity
        L9_2 = insideAmbulanceEntity
        L8_2 = L8_2(L9_2)
        L9_2 = NetworkGetNetworkIdFromEntity
        L10_2 = stretcher
        L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L9_2(L10_2)
        L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
      end
    end
    L4_2 = SetEntityHealth
    L5_2 = L1_2
    L6_2 = Config
    L6_2 = L6_2.inLastStandHealth
    L4_2(L5_2, L6_2)
    L4_2 = BodyDamage
    L4_2.inLastStand = true
    L4_2 = BodyDamage
    L4_2.Conscious = false
    L4_2 = BodyDamage
    L4_2 = L4_2.BodyPartDamage
    L4_2.BloodLevel = 5.4
    L4_2 = Config
    L4_2 = L4_2.AutomaticAmbulanceAlert
    if L4_2 then
      L4_2 = Config
      L4_2 = L4_2.Dispatch
      if "ps" == L4_2 then
        L4_2 = exports
        L4_2 = L4_2["ps-dispatch"]
        L5_2 = L4_2
        L4_2 = L4_2.InjuriedPerson
        L4_2(L5_2)
      else
        L4_2 = Config
        L4_2 = L4_2.Dispatch
        if "other" == L4_2 then
          L4_2 = dispatchNotify
          L4_2()
        else
          L4_2 = TriggerServerEvent
          L5_2 = "hospital:server:ambulanceAlert"
          L6_2 = lang
          L6_2 = L6_2.info
          L6_2 = L6_2.civ_down
          L4_2(L5_2, L6_2)
        end
      end
    end
    L4_2 = DebugPrint
    L5_2 = "set anim and values!"
    L4_2(L5_2)
    L4_2 = CreateThread
    function L5_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
      L0_3 = Config
      L0_3 = L0_3.LastStandTime
      LaststandTime = L0_3
      while true do
        L0_3 = BodyDamage
        L0_3 = L0_3.inLastStand
        if not L0_3 then
          break
        end
        L0_3 = PlayerPedId
        L0_3 = L0_3()
        L1_2 = L0_3
        L0_3 = PlayerId
        L0_3 = L0_3()
        L1_3 = LaststandTime
        if L1_3 <= 0 then
          L1_3 = SetLaststand
          L2_3 = false
          L1_3(L2_3)
          L1_3 = Config
          L1_3 = L1_3.RespawnTime
          deathTime = L1_3
          L1_3 = TriggerEvent
          L2_3 = "osp_ambulance:OnPlayerDeath"
          L1_3(L2_3)
          L1_3 = DeathTimer
          L1_3()
        end
        L1_3 = LaststandTime
        L1_3 = L1_3 - 1
        LaststandTime = L1_3
        L1_3 = Wait
        L2_3 = 1000
        L1_3(L2_3)
        L1_3 = BodyDamage
        L1_3 = L1_3.Pulse
        if L1_3 > 20 then
          L1_3 = BodyDamage
          L1_3 = L1_3.cardiacState
          if "NSR" == L1_3 then
            L1_3 = true
            L2_3 = pairs
            L3_3 = BodyDamage
            L3_3 = L3_3.BodyPartDamage
            L3_3 = L3_3.DamageType
            L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
            for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
              if L7_3 > 0 then
                L1_3 = false
              end
            end
            L2_3 = pairs
            L3_3 = BodyDamage
            L3_3 = L3_3.BodyPartDamage
            L3_3 = L3_3.Bleeding
            L2_3, L3_3, L4_3, L5_3 = L2_3(L3_3)
            for L6_3, L7_3 in L2_3, L3_3, L4_3, L5_3 do
              if L7_3 > 0 then
                L1_3 = false
              end
            end
            if L1_3 then
              L2_3 = BodyDamage
              L2_3 = L2_3.BodyPartDamage
              L2_3 = L2_3.BloodLevel
              if L2_3 > 5.0 then
                L2_3 = BodyDamage
                L2_3 = L2_3.hrIncrease
                if not (L2_3 > 0) then
                  L2_3 = BodyDamage
                  L2_3 = L2_3.hrDecrease
                  if not (L2_3 > 0) then
                    goto lbl_85
                  end
                end
                L2_3 = TriggerEvent
                L3_3 = "osp_ambulance:partialRevive"
                L2_3(L3_3)
              end
            end
          end
        end
        ::lbl_85::
      end
    end
    L4_2(L5_2)
  else
    L2_2 = instretcher
    if not L2_2 then
      L2_2 = TaskPlayAnim
      L3_2 = L1_2
      L4_2 = lastStandDict
      L5_2 = "exit"
      L6_2 = 1.0
      L7_2 = 8.0
      L8_2 = -1
      L9_2 = 1
      L10_2 = -1
      L11_2 = false
      L12_2 = false
      L13_2 = false
      L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
    end
    L2_2 = BodyDamage
    L2_2.inLastStand = false
    LaststandTime = 0
  end
  L2_2 = LocalPlayer
  L2_2 = L2_2.state
  L3_2 = L2_2
  L2_2 = L2_2.set
  L4_2 = "BodyDamage"
  L5_2 = BodyDamage
  L6_2 = true
  L2_2(L3_2, L4_2, L5_2, L6_2)
end
SetLaststand = L2_1
L2_1 = RegisterNetEvent
L3_1 = "hospital:client:SetEscortingState"
function L4_1(A0_2)
  local L1_2
  L0_1 = A0_2
end
L2_1(L3_1, L4_1)
L2_1 = RegisterNetEvent
L3_1 = "hospital:client:isEscorted"
function L4_1(A0_2)
  local L1_2
  isEscorted = A0_2
end
L2_1(L3_1, L4_1)
