local L0_1, L1_1, L2_1, L3_1
L0_1 = CreateThread
function L1_1()
  local L0_2, L1_2
  while true do
    L0_2 = Wait
    L1_2 = 1000
    L0_2(L1_2)
    L0_2 = CauseFractureStaggering
    L0_2()
  end
end
L0_1(L1_1)
L0_1 = CreateThread
function L1_1()
  local L0_2, L1_2
  while true do
    L0_2 = Wait
    L1_2 = 15000
    L0_2(L1_2)
    L0_2 = LockSteering
    L0_2()
  end
end
L0_1(L1_1)
L0_1 = {}
xrayDuiObj = L0_1
L0_1 = {}
xraySfHandle = L0_1
L0_1 = {}
xraySfName = L0_1
L0_1 = "nui://osp_ambulance/html/xray.html"
L1_1 = {}
xrayScreenId = L1_1
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:xray"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L1_2 = xrayScreenId
  if L1_2 then
    L1_2 = xrayScreenId
    L1_2 = #L1_2
    if L1_2 <= 1 then
      L1_2 = pairs
      L2_2 = xrayScreenId
      L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
      for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
        if L6_2 then
          L7_2 = TriggerServerEvent
          L8_2 = "osp_ambulance:triggerXrayScreenSyncDestroySv"
          L9_2 = L6_2
          L7_2(L8_2, L9_2)
        end
      end
    end
  end
  L1_2 = A0_2.xray
  L2_2 = GetPlayerServerId
  L3_2 = lib
  L3_2 = L3_2.getClosestPlayer
  L4_2 = vec3
  L5_2 = L1_2.coords
  L4_2 = L4_2(L5_2)
  L5_2 = 2.0
  L6_2 = true
  L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L3_2(L4_2, L5_2, L6_2)
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
  L3_2 = Player
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L3_2 = L3_2.state
  L3_2 = L3_2.BodyDamage
  if nil == L3_2 then
    L4_2 = SendTextMessage
    L5_2 = lang
    L5_2 = L5_2.interactions
    L5_2 = L5_2.medicalHeader
    L6_2 = lang
    L6_2 = L6_2.error
    L6_2 = L6_2.no_player_in_xray
    L7_2 = 5000
    L8_2 = "error"
    L4_2(L5_2, L6_2, L7_2, L8_2)
    return
  end
  L4_2 = SendNUIMessage
  L5_2 = {}
  L5_2.xraySound = true
  L4_2(L5_2)
  L4_2 = nil
  function L5_2()
    local L0_3, L1_3, L2_3
    L0_3 = 1
    L1_3 = 40
    while true do
      L2_3 = xraySfHandle
      L2_3 = L2_3[L0_3]
      if not L2_3 or 0 == L1_3 then
        break
      end
      L0_3 = L0_3 + 1
      L1_3 = L1_3 - 1
    end
    if 0 == L1_3 then
      L0_3 = false
    end
    return L0_3
  end
  L6_2 = L5_2
  L6_2 = L6_2()
  if L6_2 then
    L4_2 = L6_2
    L7_2 = TriggerServerEvent
    L8_2 = "osp_ambulance:triggerXrayScreenSyncSv"
    L9_2 = L1_2.xrayMonitor
    L10_2 = L4_2
    L11_2 = L1_2.xrayMonitorRot
    L12_2 = L1_2.screenScale
    L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
  else
    L7_2 = print
    L8_2 = "^1NO AVAILABLE SCREENS^0"
    L7_2(L8_2)
    return
  end
  L7_2 = Wait
  L8_2 = 500
  L7_2(L8_2)
  L7_2 = xrayScreenId
  L7_2[L4_2] = L4_2
  L7_2 = false
  L8_2 = false
  L9_2 = pairs
  L10_2 = L3_2.BodyPartDamage
  L10_2 = L10_2.Fractures
  L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
  for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
    if "splint" == L14_2 then
      L15_2 = SendDuiMessage
      L16_2 = xrayDuiObj
      L16_2 = L16_2[L4_2]
      L17_2 = json
      L17_2 = L17_2.encode
      L18_2 = {}
      L18_2.data = "splint"
      L17_2, L18_2 = L17_2(L18_2)
      L15_2(L16_2, L17_2, L18_2)
      L8_2 = true
      break
    end
    if true == L14_2 then
      L15_2 = SendDuiMessage
      L16_2 = xrayDuiObj
      L16_2 = L16_2[L4_2]
      L17_2 = json
      L17_2 = L17_2.encode
      L18_2 = {}
      L18_2.data = L13_2
      L17_2, L18_2 = L17_2(L18_2)
      L15_2(L16_2, L17_2, L18_2)
      L7_2 = true
      L15_2 = L3_2.BodyPartDamage
      L15_2 = L15_2.Fractures
      L15_2[L13_2] = "xrayed"
      break
    end
  end
  if not L8_2 then
    if false == L7_2 then
      L9_2 = SendDuiMessage
      L10_2 = xrayDuiObj
      L10_2 = L10_2[L4_2]
      L11_2 = json
      L11_2 = L11_2.encode
      L12_2 = {}
      L12_2.data = "none"
      L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L11_2(L12_2)
      L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
    end
    L9_2 = TriggerServerEvent
    L10_2 = "osp_ambulance:SaveDataSv"
    L11_2 = L2_2
    L12_2 = L3_2
    L9_2(L10_2, L11_2, L12_2)
  end
  L9_2 = Wait
  L10_2 = Config
  L10_2 = L10_2.XrayScreenTimeout
  L9_2(L10_2)
  L9_2 = xrayScreenId
  L9_2 = L9_2[L4_2]
  if not L9_2 then
    return
  end
  L9_2 = TriggerServerEvent
  L10_2 = "osp_ambulance:triggerXrayScreenSyncDestroySv"
  L11_2 = L4_2
  L9_2(L10_2, L11_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:sendXrayCl"
function L3_1(A0_2)
  local L1_2, L2_2
  L1_2 = SendNUIMessage
  L2_2 = {}
  L2_2.xraySound = true
  L1_2(L2_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:triggerXrayScreenSyncDestroyCl"
function L3_1(A0_2)
  local L1_2, L2_2
  L1_2 = DestroyDui
  L2_2 = xrayDuiObj
  L2_2 = L2_2[A0_2]
  L1_2(L2_2)
  L1_2 = SetScaleformMovieAsNoLongerNeeded
  L2_2 = xraySfHandle
  L2_2 = L2_2[A0_2]
  L1_2(L2_2)
  L1_2 = xrayDuiObj
  L1_2[A0_2] = nil
  L1_2 = xraySfHandle
  L1_2[A0_2] = nil
  L1_2 = xrayScreenId
  L1_2[A0_2] = nil
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:triggerXrayScreenSyncCl"
function L3_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2
  L4_2 = XrayShowScreen
  L5_2 = A0_2
  L6_2 = A1_2
  L7_2 = A2_2
  L8_2 = A3_2
  L4_2(L5_2, L6_2, L7_2, L8_2)
end
L1_1(L2_1, L3_1)
function L1_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L4_2 = xraySfHandle
  L5_2 = "sfHandle_"
  L6_2 = A1_2
  L5_2 = L5_2 .. L6_2
  L4_2[A1_2] = L5_2
  L4_2 = xrayDuiObj
  L5_2 = "duiObj_"
  L6_2 = A1_2
  L5_2 = L5_2 .. L6_2
  L4_2[A1_2] = L5_2
  L4_2 = xraySfName
  L5_2 = "generic_texture_renderer_xray"
  L6_2 = A1_2
  L5_2 = L5_2 .. L6_2
  L4_2[A1_2] = L5_2
  L4_2 = xraySfHandle
  L5_2 = loadScaleform
  L6_2 = xraySfName
  L6_2 = L6_2[A1_2]
  L5_2 = L5_2(L6_2)
  L4_2[A1_2] = L5_2
  runtimeTxd = "osp_b_dict"
  L4_2 = CreateRuntimeTxd
  L5_2 = "osp_b_dict"
  L4_2 = L4_2(L5_2)
  L5_2 = xrayDuiObj
  L6_2 = CreateDui
  L7_2 = L0_1
  L8_2 = width
  L9_2 = height
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  L5_2[A1_2] = L6_2
  L5_2 = GetDuiHandle
  L6_2 = xrayDuiObj
  L6_2 = L6_2[A1_2]
  L5_2 = L5_2(L6_2)
  L6_2 = CreateRuntimeTextureFromDuiHandle
  L7_2 = L4_2
  L8_2 = "osp_b_txd"
  L9_2 = L5_2
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  L7_2 = Wait
  L8_2 = 10
  L7_2(L8_2)
  L7_2 = PushScaleformMovieFunction
  L8_2 = xraySfHandle
  L8_2 = L8_2[A1_2]
  L9_2 = "SET_TEXTURE"
  L7_2(L8_2, L9_2)
  L7_2 = PushScaleformMovieMethodParameterString
  L8_2 = "osp_b_dict"
  L7_2(L8_2)
  L7_2 = PushScaleformMovieMethodParameterString
  L8_2 = "osp_b_txd"
  L7_2(L8_2)
  L7_2 = PushScaleformMovieFunctionParameterInt
  L8_2 = 0
  L7_2(L8_2)
  L7_2 = PushScaleformMovieFunctionParameterInt
  L8_2 = 0
  L7_2(L8_2)
  L7_2 = PushScaleformMovieFunctionParameterInt
  L8_2 = width
  L7_2(L8_2)
  L7_2 = PushScaleformMovieFunctionParameterInt
  L8_2 = height
  L7_2(L8_2)
  L7_2 = PopScaleformMovieFunctionVoid
  L7_2()
  L7_2 = GetFrameTime
  L7_2 = L7_2()
  L8_2 = 0.02
  if L7_2 > L8_2 then
    wt = 5
  else
    L8_2 = 0.011
    if L7_2 > L8_2 then
      wt = 3
    else
      wt = 1
    end
  end
  L8_2 = CreateThread
  function L9_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    while true do
      L0_3 = xrayDuiObj
      L1_3 = A1_2
      L0_3 = L0_3[L1_3]
      if not L0_3 then
        break
      end
      L0_3 = xrayDuiObj
      L1_3 = A1_2
      L0_3 = L0_3[L1_3]
      if L0_3 then
        L0_3 = xraySfHandle
        L1_3 = A1_2
        L0_3 = L0_3[L1_3]
        if nil ~= L0_3 then
          L0_3 = HasScaleformMovieLoaded
          L1_3 = xraySfHandle
          L2_3 = A1_2
          L1_3 = L1_3[L2_3]
          L0_3 = L0_3(L1_3)
          if L0_3 then
            L0_3 = DrawScaleformMovie_3dSolid
            L1_3 = xraySfHandle
            L2_3 = A1_2
            L1_3 = L1_3[L2_3]
            L2_3 = A0_2.x
            L3_3 = A0_2.y
            L4_3 = A0_2.z
            L5_3 = A2_2.x
            L6_3 = A2_2.y
            L7_3 = A2_2.z
            L8_3 = 2.0
            L9_3 = 2.0
            L10_3 = 2.0
            L11_3 = A3_2
            L11_3 = L11_3 * 1
            L12_3 = A3_2
            L12_3 = L12_3 * 0.5625
            L13_3 = 2
            L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
          end
        end
      end
      L0_3 = Wait
      L1_3 = wt
      L0_3(L1_3)
    end
  end
  L8_2(L9_2)
  L8_2 = {}
  L9_2 = xraySfName
  L9_2 = L9_2[A1_2]
  L10_2 = count
  L8_2[1] = L9_2
  L8_2[2] = L10_2
  return L8_2
end
XrayShowScreen = L1_1
L1_1 = RegisterNUICallback
L2_1 = "ApplyCast"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2
  L1_2 = Player
  L2_2 = A0_2.PlayerId
  L1_2 = L1_2(L2_2)
  L2_2 = L1_2.state
  L2_2 = L2_2.BodyDamage
  L3_2 = A0_2.item
  L4_2 = A0_2.BodyPart
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  L6_2 = DebugPrint
  L7_2 = "Got PlayerId: "
  L8_2 = A0_2.PlayerId
  L6_2(L7_2, L8_2)
  L6_2 = A0_2.PlayerId
  if not L6_2 then
    L6_2 = print
    L7_2 = "^1UNABLE TO GET PLAYERID, REPORT THIS ISSUE!"
    L6_2(L7_2)
    return
  end
  L6_2 = nil
  L7_2 = pairs
  L8_2 = Config
  L8_2 = L8_2.Casts
  L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
  for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
    L13_2 = L12_2.type
    if "cast" == L13_2 then
      L13_2 = pairs
      L14_2 = L12_2.casts
      L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
      for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
        L19_2 = L18_2.itemName
        if L19_2 == L3_2 then
          L6_2 = "cast"
          break
        end
      end
    else
      L13_2 = L12_2.type
      if "splint" == L13_2 then
        L13_2 = pairs
        L14_2 = L12_2.casts
        L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
        for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
          L19_2 = L18_2.itemName
          if L19_2 == L3_2 then
            L6_2 = "splint"
            break
          end
        end
      end
    end
  end
  if nil == L6_2 then
    return
  end
  L7_2 = Config
  L7_2 = L7_2.ModularAccessLocks
  L7_2 = L7_2[L6_2]
  if L7_2 then
    L7_2 = IsAuthorized
    L7_2 = L7_2()
    if not L7_2 then
      L7_2 = SendTextMessage
      L8_2 = lang
      L8_2 = L8_2.interactions
      L8_2 = L8_2.medicalHeader
      L9_2 = lang
      L9_2 = L9_2.error
      L9_2 = L9_2.not_authorized
      L10_2 = 5000
      L11_2 = "error"
      L7_2(L8_2, L9_2, L10_2, L11_2)
      return
    end
  end
  L7_2 = SetNuiFocus
  L8_2 = false
  L9_2 = false
  L7_2(L8_2, L9_2)
  L7_2 = SendNUIMessage
  L8_2 = {}
  L8_2.display = false
  L7_2(L8_2)
  L7_2 = L2_2.BodyPartDamage
  L7_2 = L7_2.Fractures
  L7_2 = L7_2[L4_2]
  if "cast" == L7_2 then
    return
  end
  L7_2 = L2_2.BodyPartDamage
  L7_2 = L7_2.Fractures
  L7_2 = L7_2[L4_2]
  if "splint" ~= L7_2 then
    L7_2 = L2_2.BodyPartDamage
    L7_2 = L7_2.Fractures
    L7_2 = L7_2[L4_2]
    if "cast" ~= L7_2 then
      goto lbl_173
    end
  end
  L7_2 = pairs
  L8_2 = Config
  L8_2 = L8_2.Casts
  L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
  for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
    L13_2 = L12_2.type
    if "cast" == L13_2 then
      L13_2 = pairs
      L14_2 = L12_2.casts
      L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
      for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
        L19_2 = L18_2.itemName
        if L19_2 == L3_2 then
          L19_2 = ProgressBar
          L20_2 = L12_2.removeLang
          L21_2 = L12_2.time
          L22_2 = L12_2.anim
          L22_2 = L22_2.dict
          L23_2 = L12_2.anim
          L23_2 = L23_2.name
          L19_2(L20_2, L21_2, L22_2, L23_2)
          L19_2 = TriggerServerEvent
          L20_2 = "osp_ambulance:addItem"
          L21_2 = L3_2
          L22_2 = 1
          L19_2(L20_2, L21_2, L22_2)
          break
        end
      end
    else
      L13_2 = L12_2.type
      if "splint" == L13_2 then
        L13_2 = pairs
        L14_2 = L12_2.casts
        L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
        for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
          L19_2 = L18_2.itemName
          if L19_2 == L3_2 then
            L19_2 = ProgressBar
            L20_2 = L12_2.removeLang
            L21_2 = L12_2.time
            L22_2 = L12_2.anim
            L22_2 = L22_2.dict
            L23_2 = L12_2.anim
            L23_2 = L23_2.name
            L19_2(L20_2, L21_2, L22_2, L23_2)
            L19_2 = TriggerServerEvent
            L20_2 = "osp_ambulance:addItem"
            L21_2 = L3_2
            L22_2 = 1
            L19_2(L20_2, L21_2, L22_2)
            break
          end
        end
      end
    end
  end
  goto lbl_236
  ::lbl_173::
  L7_2 = pairs
  L8_2 = Config
  L8_2 = L8_2.Casts
  L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
  for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
    L13_2 = L12_2.type
    if "cast" == L13_2 then
      L13_2 = pairs
      L14_2 = L12_2.casts
      L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
      for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
        L19_2 = L18_2.itemName
        if L19_2 == L3_2 then
          L19_2 = ProgressBar
          L20_2 = L12_2.lang
          L21_2 = L12_2.time
          L22_2 = L12_2.anim
          L22_2 = L22_2.dict
          L23_2 = L12_2.anim
          L23_2 = L23_2.name
          L19_2(L20_2, L21_2, L22_2, L23_2)
          L19_2 = TriggerServerEvent
          L20_2 = "osp_ambulance:removeItem"
          L21_2 = L3_2
          L22_2 = 1
          L19_2(L20_2, L21_2, L22_2)
          break
        end
      end
    else
      L13_2 = L12_2.type
      if "splint" == L13_2 then
        L13_2 = pairs
        L14_2 = L12_2.casts
        L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
        for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
          L19_2 = L18_2.itemName
          if L19_2 == L3_2 then
            L19_2 = ProgressBar
            L20_2 = L12_2.lang
            L21_2 = L12_2.time
            L22_2 = L12_2.anim
            L22_2 = L22_2.dict
            L23_2 = L12_2.anim
            L23_2 = L23_2.name
            L19_2(L20_2, L21_2, L22_2, L23_2)
            L19_2 = TriggerServerEvent
            L20_2 = "osp_ambulance:removeItem"
            L21_2 = L3_2
            L22_2 = 1
            L19_2(L20_2, L21_2, L22_2)
            break
          end
        end
      end
    end
  end
  ::lbl_236::
  L7_2 = TriggerServerEvent
  L8_2 = "osp_ambulance:applyCastSv"
  L9_2 = A0_2.PlayerId
  L10_2 = A0_2
  L7_2(L8_2, L9_2, L10_2)
  L7_2 = Wait
  L8_2 = 500
  L7_2(L8_2)
  L7_2 = Player
  L8_2 = A0_2.PlayerId
  L7_2 = L7_2(L8_2)
  L8_2 = L7_2.state
  L8_2 = L8_2.BodyDamage
  L9_2 = GetMedicalInventoryItems
  L9_2()
  L9_2 = SetNuiFocus
  L10_2 = true
  L11_2 = true
  L9_2(L10_2, L11_2)
  L9_2 = SendNUIMessage
  L10_2 = {}
  L10_2.display = true
  L11_2 = json
  L11_2 = L11_2.encode
  L12_2 = L8_2
  L11_2 = L11_2(L12_2)
  L10_2.damageStatus = L11_2
  L11_2 = json
  L11_2 = L11_2.encode
  L12_2 = invItems
  L11_2 = L11_2(L12_2)
  L10_2.invItems = L11_2
  L9_2(L10_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:applyCastCl"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "osp_ambulance:applyCastCl"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L1_2 = A0_2.item
  L2_2 = A0_2.BodyPart
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = BodyDamage
  L4_2 = L4_2.BodyPartDamage
  L4_2 = L4_2.Fractures
  L4_2 = L4_2[L2_2]
  if "splint" == L4_2 then
    L4_2 = BodyDamage
    L4_2 = L4_2.BodyPartDamage
    L4_2 = L4_2.Fractures
    L4_2[L2_2] = true
    L4_2 = table
    L4_2 = L4_2.insert
    L5_2 = BodyDamage
    L5_2 = L5_2.MessageLog
    L6_2 = time
    L7_2 = " | "
    L8_2 = Config
    L8_2 = L8_2.Casts
    L8_2 = L8_2[1]
    L8_2 = L8_2.langRemoved
    L6_2 = L6_2 .. L7_2 .. L8_2
    L4_2(L5_2, L6_2)
    L4_2 = pairs
    L5_2 = Config
    L5_2 = L5_2.Casts
    L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
    for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
      L10_2 = pairs
      L11_2 = L9_2.casts
      L10_2, L11_2, L12_2, L13_2 = L10_2(L11_2)
      for L14_2, L15_2 in L10_2, L11_2, L12_2, L13_2 do
        L16_2 = L15_2.itemName
        if L16_2 == L1_2 then
          L16_2 = L15_2.bone
          if L16_2 == L2_2 then
            L16_2 = Config
            L16_2 = L16_2.UseCustomProps
            if L16_2 then
              L16_2 = GetEntityModel
              L17_2 = PlayerPedId
              L17_2, L18_2, L19_2, L20_2, L21_2 = L17_2()
              L16_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
              L17_2 = GetHashKey
              L18_2 = "mp_m_freemode_01"
              L17_2 = L17_2(L18_2)
              if L16_2 == L17_2 then
                L16_2 = SetPedComponentVariation
                L17_2 = L3_2
                L18_2 = L15_2.male
                L18_2 = L18_2.pedVariationCategory
                L19_2 = 0
                L20_2 = 0
                L21_2 = 0
                L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
              else
                L16_2 = GetEntityModel
                L17_2 = PlayerPedId
                L17_2, L18_2, L19_2, L20_2, L21_2 = L17_2()
                L16_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
                L17_2 = GetHashKey
                L18_2 = "mp_f_freemode_01"
                L17_2 = L17_2(L18_2)
                if L16_2 == L17_2 then
                  L16_2 = SetPedComponentVariation
                  L17_2 = L3_2
                  L18_2 = L15_2.female
                  L18_2 = L18_2.pedVariationCategory
                  L19_2 = 0
                  L20_2 = 0
                  L21_2 = 0
                  L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
                end
              end
            end
          end
        end
      end
    end
    L4_2 = LocalPlayer
    L4_2 = L4_2.state
    L5_2 = L4_2
    L4_2 = L4_2.set
    L6_2 = "BodyDamage"
    L7_2 = BodyDamage
    L8_2 = true
    L4_2(L5_2, L6_2, L7_2, L8_2)
    return
  end
  L4_2 = BodyDamage
  L4_2 = L4_2.BodyPartDamage
  L4_2 = L4_2.Fractures
  L4_2 = L4_2[L2_2]
  if true ~= L4_2 then
    L4_2 = BodyDamage
    L4_2 = L4_2.BodyPartDamage
    L4_2 = L4_2.Fractures
    L4_2 = L4_2[L2_2]
    if "xrayed" ~= L4_2 then
      goto lbl_229
    end
  end
  L4_2 = pairs
  L5_2 = Config
  L5_2 = L5_2.Casts
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
    L10_2 = pairs
    L11_2 = L9_2.casts
    L10_2, L11_2, L12_2, L13_2 = L10_2(L11_2)
    for L14_2, L15_2 in L10_2, L11_2, L12_2, L13_2 do
      L16_2 = L15_2.itemName
      if L16_2 == L1_2 then
        L16_2 = L15_2.bone
        if L16_2 == L2_2 then
          L16_2 = Config
          L16_2 = L16_2.UseCustomProps
          if L16_2 then
            L16_2 = GetEntityModel
            L17_2 = PlayerPedId
            L17_2, L18_2, L19_2, L20_2, L21_2 = L17_2()
            L16_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
            L17_2 = GetHashKey
            L18_2 = "mp_m_freemode_01"
            L17_2 = L17_2(L18_2)
            if L16_2 == L17_2 then
              L16_2 = SetPedComponentVariation
              L17_2 = L3_2
              L18_2 = L15_2.male
              L18_2 = L18_2.pedVariationCategory
              L19_2 = L15_2.male
              L19_2 = L19_2.pedVariationId
              L20_2 = 0
              L21_2 = 0
              L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
            else
              L16_2 = GetEntityModel
              L17_2 = PlayerPedId
              L17_2, L18_2, L19_2, L20_2, L21_2 = L17_2()
              L16_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
              L17_2 = GetHashKey
              L18_2 = "mp_f_freemode_01"
              L17_2 = L17_2(L18_2)
              if L16_2 == L17_2 then
                L16_2 = SetPedComponentVariation
                L17_2 = L3_2
                L18_2 = L15_2.female
                L18_2 = L18_2.pedVariationCategory
                L19_2 = L15_2.female
                L19_2 = L19_2.pedVariationId
                L20_2 = 0
                L21_2 = 0
                L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
              end
            end
          end
          L16_2 = L9_2.type
          if "splint" == L16_2 then
            L16_2 = BodyDamage
            L16_2 = L16_2.BodyPartDamage
            L16_2 = L16_2.Fractures
            L16_2[L2_2] = "splint"
            L16_2 = table
            L16_2 = L16_2.insert
            L17_2 = BodyDamage
            L17_2 = L17_2.MessageLog
            L18_2 = time
            L19_2 = " | "
            L20_2 = Config
            L20_2 = L20_2.Casts
            L20_2 = L20_2[1]
            L20_2 = L20_2.langUsed
            L18_2 = L18_2 .. L19_2 .. L20_2
            L16_2(L17_2, L18_2)
          else
            L16_2 = L9_2.type
            if "cast" == L16_2 then
              L16_2 = BodyDamage
              L16_2 = L16_2.BodyPartDamage
              L16_2 = L16_2.Fractures
              L16_2[L2_2] = "cast"
              L16_2 = table
              L16_2 = L16_2.insert
              L17_2 = BodyDamage
              L17_2 = L17_2.MessageLog
              L18_2 = time
              L19_2 = " | "
              L20_2 = Config
              L20_2 = L20_2.Casts
              L20_2 = L20_2[2]
              L20_2 = L20_2.langUsed
              L18_2 = L18_2 .. L19_2 .. L20_2
              L16_2(L17_2, L18_2)
              L16_2 = BodyDamage
              L16_2 = L16_2.BodyPartDamage
              L16_2 = L16_2.FractureTime
              L17_2 = L9_2.timeInCast
              L16_2[L2_2] = L17_2
              L16_2 = CreateThread
              function L17_2()
                local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
                while true do
                  L0_3 = BodyDamage
                  L0_3 = L0_3.BodyPartDamage
                  L0_3 = L0_3.FractureTime
                  L1_3 = L2_2
                  L2_3 = BodyDamage
                  L2_3 = L2_3.BodyPartDamage
                  L2_3 = L2_3.FractureTime
                  L3_3 = L2_2
                  L2_3 = L2_3[L3_3]
                  L2_3 = L2_3 - 1000
                  L0_3[L1_3] = L2_3
                  L0_3 = Wait
                  L1_3 = 1000
                  L0_3(L1_3)
                  L0_3 = BodyDamage
                  L0_3 = L0_3.BodyPartDamage
                  L0_3 = L0_3.FractureTime
                  L1_3 = L2_2
                  L0_3 = L0_3[L1_3]
                  if L0_3 <= 0 then
                    L0_3 = BodyDamage
                    L0_3 = L0_3.BodyPartDamage
                    L0_3 = L0_3.Fractures
                    L1_3 = L2_2
                    L0_3[L1_3] = false
                    L0_3 = Config
                    L0_3 = L0_3.UseCustomProps
                    if L0_3 then
                      L0_3 = GetEntityModel
                      L1_3 = PlayerPedId
                      L1_3, L2_3, L3_3, L4_3, L5_3 = L1_3()
                      L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
                      L1_3 = GetHashKey
                      L2_3 = "mp_m_freemode_01"
                      L1_3 = L1_3(L2_3)
                      if L0_3 == L1_3 then
                        L0_3 = SetPedComponentVariation
                        L1_3 = L3_2
                        L2_3 = L15_2.male
                        L2_3 = L2_3.pedVariationCategory
                        L3_3 = 0
                        L4_3 = 0
                        L5_3 = 0
                        L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
                        break
                      end
                      L0_3 = GetEntityModel
                      L1_3 = PlayerPedId
                      L1_3, L2_3, L3_3, L4_3, L5_3 = L1_3()
                      L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
                      L1_3 = GetHashKey
                      L2_3 = "mp_f_freemode_01"
                      L1_3 = L1_3(L2_3)
                      if L0_3 == L1_3 then
                        L0_3 = SetPedComponentVariation
                        L1_3 = L3_2
                        L2_3 = L15_2.female
                        L2_3 = L2_3.pedVariationCategory
                        L3_3 = 0
                        L4_3 = 0
                        L5_3 = 0
                        L0_3(L1_3, L2_3, L3_3, L4_3, L5_3)
                      end
                    end
                    break
                  end
                end
              end
              L16_2(L17_2)
            end
          end
          L16_2 = L15_2.animationDict
          if L16_2 then
            L16_2 = L15_2.animationName
            if L16_2 then
              L16_2 = playerCastAnimation
              L17_2 = L15_2.animationDict
              L18_2 = L15_2.animationName
              L19_2 = L2_2
              L16_2(L17_2, L18_2, L19_2)
            end
          end
        end
      end
    end
  end
  goto lbl_232
  ::lbl_229::
  L4_2 = print
  L5_2 = "This bodypart is not fractured"
  L4_2(L5_2)
  ::lbl_232::
  L4_2 = LocalPlayer
  L4_2 = L4_2.state
  L5_2 = L4_2
  L4_2 = L4_2.set
  L6_2 = "BodyDamage"
  L7_2 = BodyDamage
  L8_2 = true
  L4_2(L5_2, L6_2, L7_2, L8_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "ApplyCosmeticCast"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L1_2 = Player
  L2_2 = A0_2.PlayerId
  L1_2 = L1_2(L2_2)
  L2_2 = L1_2.state
  L2_2 = L2_2.BodyDamage
  L3_2 = A0_2.item
  L4_2 = A0_2.BodyPart
  L5_2 = SetNuiFocus
  L6_2 = false
  L7_2 = false
  L5_2(L6_2, L7_2)
  L5_2 = SendNUIMessage
  L6_2 = {}
  L6_2.display = false
  L5_2(L6_2)
  L5_2 = pairs
  L6_2 = Config
  L6_2 = L6_2.Casts
  L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
  for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
    L11_2 = L10_2.type
    if "cast" == L11_2 then
      L11_2 = pairs
      L12_2 = L10_2.casts
      L11_2, L12_2, L13_2, L14_2 = L11_2(L12_2)
      for L15_2, L16_2 in L11_2, L12_2, L13_2, L14_2 do
        L17_2 = L16_2.itemName
        if L17_2 == L3_2 then
          L17_2 = ProgressBar
          L18_2 = L10_2.lang
          L19_2 = L10_2.time
          L20_2 = L10_2.anim
          L20_2 = L20_2.dict
          L21_2 = L10_2.anim
          L21_2 = L21_2.name
          L17_2(L18_2, L19_2, L20_2, L21_2)
          L17_2 = TriggerServerEvent
          L18_2 = "osp_ambulance:removeItem"
          L19_2 = L3_2
          L20_2 = 1
          L17_2(L18_2, L19_2, L20_2)
          break
        end
      end
    else
      L11_2 = L10_2.type
      if "splint" == L11_2 then
        L11_2 = pairs
        L12_2 = L10_2.casts
        L11_2, L12_2, L13_2, L14_2 = L11_2(L12_2)
        for L15_2, L16_2 in L11_2, L12_2, L13_2, L14_2 do
          L17_2 = L16_2.itemName
          if L17_2 == L3_2 then
            L17_2 = ProgressBar
            L18_2 = L10_2.lang
            L19_2 = L10_2.time
            L20_2 = L10_2.anim
            L20_2 = L20_2.dict
            L21_2 = L10_2.anim
            L21_2 = L21_2.name
            L17_2(L18_2, L19_2, L20_2, L21_2)
            L17_2 = TriggerServerEvent
            L18_2 = "osp_ambulance:removeItem"
            L19_2 = L3_2
            L20_2 = 1
            L17_2(L18_2, L19_2, L20_2)
            break
          end
        end
      end
    end
  end
  L5_2 = TriggerServerEvent
  L6_2 = "osp_ambulance:applyCosmeticCastSv"
  L7_2 = A0_2.PlayerId
  L8_2 = A0_2
  L5_2(L6_2, L7_2, L8_2)
  L5_2 = Wait
  L6_2 = 500
  L5_2(L6_2)
  L5_2 = Player
  L6_2 = A0_2.PlayerId
  L5_2 = L5_2(L6_2)
  L6_2 = L5_2.state
  L6_2 = L6_2.BodyDamage
  L7_2 = GetMedicalInventoryItems
  L7_2()
  L7_2 = SetNuiFocus
  L8_2 = true
  L9_2 = true
  L7_2(L8_2, L9_2)
  L7_2 = SendNUIMessage
  L8_2 = {}
  L8_2.display = true
  L9_2 = json
  L9_2 = L9_2.encode
  L10_2 = L6_2
  L9_2 = L9_2(L10_2)
  L8_2.damageStatus = L9_2
  L9_2 = json
  L9_2 = L9_2.encode
  L10_2 = invItems
  L9_2 = L9_2(L10_2)
  L8_2.invItems = L9_2
  L7_2(L8_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:applyCosmeticCastCl"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "osp_ambulance:applyCosmeticCastCl"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L1_2 = A0_2.item
  L2_2 = A0_2.BodyPart
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = pairs
  L5_2 = Config
  L5_2 = L5_2.Casts
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
    L10_2 = pairs
    L11_2 = L9_2.casts
    L10_2, L11_2, L12_2, L13_2 = L10_2(L11_2)
    for L14_2, L15_2 in L10_2, L11_2, L12_2, L13_2 do
      L16_2 = L15_2.itemName
      if L16_2 == L1_2 then
        L16_2 = L15_2.bone
        if L16_2 == L2_2 then
          L16_2 = Config
          L16_2 = L16_2.UseCustomProps
          if L16_2 then
            L16_2 = GetEntityModel
            L17_2 = L3_2
            L16_2 = L16_2(L17_2)
            L17_2 = GetHashKey
            L18_2 = "mp_m_freemode_01"
            L17_2 = L17_2(L18_2)
            if L16_2 == L17_2 then
              L16_2 = SetPedComponentVariation
              L17_2 = L3_2
              L18_2 = L15_2.male
              L18_2 = L18_2.pedVariationCategory
              L19_2 = L15_2.male
              L19_2 = L19_2.pedVariationId
              L20_2 = 0
              L21_2 = 0
              L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
            else
              L16_2 = GetEntityModel
              L17_2 = L3_2
              L16_2 = L16_2(L17_2)
              L17_2 = GetHashKey
              L18_2 = "mp_f_freemode_01"
              L17_2 = L17_2(L18_2)
              if L16_2 == L17_2 then
                L16_2 = SetPedComponentVariation
                L17_2 = L3_2
                L18_2 = L15_2.female
                L18_2 = L18_2.pedVariationCategory
                L19_2 = L15_2.female
                L19_2 = L19_2.pedVariationId
                L20_2 = 0
                L21_2 = 0
                L16_2(L17_2, L18_2, L19_2, L20_2, L21_2)
              end
            end
          end
          L16_2 = L15_2.animationDict
          if L16_2 then
            L16_2 = L15_2.animationName
            if L16_2 then
              L16_2 = playerCastAnimation
              L17_2 = L15_2.animationDict
              L18_2 = L15_2.animationName
              L19_2 = L2_2
              L16_2(L17_2, L18_2, L19_2)
            end
          end
          L16_2 = BodyDamage
          L16_2 = L16_2.BodyPartDamage
          L17_2 = BodyDamage
          L17_2 = L17_2.BodyPartDamage
          L17_2 = L17_2.CosmeticFractures
          if not L17_2 then
            L17_2 = {}
          end
          L16_2.CosmeticFractures = L17_2
          L16_2 = L9_2.type
          if "cast" == L16_2 then
            L16_2 = BodyDamage
            L16_2 = L16_2.BodyPartDamage
            L16_2 = L16_2.CosmeticFractures
            L16_2[L2_2] = "cast"
          else
            L16_2 = L9_2.type
            if "splint" == L16_2 then
              L16_2 = BodyDamage
              L16_2 = L16_2.BodyPartDamage
              L16_2 = L16_2.CosmeticFractures
              L16_2[L2_2] = "splint"
            end
          end
          L16_2 = CreateThread
          function L17_2()
            local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
            L0_3 = L9_2.timeInCast
            if not L0_3 then
              L0_3 = 600000
            end
            L1_3 = Wait
            L2_3 = L0_3
            L1_3(L2_3)
            L1_3 = BodyDamage
            L1_3 = L1_3.BodyPartDamage
            L1_3 = L1_3.CosmeticFractures
            L2_3 = L2_2
            L1_3[L2_3] = false
            L1_3 = Config
            L1_3 = L1_3.UseCustomProps
            if L1_3 then
              L1_3 = GetEntityModel
              L2_3 = L3_2
              L1_3 = L1_3(L2_3)
              L2_3 = GetHashKey
              L3_3 = "mp_m_freemode_01"
              L2_3 = L2_3(L3_3)
              if L1_3 == L2_3 then
                L1_3 = SetPedComponentVariation
                L2_3 = L3_2
                L3_3 = L15_2.male
                L3_3 = L3_3.pedVariationCategory
                L4_3 = 0
                L5_3 = 0
                L6_3 = 0
                L1_3(L2_3, L3_3, L4_3, L5_3, L6_3)
              else
                L1_3 = GetEntityModel
                L2_3 = L3_2
                L1_3 = L1_3(L2_3)
                L2_3 = GetHashKey
                L3_3 = "mp_f_freemode_01"
                L2_3 = L2_3(L3_3)
                if L1_3 == L2_3 then
                  L1_3 = SetPedComponentVariation
                  L2_3 = L3_2
                  L3_3 = L15_2.female
                  L3_3 = L3_3.pedVariationCategory
                  L4_3 = 0
                  L5_3 = 0
                  L6_3 = 0
                  L1_3(L2_3, L3_3, L4_3, L5_3, L6_3)
                end
              end
            end
            L1_3 = LocalPlayer
            L1_3 = L1_3.state
            L2_3 = L1_3
            L1_3 = L1_3.set
            L3_3 = "BodyDamage"
            L4_3 = BodyDamage
            L5_3 = true
            L1_3(L2_3, L3_3, L4_3, L5_3)
          end
          L16_2(L17_2)
          L16_2 = LocalPlayer
          L16_2 = L16_2.state
          L17_2 = L16_2
          L16_2 = L16_2.set
          L18_2 = "BodyDamage"
          L19_2 = BodyDamage
          L20_2 = true
          L16_2(L17_2, L18_2, L19_2, L20_2)
          return
        end
      end
    end
  end
  L4_2 = LocalPlayer
  L4_2 = L4_2.state
  L5_2 = L4_2
  L4_2 = L4_2.set
  L6_2 = "BodyDamage"
  L7_2 = BodyDamage
  L8_2 = true
  L4_2(L5_2, L6_2, L7_2, L8_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "RemoveCast"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2
  L1_2 = Player
  L2_2 = A0_2.PlayerId
  L1_2 = L1_2(L2_2)
  L2_2 = L1_2.state
  L2_2 = L2_2.BodyDamage
  L3_2 = A0_2.item
  L4_2 = A0_2.BodyPart
  L5_2 = L2_2.BodyPartDamage
  L5_2 = L5_2.Fractures
  L5_2 = L5_2[L4_2]
  L6_2 = L2_2.BodyPartDamage
  L6_2 = L6_2.CosmeticFractures
  L6_2 = L6_2[L4_2]
  L7_2 = DebugPrint
  L8_2 = "Got PlayerId: "
  L9_2 = A0_2.PlayerId
  L7_2(L8_2, L9_2)
  L7_2 = A0_2.PlayerId
  if not L7_2 then
    L7_2 = print
    L8_2 = "^1UNABLE TO GET PLAYERID, REPORT THIS ISSUE!"
    L7_2(L8_2)
    return
  end
  L7_2 = SetNuiFocus
  L8_2 = false
  L9_2 = false
  L7_2(L8_2, L9_2)
  L7_2 = SendNUIMessage
  L8_2 = {}
  L8_2.display = false
  L7_2(L8_2)
  L7_2 = Config
  L7_2 = L7_2.ModularAccessLocks
  L7_2 = L7_2[L3_2]
  if L7_2 then
    L7_2 = IsAuthorized
    L7_2 = L7_2()
    if not L7_2 then
      L7_2 = SendTextMessage
      L8_2 = lang
      L8_2 = L8_2.interactions
      L8_2 = L8_2.medicalHeader
      L9_2 = lang
      L9_2 = L9_2.error
      L9_2 = L9_2.not_authorized
      L10_2 = 5000
      L11_2 = "error"
      L7_2(L8_2, L9_2, L10_2, L11_2)
      return
    end
  end
  L7_2 = L2_2.BodyPartDamage
  L7_2 = L7_2.CosmeticFractures
  if L7_2 and "splint" == L6_2 or "splint" == L5_2 then
    L7_2 = pairs
    L8_2 = Config
    L8_2 = L8_2.Casts
    L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
    for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
      L13_2 = pairs
      L14_2 = L12_2.casts
      L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
      for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
        L19_2 = L18_2.bone
        if L19_2 == L4_2 then
          L19_2 = L12_2.type
          if "splint" == L19_2 then
            L19_2 = ProgressBar
            L20_2 = L12_2.removeLang
            L21_2 = L12_2.time
            L22_2 = L12_2.anim
            L22_2 = L22_2.dict
            L23_2 = L12_2.anim
            L23_2 = L23_2.name
            L19_2(L20_2, L21_2, L22_2, L23_2)
            L19_2 = TriggerServerEvent
            L20_2 = "osp_ambulance:addItem"
            L21_2 = L3_2
            L22_2 = 1
            L19_2(L20_2, L21_2, L22_2)
            break
          end
        end
      end
    end
  end
  L7_2 = L2_2.BodyPartDamage
  L7_2 = L7_2.CosmeticFractures
  if L7_2 and "cast" == L6_2 or "cast" == L5_2 then
    L7_2 = pairs
    L8_2 = Config
    L8_2 = L8_2.Casts
    L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
    for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
      L13_2 = pairs
      L14_2 = L12_2.casts
      L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
      for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
        L19_2 = L18_2.bone
        if L19_2 == L4_2 then
          L19_2 = L12_2.type
          if "cast" == L19_2 then
            L19_2 = ProgressBar
            L20_2 = L12_2.removeLang
            L21_2 = L12_2.time
            L22_2 = L12_2.anim
            L22_2 = L22_2.dict
            L23_2 = L12_2.anim
            L23_2 = L23_2.name
            L19_2(L20_2, L21_2, L22_2, L23_2)
            break
          end
        end
      end
    end
  end
  L7_2 = TriggerServerEvent
  L8_2 = "osp_ambulance:removeCastSv"
  L9_2 = A0_2.PlayerId
  L10_2 = A0_2
  L7_2(L8_2, L9_2, L10_2)
  L7_2 = Wait
  L8_2 = 500
  L7_2(L8_2)
  L7_2 = Player
  L8_2 = A0_2.PlayerId
  L7_2 = L7_2(L8_2)
  L8_2 = L7_2.state
  L8_2 = L8_2.BodyDamage
  L9_2 = GetMedicalInventoryItems
  L9_2()
  L9_2 = SetNuiFocus
  L10_2 = true
  L11_2 = true
  L9_2(L10_2, L11_2)
  L9_2 = SendNUIMessage
  L10_2 = {}
  L10_2.display = true
  L11_2 = json
  L11_2 = L11_2.encode
  L12_2 = L8_2
  L11_2 = L11_2(L12_2)
  L10_2.damageStatus = L11_2
  L11_2 = json
  L11_2 = L11_2.encode
  L12_2 = invItems
  L11_2 = L11_2(L12_2)
  L10_2.invItems = L11_2
  L9_2(L10_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:removeCastCl"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "osp_ambulance:removeCastCl"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2
  L1_2 = A0_2.item
  L2_2 = A0_2.BodyPart
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = BodyDamage
  L4_2 = L4_2.BodyPartDamage
  L4_2 = L4_2.Fractures
  L4_2 = L4_2[L2_2]
  L5_2 = BodyDamage
  L5_2 = L5_2.BodyPartDamage
  L5_2 = L5_2.CosmeticFractures
  L5_2 = L5_2[L2_2]
  if "cast" ~= L4_2 and "splint" ~= L4_2 then
    L6_2 = BodyDamage
    L6_2 = L6_2.BodyPartDamage
    L6_2 = L6_2.CosmeticFractures
    if not L6_2 or "cast" ~= L5_2 and "splint" ~= L5_2 then
      goto lbl_97
    end
  end
  L6_2 = pairs
  L7_2 = Config
  L7_2 = L7_2.Casts
  L6_2, L7_2, L8_2, L9_2 = L6_2(L7_2)
  for L10_2, L11_2 in L6_2, L7_2, L8_2, L9_2 do
    L12_2 = pairs
    L13_2 = L11_2.casts
    L12_2, L13_2, L14_2, L15_2 = L12_2(L13_2)
    for L16_2, L17_2 in L12_2, L13_2, L14_2, L15_2 do
      L18_2 = L17_2.bone
      if L18_2 == L2_2 then
        L18_2 = Config
        L18_2 = L18_2.UseCustomProps
        if L18_2 then
          L18_2 = GetEntityModel
          L19_2 = L3_2
          L18_2 = L18_2(L19_2)
          L19_2 = GetHashKey
          L20_2 = "mp_m_freemode_01"
          L19_2 = L19_2(L20_2)
          if L18_2 == L19_2 then
            L18_2 = SetPedComponentVariation
            L19_2 = L3_2
            L20_2 = L17_2.male
            L20_2 = L20_2.pedVariationCategory
            L21_2 = 0
            L22_2 = 0
            L23_2 = 0
            L18_2(L19_2, L20_2, L21_2, L22_2, L23_2)
          else
            L18_2 = GetEntityModel
            L19_2 = L3_2
            L18_2 = L18_2(L19_2)
            L19_2 = GetHashKey
            L20_2 = "mp_f_freemode_01"
            L19_2 = L19_2(L20_2)
            if L18_2 == L19_2 then
              L18_2 = SetPedComponentVariation
              L19_2 = L3_2
              L20_2 = L17_2.female
              L20_2 = L20_2.pedVariationCategory
              L21_2 = 0
              L22_2 = 0
              L23_2 = 0
              L18_2(L19_2, L20_2, L21_2, L22_2, L23_2)
            end
          end
        end
        L18_2 = BodyDamage
        L18_2 = L18_2.BodyPartDamage
        L18_2 = L18_2.CosmeticFractures
        L18_2[L2_2] = false
        L18_2 = BodyDamage
        L18_2 = L18_2.BodyPartDamage
        L18_2 = L18_2.Fractures
        L18_2[L2_2] = false
        L18_2 = LocalPlayer
        L18_2 = L18_2.state
        L19_2 = L18_2
        L18_2 = L18_2.set
        L20_2 = "BodyDamage"
        L21_2 = BodyDamage
        L22_2 = true
        L18_2(L19_2, L20_2, L21_2, L22_2)
        return
      end
    end
  end
  ::lbl_97::
  L6_2 = LocalPlayer
  L6_2 = L6_2.state
  L7_2 = L6_2
  L6_2 = L6_2.set
  L8_2 = "BodyDamage"
  L9_2 = BodyDamage
  L10_2 = true
  L6_2(L7_2, L8_2, L9_2, L10_2)
end
L1_1(L2_1, L3_1)
