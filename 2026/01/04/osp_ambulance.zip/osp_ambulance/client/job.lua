local L0_1, L1_1, L2_1
currentGarage = 0
currentHospital = nil
currentHospitalID = nil
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = Config
  L1_2 = L1_2.Hospitals
  L2_2 = currentHospitalID
  L1_2 = L1_2[L2_2]
  L1_2 = L1_2.vehicle
  L2_2 = currentGarage
  L1_2 = L1_2[L2_2]
  L2_2 = RequestModel
  L3_2 = A0_2
  L2_2(L3_2)
  while true do
    L2_2 = HasModelLoaded
    L3_2 = A0_2
    L2_2 = L2_2(L3_2)
    if L2_2 then
      break
    end
    L2_2 = Wait
    L3_2 = 1
    L2_2(L3_2)
  end
  L2_2 = CreateVehicle
  L3_2 = A0_2
  L4_2 = L1_2
  L5_2 = true
  L6_2 = true
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2)
  L3_2 = SetVehicleNumberPlateText
  L4_2 = L2_2
  L5_2 = lang
  L5_2 = L5_2.info
  L5_2 = L5_2.amb_plate
  L6_2 = tostring
  L7_2 = math
  L7_2 = L7_2.random
  L8_2 = 100
  L9_2 = 999
  L7_2, L8_2, L9_2 = L7_2(L8_2, L9_2)
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  L5_2 = L5_2 .. L6_2
  L3_2(L4_2, L5_2)
  L3_2 = SetEntityHeading
  L4_2 = L2_2
  L5_2 = L1_2.w
  L3_2(L4_2, L5_2)
  L3_2 = FullFuel
  L4_2 = L2_2
  L3_2(L4_2)
  L3_2 = TaskWarpPedIntoVehicle
  L4_2 = PlayerPedId
  L4_2 = L4_2()
  L5_2 = L2_2
  L6_2 = -1
  L3_2(L4_2, L5_2, L6_2)
  L3_2 = Config
  L3_2 = L3_2.VehicleExtras
  L3_2 = L3_2[A0_2]
  if nil ~= L3_2 then
    L3_2 = SetVehicleExtras
    L4_2 = L2_2
    L5_2 = Config
    L5_2 = L5_2.VehicleExtras
    L5_2 = L5_2[A0_2]
    L3_2(L4_2, L5_2)
  end
  L3_2 = GiveVehicleKeys
  L4_2 = L2_2
  L3_2(L4_2)
  L3_2 = SetVehicleEngineOn
  L4_2 = L2_2
  L5_2 = true
  L6_2 = true
  L3_2(L4_2, L5_2, L6_2)
end
TakeOutVehicle = L0_1
function L0_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L0_2 = {}
  L1_2 = Config
  L1_2 = L1_2.AuthorizedVehicles
  L2_2 = GetPlayerJobGrade
  L2_2 = L2_2()
  L1_2 = L1_2[L2_2]
  L2_2 = pairs
  L3_2 = L1_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = #L0_2
    L8_2 = L8_2 + 1
    L9_2 = {}
    L9_2.title = L7_2
    L9_2.description = ""
    L9_2.event = "ambulance:client:TakeOutVehicle"
    L10_2 = {}
    L10_2.vehicle = L6_2
    L9_2.args = L10_2
    L0_2[L8_2] = L9_2
  end
  L2_2 = registerContext
  L3_2 = {}
  L3_2.id = "menugarage"
  L4_2 = lang
  L4_2 = L4_2.menu
  L4_2 = L4_2.amb_vehicles
  L3_2.title = L4_2
  L3_2.options = L0_2
  L2_2(L3_2)
  L2_2 = showContext
  L3_2 = "menugarage"
  L2_2(L3_2)
end
MenuGarage = L0_1
L0_1 = RegisterNetEvent
L1_1 = "ambulance:client:TakeOutVehicle"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = A0_2.vehicle
  L2_2 = TakeOutVehicle
  L3_2 = L1_2
  L2_2(L3_2)
end
L0_1(L1_1, L2_1)
breakControls = false
check = false
function L0_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = CreateThread
  function L3_2()
    local L0_3, L1_3, L2_3
    check = true
    while true do
      L0_3 = check
      if not L0_3 then
        break
      end
      L0_3 = IsControlJustPressed
      L1_3 = 0
      L2_3 = 38
      L0_3 = L0_3(L1_3, L2_3)
      if L0_3 then
        L0_3 = A0_2
        if "sign" == L0_3 then
          L0_3 = TriggerEvent
          L1_3 = "EMSToggle:Duty"
          L0_3(L1_3)
        else
          L0_3 = A0_2
          if "stash" == L0_3 then
            L0_3 = TriggerEvent
            L1_3 = "osp_ambulance:stash"
            L0_3(L1_3)
          else
            L0_3 = A0_2
            if "shop" == L0_3 then
              L0_3 = TriggerEvent
              L1_3 = "osp_ambulance:shop"
              L0_3(L1_3)
            else
              L0_3 = A0_2
              if "storeheli" == L0_3 then
                L0_3 = TriggerEvent
                L1_3 = "osp_ambulance:storeheli"
                L0_3(L1_3)
              else
                L0_3 = A0_2
                if "takeheli" == L0_3 then
                  L0_3 = TriggerEvent
                  L1_3 = "osp_ambulance:pullheli"
                  L0_3(L1_3)
                else
                  L0_3 = A0_2
                  if "roof" == L0_3 then
                    L0_3 = TriggerEvent
                    L1_3 = "osp_ambulance:elevator_main"
                    L2_3 = A1_2
                    L0_3(L1_3, L2_3)
                  else
                    L0_3 = A0_2
                    if "main" == L0_3 then
                      L0_3 = TriggerEvent
                      L1_3 = "osp_ambulance:elevator_roof"
                      L2_3 = A1_2
                      L0_3(L1_3, L2_3)
                    end
                  end
                end
              end
            end
          end
        end
      end
      L0_3 = Wait
      L1_3 = 3
      L0_3(L1_3)
      L0_3 = breakControls
      if L0_3 then
        breakControls = false
        break
      end
    end
  end
  L2_2(L3_2)
end
EMSControls = L0_1
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:shop"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L0_2 = IsAuthorized
  L0_2 = L0_2()
  if L0_2 then
    L0_2 = {}
    L1_2 = lib
    L1_2 = L1_2.callback
    L1_2 = L1_2.await
    L2_2 = "osp_ambulance:GetMedicalStock"
    L3_2 = 1000
    L1_2 = L1_2(L2_2, L3_2)
    L2_2 = pairs
    L3_2 = Config
    L3_2 = L3_2.ItemShop
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = L1_2[L6_2]
      if nil ~= L8_2 then
        L8_2 = #L0_2
        L8_2 = L8_2 + 1
        L9_2 = {}
        L10_2 = L7_2.label
        L9_2.title = L10_2
        L10_2 = lang
        L10_2 = L10_2.store
        L10_2 = L10_2.cost
        L11_2 = L7_2.price
        L12_2 = lang
        L12_2 = L12_2.store
        L12_2 = L12_2.currency
        L13_2 = "\n"
        L14_2 = lang
        L14_2 = L14_2.store
        L14_2 = L14_2.stock
        L15_2 = L1_2[L6_2]
        L10_2 = L10_2 .. L11_2 .. L12_2 .. L13_2 .. L14_2 .. L15_2
        L9_2.description = L10_2
        L9_2.event = "osp_ambulance:buyItem"
        L10_2 = {}
        L11_2 = L7_2.price
        L10_2.price = L11_2
        L11_2 = L7_2.name
        L10_2.name = L11_2
        L10_2.index = L6_2
        L11_2 = L1_2[L6_2]
        L10_2.amount = L11_2
        L9_2.args = L10_2
        L0_2[L8_2] = L9_2
      else
        L8_2 = #L0_2
        L8_2 = L8_2 + 1
        L9_2 = {}
        L10_2 = L7_2.label
        L9_2.title = L10_2
        L10_2 = lang
        L10_2 = L10_2.store
        L10_2 = L10_2.cost
        L11_2 = L7_2.price
        L12_2 = lang
        L12_2 = L12_2.store
        L12_2 = L12_2.currency
        L10_2 = L10_2 .. L11_2 .. L12_2
        L9_2.description = L10_2
        L9_2.event = "osp_ambulance:buyItem"
        L10_2 = {}
        L11_2 = L7_2.price
        L10_2.price = L11_2
        L11_2 = L7_2.name
        L10_2.name = L11_2
        L9_2.args = L10_2
        L0_2[L8_2] = L9_2
      end
    end
    L2_2 = registerContext
    L3_2 = {}
    L3_2.id = "medicalstore"
    L4_2 = lang
    L4_2 = L4_2.store
    L4_2 = L4_2.store
    L3_2.title = L4_2
    L3_2.options = L0_2
    L2_2(L3_2)
    L2_2 = showContext
    L3_2 = "medicalstore"
    L2_2(L3_2)
  else
    L0_2 = print
    L1_2 = "you are not authorized to use this"
    L0_2(L1_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:buyItem"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = A0_2.price
  L2_2 = A0_2.name
  function L3_2(A0_3)
    local L1_3, L2_3
    L1_3 = math
    L1_3 = L1_3.type
    L2_3 = A0_3
    L1_3 = L1_3(L2_3)
    L1_3 = "integer" == L1_3
    return L1_3
  end
  isInteger = L3_2
  L3_2 = lib
  L3_2 = L3_2.inputDialog
  L4_2 = lang
  L4_2 = L4_2.store
  L4_2 = L4_2.store
  L5_2 = {}
  L6_2 = {}
  L6_2.type = "number"
  L7_2 = lang
  L7_2 = L7_2.store
  L7_2 = L7_2.amount
  L6_2.label = L7_2
  L7_2 = lang
  L7_2 = L7_2.store
  L7_2 = L7_2.want_to_buy
  L6_2.description = L7_2
  L7_2 = Config
  L7_2 = L7_2.MaxTakeOut
  L6_2.max = L7_2
  L5_2[1] = L6_2
  L3_2 = L3_2(L4_2, L5_2)
  if not L3_2 then
    return
  end
  L4_2 = tonumber
  L5_2 = L3_2[1]
  L4_2 = L4_2(L5_2)
  L3_2[1] = L4_2
  L4_2 = isInteger
  L5_2 = L3_2[1]
  L4_2 = L4_2(L5_2)
  if L4_2 then
    L4_2 = TriggerServerEvent
    L5_2 = "osp_ambulance:buyItemSv"
    L6_2 = A0_2
    L7_2 = L3_2
    L8_2 = L1_2
    L9_2 = L2_2
    L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
  else
    L4_2 = SendTextMessage
    L5_2 = lang
    L5_2 = L5_2.interactions
    L5_2 = L5_2.medicalHeader
    L6_2 = lang
    L6_2 = L6_2.store
    L6_2 = L6_2.invalid
    L7_2 = 5000
    L8_2 = "error"
    L4_2(L5_2, L6_2, L7_2, L8_2)
  end
end
L0_1(L1_1, L2_1)
CheckVehicle = false
function L0_1(A0_2, A1_2)
  local L2_2, L3_2
  CheckVehicle = true
  L2_2 = CreateThread
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    while true do
      L0_3 = CheckVehicle
      if not L0_3 then
        break
      end
      L0_3 = IsControlJustPressed
      L1_3 = 0
      L2_3 = 38
      L0_3 = L0_3(L1_3, L2_3)
      if L0_3 then
        CheckVehicle = false
        L0_3 = PlayerPedId
        L0_3 = L0_3()
        L1_3 = IsPedInAnyVehicle
        L2_3 = L0_3
        L3_3 = false
        L1_3 = L1_3(L2_3, L3_3)
        if L1_3 then
          L1_3 = pairs
          L2_3 = Config
          L2_3 = L2_3.Ambulances
          L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
          for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
            L7_3 = GetEntityModel
            L8_3 = GetVehiclePedIsIn
            L9_3 = L0_3
            L10_3 = false
            L8_3, L9_3, L10_3 = L8_3(L9_3, L10_3)
            L7_3 = L7_3(L8_3, L9_3, L10_3)
            L8_3 = GetHashKey
            L9_3 = L5_3
            L8_3 = L8_3(L9_3)
            if L7_3 == L8_3 then
              L7_3 = AmbulanceDeleteVehicle
              L8_3 = GetVehiclePedIsIn
              L9_3 = L0_3
              L10_3 = false
              L8_3, L9_3, L10_3 = L8_3(L9_3, L10_3)
              L7_3(L8_3, L9_3, L10_3)
              return
            end
          end
        else
          L1_3 = A0_2
          L2_3 = MenuGarage
          L3_3 = L1_3
          L2_3(L3_3)
          currentGarage = L1_3
          L2_3 = A1_2
          currentHospitalID = L2_3
        end
      end
      L0_3 = Wait
      L1_3 = 3
      L0_3(L1_3)
    end
  end
  L2_2(L3_2)
end
EMSVehicle = L0_1
CheckHeli = false
function L0_1(A0_2, A1_2)
  local L2_2, L3_2
  CheckHeli = true
  L2_2 = CreateThread
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    while true do
      L0_3 = CheckHeli
      if not L0_3 then
        break
      end
      L0_3 = IsControlJustPressed
      L1_3 = 0
      L2_3 = 38
      L0_3 = L0_3(L1_3, L2_3)
      if L0_3 then
        CheckHeli = false
        L0_3 = PlayerPedId
        L0_3 = L0_3()
        L1_3 = IsPedInAnyVehicle
        L2_3 = L0_3
        L3_3 = false
        L1_3 = L1_3(L2_3, L3_3)
        if L1_3 then
          L1_3 = AmbulanceDeleteVehicle
          L2_3 = GetVehiclePedIsIn
          L3_3 = L0_3
          L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3 = L2_3(L3_3)
          L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
        else
          L1_3 = A0_2
          L2_3 = A1_2
          currentHospitalID = L2_3
          L2_3 = Config
          L2_3 = L2_3.Hospitals
          L3_3 = currentHospitalID
          L2_3 = L2_3[L3_3]
          L2_3 = L2_3.helicopter
          L2_3 = L2_3[L1_3]
          L3_3 = RequestModel
          L4_3 = Config
          L4_3 = L4_3.Helicopter
          L3_3(L4_3)
          while true do
            L3_3 = HasModelLoaded
            L4_3 = Config
            L4_3 = L4_3.Helicopter
            L3_3 = L3_3(L4_3)
            if L3_3 then
              break
            end
            L3_3 = Wait
            L4_3 = 1
            L3_3(L4_3)
          end
          L3_3 = CreateVehicle
          L4_3 = Config
          L4_3 = L4_3.Helicopter
          L5_3 = L2_3
          L6_3 = true
          L7_3 = true
          L3_3 = L3_3(L4_3, L5_3, L6_3, L7_3)
          L4_3 = Config
          L4_3 = L4_3.VehicleExtras
          L5_3 = Config
          L5_3 = L5_3.Helicopter
          L4_3 = L4_3[L5_3]
          if nil ~= L4_3 then
            L4_3 = SetVehicleExtras
            L5_3 = L3_3
            L6_3 = Config
            L6_3 = L6_3.VehicleExtras
            L7_3 = Config
            L7_3 = L7_3.Helicopter
            L6_3 = L6_3[L7_3]
            L4_3(L5_3, L6_3)
          end
          L4_3 = SetVehicleNumberPlateText
          L5_3 = L3_3
          L6_3 = lang
          L6_3 = L6_3.info
          L6_3 = L6_3.heli_plate
          L7_3 = tostring
          L8_3 = math
          L8_3 = L8_3.random
          L9_3 = 1000
          L10_3 = 9999
          L8_3, L9_3, L10_3 = L8_3(L9_3, L10_3)
          L7_3 = L7_3(L8_3, L9_3, L10_3)
          L6_3 = L6_3 .. L7_3
          L4_3(L5_3, L6_3)
          L4_3 = SetEntityHeading
          L5_3 = L3_3
          L6_3 = L2_3.w
          L4_3(L5_3, L6_3)
          L4_3 = SetVehicleLivery
          L5_3 = L3_3
          L6_3 = 1
          L4_3(L5_3, L6_3)
          L4_3 = FullFuel
          L5_3 = L3_3
          L4_3(L5_3)
          L4_3 = TaskWarpPedIntoVehicle
          L5_3 = PlayerPedId
          L5_3 = L5_3()
          L6_3 = L3_3
          L7_3 = -1
          L4_3(L5_3, L6_3, L7_3)
          L4_3 = GiveVehicleKeys
          L5_3 = L3_3
          L4_3(L5_3)
          L4_3 = SetVehicleEngineOn
          L5_3 = L3_3
          L6_3 = true
          L7_3 = true
          L4_3(L5_3, L6_3, L7_3)
        end
      end
      L0_3 = Wait
      L1_3 = 3
      L0_3(L1_3)
    end
  end
  L2_2(L3_2)
end
EMSHelicopter = L0_1
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:elevator_roof"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = A0_2.hosID
  if not L2_2 then
    L2_2 = A0_2
  end
  currentHospitalID = L2_2
  L2_2 = pairs
  L3_2 = Config
  L3_2 = L3_2.Hospitals
  L4_2 = currentHospitalID
  L3_2 = L3_2[L4_2]
  L3_2 = L3_2.roof
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = DoScreenFadeOut
    L9_2 = 500
    L8_2(L9_2)
    while true do
      L8_2 = IsScreenFadedOut
      L8_2 = L8_2()
      if L8_2 then
        break
      end
      L8_2 = Wait
      L9_2 = 10
      L8_2(L9_2)
    end
    currentHospital = L6_2
    L8_2 = Config
    L8_2 = L8_2.Hospitals
    L9_2 = currentHospitalID
    L8_2 = L8_2[L9_2]
    L8_2 = L8_2.main
    L9_2 = currentHospital
    L8_2 = L8_2[L9_2]
    L9_2 = SetEntityCoords
    L10_2 = L1_2
    L11_2 = L8_2.x
    L12_2 = L8_2.y
    L13_2 = L8_2.z
    L14_2 = 0
    L15_2 = 0
    L16_2 = 0
    L17_2 = false
    L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
    L9_2 = SetEntityHeading
    L10_2 = L1_2
    L11_2 = L8_2.w
    L9_2(L10_2, L11_2)
    L9_2 = Wait
    L10_2 = 100
    L9_2(L10_2)
    L9_2 = DoScreenFadeIn
    L10_2 = 1000
    L9_2(L10_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:elevator_main"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = A0_2.hosID
  if not L2_2 then
    L2_2 = A0_2
  end
  currentHospitalID = L2_2
  L2_2 = pairs
  L3_2 = Config
  L3_2 = L3_2.Hospitals
  L4_2 = currentHospitalID
  L3_2 = L3_2[L4_2]
  L3_2 = L3_2.main
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = DoScreenFadeOut
    L9_2 = 500
    L8_2(L9_2)
    while true do
      L8_2 = IsScreenFadedOut
      L8_2 = L8_2()
      if L8_2 then
        break
      end
      L8_2 = Wait
      L9_2 = 10
      L8_2(L9_2)
    end
    currentHospital = L6_2
    L8_2 = Config
    L8_2 = L8_2.Hospitals
    L9_2 = currentHospitalID
    L8_2 = L8_2[L9_2]
    L8_2 = L8_2.roof
    L9_2 = currentHospital
    L8_2 = L8_2[L9_2]
    L9_2 = SetEntityCoords
    L10_2 = L1_2
    L11_2 = L8_2.x
    L12_2 = L8_2.y
    L13_2 = L8_2.z
    L14_2 = 0
    L15_2 = 0
    L16_2 = 0
    L17_2 = false
    L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
    L9_2 = SetEntityHeading
    L10_2 = L1_2
    L11_2 = L8_2.w
    L9_2(L10_2, L11_2)
    L9_2 = Wait
    L10_2 = 100
    L9_2(L10_2)
    L9_2 = DoScreenFadeIn
    L10_2 = 1000
    L9_2(L10_2)
  end
end
L0_1(L1_1, L2_1)
