local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1
L0_1 = nil
L1_1 = nil
L2_1 = nil
L3_1 = {}
L4_1 = 0
L5_1 = RegisterNetEvent
L6_1 = "osp_ambulance:giveCrutch"
L5_1(L6_1)
L5_1 = AddEventHandler
L6_1 = "osp_ambulance:giveCrutch"
function L7_1(A0_2)
  local L1_2, L2_2
  L1_2 = StartCrutchLoop
  L2_2 = A0_2
  L1_2(L2_2)
end
L5_1(L6_1, L7_1)
L5_1 = RegisterNetEvent
L6_1 = "osp_ambulance:giveWheelChair"
L5_1(L6_1)
L5_1 = AddEventHandler
L6_1 = "osp_ambulance:giveWheelChair"
function L7_1(A0_2)
  local L1_2, L2_2
  L1_2 = StartWheelChairLoop
  L2_2 = A0_2
  L1_2(L2_2)
end
L5_1(L6_1, L7_1)
L5_1 = RegisterNetEvent
L6_1 = "osp_ambulance:breakLoop"
L5_1(L6_1)
L5_1 = AddEventHandler
L6_1 = "osp_ambulance:breakLoop"
function L7_1()
  local L0_2, L1_2
  L0_2 = L0_1
  if not L0_2 then
    return
  end
  L0_2 = true
  L1_1 = L0_2
end
L5_1(L6_1, L7_1)
L5_1 = RegisterNetEvent
L6_1 = "osp_ambulance:givePlayerCrutch"
L5_1(L6_1)
L5_1 = AddEventHandler
L6_1 = "osp_ambulance:givePlayerCrutch"
function L7_1(A0_2)
  local L1_2, L2_2
  L1_2 = OpenCrutchMenu
  L2_2 = A0_2
  L1_2(L2_2)
end
L5_1(L6_1, L7_1)
L5_1 = RegisterNetEvent
L6_1 = "osp_ambulance:givePlayerWheelChair"
L5_1(L6_1)
L5_1 = AddEventHandler
L6_1 = "osp_ambulance:givePlayerWheelChair"
function L7_1(A0_2)
  local L1_2, L2_2
  L1_2 = OpenWheelChairMenu
  L2_2 = A0_2
  L1_2(L2_2)
end
L5_1(L6_1, L7_1)
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = lib
  L1_2 = L1_2.inputDialog
  L2_2 = lang
  L2_2 = L2_2.wheelchair
  L2_2 = L2_2.time_in_crutch
  L3_2 = {}
  L4_2 = lang
  L4_2 = L4_2.wheelchair
  L4_2 = L4_2.minutes
  L3_2[1] = L4_2
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L2_2 = math
    L2_2 = L2_2.floor
    L3_2 = L1_2[1]
    L2_2 = L2_2(L3_2)
    if L2_2 < 1 then
      L3_2 = SendTextMessage
      L4_2 = lang
      L4_2 = L4_2.wheelchair
      L4_2 = L4_2.crutch
      L5_2 = lang
      L5_2 = L5_2.wheelchair
      L5_2 = L5_2.invalid_input
      L6_2 = 3000
      L7_2 = "error"
      L3_2(L4_2, L5_2, L6_2, L7_2)
    else
      L3_2 = Config
      L3_2 = L3_2.MaxCrutchTime
      if L3_2 then
        L3_2 = Config
        L3_2 = L3_2.MaxCrutchTime
        if L2_2 > L3_2 then
          L3_2 = SendTextMessage
          L4_2 = lang
          L4_2 = L4_2.wheelchair
          L4_2 = L4_2.crutch
          L5_2 = lang
          L5_2 = L5_2.wheelchair
          L5_2 = L5_2.max_time
          L6_2 = 3000
          L7_2 = "error"
          L3_2(L4_2, L5_2, L6_2, L7_2)
      end
      else
        L3_2 = TriggerServerEvent
        L4_2 = "osp_ambulance:giveCrutch"
        L5_2 = A0_2
        L6_2 = L2_2
        L3_2(L4_2, L5_2, L6_2)
        L3_2 = TriggerServerEvent
        L4_2 = "osp_ambulance:removeItem"
        L5_2 = "crutch"
        L6_2 = 1
        L3_2(L4_2, L5_2, L6_2)
      end
    end
  else
    L2_2 = SendTextMessage
    L3_2 = lang
    L3_2 = L3_2.wheelchair
    L3_2 = L3_2.crutch
    L4_2 = lang
    L4_2 = L4_2.wheelchair
    L4_2 = L4_2.invalid_input
    L5_2 = 3000
    L6_2 = "error"
    L2_2(L3_2, L4_2, L5_2, L6_2)
  end
end
setCrutchTime = L5_1
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = lib
  L1_2 = L1_2.inputDialog
  L2_2 = lang
  L2_2 = L2_2.wheelchair
  L2_2 = L2_2.time_in_wheelchair
  L3_2 = {}
  L4_2 = lang
  L4_2 = L4_2.wheelchair
  L4_2 = L4_2.minutes
  L3_2[1] = L4_2
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L2_2 = math
    L2_2 = L2_2.floor
    L3_2 = L1_2[1]
    L2_2 = L2_2(L3_2)
    if L2_2 < 1 then
      L3_2 = SendTextMessage
      L4_2 = lang
      L4_2 = L4_2.wheelchair
      L4_2 = L4_2.wheelchair
      L5_2 = lang
      L5_2 = L5_2.wheelchair
      L5_2 = L5_2.invalid_input
      L6_2 = 3000
      L7_2 = "error"
      L3_2(L4_2, L5_2, L6_2, L7_2)
    else
      L3_2 = Config
      L3_2 = L3_2.MaxWheelChairTime
      if L3_2 then
        L3_2 = Config
        L3_2 = L3_2.MaxWheelChairTime
        if L2_2 > L3_2 then
          L3_2 = SendTextMessage
          L4_2 = lang
          L4_2 = L4_2.wheelchair
          L4_2 = L4_2.wheelchair
          L5_2 = lang
          L5_2 = L5_2.wheelchair
          L5_2 = L5_2.max_time
          L6_2 = 3000
          L7_2 = "error"
          L3_2(L4_2, L5_2, L6_2, L7_2)
      end
      else
        L3_2 = TriggerServerEvent
        L4_2 = "osp_ambulance:giveWheelChair"
        L5_2 = A0_2
        L6_2 = L2_2
        L3_2(L4_2, L5_2, L6_2)
        L3_2 = TriggerServerEvent
        L4_2 = "osp_ambulance:removeItem"
        L5_2 = "wheelchair"
        L6_2 = 1
        L3_2(L4_2, L5_2, L6_2)
      end
    end
  else
    L2_2 = SendTextMessage
    L3_2 = lang
    L3_2 = L3_2.wheelchair
    L3_2 = L3_2.wheelchair
    L4_2 = lang
    L4_2 = L4_2.wheelchair
    L4_2 = L4_2.invalid_input
    L5_2 = 3000
    L6_2 = "error"
    L2_2(L3_2, L4_2, L5_2, L6_2)
  end
end
setWheelChairTime = L5_1
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = GetEntityCoords
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = lib
  L3_2 = L3_2.getNearbyPlayers
  L4_2 = vector3
  L5_2 = L2_2.x
  L6_2 = L2_2.y
  L7_2 = L2_2.z
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  L5_2 = 10.0
  L6_2 = false
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L4_2 = #L3_2
  if L4_2 < 1 then
    L4_2 = SendTextMessage
    L5_2 = lang
    L5_2 = L5_2.wheelchair
    L5_2 = L5_2.wheelchair
    L6_2 = lang
    L6_2 = L6_2.wheelchair
    L6_2 = L6_2.no_nearby
    L7_2 = 3000
    L8_2 = "error"
    L4_2(L5_2, L6_2, L7_2, L8_2)
    return
  end
  L4_2 = {}
  L5_2 = 1
  L6_2 = #L3_2
  L7_2 = 1
  for L8_2 = L5_2, L6_2, L7_2 do
    L9_2 = #L4_2
    L9_2 = L9_2 + 1
    L10_2 = {}
    L11_2 = GetPlayerServerId
    L12_2 = L3_2[L8_2]
    L12_2 = L12_2.id
    L11_2 = L11_2(L12_2)
    L10_2.id = L11_2
    L4_2[L9_2] = L10_2
  end
  L5_2 = lib
  L5_2 = L5_2.callback
  L5_2 = L5_2.await
  L6_2 = "osp_ambulance:getPlayerData"
  L7_2 = 100
  L8_2 = L4_2
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  L6_2 = {}
  L7_2 = pairs
  L8_2 = L5_2
  L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
  for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
    L13_2 = #L6_2
    L13_2 = L13_2 + 1
    L14_2 = {}
    L14_2.icon = "user"
    L15_2 = L12_2.name
    L14_2.title = L15_2
    L15_2 = lang
    L15_2 = L15_2.wheelchair
    L15_2 = L15_2.player_id
    L16_2 = " "
    L17_2 = L12_2.id
    L15_2 = L15_2 .. L16_2 .. L17_2
    L14_2.description = L15_2
    function L15_2()
      local L0_3, L1_3
      L0_3 = setCrutchTime
      L1_3 = L12_2.id
      L0_3(L1_3)
    end
    L14_2.onSelect = L15_2
    L6_2[L13_2] = L14_2
  end
  L7_2 = registerContext
  L8_2 = {}
  L8_2.id = "give_crutch_menu"
  L9_2 = lang
  L9_2 = L9_2.wheelchair
  L9_2 = L9_2.select_patient
  L8_2.title = L9_2
  L8_2.options = L6_2
  L7_2(L8_2)
  L7_2 = showContext
  L8_2 = "give_crutch_menu"
  L7_2(L8_2)
end
OpenCrutchMenu = L5_1
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = GetEntityCoords
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = lib
  L3_2 = L3_2.getNearbyPlayers
  L4_2 = vector3
  L5_2 = L2_2.x
  L6_2 = L2_2.y
  L7_2 = L2_2.z
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  L5_2 = 10.0
  L6_2 = false
  L3_2 = L3_2(L4_2, L5_2, L6_2)
  L4_2 = #L3_2
  if L4_2 < 1 then
    L4_2 = SendTextMessage
    L5_2 = lang
    L5_2 = L5_2.wheelchair
    L5_2 = L5_2.wheelchair
    L6_2 = lang
    L6_2 = L6_2.wheelchair
    L6_2 = L6_2.no_nearby
    L7_2 = 3000
    L8_2 = "error"
    L4_2(L5_2, L6_2, L7_2, L8_2)
    return
  end
  L4_2 = {}
  L5_2 = 1
  L6_2 = #L3_2
  L7_2 = 1
  for L8_2 = L5_2, L6_2, L7_2 do
    L9_2 = #L4_2
    L9_2 = L9_2 + 1
    L10_2 = {}
    L11_2 = GetPlayerServerId
    L12_2 = L3_2[L8_2]
    L12_2 = L12_2.id
    L11_2 = L11_2(L12_2)
    L10_2.id = L11_2
    L4_2[L9_2] = L10_2
  end
  L5_2 = lib
  L5_2 = L5_2.callback
  L5_2 = L5_2.await
  L6_2 = "osp_ambulance:getPlayerData"
  L7_2 = 100
  L8_2 = L4_2
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  L6_2 = {}
  L7_2 = pairs
  L8_2 = L5_2
  L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
  for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
    L13_2 = #L6_2
    L13_2 = L13_2 + 1
    L14_2 = {}
    L14_2.icon = "user"
    L15_2 = L12_2.name
    L14_2.title = L15_2
    L15_2 = lang
    L15_2 = L15_2.wheelchair
    L15_2 = L15_2.player_id
    L16_2 = " "
    L17_2 = L12_2.id
    L15_2 = L15_2 .. L16_2 .. L17_2
    L14_2.description = L15_2
    function L15_2()
      local L0_3, L1_3
      L0_3 = setWheelChairTime
      L1_3 = L12_2.id
      L0_3(L1_3)
    end
    L14_2.onSelect = L15_2
    L6_2[L13_2] = L14_2
  end
  L7_2 = registerContext
  L8_2 = {}
  L8_2.id = "give_WheelChair_menu"
  L9_2 = lang
  L9_2 = L9_2.wheelchair
  L9_2 = L9_2.select_patient
  L8_2.title = L9_2
  L8_2.options = L6_2
  L7_2(L8_2)
  L7_2 = showContext
  L8_2 = "give_WheelChair_menu"
  L7_2(L8_2)
end
OpenWheelChairMenu = L5_1
L5_1 = lib
L5_1 = L5_1.onCache
L6_1 = "vehicle"
function L7_1(A0_2)
  local L1_2
  L2_1 = A0_2
end
L5_1(L6_1, L7_1)
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerEvent
  L2_2 = "osp_ambulance:updateCrutch"
  L3_2 = false
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
RemoveCrutch = L5_1
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = TriggerServerEvent
  L3_2 = "osp_ambulance:giveCrutch"
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2(L3_2, L4_2, L5_2)
end
SetCrutchTime = L5_1
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerEvent
  L2_2 = "osp_ambulance:updateWheelChair"
  L3_2 = false
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
RemoveWheelChair = L5_1
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = TriggerServerEvent
  L3_2 = "osp_ambulance:giveWheelChair"
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2(L3_2, L4_2, L5_2)
end
SetWheelChairTime = L5_1
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = CreateThread
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3
    L0_3 = nil
    L1_3 = nil
    L2_3 = nil
    L3_3 = L0_1
    if L3_3 then
      L3_3 = true
      L1_1 = L3_3
    end
    L3_3 = SendTextMessage
    L4_3 = lang
    L4_3 = L4_3.wheelchair
    L4_3 = L4_3.crutch
    L5_3 = lang
    L5_3 = L5_3.wheelchair
    L5_3 = L5_3.time_remaining
    L6_3 = " "
    L7_3 = A0_2
    L8_3 = lang
    L8_3 = L8_3.wheelchair
    L8_3 = L8_3.minutes
    L5_3 = L5_3 .. L6_3 .. L7_3 .. L8_3
    L6_3 = 5000
    L7_3 = "success"
    L3_3(L4_3, L5_3, L6_3, L7_3)
    while true do
      L3_3 = 1000
      L4_3 = L1_1
      if true == L4_3 then
        L4_3 = ResetPedMovementClipset
        L5_3 = L1_2
        L4_3(L5_3)
        L4_3 = DoesEntityExist
        L5_3 = L2_3
        L4_3 = L4_3(L5_3)
        if L4_3 then
          L4_3 = DeleteObject
          L5_3 = L2_3
          L4_3(L5_3)
        end
        L4_3 = nil
        L0_1 = L4_3
        L4_3 = nil
        L1_1 = L4_3
        L4_3 = {}
        L3_1 = L4_3
        L4_3 = 0
        L4_1 = L4_3
        break
      end
      L4_3 = L0_1
      if not L4_3 then
        L4_3 = true
        L0_1 = L4_3
      end
      L4_3 = L3_1
      if not L4_3 then
        L4_3 = {}
        L3_1 = L4_3
      end
      L3_1.crutch = true
      if not L0_3 then
        L4_3 = GetPedMovementClipset
        L5_3 = L1_2
        L4_3 = L4_3(L5_3)
        L1_3 = L4_3
        L4_3 = table
        L4_3 = L4_3.unpack
        L5_3 = GetOffsetFromEntityInWorldCoords
        L6_3 = L1_2
        L7_3 = 0.0
        L8_3 = 2.0
        L9_3 = 0.55
        L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3 = L5_3(L6_3, L7_3, L8_3, L9_3)
        L4_3, L5_3, L6_3 = L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3)
        L7_3 = lib
        L7_3 = L7_3.requestModel
        L8_3 = "v_med_crutch01"
        L9_3 = 5000
        L7_3(L8_3, L9_3)
        L7_3 = CreateObjectNoOffset
        L8_3 = "v_med_crutch01"
        L9_3 = L4_3
        L10_3 = L5_3
        L11_3 = L6_3
        L12_3 = true
        L13_3 = false
        L7_3 = L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
        L2_3 = L7_3
        L7_3 = SetModelAsNoLongerNeeded
        L8_3 = "v_med_crutch01"
        L7_3(L8_3)
        L7_3 = SetCurrentPedWeapon
        L8_3 = L1_2
        L9_3 = -1569615261
        L7_3(L8_3, L9_3)
        L7_3 = AttachEntityToEntity
        L8_3 = L2_3
        L9_3 = L1_2
        L10_3 = GetPedBoneIndex
        L11_3 = L1_2
        L12_3 = 43810
        L10_3 = L10_3(L11_3, L12_3)
        L11_3 = 0.9
        L12_3 = -0.15
        L13_3 = -0.03
        L14_3 = 10.31
        L15_3 = -88.64
        L16_3 = 177.48
        L17_3 = true
        L18_3 = true
        L19_3 = false
        L20_3 = true
        L21_3 = 1
        L22_3 = true
        L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3, L22_3)
        L7_3 = lib
        L7_3 = L7_3.requestAnimSet
        L8_3 = "move_lester_caneup"
        L9_3 = 1000
        L7_3(L8_3, L9_3)
        L0_3 = true
      end
      L4_3 = L2_1
      if L4_3 then
        L4_3 = DoesEntityExist
        L5_3 = L2_3
        L4_3 = L4_3(L5_3)
        if L4_3 then
          L4_3 = DeleteObject
          L5_3 = L2_3
          L4_3(L5_3)
        end
      end
      L4_3 = DoesEntityExist
      L5_3 = L2_3
      L4_3 = L4_3(L5_3)
      if not L4_3 then
        L4_3 = L2_1
        if not L4_3 then
          L4_3 = lib
          L4_3 = L4_3.requestModel
          L5_3 = "v_med_crutch01"
          L6_3 = 5000
          L4_3(L5_3, L6_3)
          L4_3 = CreateObjectNoOffset
          L5_3 = "v_med_crutch01"
          L6_3 = x
          L7_3 = y
          L8_3 = z
          L9_3 = true
          L10_3 = false
          L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3)
          L2_3 = L4_3
          L4_3 = SetModelAsNoLongerNeeded
          L5_3 = "v_med_crutch01"
          L4_3(L5_3)
          L4_3 = AttachEntityToEntity
          L5_3 = L2_3
          L6_3 = L1_2
          L7_3 = GetPedBoneIndex
          L8_3 = L1_2
          L9_3 = 43810
          L7_3 = L7_3(L8_3, L9_3)
          L8_3 = 0.93
          L9_3 = -0.15
          L10_3 = -0.03
          L11_3 = 9.31
          L12_3 = -88.64
          L13_3 = 177.48
          L14_3 = true
          L15_3 = true
          L16_3 = false
          L17_3 = true
          L18_3 = 1
          L19_3 = true
          L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3)
        end
      end
      L4_3 = IsPedArmed
      L5_3 = L1_2
      L6_3 = 1
      L4_3 = L4_3(L5_3, L6_3)
      if not L4_3 then
        L4_3 = IsPedArmed
        L5_3 = L1_2
        L6_3 = 2
        L4_3 = L4_3(L5_3, L6_3)
        if not L4_3 then
          L4_3 = IsPedArmed
          L5_3 = L1_2
          L6_3 = 4
          L4_3 = L4_3(L5_3, L6_3)
          if not L4_3 then
            goto lbl_200
          end
        end
      end
      L4_3 = SetCurrentPedWeapon
      L5_3 = L1_2
      L6_3 = -1569615261
      L4_3(L5_3, L6_3)
      ::lbl_200::
      L4_3 = GetPedMovementClipset
      L5_3 = L1_2
      L4_3 = L4_3(L5_3)
      if L4_3 == L1_3 then
        L4_3 = SetPedMovementClipset
        L5_3 = L1_2
        L6_3 = "move_lester_caneup"
        L7_3 = 1.0
        L4_3(L5_3, L6_3, L7_3)
      end
      L4_3 = L4_1
      L4_3 = L4_3 + L3_3
      L4_1 = L4_3
      L4_3 = L4_1
      L5_3 = 60000
      if L4_3 >= L5_3 then
        L4_3 = TriggerServerEvent
        L5_3 = "osp_ambulance:updateCrutch"
        L6_3 = 1
        L7_3 = cache
        L7_3 = L7_3.serverId
        L4_3(L5_3, L6_3, L7_3)
        L4_3 = 0
        L4_1 = L4_3
      end
      L4_3 = Wait
      L5_3 = L3_3
      L4_3(L5_3)
    end
  end
  L2_2(L3_2)
end
StartCrutchLoop = L5_1
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = CreateThread
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L0_3 = nil
    L1_3 = L0_1
    if L1_3 then
      L1_3 = true
      L1_1 = L1_3
    end
    L1_3 = SendTextMessage
    L2_3 = lang
    L2_3 = L2_3.wheelchair
    L2_3 = L2_3.wheelchair
    L3_3 = lang
    L3_3 = L3_3.wheelchair
    L3_3 = L3_3.time_remaining
    L4_3 = A0_2
    L5_3 = lang
    L5_3 = L5_3.wheelchair
    L5_3 = L5_3.minutes
    L3_3 = L3_3 .. L4_3 .. L5_3
    L4_3 = 5000
    L5_3 = "success"
    L1_3(L2_3, L3_3, L4_3, L5_3)
    while true do
      L1_3 = NetworkGetEntityFromNetworkId
      L2_3 = L0_3
      L1_3 = L1_3(L2_3)
      L2_3 = GetEntitySpeed
      L3_3 = L1_3
      L2_3 = L2_3(L3_3)
      L3_3 = 0.1
      if L2_3 < L3_3 then
        L2_3 = IsControlPressed
        L3_3 = 0
        L4_3 = 71
        L2_3 = L2_3(L3_3, L4_3)
        if not L2_3 then
          L2_3 = IsControlPressed
          L3_3 = 0
          L4_3 = 63
          L2_3 = L2_3(L3_3, L4_3)
          if not L2_3 then
            L2_3 = IsControlPressed
            L3_3 = 0
            L4_3 = 72
            L2_3 = L2_3(L3_3, L4_3)
            if not L2_3 then
              L2_3 = IsControlPressed
              L3_3 = 0
              L4_3 = 64
              L2_3 = L2_3(L3_3, L4_3)
              if not L2_3 then
                goto lbl_60
              end
            end
          end
        end
        L2_3 = SetVehicleEngineOn
        L3_3 = L1_3
        L4_3 = true
        L5_3 = true
        L2_3(L3_3, L4_3, L5_3)
      end
      ::lbl_60::
      L2_3 = 1000
      L3_3 = L1_1
      if true == L3_3 then
        L3_3 = NetworkDoesEntityExistWithNetworkId
        L4_3 = L0_3
        L3_3 = L3_3(L4_3)
        if L3_3 then
          L3_3 = SetEntityAsMissionEntity
          L4_3 = NetworkGetEntityFromNetworkId
          L5_3 = L0_3
          L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L4_3(L5_3)
          L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
          L3_3 = DeleteVehicle
          L4_3 = NetworkGetEntityFromNetworkId
          L5_3 = L0_3
          L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L4_3(L5_3)
          L3_3(L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
        end
        L3_3 = nil
        L0_1 = L3_3
        L3_3 = nil
        L1_1 = L3_3
        L3_3 = {}
        L3_1 = L3_3
        L3_3 = 0
        L4_1 = L3_3
        break
      end
      L3_3 = L0_1
      if not L3_3 then
        L3_3 = true
        L0_1 = L3_3
      end
      L3_3 = L3_1
      if not L3_3 then
        L3_3 = {}
        L3_1 = L3_3
      end
      L3_1.WheelChair = true
      L3_3 = GetEntityHeading
      L4_3 = L1_2
      L3_3 = L3_3(L4_3)
      L4_3 = NetworkDoesEntityExistWithNetworkId
      L5_3 = L0_3
      L4_3 = L4_3(L5_3)
      if not L4_3 then
        L4_3 = L2_1
        if not L4_3 then
          L4_3 = GetEntityCoords
          L5_3 = L1_2
          L4_3 = L4_3(L5_3)
          L5_3 = -1963629913
          L6_3 = lib
          L6_3 = L6_3.requestModel
          L7_3 = "iak_WheelChair"
          L8_3 = 5000
          L6_3(L7_3, L8_3)
          L6_3 = Wait
          L7_3 = 100
          L6_3(L7_3)
          L6_3 = NetworkGetNetworkIdFromEntity
          L7_3 = CreateVehicle
          L8_3 = L5_3
          L9_3 = L4_3.x
          L10_3 = L4_3.y
          L11_3 = L4_3.z
          L12_3 = L3_3
          L13_3 = 1
          L14_3 = 0
          L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
          L6_3 = L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
          L0_3 = L6_3
          L6_3 = TaskWarpPedIntoVehicle
          L7_3 = L1_2
          L8_3 = NetworkGetEntityFromNetworkId
          L9_3 = L0_3
          L8_3 = L8_3(L9_3)
          L9_3 = -1
          L6_3(L7_3, L8_3, L9_3)
          L6_3 = GiveVehicleKeys
          L7_3 = NetworkGetEntityFromNetworkId
          L8_3 = L0_3
          L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L7_3(L8_3)
          L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
          L6_3 = SetModelAsNoLongerNeeded
          L7_3 = L5_3
          L6_3(L7_3)
          L6_3 = SetVehicleEngineOn
          L7_3 = NetworkGetEntityFromNetworkId
          L8_3 = L0_3
          L7_3 = L7_3(L8_3)
          L8_3 = true
          L9_3 = true
          L6_3(L7_3, L8_3, L9_3)
          L6_3 = FullFuel
          L7_3 = NetworkGetEntityFromNetworkId
          L8_3 = L0_3
          L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L7_3(L8_3)
          L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
      end
      else
        L4_3 = L2_1
        if not L4_3 then
          L4_3 = GetEntityCoords
          L5_3 = NetworkGetEntityFromNetworkId
          L6_3 = L0_3
          L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L5_3(L6_3)
          L4_3 = L4_3(L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
          L5_3 = SetEntityCoords
          L6_3 = NetworkGetEntityFromNetworkId
          L7_3 = L0_3
          L6_3 = L6_3(L7_3)
          L7_3 = L4_3.x
          L8_3 = L4_3.y
          L9_3 = L4_3.z
          L9_3 = L9_3 + 1.0
          L10_3 = true
          L11_3 = false
          L12_3 = false
          L13_3 = false
          L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
          L5_3 = SetVehicleOnGroundProperly
          L6_3 = NetworkGetEntityFromNetworkId
          L7_3 = L0_3
          L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L6_3(L7_3)
          L5_3(L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
          L5_3 = TaskWarpPedIntoVehicle
          L6_3 = L1_2
          L7_3 = NetworkGetEntityFromNetworkId
          L8_3 = L0_3
          L7_3 = L7_3(L8_3)
          L8_3 = -1
          L5_3(L6_3, L7_3, L8_3)
        end
      end
      L4_3 = IsPedArmed
      L5_3 = L1_2
      L6_3 = 1
      L4_3 = L4_3(L5_3, L6_3)
      if not L4_3 then
        L4_3 = IsPedArmed
        L5_3 = L1_2
        L6_3 = 2
        L4_3 = L4_3(L5_3, L6_3)
        if not L4_3 then
          L4_3 = IsPedArmed
          L5_3 = L1_2
          L6_3 = 4
          L4_3 = L4_3(L5_3, L6_3)
          if not L4_3 then
            goto lbl_220
          end
        end
      end
      L4_3 = SetCurrentPedWeapon
      L5_3 = L1_2
      L6_3 = -1569615261
      L4_3(L5_3, L6_3)
      ::lbl_220::
      L4_3 = L4_1
      L4_3 = L4_3 + L2_3
      L4_1 = L4_3
      L4_3 = L4_1
      L5_3 = 60000
      if L4_3 >= L5_3 then
        L4_3 = TriggerServerEvent
        L5_3 = "osp_ambulance:updateWheelChair"
        L6_3 = 1
        L7_3 = cache
        L7_3 = L7_3.serverId
        L4_3(L5_3, L6_3, L7_3)
        L4_3 = 0
        L4_1 = L4_3
      end
      L4_3 = Wait
      L5_3 = L2_3
      L4_3(L5_3)
    end
  end
  L2_2(L3_2)
end
StartWheelChairLoop = L5_1
L5_1 = CreateThread
function L6_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  while true do
    L0_2 = PlayerPedId
    L0_2 = L0_2()
    L1_2 = 1500
    L2_2 = L3_1
    if L2_2 then
      L2_2 = L2_2.crutch
    end
    if L2_2 then
      L1_2 = 1
      L2_2 = DisableControlAction
      L3_2 = 0
      L4_2 = 21
      L5_2 = true
      L2_2(L3_2, L4_2, L5_2)
      L2_2 = DisableControlAction
      L3_2 = 0
      L4_2 = 22
      L5_2 = true
      L2_2(L3_2, L4_2, L5_2)
      L2_2 = DisablePlayerFiring
      L3_2 = L0_2
      L4_2 = true
      L2_2(L3_2, L4_2)
    end
    L2_2 = L3_1
    if L2_2 then
      L2_2 = L2_2.WheelChair
    end
    if L2_2 then
      L1_2 = 1
      L2_2 = DisableControlAction
      L3_2 = 0
      L4_2 = 75
      L5_2 = true
      L2_2(L3_2, L4_2, L5_2)
      L2_2 = DisableControlAction
      L3_2 = 27
      L4_2 = 75
      L5_2 = true
      L2_2(L3_2, L4_2, L5_2)
      L2_2 = DisablePlayerFiring
      L3_2 = L0_2
      L4_2 = true
      L2_2(L3_2, L4_2)
    end
    L2_2 = Wait
    L3_2 = L1_2
    L2_2(L3_2)
  end
end
L5_1(L6_1)
