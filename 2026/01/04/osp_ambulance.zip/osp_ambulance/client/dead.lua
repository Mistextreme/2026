local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1
L0_1 = 5
deathTime = 0
peripheralResistance = 100
L1_1 = 0.095
L2_1 = 9.4736842
L3_1 = 6.3157894
L4_1 = false
L5_1 = false
L6_1 = {}
L6_1.HEAD = "Head"
L6_1.NECK = "Head"
L6_1.SPINE = "Torso"
L6_1.UPPER_BODY = "Torso"
L6_1.LOWER_BODY = "Torso"
L6_1.LARM = "Larm"
L6_1.LHAND = "Larm"
L6_1.LFINGER = "Larm"
L6_1.LLEG = "Lleg"
L6_1.LFOOT = "Lleg"
L6_1.RARM = "Rarm"
L6_1.RHAND = "Rarm"
L6_1.RFINGER = "Rarm"
L6_1.RLEG = "Rleg"
L6_1.RFOOT = "Rleg"
BodyPartsType = L6_1
function L6_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  if A0_2 then
    L1_2 = {}
    L2_2 = pairs
    L3_2 = A0_2
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2 in L2_2, L3_2, L4_2, L5_2 do
      L7_2 = #L1_2
      L7_2 = L7_2 + 1
      L1_2[L7_2] = L6_2
    end
    L2_2 = math
    L2_2 = L2_2.random
    L3_2 = 1
    L4_2 = #L1_2
    L2_2 = L2_2(L3_2, L4_2)
    L3_2 = L1_2[L2_2]
    L3_2 = A0_2[L3_2]
    return L3_2
  else
    L1_2 = nil
    L2_2 = nil
    return L1_2, L2_2
  end
end
getRandomBodyPart = L6_1
L6_1 = {}
L7_1 = lang
L7_1 = L7_1.body
L7_1 = L7_1.head
L6_1.Head = L7_1
L7_1 = lang
L7_1 = L7_1.body
L7_1 = L7_1.torso
L6_1.Torso = L7_1
L7_1 = lang
L7_1 = L7_1.body
L7_1 = L7_1.larm
L6_1.Larm = L7_1
L7_1 = lang
L7_1 = L7_1.body
L7_1 = L7_1.rarm
L6_1.Rarm = L7_1
L7_1 = lang
L7_1 = L7_1.body
L7_1 = L7_1.lleg
L6_1.Lleg = L7_1
L7_1 = lang
L7_1 = L7_1.body
L7_1 = L7_1.rleg
L6_1.Rleg = L7_1
BodyPartTranslations = L6_1
L6_1 = nil
L7_1 = 0
lastDeadState = false
L8_1 = CreateThread
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  while true do
    L0_2 = Wait
    L1_2 = Config
    L1_2 = L1_2.AntiCombatLogLoop
    L0_2(L1_2)
    L0_2 = PlayerLoaded
    if L0_2 then
      L0_2 = BodyDamage
      L0_2 = L0_2.isDead
      if not L0_2 then
        L0_2 = BodyDamage
        L0_2 = L0_2.inLastStand
      end
      if L0_2 then
        L1_2 = lastDeadState
        if not L1_2 then
          L1_2 = DebugPrint
          L2_2 = "Save wound data"
          L3_2 = BodyDamage
          L3_2 = L3_2.inLastStand
          L4_2 = BodyDamage
          L4_2 = L4_2.isDead
          L1_2(L2_2, L3_2, L4_2)
          L1_2 = TriggerServerEvent
          L2_2 = "osp_ambulance:saveWoundDataSv"
          L3_2 = BodyDamage
          L1_2(L2_2, L3_2)
          lastDeadState = true
          L1_2 = TriggerServerEvent
          L2_2 = "hospital:server:SetArmourStatus"
          L3_2 = BodyDamage
          L3_2 = L3_2.playerArmour
          L1_2(L2_2, L3_2)
          L1_2 = TriggerServerEvent
          L2_2 = "osp_ambulance:RetreivePlayerDamageData"
          L3_2 = BodyDamage
          L1_2(L2_2, L3_2)
      end
      elseif not L0_2 then
        L1_2 = lastDeadState
        if L1_2 then
          L1_2 = DebugPrint
          L2_2 = "Save wound data"
          L3_2 = BodyDamage
          L3_2 = L3_2.inLastStand
          L4_2 = BodyDamage
          L4_2 = L4_2.isDead
          L1_2(L2_2, L3_2, L4_2)
          L1_2 = TriggerServerEvent
          L2_2 = "osp_ambulance:saveWoundDataSv"
          L3_2 = BodyDamage
          L1_2(L2_2, L3_2)
          lastDeadState = false
          L1_2 = TriggerServerEvent
          L2_2 = "hospital:server:SetArmourStatus"
          L3_2 = BodyDamage
          L3_2 = L3_2.playerArmour
          L1_2(L2_2, L3_2)
          L1_2 = TriggerServerEvent
          L2_2 = "osp_ambulance:RetreivePlayerDamageData"
          L3_2 = BodyDamage
          L1_2(L2_2, L3_2)
        end
      end
    end
  end
end
L8_1(L9_1)
L8_1 = CreateThread
function L9_1()
  local L0_2, L1_2
  while true do
    L0_2 = Wait
    L1_2 = 5000
    L0_2(L1_2)
    L0_2 = updateBloodLoss
    L0_2()
  end
end
L8_1(L9_1)
L8_1 = CreateThread
function L9_1()
  local L0_2, L1_2, L2_2
  while true do
    L0_2 = Wait
    L1_2 = 5000
    L0_2(L1_2)
    L0_2 = PlayerLoaded
    if L0_2 then
      L0_2 = BodyDamage
      L0_2 = L0_2.playerHealth
      if L0_2 then
        L0_2 = BodyDamage
        L1_2 = GetEntityHealth
        L2_2 = PlayerPedId
        L2_2 = L2_2()
        L1_2 = L1_2(L2_2)
        L0_2.playerHealth = L1_2
        L0_2 = BodyDamage
        L1_2 = GetPedArmour
        L2_2 = PlayerPedId
        L2_2 = L2_2()
        L1_2 = L1_2(L2_2)
        L0_2.playerArmour = L1_2
      end
    end
  end
end
L8_1(L9_1)
L8_1 = CreateThread
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  while true do
    L0_2 = Wait
    L1_2 = Config
    L1_2 = L1_2.HealthRegenUpdate
    L0_2(L1_2)
    L0_2 = BodyDamage
    L0_2 = L0_2.isDead
    if not L0_2 then
      L0_2 = BodyDamage
      L0_2 = L0_2.inLastStand
      if not L0_2 then
        L0_2 = BodyDamage
        L0_2 = L0_2.Pulse
        if L0_2 > 30 then
          L0_2 = BodyDamage
          L0_2 = L0_2.Pulse
          L1_2 = 200
          if L0_2 < L1_2 then
            L0_2 = BodyDamage
            L0_2 = L0_2.BloodPressure
            L0_2 = L0_2[1]
            L1_2 = 160
            if L0_2 < L1_2 then
              L0_2 = BodyDamage
              L0_2 = L0_2.BloodPressure
              L0_2 = L0_2[1]
              if L0_2 > 80 then
                L0_2 = false
                L1_2 = pairs
                L2_2 = BodyDamage
                L2_2 = L2_2.BodyPartDamage
                L2_2 = L2_2.DamageType
                L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
                for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
                  L7_2 = BodyDamage
                  L7_2 = L7_2.BodyPartDamage
                  L7_2 = L7_2.DamageType
                  L7_2 = L7_2[L5_2]
                  if L7_2 > 0 then
                    L0_2 = true
                  end
                end
                if not L0_2 then
                  L1_2 = GetEntityHealth
                  L2_2 = PlayerPedId
                  L2_2, L3_2, L4_2, L5_2, L6_2, L7_2 = L2_2()
                  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
                  L2_2 = 200
                  if L1_2 < L2_2 then
                    L2_2 = SetEntityHealth
                    L3_2 = PlayerPedId
                    L3_2 = L3_2()
                    L4_2 = Config
                    L4_2 = L4_2.HealthRegen
                    L4_2 = L1_2 + L4_2
                    L2_2(L3_2, L4_2)
                  end
                  L2_2 = BodyDamage
                  L2_2 = L2_2.BodyPartDamage
                  L2_2 = L2_2.BloodLevel
                  if L2_2 < 6.0 then
                    L2_2 = BodyDamage
                    L2_2 = L2_2.BodyPartDamage
                    L3_2 = BodyDamage
                    L3_2 = L3_2.BodyPartDamage
                    L3_2 = L3_2.BloodLevel
                    L3_2 = L3_2 + 0.001
                    L2_2.BloodLevel = L3_2
                  end
                  L2_2 = BodyDamage
                  L2_2 = L2_2.Pain
                  if L2_2 > 0 then
                    L2_2 = BodyDamage
                    L3_2 = BodyDamage
                    L3_2 = L3_2.Pain
                    L3_2 = L3_2 - 0.1
                    L2_2.Pain = L3_2
                  end
                  L2_2 = LocalPlayer
                  L2_2 = L2_2.state
                  L3_2 = L2_2
                  L2_2 = L2_2.set
                  L4_2 = "BodyDamage"
                  L5_2 = BodyDamage
                  L6_2 = true
                  L2_2(L3_2, L4_2, L5_2, L6_2)
                end
              end
            end
          end
        end
      end
    end
  end
end
L8_1(L9_1)
L8_1 = CreateThread
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  while true do
    L0_2 = Wait
    L1_2 = Config
    L1_2 = L1_2.HealthDegenUpdate
    L0_2(L1_2)
    L0_2 = BodyDamage
    L0_2 = L0_2.isDead
    if not L0_2 then
      L0_2 = BodyDamage
      L0_2 = L0_2.inLastStand
      if not L0_2 then
        L0_2 = BodyDamage
        L0_2 = L0_2.BodyPartDamage
        L0_2 = L0_2.BloodLevel
        if L0_2 > 1 then
          L0_2 = L7_1
          L1_2 = Config
          L1_2 = L1_2.MinimumBleedAmountBeforeHealthDegen
          if L0_2 > L1_2 then
            L0_2 = GetEntityHealth
            L1_2 = PlayerPedId
            L1_2, L2_2, L3_2, L4_2 = L1_2()
            L0_2 = L0_2(L1_2, L2_2, L3_2, L4_2)
            if L0_2 > 10 then
              L1_2 = SetEntityHealth
              L2_2 = PlayerPedId
              L2_2 = L2_2()
              L3_2 = Config
              L3_2 = L3_2.HealthBleedingDegen
              L3_2 = L0_2 - L3_2
              L1_2(L2_2, L3_2)
            end
          end
          L0_2 = LocalPlayer
          L0_2 = L0_2.state
          L1_2 = L0_2
          L0_2 = L0_2.set
          L2_2 = "BodyDamage"
          L3_2 = BodyDamage
          L4_2 = true
          L0_2(L1_2, L2_2, L3_2, L4_2)
        end
      end
    end
  end
end
L8_1(L9_1)
L8_1 = CreateThread
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  while true do
    L0_2 = Wait
    L1_2 = Config
    L1_2 = L1_2.BleedingUpdate
    L0_2(L1_2)
    L0_2 = BodyDamage
    L0_2 = L0_2.BodyPartDamage
    L0_2 = L0_2.BloodLevel
    if L0_2 > 1 then
      L0_2 = BodyDamage
      L0_2 = L0_2.BodyPartDamage
      L1_2 = BodyDamage
      L1_2 = L1_2.BodyPartDamage
      L1_2 = L1_2.BloodLevel
      L2_2 = L7_1
      L1_2 = L1_2 - L2_2
      L0_2.BloodLevel = L1_2
      L0_2 = LocalPlayer
      L0_2 = L0_2.state
      L1_2 = L0_2
      L0_2 = L0_2.set
      L2_2 = "BodyDamage"
      L3_2 = BodyDamage
      L4_2 = true
      L0_2(L1_2, L2_2, L3_2, L4_2)
    end
  end
end
L8_1(L9_1)
function L8_1(A0_2)
  local L1_2, L2_2
  L1_2 = CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
    L0_3 = nil
    L1_3 = A0_2
    if L1_3 then
      L1_3 = BodyDamage
      L1_3 = L1_3.Pulse
      L1_3 = L1_3 * 1.5
      targetPulse = L1_3
    else
      L1_3 = BodyDamage
      L1_3 = L1_3.Pulse
      L1_3 = L1_3 / 2
      targetPulse = L1_3
    end
    while true do
      L1_3 = BodyDamage
      L1_3 = L1_3.Pulse
      L2_3 = targetPulse
      L2_3 = L2_3 - L1_3
      L3_3 = L2_3 * 0.1
      L4_3 = targetPulse
      if L1_3 >= L4_3 then
        break
      end
      L4_3 = math
      L4_3 = L4_3.abs
      L5_3 = L2_3
      L4_3 = L4_3(L5_3)
      L5_3 = 0.5
      if L4_3 < L5_3 then
        break
      end
      L4_3 = 250
      if L1_3 >= L4_3 then
        break
      end
      L4_3 = L1_3 + L3_3
      L1_3 = L4_3 + 0.5
      L4_3 = BodyDamage
      L4_3 = L4_3.isDead
      if L4_3 then
        L4_3 = BodyDamage
        L4_3.Pulse = 0
        L4_3 = BodyDamage
        L4_3.cardiacState = "asystole"
        L4_3 = LocalPlayer
        L4_3 = L4_3.state
        L5_3 = L4_3
        L4_3 = L4_3.set
        L6_3 = "BodyDamage"
        L7_3 = BodyDamage
        L8_3 = true
        L4_3(L5_3, L6_3, L7_3, L8_3)
        break
      else
        L4_3 = BodyDamage
        L4_3 = L4_3.inLastStand
        if L4_3 then
          L4_3 = BodyDamage
          L5_3 = BodyDamage
          L5_3 = L5_3.Pulse
          L5_3 = L5_3 / 2
          L4_3.Pulse = L5_3
          L4_3 = LocalPlayer
          L4_3 = L4_3.state
          L5_3 = L4_3
          L4_3 = L4_3.set
          L6_3 = "BodyDamage"
          L7_3 = BodyDamage
          L8_3 = true
          L4_3(L5_3, L6_3, L7_3, L8_3)
          break
        end
      end
      L4_3 = BodyDamage
      L4_3.Pulse = L1_3
      L4_3 = LocalPlayer
      L4_3 = L4_3.state
      L5_3 = L4_3
      L4_3 = L4_3.set
      L6_3 = "BodyDamage"
      L7_3 = BodyDamage
      L8_3 = true
      L4_3(L5_3, L6_3, L7_3, L8_3)
      L4_3 = Wait
      L5_3 = 1000
      L4_3(L5_3)
    end
  end
  L1_2(L2_2)
end
ChangeBPM = L8_1
L8_1 = CreateThread
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = Wait
  L1_2 = 1000
  L0_2(L1_2)
  while true do
    L0_2 = BodyDamage
    L0_2 = L0_2.Pulse
    if L0_2 > 30 then
      L0_2 = BodyDamage
      L0_2 = L0_2.BloodPressure
      L0_2 = L0_2[1]
      if L0_2 > 0 then
        L0_2 = BodyDamage
        L0_2 = L0_2.BloodPressure
        L0_2 = L0_2[2]
        if L0_2 > 0 then
          L0_2 = BodyDamage
          L0_2 = L0_2.BloodPressure
          L1_2 = L0_2[1]
          L0_2 = BodyDamage
          L0_2 = L0_2.BloodPressure
          L0_2 = L0_2[2]
          L2_2 = false
          if L1_2 < 70 then
            if L0_2 < 40 then
              L2_2 = true
            end
          end
          if L1_2 > 180 then
            if L0_2 > 120 then
              L2_2 = true
            end
          end
          L0_2 = BodyDamage
          L0_2 = L0_2.Pain
          L1_2 = Config
          L1_2 = L1_2.PainThreshold
          if L2_2 and L0_2 >= L1_2 then
                L0_2 = BodyDamage
                L0_2 = L0_2.Pulse
                L1_2 = 200
                if L0_2 < L1_2 then
                  L0_2 = BodyDamage
                  L0_2 = L0_2.cardiacState
                  if "NSR" == L0_2 then
                    L0_2 = BodyDamage
                    L0_2 = L0_2.BloodPressure
                    L0_2 = L0_2[1]
                    if L0_2 < 70 then
                      L0_2 = ChangeBPM
                      L1_2 = true
                      L0_2(L1_2)
                      L0_2 = Wait
                      L1_2 = 15000
                      L0_2(L1_2)
                      L0_2 = BodyDamage
                      L0_2 = L0_2.Pulse
                      L1_2 = 170
                      if L0_2 > L1_2 then
                        L0_2 = BodyDamage
                        L0_2.cardiacState = "torsades"
                      end
                    else
                      L0_2 = math
                      L0_2 = L0_2.random
                      L1_2 = 1
                      L2_2 = 2
                      L0_2 = L0_2(L1_2, L2_2)
                      if 1 == L0_2 then
                        L1_2 = BodyDamage
                        L1_2.cardiacState = "torsades"
                      else
                        L1_2 = BodyDamage
                        L1_2.cardiacState = "vFib"
                        L1_2 = BodyDamage
                        L1_2.Pulse = 200
                        L1_2 = Wait
                        L2_2 = 28000
                        L1_2(L2_2)
                        L1_2 = BodyDamage
                        L1_2.cardiacState = "asystole"
                        L1_2 = BodyDamage
                        L1_2.Pulse = 0
                      end
                    end
                  end
                end
              end
            end
          end
          L0_2 = BodyDamage
          L0_2 = L0_2.Pulse
          if L0_2 < 120 then
            L0_2 = BodyDamage
            L0_2 = L0_2.Pulse
            if L0_2 > 40 then
              L0_2 = BodyDamage
              L0_2 = L0_2.BloodPressure
              L0_2 = L0_2[1]
              if L0_2 > 70 then
                L0_2 = BodyDamage
                L0_2 = L0_2.BloodPressure
                L0_2 = L0_2[2]
                if L0_2 > 40 then
                  L0_2 = BodyDamage
                  L0_2 = L0_2.BloodPressure
                  L0_2 = L0_2[1]
                  L1_2 = 180
                  if L0_2 < L1_2 then
                    L0_2 = BodyDamage
                    L0_2 = L0_2.BloodPressure
                    L0_2 = L0_2[2]
                    if L0_2 < 120 then
                      L0_2 = BodyDamage
                      L0_2.cardiacState = "NSR"
                    end
                  end
                end
              end
            end
          end
          L0_2 = BodyDamage
          L0_2 = L0_2.cardiacState
          if "NSR" == L0_2 then
            L0_2 = BodyDamage
            L0_2 = L0_2.Pulse
            L1_2 = 170
            if L0_2 > L1_2 then
              L0_2 = BodyDamage
              L0_2.cardiacState = "torsades"
            end
          end
      end
    end
    else
      L0_2 = BodyDamage
      L0_2 = L0_2.BloodPressure
      L0_2 = L0_2[1]
      if 0 ~= L0_2 then
        L0_2 = BodyDamage
        L0_2 = L0_2.Pulse
        if 0 ~= L0_2 then
          goto lbl_162
        end
      end
      L0_2 = BodyDamage
      L0_2 = L0_2.inLastStand
      if L0_2 then
        L0_2 = BodyDamage
        L0_2 = L0_2.isDead
        if not L0_2 then
          L0_2 = DebugPrint
          L1_2 = "killing player due to critical condition"
          L0_2(L1_2)
          L0_2 = SetEntityHealth
          L1_2 = PlayerPedId
          L1_2 = L1_2()
          L2_2 = 0
          L0_2(L1_2, L2_2)
        end
      end
      ::lbl_162::
      L0_2 = BodyDamage
      L0_2 = L0_2.inLastStand
      if not L0_2 then
        L0_2 = BodyDamage
        L0_2 = L0_2.BloodPressure
        L0_2[1] = 0
        L0_2 = BodyDamage
        L0_2 = L0_2.BloodPressure
        L0_2[2] = 0
        L0_2 = BodyDamage
        L0_2.Pulse = 0
        L0_2 = BodyDamage
        L0_2.cardiacState = "asystole"
        L0_2 = BodyDamage
        L0_2.Conscious = false
      end
      L0_2 = BodyDamage
      L0_2 = L0_2.isDead
      if not L0_2 then
        L0_2 = BodyDamage
        L0_2 = L0_2.inLastStand
        if not L0_2 then
          L0_2 = Config
          L0_2 = L0_2.KillPlayerInCriticalCondition
          if L0_2 then
            L0_2 = DebugPrint
            L1_2 = "killing player due to critical condition"
            L0_2(L1_2)
            L0_2 = SetEntityHealth
            L1_2 = PlayerPedId
            L1_2 = L1_2()
            L2_2 = 0
            L0_2(L1_2, L2_2)
          end
        end
      end
    end
    L0_2 = BodyDamage
    L0_2 = L0_2.cardiacState
    if "asystole" == L0_2 then
      L0_2 = BodyDamage
      L0_2.Pulse = 0
    end
    L0_2 = LocalPlayer
    L0_2 = L0_2.state
    L1_2 = L0_2
    L0_2 = L0_2.set
    L2_2 = "BodyDamage"
    L3_2 = BodyDamage
    L4_2 = true
    L0_2(L1_2, L2_2, L3_2, L4_2)
    L0_2 = Wait
    L1_2 = 3000
    L0_2(L1_2)
  end
end
L8_1(L9_1)
L8_1 = CreateThread
function L9_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L0_2 = false
  L1_2 = {}
  L2_2 = {}
  L3_2 = false
  L4_2 = false
  while true do
    L5_2 = Wait
    L6_2 = 3000
    L5_2(L6_2)
    L5_2 = getBloodPressure
    L5_2 = L5_2()
    L2_2 = L5_2
    L5_2 = L2_2[1]
    L6_2 = 200
    if L5_2 < L6_2 then
      L5_2 = L2_2[2]
      L6_2 = 130
      if L5_2 < L6_2 then
        L5_2 = BodyDamage
        L6_2 = getBloodPressure
        L6_2 = L6_2()
        L5_2.BloodPressure = L6_2
      end
    end
    L5_2 = LocalPlayer
    L5_2 = L5_2.state
    L6_2 = L5_2
    L5_2 = L5_2.set
    L7_2 = "BodyDamage"
    L8_2 = BodyDamage
    L9_2 = true
    L5_2(L6_2, L7_2, L8_2, L9_2)
    L5_2 = BodyDamage
    L5_2 = L5_2.isDead
    if not L5_2 then
      L5_2 = BodyDamage
      L5_2 = L5_2.inLastStand
    end
    if L5_2 and L3_2 then
      L3_2 = false
      L0_2 = false
      L5_2 = SendNUIMessage
      L6_2 = {}
      L6_2.blackout = 4
      L5_2(L6_2)
    end
    L5_2 = BodyDamage
    L5_2 = L5_2.isDead
    if not L5_2 then
      L5_2 = BodyDamage
      L5_2 = L5_2.inLastStand
      if not L5_2 then
        L5_2 = BodyDamage
        L5_2 = L5_2.BloodPressure
        L5_2 = L5_2[1]
        if not (L5_2 < 70) or false ~= L0_2 then
          L5_2 = BodyDamage
          L5_2 = L5_2.BloodPressure
          L5_2 = L5_2[2]
          if not (L5_2 < 40) or false ~= L0_2 then
            goto lbl_89
          end
        end
        L0_2 = true
        L3_2 = true
        L5_2 = BodyDamage
        L1_2 = L5_2.BloodPressure
        L5_2 = Config
        L5_2 = L5_2.BlackoutEffect
        if L5_2 then
          L5_2 = SendNUIMessage
          L6_2 = {}
          L6_2.blackout = 1
          L5_2(L6_2)
        end
        L5_2 = CreateThread
        function L6_2()
          local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
          L0_3 = 1
          L1_3 = 10
          L2_3 = 1
          for L3_3 = L0_3, L1_3, L2_3 do
            L4_3 = BodyDamage
            L4_3 = L4_3.oxygenSaturation
            if L4_3 > 80 then
              L4_3 = BodyDamage
              L5_3 = BodyDamage
              L5_3 = L5_3.oxygenSaturation
              L5_3 = L5_3 - 1
              L4_3.oxygenSaturation = L5_3
            end
            L4_3 = Wait
            L5_3 = 1000
            L4_3(L5_3)
          end
        end
        L5_2(L6_2)
        goto lbl_150
        ::lbl_89::
        L5_2 = BodyDamage
        L5_2 = L5_2.BloodPressure
        L5_2 = L5_2[1]
        L6_2 = 180
        if not (L5_2 > L6_2) or false ~= L0_2 then
          L5_2 = BodyDamage
          L5_2 = L5_2.BloodPressure
          L5_2 = L5_2[2]
          if not (L5_2 > 120) or false ~= L0_2 then
            goto lbl_121
          end
        end
        L0_2 = true
        L3_2 = true
        L5_2 = BodyDamage
        L1_2 = L5_2.BloodPressure
        L5_2 = Config
        L5_2 = L5_2.BlackoutEffect
        if L5_2 then
          L5_2 = SendNUIMessage
          L6_2 = {}
          L6_2.blackout = 1
          L5_2(L6_2)
        end
        L5_2 = CreateThread
        function L6_2()
          local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
          L0_3 = 1
          L1_3 = 10
          L2_3 = 1
          for L3_3 = L0_3, L1_3, L2_3 do
            L4_3 = BodyDamage
            L4_3 = L4_3.oxygenSaturation
            if L4_3 > 80 then
              L4_3 = BodyDamage
              L5_3 = BodyDamage
              L5_3 = L5_3.oxygenSaturation
              L5_3 = L5_3 - 1
              L4_3.oxygenSaturation = L5_3
            end
            L4_3 = Wait
            L5_3 = 1000
            L4_3(L5_3)
          end
        end
        L5_2(L6_2)
        goto lbl_150
        ::lbl_121::
        L5_2 = BodyDamage
        L5_2 = L5_2.Pain
        L6_2 = Config
        L6_2 = L6_2.PainThreshold
        if L5_2 > L6_2 and not L3_2 then
          L5_2 = 1
          L6_2 = 8
          L7_2 = 1
          for L8_2 = L5_2, L6_2, L7_2 do
            if not L3_2 then
              L9_2 = Config
              L9_2 = L9_2.PainEffect
              if L9_2 then
                L9_2 = SendNUIMessage
                L10_2 = {}
                L11_2 = BodyDamage
                L11_2 = L11_2.Pain
                L10_2.pain = L11_2
                L9_2(L10_2)
              end
              L9_2 = Wait
              L10_2 = 250
              L9_2(L10_2)
            end
          end
        end
        ::lbl_150::
        L5_2 = L1_2[1]
        if L5_2 then
          L5_2 = BodyDamage
          L5_2 = L5_2.BloodPressure
          L5_2 = L5_2[1]
          L6_2 = L1_2[1]
          if L5_2 == L6_2 then
            L5_2 = BodyDamage
            L5_2 = L5_2.BloodPressure
            L5_2 = L5_2[2]
            L6_2 = L1_2[2]
            if L5_2 == L6_2 then
              goto lbl_304
            end
          end
          L5_2 = BodyDamage
          L1_2 = L5_2.BloodPressure
          L5_2 = BodyDamage
          L5_2 = L5_2.BloodPressure
          L5_2 = L5_2[1]
          if not (L5_2 < 60) then
            L5_2 = BodyDamage
            L5_2 = L5_2.BloodPressure
            L5_2 = L5_2[2]
            if not (L5_2 < 30) then
              L5_2 = BodyDamage
              L5_2 = L5_2.BloodPressure
              L5_2 = L5_2[1]
              L6_2 = 190
              if not (L5_2 > L6_2) then
                L5_2 = BodyDamage
                L5_2 = L5_2.BloodPressure
                L5_2 = L5_2[2]
                L6_2 = 130
                if not (L5_2 > L6_2) then
                  goto lbl_247
                end
              end
            end
          end
          if not L3_2 then
            L5_2 = Config
            L5_2 = L5_2.BlackoutEffect
            if L5_2 then
              L5_2 = SendNUIMessage
              L6_2 = {}
              L6_2.blackout = 1
              L5_2(L6_2)
            end
          end
          L5_2 = BodyDamage
          L5_2 = L5_2.BodyPartDamage
          L5_2 = L5_2.BloodLevel
          L6_2 = 4.5
          if L5_2 < L6_2 then
            L5_2 = Config
            L5_2 = L5_2.BlackoutEffect
            if L5_2 then
              L5_2 = SendNUIMessage
              L6_2 = {}
              L6_2.blackout = 2
              L5_2(L6_2)
            end
          end
          L5_2 = CreateThread
          function L6_2()
            local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
            L0_3 = 1
            L1_3 = 15
            L2_3 = 1
            for L3_3 = L0_3, L1_3, L2_3 do
              L4_3 = BodyDamage
              L4_3 = L4_3.oxygenSaturation
              if L4_3 > 70 then
                L4_3 = BodyDamage
                L5_3 = BodyDamage
                L5_3 = L5_3.oxygenSaturation
                L5_3 = L5_3 - 1
                L4_3.oxygenSaturation = L5_3
              end
              L4_3 = Wait
              L5_3 = 1000
              L4_3(L5_3)
            end
          end
          L5_2(L6_2)
          L5_2 = BodyDamage
          L5_2 = L5_2.Pulse
          if L5_2 < 50 and not L4_2 then
            L4_2 = true
            L5_2 = SendNUIMessage
            L6_2 = {}
            L6_2.slowheartbeat = true
            L5_2(L6_2)
          else
            L5_2 = BodyDamage
            L5_2 = L5_2.Pulse
            if L5_2 > 120 and not L4_2 then
              L4_2 = true
              L5_2 = SendNUIMessage
              L6_2 = {}
              L6_2.rapidheartbeat = true
              L5_2(L6_2)
            end
          end
          L5_2 = Wait
          L6_2 = 60000
          L5_2(L6_2)
          goto lbl_304
          ::lbl_247::
          L5_2 = Config
          L5_2 = L5_2.BlackoutEffect
          if L5_2 then
            L5_2 = SendNUIMessage
            L6_2 = {}
            L6_2.blackout = 3
            L5_2(L6_2)
          end
          L5_2 = BodyDamage
          L5_2 = L5_2.Pulse
          if L5_2 < 50 and not L4_2 then
            L4_2 = true
            L5_2 = SendNUIMessage
            L6_2 = {}
            L6_2.slowheartbeat = true
            L5_2(L6_2)
          else
            L5_2 = BodyDamage
            L5_2 = L5_2.Pulse
            if L5_2 > 120 and not L4_2 then
              L4_2 = true
              L5_2 = SendNUIMessage
              L6_2 = {}
              L6_2.rapidheartbeat = true
              L5_2(L6_2)
            end
          end
          L5_2 = Wait
          L6_2 = 40000
          L5_2(L6_2)
          L5_2 = BodyDamage
          L5_2 = L5_2.isDead
          if not L5_2 then
            L5_2 = BodyDamage
            L5_2 = L5_2.inLastStand
            if not L5_2 then
              goto lbl_301
            end
          end
          L5_2 = Config
          L5_2 = L5_2.BlackoutEffect
          if L5_2 then
            L5_2 = SendNUIMessage
            L6_2 = {}
            L6_2.blackout = 4
            L5_2(L6_2)
          end
          ::lbl_301::
          L5_2 = CreateThread
          function L6_2()
            local L0_3, L1_3
            while true do
              L0_3 = BodyDamage
              L0_3 = L0_3.BloodPressure
              L0_3 = L0_3[1]
              if not (L0_3 < 70) then
                L0_3 = BodyDamage
                L0_3 = L0_3.BloodPressure
                L0_3 = L0_3[2]
                if not (L0_3 < 40) then
                  L0_3 = BodyDamage
                  L0_3 = L0_3.BloodPressure
                  L0_3 = L0_3[1]
                  L1_3 = 180
                  if not (L0_3 > L1_3) then
                    L0_3 = BodyDamage
                    L0_3 = L0_3.BloodPressure
                    L0_3 = L0_3[2]
                    if not (L0_3 > 120) then
                      L0_3 = Config
                      L0_3 = L0_3.BlackoutEffect
                      if L0_3 then
                        L0_3 = SendNUIMessage
                        L1_3 = {}
                        L1_3.blackout = 4
                        L0_3(L1_3)
                      end
                      L0_3 = false
                      L3_2 = L0_3
                      L0_3 = false
                      L0_2 = L0_3
                      break
                    end
                  end
                end
              end
              L0_3 = Wait
              L1_3 = 5000
              L0_3(L1_3)
            end
          end
          L5_2(L6_2)
        end
      end
    end
    ::lbl_304::
  end
end
L8_1(L9_1)
L8_1 = nil
L9_1 = AddEventHandler
L10_1 = "gameEventTriggered"
function L11_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  if "CEventNetworkEntityDamage" == A0_2 then
    L3_2 = disableAllSystems
    L3_2 = L3_2()
    if L3_2 then
      return
    end
    L3_2 = 0
    L4_2 = 0
    L5_2 = 0
    L6_2 = 0
    L7_2 = 0
    L8_2 = 0
    L9_2 = 0
    L10_2 = Config
    L10_2 = L10_2.b2060
    if L10_2 then
      L10_2 = table
      L10_2 = L10_2.unpack
      L11_2 = A1_2
      L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L10_2(L11_2)
      L9_2 = L16_2
      L8_2 = L15_2
      L7_2 = L14_2
      L6_2 = L13_2
      L5_2 = L12_2
      L4_2 = L11_2
      L3_2 = L10_2
    else
      L10_2 = table
      L10_2 = L10_2.unpack
      L11_2 = A1_2
      L10_2, L11_2, L12_2, L13_2, L14_2 = L10_2(L11_2)
      L9_2 = L14_2
      L8_2 = L13_2
      L5_2 = L12_2
      L4_2 = L11_2
      L3_2 = L10_2
    end
    L10_2 = PlayerPedId
    L10_2 = L10_2()
    if L3_2 == L10_2 then
      L8_1 = L9_2
    end
    L10_2 = PlayerPedId
    L10_2 = L10_2()
    if L3_2 == L10_2 and nil ~= L5_2 and 0 ~= L5_2 then
      L10_2 = GetEntityHealth
      L11_2 = L2_2
      L10_2 = L10_2(L11_2)
      L11_2 = playerHealth
      if not L11_2 then
        playerHealth = L10_2
      end
      L11_2 = playerHealth
      L11_2 = L11_2 - L10_2
      L12_2 = Config
      L12_2 = L12_2.DamageRigorousness
      if L11_2 < L12_2 then
        return
      end
      L12_2 = GetPedLastDamageBone
      L13_2 = L2_2
      L12_2, L13_2 = L12_2(L13_2)
      L14_2 = Config
      L14_2 = L14_2.Bones
      L14_2 = L14_2[L13_2]
      L15_2 = GetDamagingWeapon
      L16_2 = L2_2
      L15_2 = L15_2(L16_2)
      L16_2 = false
      if L12_2 and "NONE" ~= L14_2 then
        L17_2 = L6_1
        if L17_2 ~= L9_2 then
          L17_2 = DebugPrint
          L18_2 = "game engine weapon trigger"
          L19_2 = L12_2
          L20_2 = L14_2
          L21_2 = L9_2
          L22_2 = L15_2
          L17_2(L18_2, L19_2, L20_2, L21_2, L22_2)
          L17_2 = nil
          L8_1 = L17_2
          if L15_2 then
          else
            L17_2 = 0
            L18_2 = {}
            L19_2 = pairs
            L20_2 = Config
            L20_2 = L20_2.MinorWounds
            L19_2, L20_2, L21_2, L22_2 = L19_2(L20_2)
            for L23_2 in L19_2, L20_2, L21_2, L22_2 do
              L17_2 = L17_2 + 1
            end
            L19_2 = pairs
            L20_2 = Config
            L20_2 = L20_2.MinorWounds
            L19_2, L20_2, L21_2, L22_2 = L19_2(L20_2)
            for L23_2, L24_2 in L19_2, L20_2, L21_2, L22_2 do
              L25_2 = table
              L25_2 = L25_2.insert
              L26_2 = L18_2
              L27_2 = L23_2
              L25_2(L26_2, L27_2)
            end
            L19_2 = math
            L19_2 = L19_2.random
            L20_2 = 1
            L21_2 = L17_2
            L19_2 = L19_2(L20_2, L21_2)
            L20_2 = L18_2[L19_2]
            L21_2 = BodyDamage
            L21_2 = L21_2.BodyPartDamage
            L21_2 = L21_2.DamageType
            L22_2 = BodyPartsType
            L22_2 = L22_2[L14_2]
            L21_2 = L21_2[L22_2]
            if not L21_2 then
              L21_2 = BodyDamage
              L21_2 = L21_2.BodyPartDamage
              L21_2 = L21_2.DamageType
              L22_2 = BodyPartsType
              L22_2 = L22_2[L14_2]
              L21_2[L22_2] = 1
              L21_2 = BodyDamage
              L21_2 = L21_2.BodyPartDamage
              L21_2 = L21_2.Bleeding
              L22_2 = BodyPartsType
              L22_2 = L22_2[L14_2]
              L21_2 = L21_2[L22_2]
              L22_2 = 0.5
              if L21_2 > L22_2 then
                L21_2 = BodyDamage
                L21_2 = L21_2.BodyPartDamage
                L21_2 = L21_2.DamageType
                L22_2 = BodyPartsType
                L22_2 = L22_2[L14_2]
                L21_2[L22_2] = 2
              end
            else
              L21_2 = BodyDamage
              L21_2 = L21_2.BodyPartDamage
              L21_2 = L21_2.DamageType
              L22_2 = BodyPartsType
              L22_2 = L22_2[L14_2]
              L21_2 = L21_2[L22_2]
              if L21_2 < 3 then
                L21_2 = BodyDamage
                L21_2 = L21_2.BodyPartDamage
                L21_2 = L21_2.DamageType
                L22_2 = BodyPartsType
                L22_2 = L22_2[L14_2]
                L23_2 = BodyDamage
                L23_2 = L23_2.BodyPartDamage
                L23_2 = L23_2.DamageType
                L24_2 = BodyPartsType
                L24_2 = L24_2[L14_2]
                L23_2 = L23_2[L24_2]
                L23_2 = L23_2 + 1
                L21_2[L22_2] = L23_2
              end
            end
            L21_2 = table
            L21_2 = L21_2.insert
            L22_2 = BodyDamage
            L22_2 = L22_2.BodyPartDamage
            L22_2 = L22_2.Wounds
            L23_2 = BodyPartsType
            L23_2 = L23_2[L14_2]
            L22_2 = L22_2[L23_2]
            L23_2 = L20_2
            L21_2(L22_2, L23_2)
          end
          L17_2 = LocalPlayer
          L17_2 = L17_2.state
          L18_2 = L17_2
          L17_2 = L17_2.set
          L19_2 = "BodyDamage"
          L20_2 = BodyDamage
          L21_2 = true
          L17_2(L18_2, L19_2, L20_2, L21_2)
        end
      end
      L6_1 = L9_2
    end
  end
end
L9_1(L10_1, L11_1)
playerHealth = nil
playerArmor = nil
L9_1 = CreateThread
function L10_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2
  while true do
    L0_2 = PlayerPedId
    L0_2 = L0_2()
    L1_2 = GetEntityHealth
    L2_2 = L0_2
    L1_2 = L1_2(L2_2)
    L2_2 = GetPedArmour
    L3_2 = L0_2
    L2_2 = L2_2(L3_2)
    L3_2 = playerHealth
    if not L3_2 then
      playerHealth = L1_2
    end
    L3_2 = playerArmor
    if not L3_2 then
      playerArmor = L2_2
    end
    L3_2 = 0
    if L1_2 then
      L4_2 = playerHealth
      L3_2 = L4_2 - L1_2
    end
    L4_2 = Config
    L4_2 = L4_2.DamageRigorousness
    if L3_2 > L4_2 then
      L4_2 = disableAllSystems
      L4_2 = L4_2()
      if not L4_2 then
        L4_2 = GetPedLastDamageBone
        L5_2 = L0_2
        L4_2, L5_2 = L4_2(L5_2)
        L6_2 = Config
        L6_2 = L6_2.Bones
        L6_2 = L6_2[L5_2]
        L7_2 = GetDamagingWeapon
        L8_2 = L0_2
        L7_2 = L7_2(L8_2)
        if L4_2 and "NONE" ~= L6_2 then
          L8_2 = CauseStagger
          L8_2()
        elseif L4_2 and "NONE" ~= L6_2 then
          L8_2 = math
          L8_2 = L8_2.random
          L9_2 = 1
          L10_2 = 20
          L8_2 = L8_2(L9_2, L10_2)
          if L8_2 <= 2 then
            L9_2 = CauseStagger
            L9_2()
          end
        end
        L8_2 = CheckWeaponDamage
        L8_2()
        L8_2 = Wait
        L9_2 = 100
        L8_2(L9_2)
        L8_2 = pairs
        L9_2 = Config
        L9_2 = L9_2.Weapons
        L8_2, L9_2, L10_2, L11_2 = L8_2(L9_2)
        for L12_2, L13_2 in L8_2, L9_2, L10_2, L11_2 do
          L14_2 = L8_1
          if L12_2 == L14_2 then
            L14_2 = DebugPrint
            L15_2 = "ondamage"
            L16_2 = L12_2
            L17_2 = L8_1
            L14_2(L15_2, L16_2, L17_2)
            L14_2 = pairs
            L15_2 = Config
            L15_2 = L15_2.Wounds
            L14_2, L15_2, L16_2, L17_2 = L14_2(L15_2)
            for L18_2, L19_2 in L14_2, L15_2, L16_2, L17_2 do
              L20_2 = L19_2.causes
              L20_2 = L20_2[L13_2]
              if L20_2 then
                L20_2 = DebugPrint
                L21_2 = "ondamage"
                L22_2 = L12_2
                L23_2 = L8_1
                L24_2 = L18_2
                L25_2 = L19_2.causes
                L25_2 = L25_2[L13_2]
                L20_2(L21_2, L22_2, L23_2, L24_2, L25_2)
                L20_2 = getRandomBodyPart
                L21_2 = BodyPartsType
                L20_2 = L20_2(L21_2)
                L21_2 = table
                L21_2 = L21_2.insert
                L22_2 = BodyDamage
                L22_2 = L22_2.BodyPartDamage
                L22_2 = L22_2.Wounds
                L22_2 = L22_2[L20_2]
                L23_2 = L18_2
                L21_2(L22_2, L23_2)
                L21_2 = BodyDamage
                L22_2 = BodyDamage
                L22_2 = L22_2.Pain
                L23_2 = L19_2.pain
                L22_2 = L22_2 + L23_2
                L21_2.Pain = L22_2
                L21_2 = BodyDamage
                L21_2 = L21_2.BodyPartDamage
                L21_2 = L21_2.Bleeding
                L22_2 = BodyDamage
                L22_2 = L22_2.BodyPartDamage
                L22_2 = L22_2.Bleeding
                L22_2 = L22_2[L20_2]
                L23_2 = L19_2.bleeding
                L22_2 = L22_2 + L23_2
                L21_2[L20_2] = L22_2
                L21_2 = BodyDamage
                L21_2 = L21_2.BodyPartDamage
                L21_2 = L21_2.DamageType
                L21_2 = L21_2[L20_2]
                if not L21_2 then
                  L21_2 = BodyDamage
                  L21_2 = L21_2.BodyPartDamage
                  L21_2 = L21_2.DamageType
                  L21_2[L20_2] = 1
                  L21_2 = BodyDamage
                  L21_2 = L21_2.BodyPartDamage
                  L21_2 = L21_2.Bleeding
                  L21_2 = L21_2[L20_2]
                  L22_2 = 0.5
                  if L21_2 > L22_2 then
                    L21_2 = BodyDamage
                    L21_2 = L21_2.BodyPartDamage
                    L21_2 = L21_2.DamageType
                    L21_2[L20_2] = 2
                  end
                else
                  L21_2 = BodyDamage
                  L21_2 = L21_2.BodyPartDamage
                  L21_2 = L21_2.DamageType
                  L21_2 = L21_2[L20_2]
                  if L21_2 < 3 then
                    L21_2 = BodyDamage
                    L21_2 = L21_2.BodyPartDamage
                    L21_2 = L21_2.DamageType
                    L22_2 = BodyDamage
                    L22_2 = L22_2.BodyPartDamage
                    L22_2 = L22_2.DamageType
                    L22_2 = L22_2[L20_2]
                    L22_2 = L22_2 + 1
                    L21_2[L20_2] = L22_2
                  end
                end
                L21_2 = ProcessRunStuff
                L21_2()
                L21_2 = nil
                L8_1 = L21_2
              end
            end
          end
        end
        L8_2 = Config
        L8_2 = L8_2.PopUpSkelly
        if L8_2 then
          L8_2 = SendNUIMessage
          L9_2 = {}
          L10_2 = json
          L10_2 = L10_2.encode
          L11_2 = BodyDamage
          L10_2 = L10_2(L11_2)
          L9_2.onDamage = L10_2
          L8_2(L9_2)
        end
      end
    end
    playerHealth = L1_2
    playerArmor = L2_2
    L4_2 = Wait
    L5_2 = 200
    L4_2(L5_2)
  end
end
L9_1(L10_1)
L9_1 = 0
L10_1 = CreateThread
function L11_1()
  local L0_2, L1_2
  while true do
    L0_2 = L9_1
    if L0_2 > 0 then
      L0_2 = L9_1
      L0_2 = L0_2 - 1
      L9_1 = L0_2
    end
    L0_2 = Wait
    L1_2 = 1000
    L0_2(L1_2)
  end
end
L10_1(L11_1)
function L10_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2, L30_2
  L0_2 = false
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = pairs
  L3_2 = Config
  L3_2 = L3_2.Weapons
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = HasPedBeenDamagedByWeapon
    L9_2 = L1_2
    L10_2 = L6_2
    L11_2 = 0
    L8_2 = L8_2(L9_2, L10_2, L11_2)
    if L8_2 then
      L8_2 = DebugPrint
      L9_2 = "ped has been damaged by a registered weapon"
      L10_2 = L6_2
      L8_2(L9_2, L10_2)
      L0_2 = true
      L8_2 = nil
      L9_2 = GetPedLastDamageBone
      L10_2 = L1_2
      L9_2, L10_2 = L9_2(L10_2)
      L11_2 = BodyPartsType
      L12_2 = Config
      L12_2 = L12_2.Bones
      L12_2 = L12_2[L10_2]
      L8_2 = L11_2[L12_2]
      L11_2 = GetDamagingWeapon
      L12_2 = L1_2
      L11_2 = L11_2(L12_2)
      L12_2 = {}
      L13_2 = "Head"
      L14_2 = "Torso"
      L15_2 = "Larm"
      L16_2 = "Rarm"
      L17_2 = "Lleg"
      L18_2 = "Rleg"
      L12_2[1] = L13_2
      L12_2[2] = L14_2
      L12_2[3] = L15_2
      L12_2[4] = L16_2
      L12_2[5] = L17_2
      L12_2[6] = L18_2
      if nil == L8_2 then
        L13_2 = math
        L13_2 = L13_2.random
        L14_2 = 1
        L15_2 = #L12_2
        L13_2 = L13_2(L14_2, L15_2)
        L8_2 = L12_2[L13_2]
      else
        L13_2 = nil
        L8_1 = L13_2
      end
      L13_2 = pairs
      L14_2 = Config
      L14_2 = L14_2.Fractures
      L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
      for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
        L19_2 = L18_2.causes
        L19_2 = L19_2[L7_2]
        if L19_2 then
          L19_2 = L18_2.bone
          if L19_2 == L8_2 then
            L19_2 = math
            L19_2 = L19_2.random
            L20_2 = 0
            L21_2 = 100
            L19_2 = L19_2(L20_2, L21_2)
            L20_2 = L18_2.chance
            if L19_2 <= L20_2 then
              L20_2 = BodyDamage
              L21_2 = BodyDamage
              L21_2 = L21_2.Pain
              L22_2 = L18_2.pain
              L21_2 = L21_2 + L22_2
              L20_2.Pain = L21_2
              L20_2 = BodyDamage
              L20_2 = L20_2.BodyPartDamage
              L20_2 = L20_2.Fractures
              L20_2[L8_2] = true
              L20_2 = SendNUIMessage
              L21_2 = {}
              L22_2 = math
              L22_2 = L22_2.random
              L23_2 = 1
              L24_2 = 2
              L22_2 = L22_2(L23_2, L24_2)
              L21_2.fractureSound = L22_2
              L20_2(L21_2)
            end
          end
        end
      end
      L13_2 = pairs
      L14_2 = Config
      L14_2 = L14_2.Wounds
      L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
      for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
        if "burn" == L17_2 then
          L19_2 = L18_2.causes
          L19_2 = L19_2[L7_2]
          if L19_2 then
            L19_2 = L9_1
            if 0 == L19_2 then
              L19_2 = {}
              L20_2 = "Head"
              L21_2 = "Torso"
              L22_2 = "Larm"
              L23_2 = "Rarm"
              L24_2 = "Lleg"
              L25_2 = "Rleg"
              L19_2[1] = L20_2
              L19_2[2] = L21_2
              L19_2[3] = L22_2
              L19_2[4] = L23_2
              L19_2[5] = L24_2
              L19_2[6] = L25_2
              L20_2 = pairs
              L21_2 = L19_2
              L20_2, L21_2, L22_2, L23_2 = L20_2(L21_2)
              for L24_2, L25_2 in L20_2, L21_2, L22_2, L23_2 do
                L26_2 = table
                L26_2 = L26_2.insert
                L27_2 = BodyDamage
                L27_2 = L27_2.BodyPartDamage
                L27_2 = L27_2.Wounds
                L27_2 = L27_2[L25_2]
                L28_2 = L17_2
                L26_2(L27_2, L28_2)
                L26_2 = BodyDamage
                L27_2 = BodyDamage
                L27_2 = L27_2.Pain
                L28_2 = L18_2.pain
                L27_2 = L27_2 + L28_2
                L26_2.Pain = L27_2
                L26_2 = BodyDamage
                L26_2 = L26_2.BodyPartDamage
                L26_2 = L26_2.Bleeding
                L27_2 = BodyDamage
                L27_2 = L27_2.BodyPartDamage
                L27_2 = L27_2.Bleeding
                L27_2 = L27_2[L25_2]
                L28_2 = L18_2.bleeding
                L27_2 = L27_2 + L28_2
                L26_2[L25_2] = L27_2
                L26_2 = BodyDamage
                L26_2 = L26_2.BodyPartDamage
                L26_2 = L26_2.DamageType
                L26_2 = L26_2[L25_2]
                if not L26_2 then
                  L26_2 = BodyDamage
                  L26_2 = L26_2.BodyPartDamage
                  L26_2 = L26_2.DamageType
                  L26_2[L25_2] = 1
                  L26_2 = BodyDamage
                  L26_2 = L26_2.BodyPartDamage
                  L26_2 = L26_2.Bleeding
                  L26_2 = L26_2[L25_2]
                  L27_2 = 0.5
                  if L26_2 > L27_2 then
                    L26_2 = BodyDamage
                    L26_2 = L26_2.BodyPartDamage
                    L26_2 = L26_2.DamageType
                    L26_2[L25_2] = 3
                  end
                else
                  L26_2 = BodyDamage
                  L26_2 = L26_2.BodyPartDamage
                  L26_2 = L26_2.DamageType
                  L26_2 = L26_2[L25_2]
                  if L26_2 < 3 then
                    L26_2 = BodyDamage
                    L26_2 = L26_2.BodyPartDamage
                    L26_2 = L26_2.DamageType
                    L27_2 = BodyDamage
                    L27_2 = L27_2.BodyPartDamage
                    L27_2 = L27_2.DamageType
                    L27_2 = L27_2[L25_2]
                    L27_2 = L27_2 + 1
                    L26_2[L25_2] = L27_2
                  end
                end
                L26_2 = LocalPlayer
                L26_2 = L26_2.state
                L27_2 = L26_2
                L26_2 = L26_2.set
                L28_2 = "BodyDamage"
                L29_2 = BodyDamage
                L30_2 = true
                L26_2(L27_2, L28_2, L29_2, L30_2)
              end
              L20_2 = 5
              L9_1 = L20_2
            end
          end
        else
          L19_2 = L18_2.causes
          L19_2 = L19_2[L7_2]
          if L19_2 then
            L19_2 = DebugPrint
            L20_2 = "apply damage"
            L21_2 = L18_2.causes
            L21_2 = L21_2[L7_2]
            L22_2 = L17_2
            L23_2 = L8_2
            L24_2 = L11_2
            L19_2(L20_2, L21_2, L22_2, L23_2, L24_2)
            L19_2 = table
            L19_2 = L19_2.insert
            L20_2 = BodyDamage
            L20_2 = L20_2.BodyPartDamage
            L20_2 = L20_2.Wounds
            L20_2 = L20_2[L8_2]
            L21_2 = L17_2
            L19_2(L20_2, L21_2)
            L19_2 = BodyDamage
            L20_2 = BodyDamage
            L20_2 = L20_2.Pain
            L21_2 = L18_2.pain
            L20_2 = L20_2 + L21_2
            L19_2.Pain = L20_2
            L19_2 = BodyDamage
            L19_2 = L19_2.BodyPartDamage
            L19_2 = L19_2.Bleeding
            L20_2 = BodyDamage
            L20_2 = L20_2.BodyPartDamage
            L20_2 = L20_2.Bleeding
            L20_2 = L20_2[L8_2]
            L21_2 = L18_2.bleeding
            L20_2 = L20_2 + L21_2
            L19_2[L8_2] = L20_2
            L19_2 = BodyDamage
            L19_2 = L19_2.BodyPartDamage
            L19_2 = L19_2.DamageType
            L19_2 = L19_2[L8_2]
            if not L19_2 then
              L19_2 = BodyDamage
              L19_2 = L19_2.BodyPartDamage
              L19_2 = L19_2.DamageType
              L19_2[L8_2] = 1
              L19_2 = BodyDamage
              L19_2 = L19_2.BodyPartDamage
              L19_2 = L19_2.Bleeding
              L19_2 = L19_2[L8_2]
              L20_2 = 0.5
              if L19_2 > L20_2 then
                L19_2 = BodyDamage
                L19_2 = L19_2.BodyPartDamage
                L19_2 = L19_2.DamageType
                L19_2[L8_2] = 2
              end
            else
              L19_2 = BodyDamage
              L19_2 = L19_2.BodyPartDamage
              L19_2 = L19_2.DamageType
              L19_2 = L19_2[L8_2]
              if L19_2 < 3 then
                L19_2 = BodyDamage
                L19_2 = L19_2.BodyPartDamage
                L19_2 = L19_2.DamageType
                L20_2 = BodyDamage
                L20_2 = L20_2.BodyPartDamage
                L20_2 = L20_2.DamageType
                L20_2 = L20_2[L8_2]
                L20_2 = L20_2 + 1
                L19_2[L8_2] = L20_2
              end
            end
            L19_2 = ProcessRunStuff
            L19_2()
          end
        end
      end
    end
  end
  L2_2 = ClearEntityLastDamageEntity
  L3_2 = L1_2
  L2_2(L3_2)
end
CheckWeaponDamage = L10_1
function L10_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = pairs
  L2_2 = BodyDamage
  L2_2 = L2_2.BodyPartDamage
  L2_2 = L2_2.Wounds
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = pairs
    L8_2 = L6_2
    L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
    for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
      L13_2 = pairs
      L14_2 = Config
      L14_2 = L14_2.Wounds
      L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
      for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
        if L12_2 == L17_2 then
          L19_2 = L18_2.causeStaggering
          if L19_2 then
            L19_2 = math
            L19_2 = L19_2.random
            L20_2 = 100
            L19_2 = L19_2(L20_2)
            L20_2 = math
            L20_2 = L20_2.ceil
            L21_2 = L18_2.causeStaggering
            L20_2 = L20_2(L21_2)
            if L19_2 <= L20_2 then
              L19_2 = SetPedToRagdoll
              L20_2 = L0_2
              L21_2 = 1500
              L22_2 = 2000
              L23_2 = 3
              L24_2 = true
              L25_2 = true
              L26_2 = false
              L19_2(L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2)
            end
          end
        end
      end
    end
  end
end
CauseStagger = L10_1
function L10_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L0_2 = getCardiacOutput
  L0_2 = L0_2()
  L1_2 = peripheralResistance
  L2_2 = L0_2 * L1_2
  L3_2 = {}
  L4_2 = round
  L5_2 = L2_1
  L5_2 = L2_2 * L5_2
  L4_2 = L4_2(L5_2)
  L5_2 = round
  L6_2 = L3_1
  L6_2 = L2_2 * L6_2
  L5_2, L6_2 = L5_2(L6_2)
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L3_2[3] = L6_2
  return L3_2
end
getBloodPressure = L10_1
function L10_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = BodyDamage
  L0_2 = L0_2.Pulse
  L1_2 = BodyDamage
  L1_2 = L1_2.BodyPartDamage
  L1_2 = L1_2.BloodLevel
  L1_2 = L1_2 / 6.0
  L2_2 = linearConversion
  L3_2 = 0.5
  L4_2 = 1
  L5_2 = L1_2
  L6_2 = 0
  L7_2 = 1
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
  L3_2 = L1_1
  L3_2 = L2_2 * L3_2
  L3_2 = L3_2 * L0_2
  L3_2 = L3_2 / 60
  L4_2 = math
  L4_2 = L4_2.max
  L5_2 = 0
  L6_2 = L3_2
  return L4_2(L5_2, L6_2)
end
getCardiacOutput = L10_1
function L10_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2
  if A2_2 <= 0 then
    A2_2 = A3_2
  end
  L5_2 = A2_2 - A0_2
  L6_2 = A1_2 - A0_2
  L5_2 = L5_2 / L6_2
  L6_2 = A4_2 - A3_2
  L5_2 = L5_2 * L6_2
  L5_2 = L5_2 + A3_2
  return L5_2
end
linearConversion = L10_1
function L10_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = A1_2 or nil
  if not A1_2 then
    L2_2 = 0
  end
  L3_2 = 10
  L2_2 = L3_2 ^ L2_2
  L3_2 = math
  L3_2 = L3_2.floor
  L4_2 = A0_2 * L2_2
  L4_2 = L4_2 + 0.5
  L3_2 = L3_2(L4_2)
  L3_2 = L3_2 / L2_2
  return L3_2
end
round = L10_1
function L10_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2
  L2_2 = 1.0
  L3_2 = math
  L3_2 = L3_2.abs
  L4_2 = A0_2 - A1_2
  L3_2 = L3_2(L4_2)
  L4_2 = L2_2 >= L3_2
  return L4_2
end
isNear = L10_1
function L10_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.BloodLevel
  L1_2 = 6
  L0_2 = L1_2 - L0_2
  L1_2 = BodyDamage
  L1_2 = L1_2.Pain
  L1_2 = L1_2 * 2
  L2_2 = L0_2 * 10
  L3_2 = BodyDamage
  L3_2 = L3_2.hrIncrease
  L4_2 = BodyDamage
  L4_2 = L4_2.hrDecrease
  L3_2 = L3_2 - L4_2
  L4_2 = BodyDamage
  L4_2 = L4_2.Pulse
  L4_2 = L4_2 + L1_2
  L4_2 = L4_2 - L2_2
  L5_2 = L3_2 / 100
  L5_2 = L4_2 * L5_2
  L4_2 = L4_2 + L5_2
  L6_2 = L5_1
  if L6_2 then
    L6_2 = true
    L4_1 = L6_2
    L6_2 = Wait
    L7_2 = 1000
    L6_2(L7_2)
    L6_2 = false
    L4_1 = L6_2
  end
  L6_2 = CreateThread
  function L7_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L0_3 = L4_2
    L1_3 = BodyDamage
    L1_3 = L1_3.Pulse
    L0_3 = L0_3 - L1_3
    L1_3 = L0_3 * 0.1
    while true do
      L2_3 = true
      L5_1 = L2_3
      L2_3 = math
      L2_3 = L2_3.abs
      L3_3 = L4_2
      L4_3 = BodyDamage
      L4_3 = L4_3.Pulse
      L3_3 = L3_3 - L4_3
      L2_3 = L2_3(L3_3)
      L3_3 = 0.5
      if L2_3 <= L3_3 then
        break
      end
      goto lbl_25
      L2_3 = false
      L5_1 = L2_3
      goto lbl_48
      ::lbl_25::
      L2_3 = L4_1
      if L2_3 then
        break
      end
      L2_3 = BodyDamage
      L2_3 = L2_3.isDead
      if L2_3 then
        break
      end
      L2_3 = BodyDamage
      L2_3 = L2_3.inLastStand
      if L2_3 then
        break
      end
      goto lbl_40
      L2_3 = false
      L5_1 = L2_3
      goto lbl_48
      ::lbl_40::
      L2_3 = BodyDamage
      L2_3 = L2_3.Pulse
      L3_3 = 250
      if L2_3 >= L3_3 then
        break
      end
      goto lbl_48
      L2_3 = false
      L5_1 = L2_3
      ::lbl_48::
      if L1_3 > 0 then
        L2_3 = BodyDamage
        L2_3 = L2_3.Pulse
        L3_3 = L4_2
        if L2_3 > L3_3 then
          break
        end
      elseif L1_3 < 0 then
        L2_3 = BodyDamage
        L2_3 = L2_3.Pulse
        L3_3 = L4_2
        if L2_3 < L3_3 then
          break
        end
      end
      L2_3 = BodyDamage
      L3_3 = BodyDamage
      L3_3 = L3_3.Pulse
      L3_3 = L3_3 + L1_3
      L2_3.Pulse = L3_3
      L2_3 = LocalPlayer
      L2_3 = L2_3.state
      L3_3 = L2_3
      L2_3 = L2_3.set
      L4_3 = "BodyDamage"
      L5_3 = BodyDamage
      L6_3 = true
      L2_3(L3_3, L4_3, L5_3, L6_3)
      L2_3 = Wait
      L3_3 = 1000
      L2_3(L3_3)
    end
  end
  L6_2(L7_2)
end
updatePulse = L10_1
function L10_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Bleeding
  L0_2 = L0_2.Head
  L1_2 = BodyDamage
  L1_2 = L1_2.BodyPartDamage
  L1_2 = L1_2.Bleeding
  L1_2 = L1_2.Torso
  L2_2 = BodyDamage
  L2_2 = L2_2.BodyPartDamage
  L2_2 = L2_2.Bleeding
  L2_2 = L2_2.Lleg
  L3_2 = BodyDamage
  L3_2 = L3_2.BodyPartDamage
  L3_2 = L3_2.appliedTourniquets
  L3_2 = L3_2.Lleg
  if L3_2 then
    L2_2 = 0
  end
  L3_2 = BodyDamage
  L3_2 = L3_2.BodyPartDamage
  L3_2 = L3_2.Bleeding
  L3_2 = L3_2.Rleg
  L4_2 = BodyDamage
  L4_2 = L4_2.BodyPartDamage
  L4_2 = L4_2.appliedTourniquets
  L4_2 = L4_2.Rleg
  if L4_2 then
    L3_2 = 0
  end
  L4_2 = BodyDamage
  L4_2 = L4_2.BodyPartDamage
  L4_2 = L4_2.Bleeding
  L4_2 = L4_2.Larm
  L5_2 = BodyDamage
  L5_2 = L5_2.BodyPartDamage
  L5_2 = L5_2.appliedTourniquets
  L5_2 = L5_2.Larm
  if L5_2 then
    L4_2 = 0
  end
  L5_2 = BodyDamage
  L5_2 = L5_2.BodyPartDamage
  L5_2 = L5_2.Bleeding
  L5_2 = L5_2.Rarm
  L6_2 = BodyDamage
  L6_2 = L6_2.BodyPartDamage
  L6_2 = L6_2.appliedTourniquets
  L6_2 = L6_2.Rarm
  if L6_2 then
    L5_2 = 0
  end
  L6_2 = math
  L6_2 = L6_2.min
  L7_2 = math
  L7_2 = L7_2.min
  L8_2 = 0.9
  L9_2 = L0_2 * 2
  L9_2 = L9_2 / 0.5
  L7_2 = L7_2(L8_2, L9_2)
  L8_2 = math
  L8_2 = L8_2.min
  L9_2 = 1.0
  L10_2 = L1_2 * 2
  L10_2 = L10_2 / 0.5
  L8_2 = L8_2(L9_2, L10_2)
  L7_2 = L7_2 + L8_2
  L8_2 = 1.0
  L6_2 = L6_2(L7_2, L8_2)
  L7_2 = math
  L7_2 = L7_2.min
  L8_2 = math
  L8_2 = L8_2.min
  L9_2 = 0.3
  L10_2 = L4_2 * 2
  L10_2 = L10_2 / 0.5
  L8_2 = L8_2(L9_2, L10_2)
  L9_2 = math
  L9_2 = L9_2.min
  L10_2 = 0.3
  L11_2 = L5_2 * 2
  L11_2 = L11_2 / 0.5
  L9_2 = L9_2(L10_2, L11_2)
  L8_2 = L8_2 + L9_2
  L9_2 = math
  L9_2 = L9_2.min
  L10_2 = 0.5
  L11_2 = L2_2 * 2
  L11_2 = L11_2 / 0.5
  L9_2 = L9_2(L10_2, L11_2)
  L8_2 = L8_2 + L9_2
  L9_2 = math
  L9_2 = L9_2.min
  L10_2 = 0.5
  L11_2 = L3_2 * 2
  L11_2 = L11_2 / 0.5
  L9_2 = L9_2(L10_2, L11_2)
  L8_2 = L8_2 + L9_2
  L9_2 = 1.0
  L7_2 = L7_2(L8_2, L9_2)
  L8_2 = 1
  L8_2 = L8_2 - L6_2
  L8_2 = L7_2 * L8_2
  L9_2 = BodyDamage
  L9_2 = L9_2.Pulse
  if L9_2 > 0 then
    L9_2 = L6_2 + L8_2
    L10_2 = peripheralResistance
    L9_2 = L9_2 / L10_2
    L9_2 = L9_2 * 10
    L9_2 = L9_2 / 3
    L10_2 = BodyDamage
    L10_2 = L10_2.Pulse
    L10_2 = L10_2 / 27
    L9_2 = L9_2 * L10_2
    L7_1 = L9_2
  else
    L9_2 = L6_2 + L8_2
    L10_2 = peripheralResistance
    L9_2 = L9_2 / L10_2
    L9_2 = L9_2 * 10
    L9_2 = L9_2 / 3
    L7_1 = L9_2
  end
  L9_2 = BodyDamage
  L9_2 = L9_2.isDead
  if not L9_2 then
    L9_2 = BodyDamage
    L9_2 = L9_2.inLastStand
    if not L9_2 then
      goto lbl_174
    end
  end
  L9_2 = L7_1
  L10_2 = math
  L10_2 = L10_2.max
  L11_2 = getCardiacOutput
  L11_2 = L11_2()
  L12_2 = 0.05
  L10_2 = L10_2(L11_2, L12_2)
  L10_2 = L10_2 * 30
  L9_2 = L9_2 * L10_2
  L7_1 = L9_2
  goto lbl_186
  ::lbl_174::
  L9_2 = L7_1
  L10_2 = math
  L10_2 = L10_2.max
  L11_2 = getCardiacOutput
  L11_2 = L11_2()
  L12_2 = 0.05
  L10_2 = L10_2(L11_2, L12_2)
  L10_2 = L10_2 * 2
  L9_2 = L9_2 * L10_2
  L7_1 = L9_2
  ::lbl_186::
  L9_2 = L7_1
  L9_2 = L9_2 / 4
  L10_2 = Config
  L10_2 = L10_2.BleedLossMultiplier
  L9_2 = L9_2 * L10_2
  L7_1 = L9_2
end
updateBloodLoss = L10_1
emsNotified = false
L10_1 = AddEventHandler
L11_1 = "gameEventTriggered"
function L12_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  if "CEventNetworkEntityDamage" == A0_2 then
    L2_2 = disableAllSystems
    L2_2 = L2_2()
    if L2_2 then
      return
    end
    L2_2 = A1_2[1]
    L3_2 = A1_2[2]
    L4_2 = A1_2[4]
    L5_2 = A1_2[7]
    L6_2 = BodyDamage
    L7_2 = GetEntityHealth
    L8_2 = PlayerPedId
    L8_2, L9_2 = L8_2()
    L7_2 = L7_2(L8_2, L9_2)
    L6_2.playerHealth = L7_2
    L6_2 = BodyDamage
    L7_2 = GetPedArmour
    L8_2 = PlayerPedId
    L8_2, L9_2 = L8_2()
    L7_2 = L7_2(L8_2, L9_2)
    L6_2.playerArmour = L7_2
    L6_2 = IsEntityAPed
    L7_2 = L2_2
    L6_2 = L6_2(L7_2)
    if not L6_2 then
      return
    end
    if L4_2 then
      L6_2 = NetworkGetPlayerIndexFromPed
      L7_2 = L2_2
      L6_2 = L6_2(L7_2)
      L7_2 = PlayerId
      L7_2 = L7_2()
      if L6_2 == L7_2 then
        L6_2 = IsEntityDead
        L7_2 = PlayerPedId
        L7_2, L8_2, L9_2 = L7_2()
        L6_2 = L6_2(L7_2, L8_2, L9_2)
        if L6_2 then
          L6_2 = TriggerServerEvent
          L7_2 = "osp_ambulance:updateWheelChair"
          L8_2 = false
          L9_2 = cache
          L9_2 = L9_2.serverId
          L6_2(L7_2, L8_2, L9_2)
          L6_2 = TriggerServerEvent
          L7_2 = "osp_ambulance:updateCrutch"
          L8_2 = false
          L9_2 = cache
          L9_2 = L9_2.serverId
          L6_2(L7_2, L8_2, L9_2)
          L6_2 = DebugPrint
          L7_2 = "playerdied"
          L6_2(L7_2)
          L6_2 = BodyDamage
          L6_2 = L6_2.isDead
          if not L6_2 then
            L6_2 = DebugPrint
            L7_2 = "not dead, setting death state"
            L6_2(L7_2)
            L6_2 = BodyDamage
            L6_2 = L6_2.inLastStand
            if not L6_2 then
              L6_2 = DebugPrint
              L7_2 = "Sending player to lastastand"
              L6_2(L7_2)
              L6_2 = TriggerEvent
              L7_2 = "osp_ambulance:OnPlayerLastStand"
              L8_2 = true
              L6_2(L7_2, L8_2)
              L6_2 = CreateThread
              function L7_2()
                local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
                L0_3 = NetworkGetPlayerIndexFromPed
                L1_3 = L2_2
                L0_3 = L0_3(L1_3)
                L1_3 = GetPlayerName
                L2_3 = L0_3
                L1_3 = L1_3(L2_3)
                L2_3 = " "
                L3_3 = "("
                L4_3 = GetPlayerServerId
                L5_3 = L0_3
                L4_3 = L4_3(L5_3)
                L5_3 = ")"
                L1_3 = L1_3 .. L2_3 .. L3_3 .. L4_3 .. L5_3
                if not L1_3 then
                  L1_3 = lang
                  L1_3 = L1_3.info
                  L1_3 = L1_3.self_death
                end
                L2_3 = NetworkGetPlayerIndexFromPed
                L3_3 = L3_2
                L2_3 = L2_3(L3_3)
                L3_3 = nil
                if -1 == L2_3 then
                  L3_3 = "None (Suicide)"
                else
                  L4_3 = GetPlayerName
                  L5_3 = L2_3
                  L4_3 = L4_3(L5_3)
                  L5_3 = " "
                  L6_3 = "("
                  L7_3 = GetPlayerServerId
                  L8_3 = L2_3
                  L7_3 = L7_3(L8_3)
                  L8_3 = ")"
                  L4_3 = L4_3 .. L5_3 .. L6_3 .. L7_3 .. L8_3
                  L3_3 = L4_3 or L3_3
                  if not L4_3 then
                    L4_3 = lang
                    L4_3 = L4_3.info
                    L3_3 = L4_3.self_death
                  end
                end
                L4_3 = L5_2
                if L4_3 then
                  L4_3 = Weapons
                  L5_3 = L5_2
                  L4_3 = L4_3[L5_3]
                  if L4_3 then
                    L4_3 = Weapons
                    L5_3 = L5_2
                    L4_3 = L4_3[L5_3]
                    L4_3 = L4_3.label
                    if not L4_3 then
                      L4_3 = "Unknown"
                    end
                    weaponLabel = L4_3
                    L4_3 = Weapons
                    L5_3 = L5_2
                    L4_3 = L4_3[L5_3]
                    L4_3 = L4_3.name
                    if not L4_3 then
                      L4_3 = "Unknown"
                    end
                    weaponName = L4_3
                  else
                    weaponLabel = "Unknown"
                    weaponName = "Unknown"
                  end
                else
                  weaponLabel = "Unknown"
                  weaponName = "Unknown"
                end
                L4_3 = webHookPacket
                L5_3 = {}
                L5_3.playerName = L1_3
                L6_3 = weaponLabel
                L5_3.weaponLabel = L6_3
                L5_3.killerName = L3_3
                L4_3(L5_3)
                L4_3 = TriggerServerEvent
                L5_3 = "osp_ambulance:requestScreenshotSv"
                L6_3 = GetPlayerServerId
                L7_3 = L0_3
                L6_3, L7_3, L8_3 = L6_3(L7_3)
                L4_3(L5_3, L6_3, L7_3, L8_3)
                if -1 ~= L2_3 then
                  L4_3 = TriggerServerEvent
                  L5_3 = "osp_ambulance:requestScreenshotSv"
                  L6_3 = GetPlayerServerId
                  L7_3 = L2_3
                  L6_3, L7_3, L8_3 = L6_3(L7_3)
                  L4_3(L5_3, L6_3, L7_3, L8_3)
                end
              end
              L6_2(L7_2)
            else
              L6_2 = BodyDamage
              L6_2 = L6_2.inLastStand
              if L6_2 then
                L6_2 = BodyDamage
                L6_2 = L6_2.isDead
                if not L6_2 then
                  L6_2 = DebugPrint
                  L7_2 = "sending player to onplayerdeath"
                  L6_2(L7_2)
                  L6_2 = TriggerEvent
                  L7_2 = "osp_ambulance:OnPlayerLastStand"
                  L8_2 = false
                  L6_2(L7_2, L8_2)
                  L6_2 = Config
                  L6_2 = L6_2.RespawnTime
                  deathTime = L6_2
                  L6_2 = TriggerEvent
                  L7_2 = "osp_ambulance:OnPlayerDeath"
                  L6_2(L7_2)
                  L6_2 = DeathTimer
                  L6_2()
                end
              end
            end
          end
        end
      end
    end
    L6_2 = IsEntityDead
    L7_2 = PlayerPedId
    L7_2, L8_2, L9_2 = L7_2()
    L6_2 = L6_2(L7_2, L8_2, L9_2)
    if L6_2 then
      L6_2 = BodyDamage
      L6_2.inLastStand = true
      L6_2 = DebugPrint
      L7_2 = "Save wound data1"
      L8_2 = BodyDamage
      L8_2 = L8_2.inLastStand
      L9_2 = BodyDamage
      L9_2 = L9_2.isDead
      L6_2(L7_2, L8_2, L9_2)
      L6_2 = TriggerServerEvent
      L7_2 = "osp_ambulance:saveWoundDataSv"
      L8_2 = BodyDamage
      L6_2(L7_2, L8_2)
      L6_2 = BodyDamage
      L6_2.inLastStand = false
    end
  end
end
L10_1(L11_1, L12_1)
L10_1 = CreateThread
function L11_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L0_2 = Wait
  L1_2 = 100
  L0_2(L1_2)
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    while true do
      L0_3 = BodyDamage
      L0_3 = L0_3.isDead
      if L0_3 then
        L0_3 = BodyDamage
        L0_3.Conscious = false
        L0_3 = BodyDamage
        L0_3.Pulse = 0
        L0_3 = BodyDamage
        L0_3.cardiacState = "asystole"
        L0_3 = BodyDamage
        L0_3 = L0_3.Temp
        if L0_3 > 27 then
          L0_3 = BodyDamage
          L1_3 = round
          L2_3 = BodyDamage
          L2_3 = L2_3.Temp
          L2_3 = L2_3 - 0.1
          L3_3 = 1
          L1_3 = L1_3(L2_3, L3_3)
          L0_3.Temp = L1_3
        end
        L0_3 = BodyDamage
        L0_3 = L0_3.oxygenSaturation
        if L0_3 > 10 then
          L0_3 = BodyDamage
          L1_3 = BodyDamage
          L1_3 = L1_3.oxygenSaturation
          L1_3 = L1_3 - 1
          L0_3.oxygenSaturation = L1_3
        end
      else
        L0_3 = BodyDamage
        L0_3 = L0_3.inLastStand
        if L0_3 then
          L0_3 = BodyDamage
          L0_3 = L0_3.Pulse
          if L0_3 > 50 then
            L0_3 = BodyDamage
            L1_3 = BodyDamage
            L1_3 = L1_3.Pulse
            L1_3 = L1_3 - 3
            L0_3.Pulse = L1_3
          end
          L0_3 = BodyDamage
          L0_3.Conscious = false
          L0_3 = BodyDamage
          L0_3 = L0_3.Temp
          if L0_3 > 34 then
            L0_3 = BodyDamage
            L1_3 = round
            L2_3 = BodyDamage
            L2_3 = L2_3.Temp
            L2_3 = L2_3 - 0.1
            L3_3 = 1
            L1_3 = L1_3(L2_3, L3_3)
            L0_3.Temp = L1_3
          end
          L0_3 = BodyDamage
          L0_3 = L0_3.oxygenSaturation
          if L0_3 > 80 then
            L0_3 = BodyDamage
            L1_3 = BodyDamage
            L1_3 = L1_3.oxygenSaturation
            L1_3 = L1_3 - 1
            L0_3.oxygenSaturation = L1_3
          end
        else
          L0_3 = BodyDamage
          L0_3 = L0_3.BloodPressure
          L0_3 = L0_3[1]
          if not (L0_3 > 80) then
            L0_3 = BodyDamage
            L0_3 = L0_3.BloodPressure
            L0_3 = L0_3[2]
            if not (L0_3 > 50) then
              goto lbl_124
            end
          end
          L0_3 = BodyDamage
          L0_3 = L0_3.BloodPressure
          L0_3 = L0_3[1]
          L1_3 = 150
          if not (L0_3 < L1_3) then
            L0_3 = BodyDamage
            L0_3 = L0_3.BloodPressure
            L0_3 = L0_3[2]
            if not (L0_3 < 100) then
              goto lbl_124
            end
          end
          L0_3 = BodyDamage
          L0_3 = L0_3.Pulse
          L1_3 = 200
          if L0_3 < L1_3 then
            L0_3 = BodyDamage
            L0_3 = L0_3.Temp
            if L0_3 < 37 then
              L0_3 = BodyDamage
              L1_3 = round
              L2_3 = BodyDamage
              L2_3 = L2_3.Temp
              L2_3 = L2_3 + 0.2
              L3_3 = 1
              L1_3 = L1_3(L2_3, L3_3)
              L0_3.Temp = L1_3
            end
            L0_3 = BodyDamage
            L0_3 = L0_3.oxygenSaturation
            if L0_3 < 92 then
              L0_3 = BodyDamage
              L1_3 = BodyDamage
              L1_3 = L1_3.oxygenSaturation
              L1_3 = L1_3 + 5
              L0_3.oxygenSaturation = L1_3
            end
          end
          ::lbl_124::
          L0_3 = BodyDamage
          L0_3 = L0_3.Pulse
          if 0 == L0_3 then
            L0_3 = BodyDamage
            L0_3 = L0_3.oxygenSaturation
            if L0_3 > 50 then
              L0_3 = BodyDamage
              L1_3 = BodyDamage
              L1_3 = L1_3.oxygenSaturation
              L1_3 = L1_3 - 1
              L0_3.oxygenSaturation = L1_3
            end
          end
        end
      end
      L0_3 = LocalPlayer
      L0_3 = L0_3.state
      L1_3 = L0_3
      L0_3 = L0_3.set
      L2_3 = "BodyDamage"
      L3_3 = BodyDamage
      L4_3 = true
      L0_3(L1_3, L2_3, L3_3, L4_3)
      L0_3 = Wait
      L1_3 = 5000
      L0_3(L1_3)
    end
  end
  L0_2(L1_2)
  while true do
    L0_2 = 1000
    L1_2 = BodyDamage
    L1_2 = L1_2.isDead
    if not L1_2 then
      L1_2 = BodyDamage
      L1_2 = L1_2.inLastStand
      if not L1_2 then
        goto lbl_332
      end
    end
    L0_2 = 1
    L1_2 = PlayerPedId
    L1_2 = L1_2()
    L2_2 = disabledControls
    L2_2()
    L2_2 = BodyDamage
    L2_2 = L2_2.isCarried
    if not L2_2 then
      L2_2 = BodyDamage
      L2_2 = L2_2.isDead
      if L2_2 then
        L2_2 = isInHospitalBed
        if not L2_2 then
          L2_2 = IsDisabledControlPressed
          L3_2 = 0
          L4_2 = Config
          L4_2 = L4_2.DispatchNotifyButton
          L2_2 = L2_2(L3_2, L4_2)
          if L2_2 then
            L2_2 = emsNotified
            if not L2_2 then
              L2_2 = Config
              L2_2 = L2_2.Dispatch
              if "ps" == L2_2 then
                L2_2 = exports
                L2_2 = L2_2["ps-dispatch"]
                L3_2 = L2_2
                L2_2 = L2_2.InjuriedPerson
                L2_2(L3_2)
              else
                L2_2 = Config
                L2_2 = L2_2.Dispatch
                if "other" == L2_2 then
                  L2_2 = dispatchNotify
                  L2_2()
                else
                  L2_2 = TriggerServerEvent
                  L3_2 = "hospital:server:ambulanceAlert"
                  L4_2 = lang
                  L4_2 = L4_2.info
                  L4_2 = L4_2.civ_down
                  L2_2(L3_2, L4_2)
                end
              end
              emsNotified = true
              L2_2 = SendNUIMessage
              L3_2 = {}
              L3_2.emsnotif = 2
              L2_2(L3_2)
            end
          end
        end
        L2_2 = instretcher
        if not L2_2 then
          L2_2 = IsPedInAnyVehicle
          L3_2 = L1_2
          L4_2 = false
          L2_2 = L2_2(L3_2, L4_2)
          if L2_2 then
            L2_2 = loadAnimDict
            L3_2 = "veh@low@front_ps@idle_duck"
            L2_2(L3_2)
            L2_2 = IsEntityPlayingAnim
            L3_2 = L1_2
            L4_2 = "veh@low@front_ps@idle_duck"
            L5_2 = "sit"
            L6_2 = 3
            L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2)
            if not L2_2 then
              L2_2 = TaskPlayAnim
              L3_2 = L1_2
              L4_2 = "veh@low@front_ps@idle_duck"
              L5_2 = "sit"
              L6_2 = 1.0
              L7_2 = 1.0
              L8_2 = -1
              L9_2 = 1
              L10_2 = 0
              L11_2 = 0
              L12_2 = 0
              L13_2 = 0
              L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
            end
          else
            L2_2 = isInHospitalBed
            if L2_2 then
              L2_2 = IsEntityPlayingAnim
              L3_2 = L1_2
              L4_2 = inBedDict
              L5_2 = inBedAnim
              L6_2 = 3
              L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2)
              if not L2_2 then
                L2_2 = loadAnimDict
                L3_2 = inBedDict
                L2_2(L3_2)
                L2_2 = TaskPlayAnim
                L3_2 = L1_2
                L4_2 = inBedDict
                L5_2 = inBedAnim
                L6_2 = 1.0
                L7_2 = 1.0
                L8_2 = -1
                L9_2 = 1
                L10_2 = 0
                L11_2 = 0
                L12_2 = 0
                L13_2 = 0
                L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
              end
            else
              L2_2 = stopExternalAnimations
              L3_2 = L1_2
              L2_2(L3_2)
              L2_2 = IsEntityPlayingAnim
              L3_2 = L1_2
              L4_2 = deadAnimDict
              L5_2 = deadAnim
              L6_2 = 3
              L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2)
              if not L2_2 then
                L2_2 = loadAnimDict
                L3_2 = deadAnimDict
                L2_2(L3_2)
                L2_2 = TaskPlayAnim
                L3_2 = L1_2
                L4_2 = deadAnimDict
                L5_2 = deadAnim
                L6_2 = 1.0
                L7_2 = 1.0
                L8_2 = -1
                L9_2 = 1
                L10_2 = 0
                L11_2 = 0
                L12_2 = 0
                L13_2 = 0
                L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
              end
            end
          end
        end
        L2_2 = SetCurrentPedWeapon
        L3_2 = L1_2
        L4_2 = -1569615261
        L5_2 = true
        L2_2(L3_2, L4_2, L5_2)
      else
        L2_2 = BodyDamage
        L2_2 = L2_2.inLastStand
        if L2_2 then
          L2_2 = IsDisabledControlPressed
          L3_2 = 0
          L4_2 = Config
          L4_2 = L4_2.DispatchNotifyButton
          L2_2 = L2_2(L3_2, L4_2)
          if L2_2 then
            L2_2 = emsNotified
            if not L2_2 then
              L2_2 = Config
              L2_2 = L2_2.Dispatch
              if "ps" == L2_2 then
                L2_2 = exports
                L2_2 = L2_2["ps-dispatch"]
                L3_2 = L2_2
                L2_2 = L2_2.InjuriedPerson
                L2_2(L3_2)
              else
                L2_2 = Config
                L2_2 = L2_2.Dispatch
                if "other" == L2_2 then
                  L2_2 = dispatchNotify
                  L2_2()
                else
                  L2_2 = TriggerServerEvent
                  L3_2 = "hospital:server:ambulanceAlert"
                  L4_2 = lang
                  L4_2 = L4_2.info
                  L4_2 = L4_2.civ_down
                  L2_2(L3_2, L4_2)
                end
              end
              emsNotified = true
              L2_2 = SendNUIMessage
              L3_2 = {}
              L3_2.emsnotif = 2
              L2_2(L3_2)
            end
          end
          L2_2 = instretcher
          if not L2_2 then
            L2_2 = isEscorted
            if not L2_2 then
              L2_2 = IsPedInAnyVehicle
              L3_2 = L1_2
              L4_2 = false
              L2_2 = L2_2(L3_2, L4_2)
              if L2_2 then
                L2_2 = loadAnimDict
                L3_2 = "veh@low@front_ps@idle_duck"
                L2_2(L3_2)
                L2_2 = IsEntityPlayingAnim
                L3_2 = L1_2
                L4_2 = "veh@low@front_ps@idle_duck"
                L5_2 = "sit"
                L6_2 = 3
                L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2)
                if not L2_2 then
                  L2_2 = TaskPlayAnim
                  L3_2 = L1_2
                  L4_2 = "veh@low@front_ps@idle_duck"
                  L5_2 = "sit"
                  L6_2 = 1.0
                  L7_2 = 1.0
                  L8_2 = -1
                  L9_2 = 1
                  L10_2 = 0
                  L11_2 = 0
                  L12_2 = 0
                  L13_2 = 0
                  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
                end
                L2_2 = stopExternalAnimations
                L3_2 = L1_2
                L2_2(L3_2)
              else
                L2_2 = putInVehicle
                if not L2_2 then
                  L2_2 = stopExternalAnimations
                  L3_2 = L1_2
                  L2_2(L3_2)
                  L2_2 = Config
                  L2_2 = L2_2.Crawl
                  if L2_2 then
                    L2_2 = DeadMovement
                    L3_2 = L1_2
                    L2_2(L3_2)
                  else
                    L2_2 = IsEntityPlayingAnim
                    L3_2 = L1_2
                    L4_2 = lastStandDict
                    L5_2 = lastStandAnim
                    L6_2 = 3
                    L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2)
                    if not L2_2 then
                      L2_2 = loadAnimDict
                      L3_2 = lastStandDict
                      L2_2(L3_2)
                      L2_2 = TaskPlayAnim
                      L3_2 = L1_2
                      L4_2 = lastStandDict
                      L5_2 = lastStandAnim
                      L6_2 = 1.0
                      L7_2 = 1.0
                      L8_2 = -1
                      L9_2 = 1
                      L10_2 = 0
                      L11_2 = 0
                      L12_2 = 0
                      L13_2 = 0
                      L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
                    end
                  end
                end
              end
            else
              L2_2 = IsPedInAnyVehicle
              L3_2 = L1_2
              L4_2 = false
              L2_2 = L2_2(L3_2, L4_2)
              if L2_2 then
                L2_2 = loadAnimDict
                L3_2 = "veh@low@front_ps@idle_duck"
                L2_2(L3_2)
                L2_2 = IsEntityPlayingAnim
                L3_2 = L1_2
                L4_2 = "veh@low@front_ps@idle_duck"
                L5_2 = "sit"
                L6_2 = 3
                L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2)
                if L2_2 then
                  L2_2 = StopAnimTask
                  L3_2 = L1_2
                  L4_2 = "veh@low@front_ps@idle_duck"
                  L5_2 = "sit"
                  L6_2 = 3
                  L2_2(L3_2, L4_2, L5_2, L6_2)
                end
              else
                L2_2 = IsEntityPlayingAnim
                L3_2 = L1_2
                L4_2 = lastStandDict
                L5_2 = lastStandAnim
                L6_2 = 3
                L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2)
                if L2_2 then
                  L2_2 = loadAnimDict
                  L3_2 = lastStandDict
                  L2_2(L3_2)
                  L2_2 = StopAnimTask
                  L3_2 = L1_2
                  L4_2 = lastStandDict
                  L5_2 = lastStandAnim
                  L6_2 = 3
                  L2_2(L3_2, L4_2, L5_2, L6_2)
                end
              end
            end
          end
          L2_2 = SetCurrentPedWeapon
          L3_2 = L1_2
          L4_2 = -1569615261
          L5_2 = true
          L2_2(L3_2, L4_2, L5_2)
        end
      end
    end
    ::lbl_332::
    L1_2 = Wait
    L2_2 = L0_2
    L1_2(L2_2)
  end
end
L10_1(L11_1)
function L10_1(A0_2)
  local L1_2, L2_2
  while true do
    L1_2 = HasAnimDictLoaded
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = RequestAnimDict
    L2_2 = A0_2
    L1_2(L2_2)
    L1_2 = Wait
    L2_2 = 5
    L1_2(L2_2)
  end
end
loadAnimDict = L10_1
function L10_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  L0_2 = BodyDamage
  L0_2 = L0_2.isDead
  if not L0_2 then
    L0_2 = DebugPrint
    L1_2 = "GOING FROM LAST STAND TO DEATH STATE"
    L0_2(L1_2)
    L0_2 = BodyDamage
    L0_2.isDead = true
    L0_2 = BodyDamage
    L0_2.Pulse = 0
    L0_2 = BodyDamage
    L0_2 = L0_2.BloodPressure
    L0_2[1] = 0
    L0_2 = BodyDamage
    L0_2 = L0_2.BloodPressure
    L0_2[2] = 0
    L0_2 = BodyDamage
    L0_2.cardiacState = "asystole"
    L0_2 = BodyDamage
    L0_2.Conscious = false
    L0_2 = LocalPlayer
    L0_2 = L0_2.state
    L1_2 = L0_2
    L0_2 = L0_2.set
    L2_2 = "BodyDamage"
    L3_2 = BodyDamage
    L4_2 = true
    L0_2(L1_2, L2_2, L3_2, L4_2)
    L0_2 = DebugPrint
    L1_2 = "sending player to onplayerdeath"
    L0_2(L1_2)
    L0_2 = TriggerServerEvent
    L1_2 = "hospital:server:SetLaststandStatus"
    L2_2 = false
    L0_2(L1_2, L2_2)
    L0_2 = TriggerServerEvent
    L1_2 = "hospital:server:SetDeathStatus"
    L2_2 = true
    L0_2(L1_2, L2_2)
    L0_2 = TriggerServerEvent
    L1_2 = "InteractSound_SV:PlayOnSource"
    L2_2 = "demo"
    L3_2 = 0.1
    L0_2(L1_2, L2_2, L3_2)
    L0_2 = PlayerPedId
    L0_2 = L0_2()
    L1_2 = isPedMovingCheck
    L2_2 = L0_2
    L1_2(L2_2)
    L1_2 = DebugPrint
    L2_2 = "APPLYING DEATH SCREEN IN DEATH STATE"
    L1_2(L2_2)
    L1_2 = Config
    L1_2 = L1_2.CustomDeathScreen
    if false == L1_2 then
      L1_2 = SendNUIMessage
      L2_2 = {}
      L2_2.death = 3
      L2_2.blackout = 4
      L1_2(L2_2)
      L1_2 = SendNUIMessage
      L2_2 = {}
      L2_2.death = 2
      L3_2 = Config
      L3_2 = L3_2.LastStandTime
      L2_2.laststandtime = L3_2
      L3_2 = Config
      L3_2 = L3_2.RespawnTime
      L2_2.respawntime = L3_2
      L1_2(L2_2)
    end
    L1_2 = BodyDamage
    L1_2 = L1_2.isDead
    if L1_2 then
      L1_2 = GetEntityCoords
      L2_2 = L0_2
      L1_2 = L1_2(L2_2)
      L2_2 = GetEntityHeading
      L3_2 = L0_2
      L2_2 = L2_2(L3_2)
      L3_2 = DebugPrint
      L4_2 = "APPLYING ANIMATION, in bodybag: "
      L5_2 = BodyDamage
      L5_2 = L5_2.inBodyBag
      L3_2(L4_2, L5_2)
      L3_2 = instretcher
      if not L3_2 then
        L3_2 = IsPedInAnyVehicle
        L4_2 = L0_2
        L3_2 = L3_2(L4_2)
        if L3_2 then
          L3_2 = GetVehiclePedIsIn
          L4_2 = L0_2
          L3_2 = L3_2(L4_2)
          L4_2 = GetVehicleModelNumberOfSeats
          L5_2 = GetHashKey
          L6_2 = GetEntityModel
          L7_2 = L3_2
          L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L6_2(L7_2)
          L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
          L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
          L5_2 = -1
          L6_2 = L4_2
          L7_2 = 1
          for L8_2 = L5_2, L6_2, L7_2 do
            L9_2 = GetPedInVehicleSeat
            L10_2 = L3_2
            L11_2 = L8_2
            L9_2 = L9_2(L10_2, L11_2)
            if L9_2 == L0_2 then
              L10_2 = NetworkResurrectLocalPlayer
              L11_2 = L1_2.x
              L12_2 = L1_2.y
              L13_2 = L1_2.z
              L13_2 = L13_2 + 0.5
              L14_2 = L2_2
              L15_2 = true
              L16_2 = false
              L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
              L10_2 = SetPedIntoVehicle
              L11_2 = L0_2
              L12_2 = L3_2
              L13_2 = L8_2
              L10_2(L11_2, L12_2, L13_2)
            end
          end
        else
          L3_2 = isInHospitalBed
          if L3_2 then
            L3_2 = NetworkResurrectLocalPlayer
            L4_2 = L1_2.x
            L5_2 = L1_2.y
            L6_2 = L1_2.z
            L7_2 = L2_2
            L8_2 = true
            L9_2 = false
            L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
          else
            L3_2 = NetworkResurrectLocalPlayer
            L4_2 = L1_2.x
            L5_2 = L1_2.y
            L6_2 = L1_2.z
            L6_2 = L6_2 + 0.5
            L7_2 = L2_2
            L8_2 = true
            L9_2 = false
            L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
          end
        end
        L3_2 = IsPedInAnyVehicle
        L4_2 = L0_2
        L5_2 = false
        L3_2 = L3_2(L4_2, L5_2)
        if L3_2 then
          L3_2 = loadAnimDict
          L4_2 = "veh@low@front_ps@idle_duck"
          L3_2(L4_2)
          L3_2 = TaskPlayAnim
          L4_2 = L0_2
          L5_2 = "veh@low@front_ps@idle_duck"
          L6_2 = "sit"
          L7_2 = 1.0
          L8_2 = 1.0
          L9_2 = -1
          L10_2 = 1
          L11_2 = 0
          L12_2 = 0
          L13_2 = 0
          L14_2 = 0
          L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
        else
          L3_2 = BodyDamage
          L3_2 = L3_2.inBodyBag
          if not L3_2 then
            L3_2 = loadAnimDict
            L4_2 = deadAnimDict
            L3_2(L4_2)
            L3_2 = TaskPlayAnim
            L4_2 = L0_2
            L5_2 = deadAnimDict
            L6_2 = deadAnim
            L7_2 = 1.0
            L8_2 = 1.0
            L9_2 = -1
            L10_2 = 1
            L11_2 = 0
            L12_2 = 0
            L13_2 = 0
            L14_2 = 0
            L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
          end
        end
      end
      L3_2 = instretcher
      if L3_2 then
        L3_2 = ClearPedTasks
        L4_2 = L0_2
        L3_2(L4_2)
        L3_2 = ClearPedTasksImmediately
        L4_2 = L0_2
        L3_2(L4_2)
        L3_2 = GetEntityModel
        L4_2 = stretcherEntity
        L3_2 = L3_2(L4_2)
        L4_2 = GetHashKey
        L5_2 = Config
        L5_2 = L5_2.StretcherModel
        L5_2 = L5_2.regular
        L4_2 = L4_2(L5_2)
        if L3_2 == L4_2 then
          L3_2 = AttachEntityToEntity
          L4_2 = L0_2
          L5_2 = stretcherEntity
          L6_2 = nil
          L7_2 = 0.0
          L8_2 = 0.0
          L9_2 = 2.1
          L10_2 = 0.0
          L11_2 = 0.0
          L12_2 = 100.0
          L13_2 = true
          L14_2 = true
          L15_2 = false
          L16_2 = true
          L17_2 = 1
          L18_2 = true
          L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
          L3_2 = lib
          L3_2 = L3_2.requestAnimDict
          L4_2 = "timetable@jimmy@mics3_ig_15@"
          L5_2 = 100
          L3_2(L4_2, L5_2)
          L3_2 = TaskPlayAnim
          L4_2 = L0_2
          L5_2 = "timetable@jimmy@mics3_ig_15@"
          L6_2 = "mics3_15_base_jimmy"
          L7_2 = 8.0
          L8_2 = 8.0
          L9_2 = -1
          L10_2 = 69
          L11_2 = 1
          L12_2 = false
          L13_2 = false
          L14_2 = false
          L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
        else
          L3_2 = GetEntityModel
          L4_2 = entity
          L3_2 = L3_2(L4_2)
          L4_2 = GetHashKey
          L5_2 = Config
          L5_2 = L5_2.StretcherModel
          L5_2 = L5_2.folded
          L4_2 = L4_2(L5_2)
          if L3_2 == L4_2 then
            L3_2 = AttachEntityToEntity
            L4_2 = L0_2
            L5_2 = stretcherEntity
            L6_2 = nil
            L7_2 = 0.15
            L8_2 = 0.0
            L9_2 = 2.1
            L10_2 = 0.0
            L11_2 = 0.0
            L12_2 = 90.0
            L13_2 = true
            L14_2 = true
            L15_2 = false
            L16_2 = true
            L17_2 = 1
            L18_2 = true
            L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
            L3_2 = lib
            L3_2 = L3_2.requestAnimDict
            L4_2 = "anim@gangops@morgue@table@"
            L5_2 = 100
            L3_2(L4_2, L5_2)
            L3_2 = TaskPlayAnim
            L4_2 = L0_2
            L5_2 = "anim@gangops@morgue@table@"
            L6_2 = "body_search"
            L7_2 = 8.0
            L8_2 = 8.0
            L9_2 = -1
            L10_2 = 69
            L11_2 = 1
            L12_2 = false
            L13_2 = false
            L14_2 = false
            L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
          else
            L3_2 = GetEntityModel
            L4_2 = stretcherEntity
            L3_2 = L3_2(L4_2)
            L4_2 = GetHashKey
            L5_2 = Config
            L5_2 = L5_2.StretcherModel
            L5_2 = L5_2.lowered
            L4_2 = L4_2(L5_2)
            if L3_2 == L4_2 then
              L3_2 = AttachEntityToEntity
              L4_2 = L0_2
              L5_2 = stretcherEntity
              L6_2 = nil
              L7_2 = 0.0
              L8_2 = 0.0
              L9_2 = 2.1
              L10_2 = 0.0
              L11_2 = 0.0
              L12_2 = 90.0
              L13_2 = true
              L14_2 = true
              L15_2 = false
              L16_2 = true
              L17_2 = 1
              L18_2 = true
              L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
              L3_2 = lib
              L3_2 = L3_2.requestAnimDict
              L4_2 = "anim@gangops@morgue@table@"
              L5_2 = 100
              L3_2(L4_2, L5_2)
              L3_2 = TaskPlayAnim
              L4_2 = L0_2
              L5_2 = "anim@gangops@morgue@table@"
              L6_2 = "body_search"
              L7_2 = 8.0
              L8_2 = 8.0
              L9_2 = -1
              L10_2 = 69
              L11_2 = 1
              L12_2 = false
              L13_2 = false
              L14_2 = false
              L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
            end
          end
        end
        L3_2 = insideAmbulance
        if L3_2 then
          L3_2 = DetachEntity
          L4_2 = L0_2
          L5_2 = true
          L6_2 = true
          L3_2(L4_2, L5_2, L6_2)
          L3_2 = DetachEntity
          L4_2 = stretcher
          L5_2 = true
          L6_2 = true
          L3_2(L4_2, L5_2, L6_2)
          L3_2 = DeleteEntity
          L4_2 = stretcher
          L3_2(L4_2)
          L3_2 = Config
          L3_2 = L3_2.StretcherModel
          L3_2 = L3_2.lowered
          L4_2 = lib
          L4_2 = L4_2.requestModel
          L5_2 = L3_2
          L6_2 = 10000
          L4_2(L5_2, L6_2)
          L4_2 = lib
          L4_2 = L4_2.requestAnimDict
          L5_2 = "anim@gangops@morgue@table@"
          L6_2 = 1000
          L4_2(L5_2, L6_2)
          L4_2 = lib
          L4_2 = L4_2.requestModel
          L5_2 = "xm_prop_body_bag"
          L6_2 = 10000
          L4_2(L5_2, L6_2)
          L4_2 = CreateObjectNoOffset
          L5_2 = L3_2
          L6_2 = vector3
          L7_2 = 294.018
          L8_2 = -613.7497
          L9_2 = 42.4297
          L6_2 = L6_2(L7_2, L8_2, L9_2)
          L7_2 = 1
          L8_2 = 1
          L9_2 = 0
          L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
          stretcher = L4_2
          L4_2 = Entity
          L5_2 = stretcher
          L4_2 = L4_2(L5_2)
          L4_2 = L4_2.state
          L5_2 = L4_2
          L4_2 = L4_2.set
          L6_2 = "HasPlayer"
          L7_2 = GetPlayerServerId
          L8_2 = NetworkGetPlayerIndexFromPed
          L9_2 = PlayerPedId
          L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L9_2()
          L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
          L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
          L8_2 = true
          L4_2(L5_2, L6_2, L7_2, L8_2)
          L4_2 = GetEntityModel
          L5_2 = stretcherEntity
          L4_2 = L4_2(L5_2)
          L5_2 = GetHashKey
          L6_2 = Config
          L6_2 = L6_2.StretcherModel
          L6_2 = L6_2.folded
          L5_2 = L5_2(L6_2)
          if L4_2 == L5_2 then
            L4_2 = Entity
            L5_2 = stretcher
            L4_2 = L4_2(L5_2)
            L4_2 = L4_2.state
            L5_2 = L4_2
            L4_2 = L4_2.set
            L6_2 = "ifFolded"
            L7_2 = true
            L8_2 = true
            L4_2(L5_2, L6_2, L7_2, L8_2)
          else
            L4_2 = Entity
            L5_2 = stretcher
            L4_2 = L4_2(L5_2)
            L4_2 = L4_2.state
            L5_2 = L4_2
            L4_2 = L4_2.set
            L6_2 = "ifFolded"
            L7_2 = false
            L8_2 = true
            L4_2(L5_2, L6_2, L7_2, L8_2)
          end
          L4_2 = DetachEntity
          L5_2 = L0_2
          L6_2 = true
          L7_2 = true
          L4_2(L5_2, L6_2, L7_2)
          L4_2 = ClearPedTasks
          L5_2 = L0_2
          L4_2(L5_2)
          L4_2 = ClearPedTasksImmediately
          L5_2 = L0_2
          L4_2(L5_2)
          L4_2 = TaskPlayAnim
          L5_2 = L0_2
          L6_2 = "anim@gangops@morgue@table@"
          L7_2 = "body_search"
          L8_2 = 8.0
          L9_2 = 8.0
          L10_2 = -1
          L11_2 = 69
          L12_2 = 1
          L13_2 = false
          L14_2 = false
          L15_2 = false
          L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
          L4_2 = DebugPrint
          L5_2 = "Attaching stretcher to client"
          L6_2 = stretcher
          L4_2(L5_2, L6_2)
          L4_2 = pairs
          L5_2 = Config
          L5_2 = L5_2.Ambulances
          L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
          for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
            L10_2 = IsVehicleModel
            L11_2 = insideAmbulanceEntity
            L12_2 = GetHashKey
            L13_2 = L8_2
            L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L12_2(L13_2)
            L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
            if L10_2 then
              L10_2 = AttachEntityToEntity
              L11_2 = stretcher
              L12_2 = PlayerPedId
              L12_2 = L12_2()
              L13_2 = nil
              L14_2 = L9_2.stretcheroffset
              L15_2 = L9_2.stretcherrotation
              L16_2 = true
              L17_2 = true
              L18_2 = false
              L19_2 = true
              L20_2 = 1
              L21_2 = true
              L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
              L10_2 = DebugPrint
              L11_2 = "Attaching client to vehicle"
              L12_2 = insideAmbulanceEntity
              L10_2(L11_2, L12_2)
              L10_2 = AttachEntityToEntity
              L11_2 = PlayerPedId
              L11_2 = L11_2()
              L12_2 = insideAmbulanceEntity
              L13_2 = nil
              L14_2 = L9_2.playeroffset
              L15_2 = L9_2.playerrotation
              L16_2 = true
              L17_2 = true
              L18_2 = false
              L19_2 = true
              L20_2 = 1
              L21_2 = true
              L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
            end
          end
          L4_2 = Wait
          L5_2 = 500
          L4_2(L5_2)
          L4_2 = TriggerServerEvent
          L5_2 = "osp_ambulance:SyncPulloutTargetSv"
          L6_2 = syncPullout
          L7_2 = NetworkGetNetworkIdFromEntity
          L8_2 = insideAmbulanceEntity
          L7_2 = L7_2(L8_2)
          L8_2 = NetworkGetNetworkIdFromEntity
          L9_2 = stretcher
          L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2 = L8_2(L9_2)
          L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2)
        end
      end
      L3_2 = SetEntityInvincible
      L4_2 = L0_2
      L5_2 = true
      L3_2(L4_2, L5_2)
      L3_2 = SetEntityHealth
      L4_2 = L0_2
      L5_2 = Config
      L5_2 = L5_2.DeathHealth
      L3_2(L4_2, L5_2)
      L3_2 = Config
      L3_2 = L3_2.AutomaticAmbulanceAlert
      if L3_2 then
        L3_2 = Config
        L3_2 = L3_2.Dispatch
        if "ps" == L3_2 then
          L3_2 = exports
          L3_2 = L3_2["ps-dispatch"]
          L4_2 = L3_2
          L3_2 = L3_2.InjuriedPerson
          L3_2(L4_2)
        else
          L3_2 = Config
          L3_2 = L3_2.Dispatch
          if "other" == L3_2 then
            L3_2 = dispatchNotify
            L3_2()
          else
            L3_2 = TriggerServerEvent
            L4_2 = "hospital:server:ambulanceAlert"
            L5_2 = lang
            L5_2 = L5_2.info
            L5_2 = L5_2.civ_down
            L3_2(L4_2, L5_2)
          end
        end
      end
      L3_2 = ClearTimecycleModifier
      L3_2()
      L3_2 = SetExtraTimecycleModifier
      L4_2 = "fp_vig_red"
      L3_2(L4_2)
      L3_2 = SetExtraTimecycleModifierStrength
      L4_2 = 1.0
      L3_2(L4_2)
      L3_2 = SetPedMotionBlur
      L4_2 = PlayerPedId
      L4_2 = L4_2()
      L5_2 = true
      L3_2(L4_2, L5_2)
    end
  end
end
OnDeath = L10_1
function L10_1()
  local L0_2, L1_2, L2_2
  L0_2 = 2
  L0_1 = L0_2
  while true do
    L0_2 = BodyDamage
    L0_2 = L0_2.isDead
    if not L0_2 then
      break
    end
    L0_2 = Wait
    L1_2 = 1000
    L0_2(L1_2)
    L0_2 = deathTime
    L0_2 = L0_2 - 1
    deathTime = L0_2
    L0_2 = deathTime
    if L0_2 <= 0 then
      L0_2 = IsControlPressed
      L1_2 = 0
      L2_2 = 38
      L0_2 = L0_2(L1_2, L2_2)
      if not L0_2 then
        L0_2 = IsDisabledControlPressed
        L1_2 = 0
        L2_2 = 38
        L0_2 = L0_2(L1_2, L2_2)
        if not L0_2 then
          goto lbl_53
        end
      end
      L0_2 = L0_1
      if L0_2 <= 0 then
        L0_2 = isInHospitalBed
        if not L0_2 then
          L0_2 = SetPedMotionBlur
          L1_2 = PlayerPedId
          L1_2 = L1_2()
          L2_2 = false
          L0_2(L1_2, L2_2)
          L0_2 = ClearExtraTimecycleModifier
          L0_2()
          L0_2 = SendNUIMessage
          L1_2 = {}
          L1_2.death = 3
          L0_2(L1_2)
          L0_2 = TriggerEvent
          L1_2 = "hospital:client:RespawnAtHospital"
          L0_2(L1_2)
          L0_2 = 5
          L0_1 = L0_2
          break
        end
      end
      ::lbl_53::
      L0_2 = IsControlPressed
      L1_2 = 0
      L2_2 = 38
      L0_2 = L0_2(L1_2, L2_2)
      if not L0_2 then
        L0_2 = IsDisabledControlPressed
        L1_2 = 0
        L2_2 = 38
        L0_2 = L0_2(L1_2, L2_2)
        if not L0_2 then
          goto lbl_77
        end
      end
      L0_2 = L0_1
      L0_2 = L0_2 - 1
      if L0_2 >= 0 then
        L0_2 = L0_1
        L0_2 = L0_2 - 1
        L0_1 = L0_2
      else
        L0_2 = 0
        L0_1 = L0_2
      end
      ::lbl_77::
      L0_2 = IsControlReleased
      L1_2 = 0
      L2_2 = 38
      L0_2 = L0_2(L1_2, L2_2)
      if not L0_2 then
        L0_2 = IsDisabledControlReleased
        L1_2 = 0
        L2_2 = 38
        L0_2 = L0_2(L1_2, L2_2)
        if not L0_2 then
          goto lbl_91
        end
      end
      L0_2 = 2
      L0_1 = L0_2
    end
    ::lbl_91::
  end
end
DeathTimer = L10_1
function L10_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2, A8_2, A9_2, A10_2)
  local L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L11_2 = SetTextFont
  L12_2 = 4
  L11_2(L12_2)
  L11_2 = SetTextProportional
  L12_2 = 0
  L11_2(L12_2)
  L11_2 = SetTextScale
  L12_2 = A4_2
  L13_2 = A4_2
  L11_2(L12_2, L13_2)
  L11_2 = SetTextColour
  L12_2 = A6_2
  L13_2 = A7_2
  L14_2 = A8_2
  L15_2 = A9_2
  L11_2(L12_2, L13_2, L14_2, L15_2)
  L11_2 = SetTextDropShadow
  L12_2 = 0
  L13_2 = 0
  L14_2 = 0
  L15_2 = 0
  L16_2 = 255
  L11_2(L12_2, L13_2, L14_2, L15_2, L16_2)
  L11_2 = SetTextEdge
  L12_2 = 2
  L13_2 = 0
  L14_2 = 0
  L15_2 = 0
  L16_2 = 255
  L11_2(L12_2, L13_2, L14_2, L15_2, L16_2)
  L11_2 = SetTextDropShadow
  L11_2()
  L11_2 = SetTextOutline
  L11_2()
  L11_2 = SetTextEntry
  L12_2 = "STRING"
  L11_2(L12_2)
  L11_2 = AddTextComponentString
  L12_2 = A5_2
  L11_2(L12_2)
  L11_2 = DrawText
  L12_2 = A2_2 / 2
  L12_2 = A0_2 - L12_2
  L13_2 = A3_2 / 2
  L13_2 = A1_2 - L13_2
  L13_2 = L13_2 + 0.005
  L11_2(L12_2, L13_2)
end
DrawTxt = L10_1
