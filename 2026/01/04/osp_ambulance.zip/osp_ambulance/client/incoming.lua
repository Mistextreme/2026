local L0_1, L1_1, L2_1
L0_1 = Wait
L1_1 = 500
L0_1(L1_1)
width = 1280
height = 720
L0_1 = {}
PolyList = L0_1
L0_1 = {}
incomingMessageCache = L0_1
L0_1 = {}
incomingDuiObj = L0_1
L0_1 = {}
incomingSfHandle = L0_1
incomingDuiUrl = "nui://osp_ambulance/html/incoming.html"
L0_1 = {}
incomingSfName = L0_1
L0_1 = CreateThread
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2
  while true do
    L0_2 = PlayerLoaded
    if L0_2 then
      break
    end
    L0_2 = Wait
    L1_2 = 5000
    L0_2(L1_2)
  end
  L0_2 = DebugPrint
  L1_2 = "Loading screens..."
  L0_2(L1_2)
  L0_2 = Config
  L0_2 = L0_2.ScreenProp
  L1_2 = RequestModel
  L2_2 = L0_2
  L1_2(L2_2)
  while true do
    L1_2 = HasModelLoaded
    L2_2 = L0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = Wait
    L2_2 = 10
    L1_2(L2_2)
  end
  L1_2 = pairs
  L2_2 = Config
  L2_2 = L2_2.Hospitals
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = {}
    L6_2.incomingScreenProps = L7_2
    L7_2 = pairs
    L8_2 = L6_2.IncomingScreenPos
    L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
    for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
      L13_2 = CreateObjectNoOffset
      L14_2 = L0_2
      L15_2 = L12_2.x
      L16_2 = L12_2.y
      L17_2 = L12_2.z
      L18_2 = false
      L19_2 = true
      L20_2 = false
      L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2)
      L14_2 = SetEntityHeading
      L15_2 = L13_2
      L16_2 = L12_2.w
      L14_2(L15_2, L16_2)
      L14_2 = FreezeEntityPosition
      L15_2 = L13_2
      L16_2 = true
      L14_2(L15_2, L16_2)
      L14_2 = SetEntityAlpha
      L15_2 = L13_2
      L16_2 = 255
      L17_2 = false
      L14_2(L15_2, L16_2, L17_2)
      L14_2 = SetEntityAsMissionEntity
      L15_2 = L13_2
      L16_2 = true
      L17_2 = true
      L14_2(L15_2, L16_2, L17_2)
      L14_2 = L6_2.incomingScreenProps
      L14_2[L11_2] = L13_2
      L14_2 = GetOffsetFromEntityInWorldCoords
      L15_2 = L13_2
      L16_2 = incomingScreenOffset
      L14_2 = L14_2(L15_2, L16_2)
      L15_2 = GetEntityRotation
      L16_2 = L13_2
      L15_2 = L15_2(L16_2)
      L16_2 = incomingShowScreen
      L17_2 = L14_2
      L18_2 = L11_2
      L19_2 = L15_2
      L20_2 = L5_2
      L16_2(L17_2, L18_2, L19_2, L20_2)
    end
  end
  L1_2 = SetModelAsNoLongerNeeded
  L2_2 = L0_2
  L1_2(L2_2)
  L1_2 = DebugPrint
  L2_2 = "Incoming Screen Model Loaded"
  L1_2(L2_2)
end
L0_1(L1_1)
L0_1 = CreateThread
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  while true do
    L0_2 = PlayerLoaded
    if L0_2 then
      break
    end
    L0_2 = Wait
    L1_2 = 6000
    L0_2(L1_2)
  end
  while true do
    L0_2 = PlayerPedId
    L0_2 = L0_2()
    L1_2 = GetEntityCoords
    L2_2 = L0_2
    L1_2 = L1_2(L2_2)
    L2_2 = pairs
    L3_2 = Config
    L3_2 = L3_2.Hospitals
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = L7_2.incomingScreenProps
      if L8_2 then
        L8_2 = pairs
        L9_2 = L7_2.IncomingScreenPos
        L8_2, L9_2, L10_2, L11_2 = L8_2(L9_2)
        for L12_2, L13_2 in L8_2, L9_2, L10_2, L11_2 do
          L14_2 = vector3
          L15_2 = L13_2.x
          L16_2 = L13_2.y
          L17_2 = L13_2.z
          L14_2 = L14_2(L15_2, L16_2, L17_2)
          L14_2 = L1_2 - L14_2
          L14_2 = #L14_2
          L15_2 = L7_2.incomingScreenProps
          L15_2 = L15_2[L12_2]
          if L14_2 < 25.0 and L15_2 then
            L16_2 = GetInteriorAtCoords
            L17_2 = L13_2.x
            L18_2 = L13_2.y
            L19_2 = L13_2.z
            L16_2 = L16_2(L17_2, L18_2, L19_2)
            if 0 ~= L16_2 then
              L17_2 = IsValidInterior
              L18_2 = L16_2
              L17_2 = L17_2(L18_2)
              if L17_2 then
                L17_2 = LoadInterior
                L18_2 = L16_2
                L17_2(L18_2)
                while true do
                  L17_2 = IsInteriorReady
                  L18_2 = L16_2
                  L17_2 = L17_2(L18_2)
                  if L17_2 then
                    break
                  end
                  L17_2 = Wait
                  L18_2 = 0
                  L17_2(L18_2)
                end
                L17_2 = Wait
                L18_2 = 10
                L17_2(L18_2)
                L17_2 = GetRoomKeyFromEntity
                L18_2 = L0_2
                L17_2 = L17_2(L18_2)
                if 0 ~= L17_2 then
                  L18_2 = ForceRoomForEntity
                  L19_2 = L15_2
                  L20_2 = L16_2
                  L21_2 = L17_2
                  L18_2(L19_2, L20_2, L21_2)
                end
              end
            end
          end
        end
      end
    end
    L2_2 = Wait
    L3_2 = 1000
    L2_2(L3_2)
  end
end
L0_1(L1_1)
L0_1 = AddEventHandler
L1_1 = "onResourceStop"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  if A0_2 == L1_2 then
    L1_2 = pairs
    L2_2 = Config
    L2_2 = L2_2.Hospitals
    L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
    for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
      L7_2 = pairs
      L8_2 = incomingDuiObj
      L8_2 = L8_2[L5_2]
      L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
      for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
        L13_2 = IsDuiAvailable
        L14_2 = L12_2
        L13_2 = L13_2(L14_2)
        if L13_2 then
          L13_2 = DestroyDui
          L14_2 = L12_2
          L13_2(L14_2)
        end
      end
      L7_2 = pairs
      L8_2 = incomingSfHandle
      L8_2 = L8_2[L5_2]
      L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
      for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
        L13_2 = SetScaleformMovieAsNoLongerNeeded
        L14_2 = L12_2
        L13_2(L14_2)
      end
      L7_2 = pairs
      L8_2 = L6_2.incomingScreenProps
      L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
      for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
        L13_2 = DeleteObject
        L14_2 = L12_2
        L13_2(L14_2)
      end
      L7_2 = pairs
      L8_2 = L6_2.ScreenPropList
      L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
      for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
        L13_2 = DeleteObject
        L14_2 = L12_2
        L13_2(L14_2)
      end
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:incoming"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L0_2 = IsAuthorized
  L0_2 = L0_2()
  if not L0_2 then
    L0_2 = SendTextMessage
    L1_2 = lang
    L1_2 = L1_2.interactions
    L1_2 = L1_2.medicalHeader
    L2_2 = "NOT AUTHORIZED"
    L3_2 = 3000
    L4_2 = "error"
    L0_2(L1_2, L2_2, L3_2, L4_2)
    return
  end
  L0_2 = {}
  L1_2 = {}
  L2_2 = pairs
  L3_2 = Config
  L3_2 = L3_2.Hospitals
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = table
    L8_2 = L8_2.insert
    L9_2 = L0_2
    L10_2 = {}
    L10_2.value = L6_2
    L11_2 = L7_2.label
    L10_2.label = L11_2
    L8_2(L9_2, L10_2)
  end
  L2_2 = pairs
  L3_2 = lang
  L3_2 = L3_2.incoming
  L3_2 = L3_2.sex
  L3_2 = L3_2.options
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = table
    L8_2 = L8_2.insert
    L9_2 = L1_2
    L10_2 = {}
    L12_2 = L7_2
    L11_2 = L7_2.lower
    L11_2 = L11_2(L12_2)
    L10_2.value = L11_2
    L12_2 = L7_2
    L11_2 = L7_2.upper
    L11_2 = L11_2(L12_2)
    L10_2.label = L11_2
    L8_2(L9_2, L10_2)
  end
  L2_2 = lib
  L2_2 = L2_2.inputDialog
  L3_2 = lang
  L3_2 = L3_2.incoming
  L3_2 = L3_2.pager
  L4_2 = {}
  L5_2 = {}
  L5_2.type = "input"
  L6_2 = lang
  L6_2 = L6_2.incoming
  L6_2 = L6_2.name
  L5_2.label = L6_2
  L6_2 = lang
  L6_2 = L6_2.incoming
  L6_2 = L6_2.namedesc
  L5_2.description = L6_2
  L6_2 = {}
  L6_2.type = "select"
  L7_2 = lang
  L7_2 = L7_2.incoming
  L7_2 = L7_2.sex
  L7_2 = L7_2.label
  L6_2.label = L7_2
  L7_2 = lang
  L7_2 = L7_2.incoming
  L7_2 = L7_2.sex
  L7_2 = L7_2.description
  L6_2.description = L7_2
  L6_2.options = L1_2
  L7_2 = {}
  L7_2.type = "number"
  L8_2 = lang
  L8_2 = L8_2.incoming
  L8_2 = L8_2.age
  L7_2.label = L8_2
  L8_2 = lang
  L8_2 = L8_2.incoming
  L8_2 = L8_2.agedesc
  L7_2.description = L8_2
  L8_2 = {}
  L8_2.type = "select"
  L9_2 = lang
  L9_2 = L9_2.incoming
  L9_2 = L9_2.condition
  L8_2.label = L9_2
  L9_2 = {}
  L10_2 = {}
  L11_2 = lang
  L11_2 = L11_2.incoming
  L11_2 = L11_2.stable
  L10_2.value = L11_2
  L11_2 = lang
  L11_2 = L11_2.incoming
  L11_2 = L11_2.stable
  L10_2.label = L11_2
  L11_2 = {}
  L12_2 = lang
  L12_2 = L12_2.incoming
  L12_2 = L12_2.guarded
  L11_2.value = L12_2
  L12_2 = lang
  L12_2 = L12_2.incoming
  L12_2 = L12_2.guarded
  L11_2.label = L12_2
  L12_2 = {}
  L13_2 = lang
  L13_2 = L13_2.incoming
  L13_2 = L13_2.critical
  L12_2.value = L13_2
  L13_2 = lang
  L13_2 = L13_2.incoming
  L13_2 = L13_2.critical
  L12_2.label = L13_2
  L13_2 = {}
  L14_2 = lang
  L14_2 = L14_2.incoming
  L14_2 = L14_2.deceased
  L13_2.value = L14_2
  L14_2 = lang
  L14_2 = L14_2.incoming
  L14_2 = L14_2.deceased
  L13_2.label = L14_2
  L9_2[1] = L10_2
  L9_2[2] = L11_2
  L9_2[3] = L12_2
  L9_2[4] = L13_2
  L8_2.options = L9_2
  L9_2 = {}
  L9_2.type = "number"
  L10_2 = lang
  L10_2 = L10_2.incoming
  L10_2 = L10_2.eta
  L9_2.label = L10_2
  L10_2 = lang
  L10_2 = L10_2.incoming
  L10_2 = L10_2.etadesc
  L9_2.description = L10_2
  L10_2 = {}
  L10_2.type = "select"
  L11_2 = lang
  L11_2 = L11_2.incoming
  L11_2 = L11_2.hospital
  L10_2.label = L11_2
  L11_2 = lang
  L11_2 = L11_2.incoming
  L11_2 = L11_2.hospitaldesc
  L10_2.description = L11_2
  L10_2.options = L0_2
  L4_2[1] = L5_2
  L4_2[2] = L6_2
  L4_2[3] = L7_2
  L4_2[4] = L8_2
  L4_2[5] = L9_2
  L4_2[6] = L10_2
  L2_2 = L2_2(L3_2, L4_2)
  if not L2_2 then
    return
  end
  L3_2 = L2_2[1]
  L4_2 = L2_2[2]
  L5_2 = L2_2[3]
  L6_2 = L2_2[4]
  L7_2 = L2_2[5]
  L8_2 = L2_2[6]
  if nil == L8_2 then
    L9_2 = print
    L10_2 = "[ERROR] Missing hospital selection!"
    L9_2(L10_2)
    return
  end
  if nil == L3_2 then
    L9_2 = lang
    L9_2 = L9_2.incoming
    L3_2 = L9_2.unkown
  end
  if nil == L4_2 then
    L9_2 = lang
    L9_2 = L9_2.incoming
    L4_2 = L9_2.unkown
  end
  if nil == L5_2 then
    L9_2 = lang
    L9_2 = L9_2.incoming
    L5_2 = L9_2.unkown
  end
  if nil == L6_2 then
    L9_2 = lang
    L9_2 = L9_2.incoming
    L6_2 = L9_2.unkown
  end
  if nil == L7_2 then
    L9_2 = lang
    L9_2 = L9_2.incoming
    L7_2 = L9_2.unkown
  end
  L9_2 = {}
  L10_2 = L3_2
  L11_2 = L4_2
  L12_2 = L5_2
  L13_2 = L6_2
  L14_2 = L7_2
  L15_2 = L8_2
  L9_2[1] = L10_2
  L9_2[2] = L11_2
  L9_2[3] = L12_2
  L9_2[4] = L13_2
  L9_2[5] = L14_2
  L9_2[6] = L15_2
  L10_2 = TriggerServerEvent
  L11_2 = "osp_ambulance:SyncIncomingSv"
  L12_2 = L9_2
  L10_2(L11_2, L12_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:SyncIncomingCl"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L1_2 = "green"
  L2_2 = A0_2[4]
  L3_2 = lang
  L3_2 = L3_2.incoming
  L3_2 = L3_2.stable
  if L2_2 == L3_2 then
    L1_2 = "green"
  else
    L2_2 = A0_2[4]
    L3_2 = lang
    L3_2 = L3_2.incoming
    L3_2 = L3_2.guarded
    if L2_2 == L3_2 then
      L1_2 = "yellow"
    else
      L2_2 = A0_2[4]
      L3_2 = lang
      L3_2 = L3_2.incoming
      L3_2 = L3_2.critical
      if L2_2 == L3_2 then
        L1_2 = "red"
      else
        L2_2 = A0_2[4]
        L3_2 = lang
        L3_2 = L3_2.incoming
        L3_2 = L3_2.deceased
        if L2_2 == L3_2 then
          L1_2 = "black"
        end
      end
    end
  end
  L2_2 = A0_2[6]
  A0_2[7] = L1_2
  L3_2 = incomingMessageCache
  L4_2 = incomingMessageCache
  L4_2 = L4_2[L2_2]
  if not L4_2 then
    L4_2 = {}
  end
  L3_2[L2_2] = L4_2
  L3_2 = table
  L3_2 = L3_2.insert
  L4_2 = incomingMessageCache
  L4_2 = L4_2[L2_2]
  L5_2 = A0_2
  L3_2(L4_2, L5_2)
  L3_2 = pairs
  L4_2 = Config
  L4_2 = L4_2.Hospitals
  L4_2 = L4_2[L2_2]
  L4_2 = L4_2.IncomingScreenPos
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
    L9_2 = incomingDuiObj
    L9_2 = L9_2[L2_2]
    L9_2 = L9_2[L7_2]
    if L9_2 then
      L9_2 = SendDuiMessage
      L10_2 = incomingDuiObj
      L10_2 = L10_2[L2_2]
      L10_2 = L10_2[L7_2]
      L11_2 = json
      L11_2 = L11_2.encode
      L12_2 = {}
      L12_2.type = "incoming"
      L13_2 = A0_2[1]
      L12_2.name = L13_2
      L13_2 = A0_2[2]
      L12_2.sex = L13_2
      L13_2 = A0_2[3]
      L12_2.age = L13_2
      L13_2 = A0_2[4]
      L12_2.condition = L13_2
      L13_2 = A0_2[5]
      L12_2.eta = L13_2
      L12_2.color = L1_2
      L11_2, L12_2, L13_2, L14_2, L15_2 = L11_2(L12_2)
      L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
    end
  end
  L3_2 = pairs
  L4_2 = Config
  L4_2 = L4_2.Hospitals
  L4_2 = L4_2[L2_2]
  L4_2 = L4_2.IncomingScreenSoundPos
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
    L9_2 = TriggerSound
    L10_2 = "inc"
    L11_2 = L8_2
    L12_2 = Config
    L12_2 = L12_2.IncomingScreenSoundRange
    L9_2(L10_2, L11_2, L12_2)
    L9_2 = Config
    L9_2 = L9_2.UseXsound
    if L9_2 then
      L9_2 = xSound
      L10_2 = L9_2
      L9_2 = L9_2.PlayUrlPos
      L11_2 = "codeblue"
      L12_2 = "inc.mp3"
      L13_2 = 0.1
      L14_2 = L8_2
      L15_2 = false
      L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
      L9_2 = xSound
      L10_2 = L9_2
      L9_2 = L9_2.Distance
      L11_2 = "codeblue"
      L12_2 = Config
      L12_2 = L12_2.IncomingScreenSoundRange
      L9_2(L10_2, L11_2, L12_2)
      L9_2 = xSound
      L10_2 = L9_2
      L9_2 = L9_2.destroyOnFinish
      L11_2 = "codeblue"
      L12_2 = true
      L9_2(L10_2, L11_2, L12_2)
    end
  end
  L3_2 = CreateThread
  function L4_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    L0_3 = A0_2
    while true do
      L1_3 = Wait
      L2_3 = 60000
      L1_3(L2_3)
      L1_3 = L0_3[5]
      if L1_3 then
        L1_3 = L0_3[5]
        if L1_3 >= 1 then
          L1_3 = L0_3[5]
          L1_3 = L1_3 - 1
          L0_3[5] = L1_3
          L1_3 = pairs
          L2_3 = Config
          L2_3 = L2_3.Hospitals
          L3_3 = L0_3[6]
          L2_3 = L2_3[L3_3]
          L2_3 = L2_3.IncomingScreenPos
          L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
          for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
            L7_3 = incomingDuiObj
            L8_3 = L0_3[6]
            L7_3 = L7_3[L8_3]
            L7_3 = L7_3[L5_3]
            if L7_3 then
              L7_3 = SendDuiMessage
              L8_3 = incomingDuiObj
              L9_3 = L0_3[6]
              L8_3 = L8_3[L9_3]
              L8_3 = L8_3[L5_3]
              L9_3 = json
              L9_3 = L9_3.encode
              L10_3 = {}
              L10_3.type = "incoming"
              L11_3 = L0_3[1]
              L10_3.name = L11_3
              L11_3 = L0_3[2]
              L10_3.sex = L11_3
              L11_3 = L0_3[3]
              L10_3.age = L11_3
              L11_3 = L0_3[4]
              L10_3.condition = L11_3
              L11_3 = L0_3[5]
              L10_3.eta = L11_3
              L11_3 = L0_3[7]
              L10_3.color = L11_3
              L9_3, L10_3, L11_3 = L9_3(L10_3)
              L7_3(L8_3, L9_3, L10_3, L11_3)
            end
          end
        else
          L1_3 = Wait
          L2_3 = 120000
          L1_3(L2_3)
          L1_3 = pairs
          L2_3 = Config
          L2_3 = L2_3.Hospitals
          L3_3 = L0_3[6]
          L2_3 = L2_3[L3_3]
          L2_3 = L2_3.IncomingScreenPos
          L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
          for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
            L7_3 = incomingDuiObj
            L8_3 = L0_3[6]
            L7_3 = L7_3[L8_3]
            L7_3 = L7_3[L5_3]
            if L7_3 then
              L7_3 = SendDuiMessage
              L8_3 = incomingDuiObj
              L9_3 = L0_3[6]
              L8_3 = L8_3[L9_3]
              L8_3 = L8_3[L5_3]
              L9_3 = json
              L9_3 = L9_3.encode
              L10_3 = {}
              L10_3.type = "default"
              L9_3, L10_3, L11_3 = L9_3(L10_3)
              L7_3(L8_3, L9_3, L10_3, L11_3)
            end
          end
          L1_3 = pairs
          L2_3 = soundTable
          L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
          for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
            if "codeblue" == L6_3 then
              L7_3 = StopSound
              L8_3 = L5_3
              L7_3(L8_3)
              L7_3 = ReleaseSoundId
              L8_3 = L5_3
              L7_3(L8_3)
              L7_3 = soundTable
              L7_3[L5_3] = nil
            end
          end
          L1_3 = pairs
          L2_3 = incomingMessageCache
          L3_3 = L0_3[6]
          L2_3 = L2_3[L3_3]
          L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
          for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
            L7_3 = L6_3[1]
            L8_3 = L0_3[1]
            if L7_3 == L8_3 then
              L7_3 = table
              L7_3 = L7_3.remove
              L8_3 = incomingMessageCache
              L9_3 = L0_3[6]
              L8_3 = L8_3[L9_3]
              L9_3 = L5_3
              L7_3(L8_3, L9_3)
            end
          end
          break
        end
      end
    end
  end
  L3_2(L4_2)
end
L0_1(L1_1, L2_1)
function L0_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L4_2 = incomingSfName
  L5_2 = incomingSfName
  L5_2 = L5_2[A3_2]
  if not L5_2 then
    L5_2 = {}
  end
  L4_2[A3_2] = L5_2
  L4_2 = incomingSfHandle
  L5_2 = incomingSfHandle
  L5_2 = L5_2[A3_2]
  if not L5_2 then
    L5_2 = {}
  end
  L4_2[A3_2] = L5_2
  L4_2 = incomingDuiObj
  L5_2 = incomingDuiObj
  L5_2 = L5_2[A3_2]
  if not L5_2 then
    L5_2 = {}
  end
  L4_2[A3_2] = L5_2
  L4_2 = incomingSfName
  L4_2 = L4_2[A3_2]
  L5_2 = "generic_texture_renderer_incoming"
  L6_2 = A1_2
  L5_2 = L5_2 .. L6_2
  L4_2[A1_2] = L5_2
  L4_2 = DebugPrint
  L5_2 = "Incoming Screen Name: "
  L6_2 = incomingSfName
  L6_2 = L6_2[A3_2]
  L6_2 = L6_2[A1_2]
  L5_2 = L5_2 .. L6_2
  L4_2(L5_2)
  L4_2 = false
  function L5_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3
    L1_3 = Wait
    L2_3 = 2000
    L1_3(L2_3)
    L1_3 = true
    L4_2 = L1_3
    L1_3 = incomingSfHandle
    L2_3 = A3_2
    L1_3 = L1_3[L2_3]
    L2_3 = A1_2
    L3_3 = incomingSfHandle
    L4_3 = A3_2
    L3_3 = L3_3[L4_3]
    L4_3 = A1_2
    L3_3 = L3_3[L4_3]
    if not L3_3 then
      L3_3 = nil
    end
    L1_3[L2_3] = L3_3
    L1_3 = incomingDuiObj
    L2_3 = A3_2
    L1_3 = L1_3[L2_3]
    L2_3 = A1_2
    L3_3 = incomingDuiObj
    L4_3 = A3_2
    L3_3 = L3_3[L4_3]
    L4_3 = A1_2
    L3_3 = L3_3[L4_3]
    if not L3_3 then
      L3_3 = nil
    end
    L1_3[L2_3] = L3_3
    L1_3 = incomingSfHandle
    L2_3 = A3_2
    L1_3 = L1_3[L2_3]
    L2_3 = A1_2
    L3_3 = loadScaleform
    L4_3 = incomingSfName
    L5_3 = A3_2
    L4_3 = L4_3[L5_3]
    L5_3 = A1_2
    L4_3 = L4_3[L5_3]
    L3_3 = L3_3(L4_3)
    L1_3[L2_3] = L3_3
    L1_3 = incomingSfHandle
    L2_3 = A3_2
    L1_3 = L1_3[L2_3]
    L2_3 = A1_2
    L1_3 = L1_3[L2_3]
    if L1_3 then
      L1_3 = DebugPrint
      L2_3 = "Incoming Screen Handle: "
      L3_3 = incomingSfHandle
      L4_3 = A3_2
      L3_3 = L3_3[L4_3]
      L4_3 = A1_2
      L3_3 = L3_3[L4_3]
      L1_3(L2_3, L3_3)
      L1_3 = CreateRuntimeTxd
      L2_3 = "osp_b_dict"
      L1_3 = L1_3(L2_3)
      L2_3 = incomingDuiObj
      L3_3 = A3_2
      L2_3 = L2_3[L3_3]
      L3_3 = A1_2
      L4_3 = CreateDui
      L5_3 = incomingDuiUrl
      L6_3 = width
      L7_3 = height
      L4_3 = L4_3(L5_3, L6_3, L7_3)
      L2_3[L3_3] = L4_3
      L2_3 = GetDuiHandle
      L3_3 = incomingDuiObj
      L4_3 = A3_2
      L3_3 = L3_3[L4_3]
      L4_3 = A1_2
      L3_3 = L3_3[L4_3]
      L2_3 = L2_3(L3_3)
      L3_3 = CreateRuntimeTextureFromDuiHandle
      L4_3 = L1_3
      L5_3 = "osp_b_txd"
      L6_3 = L2_3
      L3_3 = L3_3(L4_3, L5_3, L6_3)
      L4_3 = Wait
      L5_3 = 10
      L4_3(L5_3)
      L4_3 = PushScaleformMovieFunction
      L5_3 = incomingSfHandle
      L6_3 = A3_2
      L5_3 = L5_3[L6_3]
      L6_3 = A1_2
      L5_3 = L5_3[L6_3]
      L6_3 = "SET_TEXTURE"
      L4_3(L5_3, L6_3)
      L4_3 = PushScaleformMovieMethodParameterString
      L5_3 = "osp_b_dict"
      L4_3(L5_3)
      L4_3 = PushScaleformMovieMethodParameterString
      L5_3 = "osp_b_txd"
      L4_3(L5_3)
      L4_3 = PushScaleformMovieFunctionParameterInt
      L5_3 = 0
      L4_3(L5_3)
      L4_3 = PushScaleformMovieFunctionParameterInt
      L5_3 = 0
      L4_3(L5_3)
      L4_3 = PushScaleformMovieFunctionParameterInt
      L5_3 = width
      L4_3(L5_3)
      L4_3 = PushScaleformMovieFunctionParameterInt
      L5_3 = height
      L4_3(L5_3)
      L4_3 = PopScaleformMovieFunctionVoid
      L4_3()
    end
    L1_3 = json
    L1_3 = L1_3.encode
    L2_3 = incomingMessageCache
    L1_3 = L1_3(L2_3)
    if "[]" ~= L1_3 then
      L1_3 = json
      L1_3 = L1_3.encode
      L2_3 = incomingMessageCache
      L3_3 = A3_2
      L2_3 = L2_3[L3_3]
      L1_3 = L1_3(L2_3)
      if "[]" ~= L1_3 then
        L1_3 = pairs
        L2_3 = incomingMessageCache
        L3_3 = A3_2
        L2_3 = L2_3[L3_3]
        L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
        for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
          L7_3 = pairs
          L8_3 = Config
          L8_3 = L8_3.Hospitals
          L9_3 = A3_2
          L8_3 = L8_3[L9_3]
          L8_3 = L8_3.IncomingScreenPos
          L7_3, L8_3, L9_3, L10_3 = L7_3(L8_3)
          for L11_3, L12_3 in L7_3, L8_3, L9_3, L10_3 do
            L13_3 = incomingDuiObj
            L14_3 = A3_2
            L13_3 = L13_3[L14_3]
            L13_3 = L13_3[L11_3]
            if L13_3 then
              L13_3 = SendDuiMessage
              L14_3 = incomingDuiObj
              L15_3 = A3_2
              L14_3 = L14_3[L15_3]
              L14_3 = L14_3[L11_3]
              L15_3 = json
              L15_3 = L15_3.encode
              L16_3 = {}
              L16_3.type = "incoming"
              L17_3 = L6_3[1]
              L16_3.name = L17_3
              L17_3 = L6_3[2]
              L16_3.sex = L17_3
              L17_3 = L6_3[3]
              L16_3.age = L17_3
              L17_3 = L6_3[4]
              L16_3.condition = L17_3
              L17_3 = L6_3[5]
              L16_3.eta = L17_3
              L17_3 = L6_3[7]
              L16_3.color = L17_3
              L15_3, L16_3, L17_3 = L15_3(L16_3)
              L13_3(L14_3, L15_3, L16_3, L17_3)
            end
          end
        end
      end
    end
  end
  function L6_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = false
    L4_2 = L1_3
    L1_3 = incomingDuiObj
    L2_3 = A3_2
    L1_3 = L1_3[L2_3]
    L2_3 = A1_2
    L1_3 = L1_3[L2_3]
    if nil ~= L1_3 then
      L1_3 = IsDuiAvailable
      L2_3 = incomingDuiObj
      L3_3 = A3_2
      L2_3 = L2_3[L3_3]
      L3_3 = A1_2
      L2_3 = L2_3[L3_3]
      L1_3 = L1_3(L2_3)
      if L1_3 then
        L1_3 = DestroyDui
        L2_3 = incomingDuiObj
        L3_3 = A3_2
        L2_3 = L2_3[L3_3]
        L3_3 = A1_2
        L2_3 = L2_3[L3_3]
        L1_3(L2_3)
      else
        L1_3 = print
        L2_3 = "^1 Incoming screen not available when destroying"
        L1_3(L2_3)
      end
      L1_3 = incomingDuiObj
      L2_3 = A3_2
      L1_3 = L1_3[L2_3]
      L2_3 = A1_2
      L1_3[L2_3] = nil
    end
    L1_3 = incomingSfHandle
    L2_3 = A3_2
    L1_3 = L1_3[L2_3]
    L2_3 = A1_2
    L1_3 = L1_3[L2_3]
    if nil ~= L1_3 then
      L1_3 = SetScaleformMovieAsNoLongerNeeded
      L2_3 = incomingSfHandle
      L3_3 = A3_2
      L2_3 = L2_3[L3_3]
      L3_3 = A1_2
      L2_3 = L2_3[L3_3]
      L1_3(L2_3)
      L1_3 = incomingSfHandle
      L2_3 = A3_2
      L1_3 = L1_3[L2_3]
      L2_3 = A1_2
      L1_3[L2_3] = nil
    end
  end
  L7_2 = lib
  L7_2 = L7_2.zones
  L7_2 = L7_2.box
  L8_2 = {}
  L9_2 = vec3
  L10_2 = A0_2.x
  L11_2 = A0_2.y
  L12_2 = A0_2.z
  L12_2 = L12_2 - 10
  L9_2 = L9_2(L10_2, L11_2, L12_2)
  L8_2.coords = L9_2
  L9_2 = propdupe
  L8_2.name = L9_2
  L9_2 = vec3
  L10_2 = Config
  L10_2 = L10_2.IncomingRenderDistance
  L11_2 = Config
  L11_2 = L11_2.IncomingRenderDistance
  L12_2 = Config
  L12_2 = L12_2.IncomingRenderDistance
  L9_2 = L9_2(L10_2, L11_2, L12_2)
  L8_2.size = L9_2
  L8_2.rotation = 45
  L8_2.debug = false
  L9_2 = inside
  L8_2.inside = L9_2
  L8_2.onEnter = L5_2
  L8_2.onExit = L6_2
  L7_2 = L7_2(L8_2)
  statECGPoly = L7_2
  L7_2 = DebugPrint
  L8_2 = "Ready to load incoming screen"
  L7_2(L8_2)
  L7_2 = GetFrameTime
  L7_2 = L7_2()
  L8_2 = 0.02
  if L7_2 > L8_2 then
    L8_2 = 5
    if L8_2 then
      goto lbl_91
    end
  end
  L8_2 = 0.011
  if L7_2 > L8_2 then
    L8_2 = 3
    if L8_2 then
      goto lbl_91
    end
  end
  L8_2 = 1
  ::lbl_91::
  L9_2 = CreateThread
  function L10_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L0_3 = 1000
    while true do
      L0_3 = 1000
      L1_3 = L4_2
      if L1_3 then
        L0_3 = L8_2
        L1_3 = incomingDuiObj
        L2_3 = A3_2
        L1_3 = L1_3[L2_3]
        L2_3 = A1_2
        L1_3 = L1_3[L2_3]
        if L1_3 then
          L1_3 = incomingSfHandle
          L2_3 = A3_2
          L1_3 = L1_3[L2_3]
          L2_3 = A1_2
          L1_3 = L1_3[L2_3]
          if L1_3 then
            L1_3 = HasScaleformMovieLoaded
            L2_3 = incomingSfHandle
            L3_3 = A3_2
            L2_3 = L2_3[L3_3]
            L3_3 = A1_2
            L2_3 = L2_3[L3_3]
            L1_3 = L1_3(L2_3)
            if L1_3 then
              L1_3 = DrawScaleformMovie_3dSolid
              L2_3 = incomingSfHandle
              L3_3 = A3_2
              L2_3 = L2_3[L3_3]
              L3_3 = A1_2
              L2_3 = L2_3[L3_3]
              L3_3 = A0_2.x
              L4_3 = A0_2.y
              L5_3 = A0_2.z
              L6_3 = A2_2.x
              L7_3 = incomingScreenRot
              L6_3 = L6_3 + L7_3
              L7_3 = A2_2.y
              L8_3 = A2_2.z
              L9_3 = 2.0
              L10_3 = 2.0
              L11_3 = 2.0
              L12_3 = incomingScreenScale
              L12_3 = L12_3 * 1
              L13_3 = incomingScreenScale
              L13_3 = L13_3 * 0.5625
              L14_3 = 2
              L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
            end
          end
        end
      end
      L1_3 = Wait
      L2_3 = L0_3
      L1_3(L2_3)
    end
  end
  L9_2(L10_2)
end
incomingShowScreen = L0_1
