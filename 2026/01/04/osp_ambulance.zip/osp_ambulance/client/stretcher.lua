local L0_1, L1_1, L2_1
L0_1 = {}
stretcherPolyList = L0_1
activeStretcher = false
L0_1 = {}
stretcherInVehicle = L0_1
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:SpawnStretcher"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = Config
  L0_2 = L0_2.StretcherLimit
  if L0_2 then
    L0_2 = activeStretcher
    if L0_2 then
      L0_2 = SendTextMessage
      L1_2 = "Ambulance"
      L2_2 = "Please delete other stretcher first"
      L3_2 = 5000
      L4_2 = "error"
      L0_2(L1_2, L2_2, L3_2, L4_2)
      return
    end
    activeStretcher = true
  end
  L0_2 = TriggerServerEvent
  L1_2 = "osp_ambulance:removeItem"
  L2_2 = "stretcher"
  L3_2 = 1
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = lib
  L0_2 = L0_2.requestModel
  L1_2 = Config
  L1_2 = L1_2.StretcherModel
  L1_2 = L1_2.regular
  L2_2 = 10000
  L0_2(L1_2, L2_2)
  L0_2 = CreateObjectNoOffset
  L1_2 = Config
  L1_2 = L1_2.StretcherModel
  L1_2 = L1_2.regular
  L2_2 = GetEntityCoords
  L3_2 = PlayerPedId
  L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L3_2()
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L2_2 = L2_2 - 2
  L3_2 = 1
  L4_2 = 1
  L5_2 = 0
  L0_2 = L0_2(L1_2, L2_2, L3_2, L4_2, L5_2)
  while not L0_2 do
    L1_2 = Wait
    L2_2 = 100
    L1_2(L2_2)
    L1_2 = print
    L2_2 = "^1OBJECT HAS NOT SPAWNED YET"
    L3_2 = L0_2
    L1_2(L2_2, L3_2)
  end
  L1_2 = GetEntityModel
  L2_2 = PlayerPedId
  L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L2_2()
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L2_2 = GetHashKey
  L3_2 = "mp_m_freemode_01"
  L2_2 = L2_2(L3_2)
  if L1_2 ~= L2_2 then
    L1_2 = GetEntityModel
    L2_2 = PlayerPedId
    L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L2_2()
    L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
    L2_2 = GetHashKey
    L3_2 = "mp_f_freemode_01"
    L2_2 = L2_2(L3_2)
    if L1_2 ~= L2_2 then
      goto lbl_95
    end
  end
  L1_2 = AttachEntityToEntity
  L2_2 = L0_2
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = GetPedBoneIndex
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  L6_2 = 64654
  L4_2 = L4_2(L5_2, L6_2)
  L5_2 = Config
  L5_2 = L5_2.StretcherAttach
  L5_2 = L5_2.playerOnStretcherOffset
  L5_2 = L5_2.freemode
  L6_2 = Config
  L6_2 = L6_2.StretcherAttach
  L6_2 = L6_2.playerOnStretcherRotation
  L6_2 = L6_2.freemode
  L7_2 = true
  L8_2 = true
  L9_2 = false
  L10_2 = true
  L11_2 = 1
  L12_2 = true
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  goto lbl_119
  ::lbl_95::
  L1_2 = AttachEntityToEntity
  L2_2 = L0_2
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = GetPedBoneIndex
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  L6_2 = 64654
  L4_2 = L4_2(L5_2, L6_2)
  L5_2 = Config
  L5_2 = L5_2.StretcherAttach
  L5_2 = L5_2.playerOnStretcherOffset
  L5_2 = L5_2.ped
  L6_2 = Config
  L6_2 = L6_2.StretcherAttach
  L6_2 = L6_2.playerOnStretcherRotation
  L6_2 = L6_2.ped
  L7_2 = true
  L8_2 = true
  L9_2 = false
  L10_2 = true
  L11_2 = 1
  L12_2 = true
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  ::lbl_119::
  L1_2 = lib
  L1_2 = L1_2.requestAnimDict
  L2_2 = "anim@heists@box_carry@"
  L3_2 = 1000
  L1_2(L2_2, L3_2)
  L1_2 = TaskPlayAnim
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = "anim@heists@box_carry@"
  L4_2 = "idle"
  L5_2 = 8.0
  L6_2 = 8.0
  L7_2 = -1
  L8_2 = 50
  L9_2 = 0
  L10_2 = false
  L11_2 = false
  L12_2 = false
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L1_2 = Config
  L1_2 = L1_2.UseTarget
  if L1_2 then
    L1_2 = creatingStretcherInteraction
    L2_2 = L0_2
    L1_2(L2_2)
  end
  L1_2 = CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3
    while true do
      L0_3 = IsControlJustPressed
      L1_3 = 0
      L2_3 = Config
      L2_3 = L2_3.ReleaseStretcher
      L0_3 = L0_3(L1_3, L2_3)
      if L0_3 then
        L0_3 = ClearPedTasks
        L1_3 = PlayerPedId
        L1_3, L2_3 = L1_3()
        L0_3(L1_3, L2_3)
        L0_3 = DetachEntity
        L1_3 = L0_2
        L0_3(L1_3)
        L0_3 = PlaceObjectOnGroundProperly
        L1_3 = L0_2
        L0_3(L1_3)
        L0_3 = GetEntityModel
        L1_3 = L0_2
        L0_3 = L0_3(L1_3)
        L1_3 = GetHashKey
        L2_3 = Config
        L2_3 = L2_3.StretcherModel
        L2_3 = L2_3.folded
        L1_3 = L1_3(L2_3)
        if L0_3 == L1_3 then
          L0_3 = SetEntityCollision
          L1_3 = L0_2
          L2_3 = true
          L0_3(L1_3, L2_3)
          L0_3 = FreezeEntityPosition
          L1_3 = L0_2
          L2_3 = true
          L0_3(L1_3, L2_3)
        end
        L0_3 = Config
        L0_3 = L0_3.UseTarget
        if not L0_3 then
          L0_3 = CreateThread
          function L1_3()
            local L0_4, L1_4
            L0_4 = Wait
            L1_4 = 500
            L0_4(L1_4)
            L0_4 = creatingStretcherPoly
            L1_4 = L0_2
            L0_4(L1_4)
          end
          L0_3(L1_3)
        end
        break
      end
      L0_3 = Wait
      L1_3 = 3
      L0_3(L1_3)
    end
  end
  L1_2(L2_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:PutPlayerInOutStretcherPrepCl"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = instretcher
  if L1_2 then
    return
  end
  L1_2 = lib
  L1_2 = L1_2.getClosestPlayer
  L2_2 = GetEntityCoords
  L3_2 = A0_2.entity
  L2_2 = L2_2(L3_2)
  L3_2 = 5.0
  L4_2 = false
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L2_2 = Entity
  L3_2 = A0_2.entity
  L2_2 = L2_2(L3_2)
  L3_2 = L2_2.state
  L3_2 = L3_2.HasPlayer
  if L1_2 then
    L4_2 = GetPlayerServerId
    L5_2 = L1_2
    L4_2 = L4_2(L5_2)
    if L3_2 then
      L5_2 = TriggerServerEvent
      L6_2 = "osp_ambulance:PutPlayerInOutStretcherSv"
      L7_2 = L3_2
      L8_2 = NetworkGetNetworkIdFromEntity
      L9_2 = A0_2.entity
      L8_2 = L8_2(L9_2)
      L9_2 = A0_2.manual
      L5_2(L6_2, L7_2, L8_2, L9_2)
    else
      L5_2 = TriggerServerEvent
      L6_2 = "osp_ambulance:PutPlayerInOutStretcherSv"
      L7_2 = L4_2
      L8_2 = NetworkGetNetworkIdFromEntity
      L9_2 = A0_2.entity
      L8_2 = L8_2(L9_2)
      L9_2 = A0_2.manual
      L5_2(L6_2, L7_2, L8_2, L9_2)
    end
  else
    L4_2 = print
    L5_2 = "no player nearby"
    L4_2(L5_2)
  end
end
L0_1(L1_1, L2_1)
instretcher = false
stretcherEntity = nil
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:PutPlayerInOutStretcherCl"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2
  L2_2 = NetworkGetEntityFromNetworkId
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  stretcherEntity = L2_2
  L4_2 = instretcher
  if not L4_2 then
    L4_2 = TriggerEvent
    L5_2 = "osp_ambulance:PlacedInStretcher"
    L4_2(L5_2)
    instretcher = true
    L4_2 = CreateThread
    function L5_2()
      local L0_3, L1_3
      while true do
        L0_3 = disabledControls
        L0_3()
        L0_3 = instretcher
        if false == L0_3 then
          break
        end
        L0_3 = Wait
        L1_3 = 1
        L0_3(L1_3)
      end
    end
    L4_2(L5_2)
    L4_2 = ClearPedTasks
    L5_2 = L3_2
    L4_2(L5_2)
    L4_2 = ClearPedTasksImmediately
    L5_2 = L3_2
    L4_2(L5_2)
    L4_2 = Entity
    L5_2 = L2_2
    L4_2 = L4_2(L5_2)
    L4_2 = L4_2.state
    L5_2 = L4_2
    L4_2 = L4_2.set
    L6_2 = "HasPlayer"
    L7_2 = GetPlayerServerId
    L8_2 = NetworkGetPlayerIndexFromPed
    L9_2 = PlayerPedId
    L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L9_2()
    L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
    L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
    L8_2 = true
    L4_2(L5_2, L6_2, L7_2, L8_2)
    L4_2 = isInHospitalBed
    if L4_2 then
      L4_2 = canLeaveBed
      if L4_2 then
        L4_2 = stationaryDuiObj
        L5_2 = MyActiveHospital
        L4_2 = L4_2[L5_2]
        L5_2 = OnECGNumMonitor
        L4_2 = L4_2[L5_2]
        if L4_2 then
          L4_2 = TriggerServerEvent
          L5_2 = "osp_ambulance:DestroySyncScreenSv"
          L6_2 = OnECGNumMonitor
          L7_2 = MyActiveHospital
          L4_2(L5_2, L6_2, L7_2)
        end
        OnECGNumMonitor = false
        L4_2 = FreezeEntityPosition
        L5_2 = L3_2
        L6_2 = false
        L4_2(L5_2, L6_2)
        L4_2 = SetEntityInvincible
        L5_2 = L3_2
        L6_2 = false
        L4_2(L5_2, L6_2)
        L4_2 = TriggerServerEvent
        L5_2 = "hospital:server:LeaveBed"
        L6_2 = bedOccupying
        L7_2 = MyActiveHospital
        L4_2(L5_2, L6_2, L7_2)
        L4_2 = FreezeEntityPosition
        L5_2 = bedObject
        L6_2 = true
        L4_2(L5_2, L6_2)
        L4_2 = RenderScriptCams
        L5_2 = 0
        L6_2 = true
        L7_2 = 200
        L8_2 = true
        L9_2 = true
        L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
        L4_2 = DestroyCam
        L5_2 = cam
        L6_2 = false
        L4_2(L5_2, L6_2)
        bedOccupying = nil
        bedObject = nil
        bedOccupyingData = nil
        isInHospitalBed = false
        MyActiveHospital = nil
        L4_2 = removeTextUi
        L4_2()
      end
    end
    L4_2 = GetEntityModel
    L5_2 = L2_2
    L4_2 = L4_2(L5_2)
    L5_2 = GetHashKey
    L6_2 = Config
    L6_2 = L6_2.StretcherModel
    L6_2 = L6_2.folded
    L5_2 = L5_2(L6_2)
    if L4_2 == L5_2 then
      L4_2 = BodyDamage
      L4_2 = L4_2.inBodyBag
      if L4_2 then
        L4_2 = lib
        L4_2 = L4_2.requestModel
        L5_2 = "xm_prop_body_bag"
        L6_2 = 10000
        L4_2(L5_2, L6_2)
        L4_2 = lib
        L4_2 = L4_2.requestAnimDict
        L5_2 = "anim@gangops@morgue@table@"
        L6_2 = 100
        L4_2(L5_2, L6_2)
        L4_2 = DetachEntity
        L5_2 = L3_2
        L6_2 = true
        L7_2 = true
        L4_2(L5_2, L6_2, L7_2)
        L4_2 = DeleteEntity
        L5_2 = bodyBag
        L4_2(L5_2)
        L4_2 = DetachEntity
        L5_2 = L3_2
        L6_2 = true
        L7_2 = true
        L4_2(L5_2, L6_2, L7_2)
        L4_2 = DeleteEntity
        L5_2 = NetworkGetEntityFromNetworkId
        L6_2 = BodyDamage
        L6_2 = L6_2.inBodyBag
        L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L5_2(L6_2)
        L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
        L4_2 = TaskPlayAnim
        L5_2 = L3_2
        L6_2 = "anim@gangops@morgue@table@"
        L7_2 = "body_search"
        L8_2 = 8.0
        L9_2 = 8.0
        L10_2 = -1
        L11_2 = 69
        L12_2 = 1
        L13_2 = false
        L14_2 = false
        L15_2 = false
        L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
        L4_2 = AttachEntityToEntity
        L5_2 = L3_2
        L6_2 = L2_2
        L7_2 = nil
        L8_2 = 0.0
        L9_2 = 0.0
        L10_2 = 2.1
        L11_2 = 0.0
        L12_2 = 0.0
        L13_2 = 90.0
        L14_2 = true
        L15_2 = true
        L16_2 = false
        L17_2 = true
        L18_2 = 1
        L19_2 = true
        L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
        L4_2 = CreateObject
        L5_2 = "xm_prop_body_bag"
        L6_2 = GetEntityCoords
        L7_2 = L3_2
        L6_2 = L6_2(L7_2)
        L7_2 = true
        L8_2 = true
        L9_2 = true
        L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
        bodyBag = L4_2
        L4_2 = AttachEntityToEntity
        L5_2 = bodyBag
        L6_2 = L3_2
        L7_2 = nil
        L8_2 = 0.03
        L9_2 = 0.0
        L10_2 = -0.35
        L11_2 = -77.0
        L12_2 = -4.0
        L13_2 = -5.0
        L14_2 = false
        L15_2 = false
        L16_2 = false
        L17_2 = false
        L18_2 = 1
        L19_2 = true
        L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
        L4_2 = BodyDamage
        L5_2 = NetworkGetNetworkIdFromEntity
        L6_2 = bodyBag
        L5_2 = L5_2(L6_2)
        L4_2.inBodyBag = L5_2
        L4_2 = LocalPlayer
        L4_2 = L4_2.state
        L5_2 = L4_2
        L4_2 = L4_2.set
        L6_2 = "BodyDamage"
        L7_2 = BodyDamage
        L8_2 = true
        L4_2(L5_2, L6_2, L7_2, L8_2)
    end
    else
      L4_2 = BodyDamage
      L4_2 = L4_2.inBodyBag
      if L4_2 then
        L4_2 = print
        L5_2 = "you can not be put inside a sitting stretcher"
        L4_2(L5_2)
        instretcher = false
        return
      end
      L4_2 = GetEntityModel
      L5_2 = L2_2
      L4_2 = L4_2(L5_2)
      L5_2 = GetHashKey
      L6_2 = Config
      L6_2 = L6_2.StretcherModel
      L6_2 = L6_2.regular
      L5_2 = L5_2(L6_2)
      if L4_2 == L5_2 then
        L4_2 = AttachEntityToEntity
        L5_2 = L3_2
        L6_2 = L2_2
        L7_2 = nil
        L8_2 = 0.0
        L9_2 = 0.0
        L10_2 = 2.1
        L11_2 = 0.0
        L12_2 = 0.0
        L13_2 = 100.0
        L14_2 = true
        L15_2 = true
        L16_2 = false
        L17_2 = true
        L18_2 = 1
        L19_2 = true
        L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
        L4_2 = lib
        L4_2 = L4_2.requestAnimDict
        L5_2 = "timetable@jimmy@mics3_ig_15@"
        L6_2 = 1000
        L4_2(L5_2, L6_2)
        L4_2 = TaskPlayAnim
        L5_2 = L3_2
        L6_2 = "timetable@jimmy@mics3_ig_15@"
        L7_2 = "mics3_15_base_jimmy"
        L8_2 = 8.0
        L9_2 = 8.0
        L10_2 = -1
        L11_2 = 69
        L12_2 = 1
        L13_2 = false
        L14_2 = false
        L15_2 = false
        L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
        L4_2 = CreateThread
        function L5_2()
          local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
          while true do
            L0_3 = instretcher
            if not L0_3 then
              break
            end
            L0_3 = inAmbo
            if L0_3 then
              break
            end
            L0_3 = IsEntityPlayingAnim
            L1_3 = L3_2
            L2_3 = "timetable@jimmy@mics3_ig_15@"
            L3_3 = "mics3_15_base_jimmy"
            L4_3 = 3
            L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3)
            if not L0_3 then
              L0_3 = TaskPlayAnim
              L1_3 = L3_2
              L2_3 = "timetable@jimmy@mics3_ig_15@"
              L3_3 = "mics3_15_base_jimmy"
              L4_3 = 2.0
              L5_3 = 2.0
              L6_3 = -1
              L7_3 = 1
              L8_3 = 0
              L9_3 = 0
              L10_3 = 0
              L11_3 = 0
              L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
            end
            L0_3 = IsEntityAttachedToEntity
            L1_3 = L3_2
            L2_3 = L2_2
            L0_3 = L0_3(L1_3, L2_3)
            if not L0_3 then
              L0_3 = AttachEntityToEntity
              L1_3 = L3_2
              L2_3 = L2_2
              L3_3 = nil
              L4_3 = 0.0
              L5_3 = 0.0
              L6_3 = 2.1
              L7_3 = 0.0
              L8_3 = 0.0
              L9_3 = 100.0
              L10_3 = true
              L11_3 = true
              L12_3 = false
              L13_3 = true
              L14_3 = 1
              L15_3 = true
              L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
            end
            L0_3 = BodyDamage
            L0_3 = L0_3.isDead
            if not L0_3 then
              L0_3 = BodyDamage
              L0_3 = L0_3.inLastStand
              if not L0_3 then
                goto lbl_82
              end
            end
            L0_3 = IsEntityPlayingAnim
            L1_3 = L3_2
            L2_3 = "mp_sleep"
            L3_3 = "sleep_loop"
            L4_3 = 3
            L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3)
            if not L0_3 then
              L0_3 = TaskPlayAnim
              L1_3 = L3_2
              L2_3 = "mp_sleep"
              L3_3 = "sleep_loop"
              L4_3 = 2.0
              L5_3 = 2.0
              L6_3 = -1
              L7_3 = 51
              L8_3 = 0
              L9_3 = 0
              L10_3 = 0
              L11_3 = 0
              L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
              goto lbl_82
              break
            end
            ::lbl_82::
            L0_3 = Wait
            L1_3 = 40
            L0_3(L1_3)
          end
        end
        L4_2(L5_2)
      else
        L4_2 = GetEntityModel
        L5_2 = L2_2
        L4_2 = L4_2(L5_2)
        L5_2 = GetHashKey
        L6_2 = Config
        L6_2 = L6_2.StretcherModel
        L6_2 = L6_2.folded
        L5_2 = L5_2(L6_2)
        if L4_2 == L5_2 then
          L4_2 = AttachEntityToEntity
          L5_2 = L3_2
          L6_2 = L2_2
          L7_2 = nil
          L8_2 = 0.15
          L9_2 = 0.0
          L10_2 = 2.1
          L11_2 = 0.0
          L12_2 = 0.0
          L13_2 = 90.0
          L14_2 = true
          L15_2 = true
          L16_2 = false
          L17_2 = true
          L18_2 = 1
          L19_2 = true
          L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
          L4_2 = lib
          L4_2 = L4_2.requestAnimDict
          L5_2 = "anim@gangops@morgue@table@"
          L6_2 = 100
          L4_2(L5_2, L6_2)
          L4_2 = TaskPlayAnim
          L5_2 = L3_2
          L6_2 = "anim@gangops@morgue@table@"
          L7_2 = "body_search"
          L8_2 = 8.0
          L9_2 = 8.0
          L10_2 = -1
          L11_2 = 69
          L12_2 = 1
          L13_2 = false
          L14_2 = false
          L15_2 = false
          L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
          L4_2 = CreateThread
          function L5_2()
            local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
            while true do
              L0_3 = instretcher
              if not L0_3 then
                break
              end
              L0_3 = inAmbo
              if not L0_3 then
                L0_3 = IsEntityPlayingAnim
                L1_3 = L3_2
                L2_3 = "anim@gangops@morgue@table@"
                L3_3 = "body_search"
                L4_3 = 3
                L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3)
                if not L0_3 then
                  L0_3 = TaskPlayAnim
                  L1_3 = L3_2
                  L2_3 = "anim@gangops@morgue@table@"
                  L3_3 = "body_search"
                  L4_3 = 1.0
                  L5_3 = 1.0
                  L6_3 = -1
                  L7_3 = 1
                  L8_3 = 0
                  L9_3 = 0
                  L10_3 = 0
                  L11_3 = 0
                  L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
                end
                L0_3 = IsEntityAttachedToEntity
                L1_3 = L3_2
                L2_3 = L2_2
                L0_3 = L0_3(L1_3, L2_3)
                if not L0_3 then
                  L0_3 = AttachEntityToEntity
                  L1_3 = L3_2
                  L2_3 = L2_2
                  L3_3 = nil
                  L4_3 = 0.15
                  L5_3 = 0.0
                  L6_3 = 2.1
                  L7_3 = 0.0
                  L8_3 = 0.0
                  L9_3 = 90.0
                  L10_3 = true
                  L11_3 = true
                  L12_3 = false
                  L13_3 = true
                  L14_3 = 1
                  L15_3 = true
                  L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
                end
              else
                break
              end
              L0_3 = Wait
              L1_3 = 40
              L0_3(L1_3)
            end
          end
          L4_2(L5_2)
        else
          L4_2 = GetEntityModel
          L5_2 = L2_2
          L4_2 = L4_2(L5_2)
          L5_2 = GetHashKey
          L6_2 = Config
          L6_2 = L6_2.StretcherModel
          L6_2 = L6_2.lowered
          L5_2 = L5_2(L6_2)
          if L4_2 == L5_2 then
            L4_2 = AttachEntityToEntity
            L5_2 = L3_2
            L6_2 = L2_2
            L7_2 = nil
            L8_2 = 0.0
            L9_2 = 0.0
            L10_2 = 2.1
            L11_2 = 0.0
            L12_2 = 0.0
            L13_2 = 90.0
            L14_2 = true
            L15_2 = true
            L16_2 = false
            L17_2 = true
            L18_2 = 1
            L19_2 = true
            L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
            L4_2 = lib
            L4_2 = L4_2.requestAnimDict
            L5_2 = "anim@gangops@morgue@table@"
            L6_2 = 100
            L4_2(L5_2, L6_2)
            L4_2 = TaskPlayAnim
            L5_2 = L3_2
            L6_2 = "anim@gangops@morgue@table@"
            L7_2 = "body_search"
            L8_2 = 8.0
            L9_2 = 8.0
            L10_2 = -1
            L11_2 = 69
            L12_2 = 1
            L13_2 = false
            L14_2 = false
            L15_2 = false
            L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
            L4_2 = CreateThread
            function L5_2()
              local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
              while true do
                L0_3 = instretcher
                if L0_3 then
                  L0_3 = IsEntityPlayingAnim
                  L1_3 = L3_2
                  L2_3 = "anim@gangops@morgue@table@"
                  L3_3 = "body_search"
                  L4_3 = 3
                  L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3)
                  if not L0_3 then
                    L0_3 = TaskPlayAnim
                    L1_3 = L3_2
                    L2_3 = "anim@gangops@morgue@table@"
                    L3_3 = "body_search"
                    L4_3 = 1.0
                    L5_3 = 1.0
                    L6_3 = -1
                    L7_3 = 1
                    L8_3 = 0
                    L9_3 = 0
                    L10_3 = 0
                    L11_3 = 0
                    L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
                  end
                  L0_3 = IsEntityAttachedToEntity
                  L1_3 = L3_2
                  L2_3 = L2_2
                  L0_3 = L0_3(L1_3, L2_3)
                  if not L0_3 then
                    L0_3 = AttachEntityToEntity
                    L1_3 = L3_2
                    L2_3 = L2_2
                    L3_3 = nil
                    L4_3 = 0.0
                    L5_3 = 0.0
                    L6_3 = 2.1
                    L7_3 = 0.0
                    L8_3 = 0.0
                    L9_3 = 90.0
                    L10_3 = true
                    L11_3 = true
                    L12_3 = false
                    L13_3 = true
                    L14_3 = 1
                    L15_3 = true
                    L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
                  end
                else
                  break
                end
                L0_3 = Wait
                L1_3 = 40
                L0_3(L1_3)
              end
            end
            L4_2(L5_2)
          end
        end
      end
    end
  else
    instretcher = false
    L4_2 = Wait
    L5_2 = 100
    L4_2(L5_2)
    if A1_2 then
      L4_2 = GetEntityCoords
      L5_2 = PlayerPedId
      L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L5_2()
      L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
      L5_2 = nil
      L6_2 = nil
      L7_2 = pairs
      L8_2 = Config
      L8_2 = L8_2.Hospitals
      L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
      for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
        L13_2 = pairs
        L14_2 = L12_2.beds
        L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
        for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
          L19_2 = L12_2.beds
          L19_2 = L19_2[L17_2]
          L19_2 = L19_2.taken
          if not L19_2 then
            L19_2 = vector3
            L20_2 = L12_2.beds
            L20_2 = L20_2[L17_2]
            L20_2 = L20_2.coords
            L20_2 = L20_2.x
            L21_2 = L12_2.beds
            L21_2 = L21_2[L17_2]
            L21_2 = L21_2.coords
            L21_2 = L21_2.y
            L22_2 = L12_2.beds
            L22_2 = L22_2[L17_2]
            L22_2 = L22_2.coords
            L22_2 = L22_2.z
            L19_2 = L19_2(L20_2, L21_2, L22_2)
            L19_2 = L4_2 - L19_2
            L19_2 = #L19_2
            if L19_2 < 2 then
              L5_2 = L17_2
              L6_2 = L11_2
            end
          end
        end
      end
      if L5_2 then
        L7_2 = Entity
        L8_2 = L2_2
        L7_2 = L7_2(L8_2)
        L7_2 = L7_2.state
        L8_2 = L7_2
        L7_2 = L7_2.set
        L9_2 = "HasPlayer"
        L10_2 = nil
        L11_2 = true
        L7_2(L8_2, L9_2, L10_2, L11_2)
        L7_2 = TriggerServerEvent
        L8_2 = "hospital:server:SendToBed"
        L9_2 = L5_2
        L10_2 = false
        L11_2 = L6_2
        L7_2(L8_2, L9_2, L10_2, L11_2)
        L7_2 = Wait
        L8_2 = 1000
        L7_2(L8_2)
        L7_2 = DetachEntity
        L8_2 = L3_2
        L9_2 = true
        L10_2 = true
        L7_2(L8_2, L9_2, L10_2)
        L7_2 = ClearPedTasksImmediately
        L8_2 = L3_2
        L7_2(L8_2)
      else
        L7_2 = Entity
        L8_2 = L2_2
        L7_2 = L7_2(L8_2)
        L7_2 = L7_2.state
        L8_2 = L7_2
        L7_2 = L7_2.set
        L9_2 = "HasPlayer"
        L10_2 = nil
        L11_2 = true
        L7_2(L8_2, L9_2, L10_2, L11_2)
        L7_2 = GetEntityCoords
        L8_2 = L2_2
        L7_2 = L7_2(L8_2)
        L8_2 = GetOffsetFromEntityInWorldCoords
        L9_2 = L2_2
        L10_2 = -0.3
        L11_2 = -0.7
        L12_2 = 0.0
        L8_2 = L8_2(L9_2, L10_2, L11_2, L12_2)
        L9_2 = BodyDamage
        L9_2 = L9_2.isDead
        if not L9_2 then
          L9_2 = BodyDamage
          L9_2 = L9_2.inLastStand
          if not L9_2 then
            goto lbl_476
          end
        end
        L9_2 = GetEntityHeading
        L10_2 = L3_2
        L9_2 = L9_2(L10_2)
        L10_2 = NetworkResurrectLocalPlayer
        L11_2 = L8_2
        L12_2 = L9_2
        L13_2 = true
        L14_2 = false
        L10_2(L11_2, L12_2, L13_2, L14_2)
        ::lbl_476::
        L9_2 = DetachEntity
        L10_2 = L3_2
        L11_2 = true
        L12_2 = true
        L9_2(L10_2, L11_2, L12_2)
        L9_2 = SetEntityCoords
        L10_2 = L3_2
        L11_2 = L8_2
        L9_2(L10_2, L11_2)
        L9_2 = ClearPedTasksImmediately
        L10_2 = L3_2
        L9_2(L10_2)
      end
    else
      L4_2 = Entity
      L5_2 = L2_2
      L4_2 = L4_2(L5_2)
      L4_2 = L4_2.state
      L5_2 = L4_2
      L4_2 = L4_2.set
      L6_2 = "HasPlayer"
      L7_2 = nil
      L8_2 = true
      L4_2(L5_2, L6_2, L7_2, L8_2)
      L4_2 = ClearPedTasksImmediately
      L5_2 = L3_2
      L4_2(L5_2)
      L4_2 = DetachEntity
      L5_2 = L3_2
      L6_2 = true
      L7_2 = true
      L4_2(L5_2, L6_2, L7_2)
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:PickupStretcher"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L1_2 = instretcher
  if L1_2 then
    return
  end
  L1_2 = A0_2.entity
  L2_2 = Config
  L2_2 = L2_2.UseTarget
  if not L2_2 then
    L2_2 = deleteStretcherPoly
    L3_2 = L1_2
    L2_2(L3_2)
  end
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = GetEntityModel
  L4_2 = PlayerPedId
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2 = L4_2()
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  L4_2 = GetHashKey
  L5_2 = "mp_m_freemode_01"
  L4_2 = L4_2(L5_2)
  if L3_2 ~= L4_2 then
    L3_2 = GetEntityModel
    L4_2 = PlayerPedId
    L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2 = L4_2()
    L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
    L4_2 = GetHashKey
    L5_2 = "mp_f_freemode_01"
    L4_2 = L4_2(L5_2)
    if L3_2 ~= L4_2 then
      goto lbl_58
    end
  end
  L3_2 = AttachEntityToEntity
  L4_2 = L1_2
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  L6_2 = GetPedBoneIndex
  L7_2 = PlayerPedId
  L7_2 = L7_2()
  L8_2 = 64654
  L6_2 = L6_2(L7_2, L8_2)
  L7_2 = Config
  L7_2 = L7_2.StretcherAttach
  L7_2 = L7_2.playerOnStretcherOffset
  L7_2 = L7_2.freemode
  L8_2 = Config
  L8_2 = L8_2.StretcherAttach
  L8_2 = L8_2.playerOnStretcherRotation
  L8_2 = L8_2.freemode
  L9_2 = true
  L10_2 = true
  L11_2 = false
  L12_2 = true
  L13_2 = 1
  L14_2 = true
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  goto lbl_82
  ::lbl_58::
  L3_2 = AttachEntityToEntity
  L4_2 = L1_2
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  L6_2 = GetPedBoneIndex
  L7_2 = PlayerPedId
  L7_2 = L7_2()
  L8_2 = 64654
  L6_2 = L6_2(L7_2, L8_2)
  L7_2 = Config
  L7_2 = L7_2.StretcherAttach
  L7_2 = L7_2.playerOnStretcherOffset
  L7_2 = L7_2.ped
  L8_2 = Config
  L8_2 = L8_2.StretcherAttach
  L8_2 = L8_2.playerOnStretcherRotation
  L8_2 = L8_2.ped
  L9_2 = true
  L10_2 = true
  L11_2 = false
  L12_2 = true
  L13_2 = 1
  L14_2 = true
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  ::lbl_82::
  L3_2 = lib
  L3_2 = L3_2.requestAnimDict
  L4_2 = "anim@heists@box_carry@"
  L5_2 = 1000
  L3_2(L4_2, L5_2)
  L3_2 = TaskPlayAnim
  L4_2 = L2_2
  L5_2 = "anim@heists@box_carry@"
  L6_2 = "idle"
  L7_2 = 8.0
  L8_2 = 8.0
  L9_2 = -1
  L10_2 = 50
  L11_2 = 0
  L12_2 = false
  L13_2 = false
  L14_2 = false
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  L3_2 = CreateThread
  function L4_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    while true do
      L0_3 = IsEntityPlayingAnim
      L1_3 = L2_2
      L2_3 = "anim@heists@box_carry@"
      L3_3 = "idle"
      L4_3 = 3
      L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3)
      if not L0_3 then
        L0_3 = TaskPlayAnim
        L1_3 = L2_2
        L2_3 = "anim@heists@box_carry@"
        L3_3 = "idle"
        L4_3 = 8.0
        L5_3 = 8.0
        L6_3 = -1
        L7_3 = 50
        L8_3 = 0
        L9_3 = false
        L10_3 = false
        L11_3 = false
        L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
      end
      L0_3 = IsControlJustPressed
      L1_3 = 0
      L2_3 = Config
      L2_3 = L2_3.ReleaseStretcher
      L0_3 = L0_3(L1_3, L2_3)
      if L0_3 then
        L0_3 = ClearPedTasks
        L1_3 = L2_2
        L0_3(L1_3)
        L0_3 = DetachEntity
        L1_3 = L1_2
        L0_3(L1_3)
        L0_3 = PlaceObjectOnGroundProperly
        L1_3 = L1_2
        L0_3(L1_3)
        L0_3 = GetEntityModel
        L1_3 = L1_2
        L0_3 = L0_3(L1_3)
        L1_3 = GetHashKey
        L2_3 = Config
        L2_3 = L2_3.StretcherModel
        L2_3 = L2_3.folded
        L1_3 = L1_3(L2_3)
        if L0_3 == L1_3 then
          L0_3 = SetEntityCollision
          L1_3 = L1_2
          L2_3 = true
          L0_3(L1_3, L2_3)
          L0_3 = FreezeEntityPosition
          L1_3 = L1_2
          L2_3 = true
          L0_3(L1_3, L2_3)
        end
        L0_3 = Config
        L0_3 = L0_3.UseTarget
        if not L0_3 then
          L0_3 = CreateThread
          function L1_3()
            local L0_4, L1_4
            L0_4 = Wait
            L1_4 = 500
            L0_4(L1_4)
            L0_4 = creatingStretcherPoly
            L1_4 = L1_2
            L0_4(L1_4)
          end
          L0_3(L1_3)
        end
        break
      end
      L0_3 = Wait
      L1_3 = 5
      L0_3(L1_3)
    end
  end
  L3_2(L4_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:FoldStretcher"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = DebugPrint
  L2_2 = "Folding stretcher"
  L1_2(L2_2)
  L1_2 = A0_2.entity
  L2_2 = GetEntityCoords
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = GetEntityHeading
  L4_2 = L1_2
  L3_2 = L3_2(L4_2)
  L4_2 = GetEntityModel
  L5_2 = L1_2
  L4_2 = L4_2(L5_2)
  L5_2 = GetHashKey
  L6_2 = Config
  L6_2 = L6_2.StretcherModel
  L6_2 = L6_2.folded
  L5_2 = L5_2(L6_2)
  if L4_2 == L5_2 then
    L4_2 = Entity
    L5_2 = L1_2
    L4_2 = L4_2(L5_2)
    L4_2 = L4_2.state
    L5_2 = L4_2
    L4_2 = L4_2.set
    L6_2 = "ifFolded"
    L7_2 = true
    L8_2 = true
    L4_2(L5_2, L6_2, L7_2, L8_2)
  else
    L4_2 = Entity
    L5_2 = L1_2
    L4_2 = L4_2(L5_2)
    L4_2 = L4_2.state
    L5_2 = L4_2
    L4_2 = L4_2.set
    L6_2 = "ifFolded"
    L7_2 = false
    L8_2 = true
    L4_2(L5_2, L6_2, L7_2, L8_2)
  end
  L4_2 = Entity
  L5_2 = L1_2
  L4_2 = L4_2(L5_2)
  L5_2 = L4_2.state
  L5_2 = L5_2.ifFolded
  L6_2 = L4_2.state
  L6_2 = L6_2.HasPlayer
  if L6_2 then
    L7_2 = TriggerEvent
    L8_2 = "osp_ambulance:PutPlayerInOutStretcherPrepCl"
    L9_2 = {}
    L9_2.entity = L1_2
    L7_2(L8_2, L9_2)
  end
  L7_2 = Config
  L7_2 = L7_2.UseTarget
  if not L7_2 then
    L7_2 = deleteStretcherPoly
    L8_2 = L1_2
    L7_2(L8_2)
  end
  L7_2 = DeleteEntity
  L8_2 = L1_2
  L7_2(L8_2)
  L7_2 = DebugPrint
  L8_2 = "replaced player on new stretcher and deleted old one"
  L7_2(L8_2)
  if L5_2 then
    L7_2 = lib
    L7_2 = L7_2.requestModel
    L8_2 = Config
    L8_2 = L8_2.StretcherModel
    L8_2 = L8_2.regular
    L9_2 = 10000
    L7_2(L8_2, L9_2)
    L7_2 = CreateObjectNoOffset
    L8_2 = Config
    L8_2 = L8_2.StretcherModel
    L8_2 = L8_2.regular
    L9_2 = L2_2
    L10_2 = 1
    L11_2 = 1
    L12_2 = 0
    L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
    L1_2 = L7_2
    L7_2 = Config
    L7_2 = L7_2.UseTarget
    if not L7_2 then
      L7_2 = CreateThread
      function L8_2()
        local L0_3, L1_3
        L0_3 = Wait
        L1_3 = 500
        L0_3(L1_3)
        L0_3 = creatingStretcherPoly
        L1_3 = L1_2
        L0_3(L1_3)
      end
      L7_2(L8_2)
    end
    L7_2 = SetEntityHeading
    L8_2 = L1_2
    L9_2 = L3_2
    L7_2(L8_2, L9_2)
    L7_2 = Config
    L7_2 = L7_2.UseTarget
    if L7_2 then
      L7_2 = creatingStretcherInteraction
      L8_2 = L1_2
      L7_2(L8_2)
    end
    L7_2 = Wait
    L8_2 = 500
    L7_2(L8_2)
    if L6_2 then
      L7_2 = TriggerEvent
      L8_2 = "osp_ambulance:PutPlayerInOutStretcherPrepCl"
      L9_2 = {}
      L9_2.entity = L1_2
      L7_2(L8_2, L9_2)
    end
  else
    L7_2 = lib
    L7_2 = L7_2.requestModel
    L8_2 = Config
    L8_2 = L8_2.StretcherModel
    L8_2 = L8_2.folded
    L9_2 = 10000
    L7_2(L8_2, L9_2)
    L7_2 = CreateObjectNoOffset
    L8_2 = Config
    L8_2 = L8_2.StretcherModel
    L8_2 = L8_2.folded
    L9_2 = L2_2
    L10_2 = 1
    L11_2 = 1
    L12_2 = 0
    L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
    L1_2 = L7_2
    L7_2 = Config
    L7_2 = L7_2.UseTarget
    if not L7_2 then
      L7_2 = CreateThread
      function L8_2()
        local L0_3, L1_3
        L0_3 = Wait
        L1_3 = 500
        L0_3(L1_3)
        L0_3 = creatingStretcherPoly
        L1_3 = L1_2
        L0_3(L1_3)
      end
      L7_2(L8_2)
    end
    L7_2 = SetEntityHeading
    L8_2 = L1_2
    L9_2 = L3_2
    L7_2(L8_2, L9_2)
    L7_2 = FreezeEntityPosition
    L8_2 = L1_2
    L9_2 = true
    L7_2(L8_2, L9_2)
    L7_2 = Config
    L7_2 = L7_2.UseTarget
    if L7_2 then
      L7_2 = creatingStretcherInteraction
      L8_2 = L1_2
      L7_2(L8_2)
    end
    L7_2 = Wait
    L8_2 = 500
    L7_2(L8_2)
    if L6_2 then
      L7_2 = TriggerEvent
      L8_2 = "osp_ambulance:PutPlayerInOutStretcherPrepCl"
      L9_2 = {}
      L9_2.entity = L1_2
      L7_2(L8_2, L9_2)
    end
    L7_2 = DebugPrint
    L8_2 = "new stretcher"
    L9_2 = L1_2
    L10_2 = GetEntityCoords
    L11_2 = L1_2
    L10_2, L11_2, L12_2 = L10_2(L11_2)
    L7_2(L8_2, L9_2, L10_2, L11_2, L12_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:PutStretcherInAmbulance"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2
  L1_2 = A0_2.entity
  L2_2 = Entity
  L3_2 = L1_2
  L2_2 = L2_2(L3_2)
  L3_2 = L2_2.state
  L3_2 = L3_2.HasPlayer
  L4_2 = false
  L5_2 = GetGamePool
  L6_2 = "CVehicle"
  L5_2 = L5_2(L6_2)
  L6_2 = nil
  L7_2 = pairs
  L8_2 = L5_2
  L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
  for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
    L13_2 = GetEntityCoords
    L14_2 = L12_2
    L13_2 = L13_2(L14_2)
    L14_2 = GetEntityCoords
    L15_2 = L1_2
    L14_2 = L14_2(L15_2)
    L13_2 = L13_2 - L14_2
    L13_2 = #L13_2
    if L13_2 <= 10.0 then
      L13_2 = pairs
      L14_2 = Config
      L14_2 = L14_2.Ambulances
      L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
      for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
        L19_2 = IsVehicleModel
        L20_2 = L12_2
        L21_2 = GetHashKey
        L22_2 = L17_2
        L21_2, L22_2, L23_2, L24_2 = L21_2(L22_2)
        L19_2 = L19_2(L20_2, L21_2, L22_2, L23_2, L24_2)
        if L19_2 then
          L19_2 = DebugPrint
          L20_2 = "found nearby ambulance"
          L21_2 = L12_2
          L19_2(L20_2, L21_2)
          L4_2 = true
          L6_2 = L12_2
        end
      end
    end
  end
  if L4_2 then
    L7_2 = Config
    L7_2 = L7_2.UseTarget
    if not L7_2 then
      L7_2 = deleteStretcherPoly
      L8_2 = L1_2
      L7_2(L8_2)
    end
    L4_2 = false
    if L3_2 then
      L7_2 = DebugPrint
      L8_2 = "Sending request to put other client in ambulance"
      L9_2 = L3_2
      L10_2 = NetworkGetNetworkIdFromEntity
      L11_2 = L6_2
      L10_2 = L10_2(L11_2)
      L11_2 = NetworkGetNetworkIdFromEntity
      L12_2 = L1_2
      L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L11_2(L12_2)
      L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
      L7_2 = TriggerServerEvent
      L8_2 = "osp_ambulance:UpdateStretcherPositionInSv"
      L9_2 = L3_2
      L10_2 = NetworkGetNetworkIdFromEntity
      L11_2 = L1_2
      L10_2 = L10_2(L11_2)
      L11_2 = NetworkGetNetworkIdFromEntity
      L12_2 = L6_2
      L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L11_2(L12_2)
      L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
      L7_2 = CreateThread
      function L8_2()
        local L0_3, L1_3
        L0_3 = Wait
        L1_3 = 300
        L0_3(L1_3)
        L0_3 = DeleteEntity
        L1_3 = L1_2
        L0_3(L1_3)
      end
      L7_2(L8_2)
    else
      L7_2 = pairs
      L8_2 = Config
      L8_2 = L8_2.Ambulances
      L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
      for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
        L13_2 = IsVehicleModel
        L14_2 = L6_2
        L15_2 = GetHashKey
        L16_2 = L11_2
        L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L15_2(L16_2)
        L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
        if L13_2 then
          L13_2 = lib
          L13_2 = L13_2.requestModel
          L14_2 = Config
          L14_2 = L14_2.StretcherModel
          L14_2 = L14_2.lowered
          L15_2 = 10000
          L13_2(L14_2, L15_2)
          L13_2 = CreateObjectNoOffset
          L14_2 = Config
          L14_2 = L14_2.StretcherModel
          L14_2 = L14_2.lowered
          L15_2 = vector3
          L16_2 = 294.018
          L17_2 = -613.7497
          L18_2 = 42.4297
          L15_2 = L15_2(L16_2, L17_2, L18_2)
          L16_2 = 1
          L17_2 = 1
          L18_2 = 0
          L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2, L18_2)
          stretcher = L13_2
          L13_2 = GetEntityModel
          L14_2 = L1_2
          L13_2 = L13_2(L14_2)
          L14_2 = GetHashKey
          L15_2 = Config
          L15_2 = L15_2.StretcherModel
          L15_2 = L15_2.folded
          L14_2 = L14_2(L15_2)
          if L13_2 == L14_2 then
            L13_2 = Entity
            L14_2 = stretcher
            L13_2 = L13_2(L14_2)
            L13_2 = L13_2.state
            L14_2 = L13_2
            L13_2 = L13_2.set
            L15_2 = "ifFolded"
            L16_2 = true
            L17_2 = true
            L13_2(L14_2, L15_2, L16_2, L17_2)
          else
            L13_2 = Entity
            L14_2 = stretcher
            L13_2 = L13_2(L14_2)
            L13_2 = L13_2.state
            L14_2 = L13_2
            L13_2 = L13_2.set
            L15_2 = "ifFolded"
            L16_2 = false
            L17_2 = true
            L13_2(L14_2, L15_2, L16_2, L17_2)
          end
          L13_2 = DeleteEntity
          L14_2 = L1_2
          L13_2(L14_2)
          L13_2 = DeleteObject
          L14_2 = L1_2
          L13_2(L14_2)
          L13_2 = print
          L14_2 = "network has control of vehicle"
          L15_2 = NetworkHasControlOfEntity
          L16_2 = L6_2
          L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L15_2(L16_2)
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
          L13_2 = NetworkHasControlOfEntity
          L14_2 = L6_2
          L13_2 = L13_2(L14_2)
          if L13_2 then
            L13_2 = updateAmbulancePosition
            L14_2 = L6_2
            L15_2 = L12_2.offsetinstart
            L16_2 = L12_2.offsetinstop
            L17_2 = L12_2.rotation
            L18_2 = 1
            L19_2 = 200
            L20_2 = stretcher
            L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2)
            L13_2 = Wait
            L14_2 = 500
            L13_2(L14_2)
            L13_2 = 0
            L14_2 = 100
            L15_2 = 1
            for L16_2 = L13_2, L14_2, L15_2 do
              L17_2 = updateAmbulancePosition
              L18_2 = L6_2
              L19_2 = L12_2.offsetinstart
              L20_2 = L12_2.offsetinstop
              L21_2 = L12_2.rotation
              L22_2 = L16_2
              L23_2 = 200
              L24_2 = stretcher
              L17_2(L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
              L17_2 = Wait
              L18_2 = 10
              L17_2(L18_2)
            end
          else
            L13_2 = NetworkRequestControlOfEntity
            L14_2 = L6_2
            L13_2(L14_2)
            L13_2 = updateAmbulancePosition
            L14_2 = L6_2
            L15_2 = L12_2.offsetinstart
            L16_2 = L12_2.offsetinstop
            L17_2 = L12_2.rotation
            L18_2 = 100
            L19_2 = 200
            L20_2 = stretcher
            L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2)
            L13_2 = Wait
            L14_2 = 1000
            L13_2(L14_2)
            L13_2 = print
            L14_2 = "deleting stretcher at entity owner"
            L15_2 = NetworkGetNetworkIdFromEntity
            L16_2 = L6_2
            L15_2 = L15_2(L16_2)
            L16_2 = NetworkGetNetworkIdFromEntity
            L17_2 = stretcher
            L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L16_2(L17_2)
            L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
          end
          L13_2 = TriggerServerEvent
          L14_2 = "osp_ambulance:SyncPulloutTargetSv"
          L15_2 = GetPlayerServerId
          L16_2 = NetworkGetPlayerIndexFromPed
          L17_2 = PlayerPedId
          L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L17_2()
          L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
          L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
          L16_2 = NetworkGetNetworkIdFromEntity
          L17_2 = L6_2
          L16_2 = L16_2(L17_2)
          L17_2 = NetworkGetNetworkIdFromEntity
          L18_2 = stretcher
          L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2 = L17_2(L18_2)
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
        end
      end
    end
    L7_2 = stretcherInVehicle
    L8_2 = NetworkGetNetworkIdFromEntity
    L9_2 = L6_2
    L8_2 = L8_2(L9_2)
    L9_2 = {}
    L10_2 = NetworkGetNetworkIdFromEntity
    L11_2 = stretcher
    L10_2 = L10_2(L11_2)
    L9_2.stretcherId = L10_2
    L9_2.hasPlayer = L3_2
    L7_2[L8_2] = L9_2
  else
    L7_2 = print
    L8_2 = "NO NEARBY AMBULANCE!"
    L7_2(L8_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = {}
ambulanceLoopTable = L0_1
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:SyncPulloutTargetCl"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = NetworkGetEntityFromNetworkId
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L3_2 = IsEntityAVehicle
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if L3_2 then
    L3_2 = Config
    L3_2 = L3_2.UseTarget
    if L3_2 then
      L3_2 = RemoveTargetZone
      L4_2 = L2_2
      L3_2(L4_2)
      L3_2 = Config
      L3_2 = L3_2.UseOxTarget
      if L3_2 then
        L3_2 = TargetEntity
        L4_2 = L2_2
        L5_2 = {}
        L5_2.name = L2_2
        L5_2.event = "osp_ambulance:GetStretcherOutAmbulance"
        L5_2.icon = "fa-solid fa-right-from-bracket"
        L6_2 = lang
        L6_2 = L6_2.update1
        L6_2 = L6_2.pulloutstretcher
        L5_2.label = L6_2
        L5_2.stretcher = A1_2
        L3_2(L4_2, L5_2)
      else
        L3_2 = TargetEntity
        L4_2 = L2_2
        L5_2 = {}
        L5_2.type = "client"
        L5_2.event = "osp_ambulance:GetStretcherOutAmbulance"
        L5_2.icon = "fa-solid fa-right-from-bracket"
        L6_2 = lang
        L6_2 = L6_2.update1
        L6_2 = L6_2.pulloutstretcher
        L5_2.label = L6_2
        L5_2.stretcher = A1_2
        L3_2(L4_2, L5_2)
      end
    else
      L3_2 = CreateThread
      function L4_2()
        local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
        L0_3 = PlayerPedId
        L0_3 = L0_3()
        L1_3 = NetworkGetNetworkIdFromEntity
        L2_3 = L2_2
        L1_3 = L1_3(L2_3)
        L2_3 = ambulanceLoopTable
        L2_3[L1_3] = true
        while true do
          L2_3 = 1000
          L3_3 = GetEntityCoords
          L4_3 = L0_3
          L3_3 = L3_3(L4_3)
          L4_3 = GetEntityCoords
          L5_3 = L2_2
          L4_3 = L4_3(L5_3)
          L3_3 = L3_3 - L4_3
          L3_3 = #L3_3
          if L3_3 < 7 then
            L4_3 = IsPedInAnyVehicle
            L5_3 = PlayerPedId
            L5_3 = L5_3()
            L6_3 = true
            L4_3 = L4_3(L5_3, L6_3)
            if not L4_3 then
              L2_3 = 5
              L4_3 = textUi
              L5_3 = "[E] "
              L6_3 = lang
              L6_3 = L6_3.update1
              L6_3 = L6_3.pulloutstretcher
              L5_3 = L5_3 .. L6_3
              L4_3(L5_3)
              L4_3 = IsControlJustReleased
              L5_3 = 0
              L6_3 = 38
              L4_3 = L4_3(L5_3, L6_3)
              if L4_3 then
                L4_3 = removeTextUi
                L4_3()
                L4_3 = TriggerEvent
                L5_3 = "osp_ambulance:GetStretcherOutAmbulance"
                L6_3 = {}
                L7_3 = L2_2
                L6_3.entity = L7_3
                L7_3 = A1_2
                L6_3.stretcher = L7_3
                L4_3(L5_3, L6_3)
              end
            else
              L4_3 = removeTextUi
              L4_3()
            end
          else
            L4_3 = removeTextUi
            L4_3()
          end
          L4_3 = ambulanceLoopTable
          L4_3 = L4_3[L1_3]
          if not L4_3 then
            L4_3 = removeTextUi
            L4_3()
            break
          end
          L4_3 = Wait
          L5_3 = L2_3
          L4_3(L5_3)
        end
      end
      L3_2(L4_2)
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:GetStretcherOutAmbulance"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2
  L1_2 = A0_2.entity
  while true do
    L2_2 = NetworkGetNetworkIdFromEntity
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    if 0 ~= L2_2 then
      break
    end
    L2_2 = Wait
    L3_2 = 1
    L2_2(L3_2)
  end
  L2_2 = NetworkGetEntityFromNetworkId
  L3_2 = A0_2.stretcher
  L2_2 = L2_2(L3_2)
  L3_2 = Entity
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2.state
  L4_2 = L4_2.HasPlayer
  L5_2 = L3_2.state
  L5_2 = L5_2.ifFolded
  L6_2 = NetworkGetNetworkIdFromEntity
  L7_2 = L1_2
  L6_2 = L6_2(L7_2)
  L7_2 = ambulanceLoopTable
  L7_2[L6_2] = nil
  L7_2 = Config
  L7_2 = L7_2.UseTarget
  if L7_2 then
    L7_2 = RemoveTargetZone
    L8_2 = L1_2
    L7_2(L8_2)
  end
  L7_2 = DebugPrint
  L8_2 = "Stretcher: "
  L9_2 = L2_2
  L10_2 = L1_2
  L7_2(L8_2, L9_2, L10_2)
  L7_2 = DebugPrint
  L8_2 = "Stretcher has player: "
  L9_2 = L4_2
  L7_2(L8_2, L9_2)
  if nil ~= L5_2 then
    if L4_2 then
      L7_2 = TriggerServerEvent
      L8_2 = "osp_ambulance:UpdateStretcherPositionOutSv"
      L9_2 = L4_2
      L10_2 = NetworkGetNetworkIdFromEntity
      L11_2 = L2_2
      L10_2 = L10_2(L11_2)
      L11_2 = NetworkGetNetworkIdFromEntity
      L12_2 = L1_2
      L11_2 = L11_2(L12_2)
      L12_2 = GetPlayerServerId
      L13_2 = PlayerId
      L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = L13_2()
      L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = L12_2(L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2)
      L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2)
    else
      L7_2 = PlayerPedId
      L7_2 = L7_2()
      L8_2 = pairs
      L9_2 = Config
      L9_2 = L9_2.Ambulances
      L8_2, L9_2, L10_2, L11_2 = L8_2(L9_2)
      for L12_2, L13_2 in L8_2, L9_2, L10_2, L11_2 do
        L14_2 = IsVehicleModel
        L15_2 = L1_2
        L16_2 = GetHashKey
        L17_2 = L12_2
        L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = L16_2(L17_2)
        L14_2 = L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2)
        if L14_2 then
          L14_2 = NetworkRequestControlOfEntity
          L15_2 = L1_2
          L14_2(L15_2)
          L14_2 = NetworkRequestControlOfNetworkId
          L15_2 = NetworkGetNetworkIdFromEntity
          L16_2 = L1_2
          L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = L15_2(L16_2)
          L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2)
          L14_2 = NetworkHasControlOfEntity
          L15_2 = L1_2
          L14_2 = L14_2(L15_2)
          if L14_2 then
            L14_2 = NetworkRequestControlOfEntity
            L15_2 = L1_2
            L14_2(L15_2)
            L14_2 = NetworkRequestControlOfEntity
            L15_2 = L2_2
            L14_2(L15_2)
            L14_2 = 0
            L15_2 = 100
            L16_2 = 1
            for L17_2 = L14_2, L15_2, L16_2 do
              L18_2 = updateAmbulancePosition
              L19_2 = L1_2
              L20_2 = L13_2.offsetoutstart
              L21_2 = L13_2.offsetoutstop
              L22_2 = L13_2.rotation
              L23_2 = L17_2
              L24_2 = 200
              L25_2 = L2_2
              L18_2(L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2)
              L18_2 = Wait
              L19_2 = 10
              L18_2(L19_2)
            end
            L14_2 = Wait
            L15_2 = 1000
            L14_2(L15_2)
          end
          L14_2 = TriggerServerEvent
          L15_2 = "osp_ambulance:deleteStretcherAtEntityOwnerSv"
          L16_2 = NetworkGetNetworkIdFromEntity
          L17_2 = L1_2
          L16_2 = L16_2(L17_2)
          L17_2 = NetworkGetNetworkIdFromEntity
          L18_2 = L2_2
          L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = L17_2(L18_2)
          L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2)
          if L5_2 then
            L14_2 = Config
            L14_2 = L14_2.StretcherModel
            L14_2 = L14_2.folded
            stretcherM = L14_2
            L14_2 = lib
            L14_2 = L14_2.requestModel
            L15_2 = stretcherM
            L16_2 = 10000
            L14_2(L15_2, L16_2)
          else
            L14_2 = Config
            L14_2 = L14_2.StretcherModel
            L14_2 = L14_2.regular
            stretcherM = L14_2
            L14_2 = lib
            L14_2 = L14_2.requestModel
            L15_2 = stretcherM
            L16_2 = 10000
            L14_2(L15_2, L16_2)
          end
          L14_2 = CreateObjectNoOffset
          L15_2 = stretcherM
          L16_2 = vector3
          L17_2 = 284.9842
          L18_2 = -612.2672
          L19_2 = 41.3219
          L16_2 = L16_2(L17_2, L18_2, L19_2)
          L17_2 = 1
          L18_2 = 1
          L19_2 = 0
          L14_2 = L14_2(L15_2, L16_2, L17_2, L18_2, L19_2)
          L15_2 = GetEntityModel
          L16_2 = PlayerPedId
          L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = L16_2()
          L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2)
          L16_2 = GetHashKey
          L17_2 = "mp_m_freemode_01"
          L16_2 = L16_2(L17_2)
          if L15_2 ~= L16_2 then
            L15_2 = GetEntityModel
            L16_2 = PlayerPedId
            L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2 = L16_2()
            L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2)
            L16_2 = GetHashKey
            L17_2 = "mp_f_freemode_01"
            L16_2 = L16_2(L17_2)
            if L15_2 ~= L16_2 then
              goto lbl_199
            end
          end
          L15_2 = AttachEntityToEntity
          L16_2 = L14_2
          L17_2 = PlayerPedId
          L17_2 = L17_2()
          L18_2 = GetPedBoneIndex
          L19_2 = PlayerPedId
          L19_2 = L19_2()
          L20_2 = 64654
          L18_2 = L18_2(L19_2, L20_2)
          L19_2 = Config
          L19_2 = L19_2.StretcherAttach
          L19_2 = L19_2.playerOnStretcherOffset
          L19_2 = L19_2.freemode
          L20_2 = Config
          L20_2 = L20_2.StretcherAttach
          L20_2 = L20_2.playerOnStretcherRotation
          L20_2 = L20_2.freemode
          L21_2 = true
          L22_2 = true
          L23_2 = false
          L24_2 = true
          L25_2 = 1
          L26_2 = true
          L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2)
          goto lbl_223
          ::lbl_199::
          L15_2 = AttachEntityToEntity
          L16_2 = L14_2
          L17_2 = PlayerPedId
          L17_2 = L17_2()
          L18_2 = GetPedBoneIndex
          L19_2 = PlayerPedId
          L19_2 = L19_2()
          L20_2 = 64654
          L18_2 = L18_2(L19_2, L20_2)
          L19_2 = Config
          L19_2 = L19_2.StretcherAttach
          L19_2 = L19_2.playerOnStretcherOffset
          L19_2 = L19_2.ped
          L20_2 = Config
          L20_2 = L20_2.StretcherAttach
          L20_2 = L20_2.playerOnStretcherRotation
          L20_2 = L20_2.ped
          L21_2 = true
          L22_2 = true
          L23_2 = false
          L24_2 = true
          L25_2 = 1
          L26_2 = true
          L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2)
          ::lbl_223::
          L15_2 = lib
          L15_2 = L15_2.requestAnimDict
          L16_2 = "anim@heists@box_carry@"
          L17_2 = 1000
          L15_2(L16_2, L17_2)
          L15_2 = TaskPlayAnim
          L16_2 = PlayerPedId
          L16_2 = L16_2()
          L17_2 = "anim@heists@box_carry@"
          L18_2 = "idle"
          L19_2 = 8.0
          L20_2 = 8.0
          L21_2 = -1
          L22_2 = 50
          L23_2 = 0
          L24_2 = false
          L25_2 = false
          L26_2 = false
          L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2)
          L15_2 = Config
          L15_2 = L15_2.UseTarget
          if L15_2 then
            L15_2 = creatingStretcherInteraction
            L16_2 = L14_2
            L15_2(L16_2)
          end
          L15_2 = CreateThread
          function L16_2()
            local L0_3, L1_3, L2_3
            while true do
              L0_3 = IsControlJustPressed
              L1_3 = 0
              L2_3 = 46
              L0_3 = L0_3(L1_3, L2_3)
              if L0_3 then
                L0_3 = ClearPedTasks
                L1_3 = PlayerPedId
                L1_3, L2_3 = L1_3()
                L0_3(L1_3, L2_3)
                L0_3 = DetachEntity
                L1_3 = L14_2
                L0_3(L1_3)
                L0_3 = PlaceObjectOnGroundProperly
                L1_3 = L14_2
                L0_3(L1_3)
                L0_3 = GetEntityModel
                L1_3 = L14_2
                L0_3 = L0_3(L1_3)
                L1_3 = GetHashKey
                L2_3 = Config
                L2_3 = L2_3.StretcherModel
                L2_3 = L2_3.folded
                L1_3 = L1_3(L2_3)
                if L0_3 == L1_3 then
                  L0_3 = SetEntityCollision
                  L1_3 = L14_2
                  L2_3 = true
                  L0_3(L1_3, L2_3)
                  L0_3 = FreezeEntityPosition
                  L1_3 = L14_2
                  L2_3 = true
                  L0_3(L1_3, L2_3)
                end
                L0_3 = Config
                L0_3 = L0_3.UseTarget
                if not L0_3 then
                  L0_3 = CreateThread
                  function L1_3()
                    local L0_4, L1_4
                    L0_4 = Wait
                    L1_4 = 500
                    L0_4(L1_4)
                    L0_4 = creatingStretcherPoly
                    L1_4 = L14_2
                    L0_4(L1_4)
                  end
                  L0_3(L1_3)
                end
                break
              end
              L0_3 = Wait
              L1_3 = 3
              L0_3(L1_3)
            end
          end
          L15_2(L16_2)
          break
        end
      end
    end
  else
    L7_2 = print
    L8_2 = "NO DATA CONNECTED TO STRETCHER"
    L7_2(L8_2)
  end
end
L0_1(L1_1, L2_1)
insideAmbulanceEntity = nil
insideAmbulance = false
syncPullout = nil
inAmbo = false
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:UpdateStretcherPositionInCl"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2
  L3_2 = DebugPrint
  L4_2 = "client recived request to put stretcher in ambulance"
  L3_2(L4_2)
  L3_2 = NetworkGetEntityFromNetworkId
  L4_2 = A1_2
  L3_2 = L3_2(L4_2)
  L4_2 = NetworkGetEntityFromNetworkId
  L5_2 = A2_2
  L4_2 = L4_2(L5_2)
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  L6_2 = DebugPrint
  L7_2 = "client update stretcher position in"
  L8_2 = L4_2
  L9_2 = A2_2
  L10_2 = L3_2
  L6_2(L7_2, L8_2, L9_2, L10_2)
  L6_2 = pairs
  L7_2 = Config
  L7_2 = L7_2.Ambulances
  L6_2, L7_2, L8_2, L9_2 = L6_2(L7_2)
  for L10_2, L11_2 in L6_2, L7_2, L8_2, L9_2 do
    L12_2 = IsVehicleModel
    L13_2 = L4_2
    L14_2 = GetHashKey
    L15_2 = L10_2
    L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L14_2(L15_2)
    L12_2 = L12_2(L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
    if L12_2 then
      inAmbo = true
      insideAmbulanceEntity = L4_2
      insideAmbulance = true
      L12_2 = Config
      L12_2 = L12_2.StretcherModel
      L12_2 = L12_2.lowered
      L13_2 = lib
      L13_2 = L13_2.requestModel
      L14_2 = L12_2
      L15_2 = 10000
      L13_2(L14_2, L15_2)
      L13_2 = lib
      L13_2 = L13_2.requestAnimDict
      L14_2 = "anim@gangops@morgue@table@"
      L15_2 = 1000
      L13_2(L14_2, L15_2)
      L13_2 = lib
      L13_2 = L13_2.requestModel
      L14_2 = "xm_prop_body_bag"
      L15_2 = 10000
      L13_2(L14_2, L15_2)
      L13_2 = GetEntityModel
      L14_2 = L3_2
      L13_2 = L13_2(L14_2)
      L14_2 = GetHashKey
      L15_2 = Config
      L15_2 = L15_2.StretcherModel
      L15_2 = L15_2.folded
      L14_2 = L14_2(L15_2)
      if L13_2 == L14_2 then
        L13_2 = BodyDamage
        L13_2 = L13_2.inBodyBag
        if L13_2 then
          L13_2 = CreateObjectNoOffset
          L14_2 = L12_2
          L15_2 = vector3
          L16_2 = 294.018
          L17_2 = -613.7497
          L18_2 = 42.4297
          L15_2 = L15_2(L16_2, L17_2, L18_2)
          L16_2 = 1
          L17_2 = 1
          L18_2 = 0
          L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2, L18_2)
          stretcher = L13_2
          L13_2 = Entity
          L14_2 = stretcher
          L13_2 = L13_2(L14_2)
          L13_2 = L13_2.state
          L14_2 = L13_2
          L13_2 = L13_2.set
          L15_2 = "HasPlayer"
          L16_2 = GetPlayerServerId
          L17_2 = NetworkGetPlayerIndexFromPed
          L18_2 = PlayerPedId
          L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L18_2()
          L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L17_2(L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L16_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L17_2 = true
          L13_2(L14_2, L15_2, L16_2, L17_2)
          L13_2 = Entity
          L14_2 = stretcher
          L13_2 = L13_2(L14_2)
          L13_2 = L13_2.state
          L14_2 = L13_2
          L13_2 = L13_2.set
          L15_2 = "ifFolded"
          L16_2 = true
          L17_2 = true
          L13_2(L14_2, L15_2, L16_2, L17_2)
          L13_2 = DetachEntity
          L14_2 = L5_2
          L15_2 = true
          L16_2 = true
          L13_2(L14_2, L15_2, L16_2)
          L13_2 = ClearPedTasks
          L14_2 = L5_2
          L13_2(L14_2)
          L13_2 = ClearPedTasksImmediately
          L14_2 = L5_2
          L13_2(L14_2)
          L13_2 = DetachEntity
          L14_2 = NetworkGetEntityFromNetworkId
          L15_2 = BodyDamage
          L15_2 = L15_2.inBodyBag
          L14_2 = L14_2(L15_2)
          L15_2 = true
          L16_2 = true
          L13_2(L14_2, L15_2, L16_2)
          L13_2 = DeleteEntity
          L14_2 = NetworkGetEntityFromNetworkId
          L15_2 = BodyDamage
          L15_2 = L15_2.inBodyBag
          L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L14_2(L15_2)
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L13_2 = TaskPlayAnim
          L14_2 = L5_2
          L15_2 = "anim@gangops@morgue@table@"
          L16_2 = "body_search"
          L17_2 = 8.0
          L18_2 = 8.0
          L19_2 = -1
          L20_2 = 69
          L21_2 = 1
          L22_2 = false
          L23_2 = false
          L24_2 = false
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
          L13_2 = CreateObject
          L14_2 = "xm_prop_body_bag"
          L15_2 = GetEntityCoords
          L16_2 = PlayerPedId
          L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L16_2()
          L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L16_2 = true
          L17_2 = true
          L18_2 = true
          L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2, L18_2)
          bodyBag = L13_2
          L13_2 = AttachEntityToEntity
          L14_2 = bodyBag
          L15_2 = L5_2
          L16_2 = nil
          L17_2 = 0.0
          L18_2 = -0.25
          L19_2 = 0.45
          L20_2 = 80.0
          L21_2 = 0.0
          L22_2 = -180.0
          L23_2 = false
          L24_2 = false
          L25_2 = false
          L26_2 = false
          L27_2 = 1
          L28_2 = true
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L13_2 = BodyDamage
          L14_2 = NetworkGetNetworkIdFromEntity
          L15_2 = bodyBag
          L14_2 = L14_2(L15_2)
          L13_2.inBodyBag = L14_2
          L13_2 = LocalPlayer
          L13_2 = L13_2.state
          L14_2 = L13_2
          L13_2 = L13_2.set
          L15_2 = "BodyDamage"
          L16_2 = BodyDamage
          L17_2 = true
          L13_2(L14_2, L15_2, L16_2, L17_2)
          L13_2 = AttachEntityToEntity
          L14_2 = stretcher
          L15_2 = PlayerPedId
          L15_2 = L15_2()
          L16_2 = nil
          L17_2 = 0.0
          L18_2 = -0.9
          L19_2 = 0.0
          L20_2 = 90.0
          L21_2 = -90.0
          L22_2 = -190.0
          L23_2 = true
          L24_2 = true
          L25_2 = false
          L26_2 = true
          L27_2 = 1
          L28_2 = true
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L13_2 = AttachEntityToEntity
          L14_2 = PlayerPedId
          L14_2 = L14_2()
          L15_2 = L4_2
          L16_2 = nil
          L17_2 = 0.0
          L18_2 = -2.5
          L19_2 = 1.7
          L20_2 = 0.0
          L21_2 = 0.0
          L22_2 = 177.0
          L23_2 = true
          L24_2 = true
          L25_2 = false
          L26_2 = true
          L27_2 = 1
          L28_2 = true
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L13_2 = Wait
          L14_2 = 500
          L13_2(L14_2)
          L13_2 = TriggerServerEvent
          L14_2 = "osp_ambulance:SyncPulloutTargetSv"
          L15_2 = A0_2
          L16_2 = NetworkGetNetworkIdFromEntity
          L17_2 = L4_2
          L16_2 = L16_2(L17_2)
          L17_2 = NetworkGetNetworkIdFromEntity
          L18_2 = stretcher
          L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L17_2(L18_2)
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          syncPullout = A0_2
      end
      else
        L13_2 = BodyDamage
        L13_2 = L13_2.inBodyBag
        if not L13_2 then
          L13_2 = DebugPrint
          L14_2 = "Not in bodybag"
          L13_2(L14_2)
          L13_2 = CreateObjectNoOffset
          L14_2 = L12_2
          L15_2 = vector3
          L16_2 = 294.018
          L17_2 = -613.7497
          L18_2 = 42.4297
          L15_2 = L15_2(L16_2, L17_2, L18_2)
          L16_2 = 1
          L17_2 = 1
          L18_2 = 0
          L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2, L18_2)
          stretcher = L13_2
          L13_2 = Entity
          L14_2 = stretcher
          L13_2 = L13_2(L14_2)
          L13_2 = L13_2.state
          L14_2 = L13_2
          L13_2 = L13_2.set
          L15_2 = "HasPlayer"
          L16_2 = GetPlayerServerId
          L17_2 = NetworkGetPlayerIndexFromPed
          L18_2 = PlayerPedId
          L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L18_2()
          L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L17_2(L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L16_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L17_2 = true
          L13_2(L14_2, L15_2, L16_2, L17_2)
          L13_2 = GetEntityModel
          L14_2 = L3_2
          L13_2 = L13_2(L14_2)
          L14_2 = GetHashKey
          L15_2 = Config
          L15_2 = L15_2.StretcherModel
          L15_2 = L15_2.folded
          L14_2 = L14_2(L15_2)
          if L13_2 == L14_2 then
            L13_2 = Entity
            L14_2 = stretcher
            L13_2 = L13_2(L14_2)
            L13_2 = L13_2.state
            L14_2 = L13_2
            L13_2 = L13_2.set
            L15_2 = "ifFolded"
            L16_2 = true
            L17_2 = true
            L13_2(L14_2, L15_2, L16_2, L17_2)
          else
            L13_2 = Entity
            L14_2 = stretcher
            L13_2 = L13_2(L14_2)
            L13_2 = L13_2.state
            L14_2 = L13_2
            L13_2 = L13_2.set
            L15_2 = "ifFolded"
            L16_2 = false
            L17_2 = true
            L13_2(L14_2, L15_2, L16_2, L17_2)
          end
          L13_2 = DetachEntity
          L14_2 = L5_2
          L15_2 = true
          L16_2 = true
          L13_2(L14_2, L15_2, L16_2)
          L13_2 = ClearPedTasks
          L14_2 = L5_2
          L13_2(L14_2)
          L13_2 = ClearPedTasksImmediately
          L14_2 = L5_2
          L13_2(L14_2)
          L13_2 = TaskPlayAnim
          L14_2 = L5_2
          L15_2 = "anim@gangops@morgue@table@"
          L16_2 = "body_search"
          L17_2 = 8.0
          L18_2 = 8.0
          L19_2 = -1
          L20_2 = 69
          L21_2 = 1
          L22_2 = false
          L23_2 = false
          L24_2 = false
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
          L13_2 = DebugPrint
          L14_2 = "Attaching stretcher to client"
          L15_2 = stretcher
          L13_2(L14_2, L15_2)
          L13_2 = AttachEntityToEntity
          L14_2 = stretcher
          L15_2 = PlayerPedId
          L15_2 = L15_2()
          L16_2 = nil
          L17_2 = L11_2.stretcheroffset
          L18_2 = L11_2.stretcherrotation
          L19_2 = true
          L20_2 = true
          L21_2 = false
          L22_2 = true
          L23_2 = 1
          L24_2 = true
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
          L13_2 = DebugPrint
          L14_2 = "Attaching client to vehicle"
          L15_2 = L4_2
          L13_2(L14_2, L15_2)
          L13_2 = AttachEntityToEntity
          L14_2 = PlayerPedId
          L14_2 = L14_2()
          L15_2 = L4_2
          L16_2 = nil
          L17_2 = L11_2.playeroffset
          L18_2 = L11_2.playerrotation
          L19_2 = true
          L20_2 = true
          L21_2 = false
          L22_2 = true
          L23_2 = 1
          L24_2 = true
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2)
          L13_2 = Wait
          L14_2 = 500
          L13_2(L14_2)
          L13_2 = TriggerServerEvent
          L14_2 = "osp_ambulance:SyncPulloutTargetSv"
          L15_2 = A0_2
          L16_2 = NetworkGetNetworkIdFromEntity
          L17_2 = L4_2
          L16_2 = L16_2(L17_2)
          L17_2 = NetworkGetNetworkIdFromEntity
          L18_2 = stretcher
          L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L17_2(L18_2)
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          syncPullout = A0_2
          L13_2 = DebugPrint
          L14_2 = "Successfully put inside ambulance"
          L13_2(L14_2)
        end
      end
      inAmbo = false
    end
  end
  L6_2 = CreateThread
  function L7_2()
    local L0_3, L1_3, L2_3, L3_3
    while true do
      L0_3 = insideAmbulance
      if L0_3 then
        L0_3 = IsEntityAttachedToAnyVehicle
        L1_3 = L5_2
        L0_3 = L0_3(L1_3)
        if not L0_3 then
          insideAmbulance = false
          instretcher = false
          L0_3 = DetachEntity
          L1_3 = L5_2
          L2_3 = true
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = ClearPedTasks
          L1_3 = L5_2
          L0_3(L1_3)
          L0_3 = ClearPedTasksImmediately
          L1_3 = L5_2
          L0_3(L1_3)
          L0_3 = DetachEntity
          L1_3 = stretcher
          L2_3 = true
          L3_3 = true
          L0_3(L1_3, L2_3, L3_3)
          L0_3 = DeleteEntity
          L1_3 = stretcher
          L0_3(L1_3)
          L0_3 = FreezeEntityPosition
          L1_3 = L5_2
          L2_3 = false
          L0_3(L1_3, L2_3)
        end
      end
      L0_3 = insideAmbulance
      if not L0_3 then
        break
      end
      L0_3 = Wait
      L1_3 = 1000
      L0_3(L1_3)
    end
  end
  L6_2(L7_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:UpdateStretcherPositionOutCl"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2
  while true do
    L3_2 = NetworkGetEntityFromNetworkId
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    if 0 ~= L3_2 then
      break
    end
    L3_2 = Wait
    L4_2 = 1
    L3_2(L4_2)
  end
  L3_2 = NetworkGetEntityFromNetworkId
  L4_2 = A0_2
  L3_2 = L3_2(L4_2)
  L4_2 = NetworkGetEntityFromNetworkId
  L5_2 = A1_2
  L4_2 = L4_2(L5_2)
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  L6_2 = Entity
  L7_2 = L3_2
  L6_2 = L6_2(L7_2)
  L7_2 = L6_2.state
  L7_2 = L7_2.ifFolded
  L8_2 = L6_2.state
  L8_2 = L8_2.HasPlayer
  insideAmbulance = false
  L9_2 = pairs
  L10_2 = Config
  L10_2 = L10_2.Ambulances
  L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
  for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
    L15_2 = IsVehicleModel
    L16_2 = L4_2
    L17_2 = GetHashKey
    L18_2 = L13_2
    L17_2, L18_2, L19_2, L20_2 = L17_2(L18_2)
    L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2)
    if L15_2 then
      L15_2 = TriggerServerEvent
      L16_2 = "osp_ambulance:AttachStretcherToCarrierSv"
      L17_2 = A2_2
      L18_2 = GetPlayerServerId
      L19_2 = PlayerId
      L19_2, L20_2 = L19_2()
      L18_2 = L18_2(L19_2, L20_2)
      L19_2 = L8_2
      L20_2 = L7_2
      L15_2(L16_2, L17_2, L18_2, L19_2, L20_2)
      L15_2 = DebugPrint
      L16_2 = "Deleting old stretcher: "
      L17_2 = L3_2
      L15_2(L16_2, L17_2)
      L15_2 = NetworkRequestControlOfEntity
      L16_2 = L3_2
      L15_2(L16_2)
      L15_2 = DeleteEntity
      L16_2 = L3_2
      L15_2(L16_2)
      L15_2 = TriggerServerEvent
      L16_2 = "osp_ambulance:deleteStretcherAtEntityOwnerSv"
      L17_2 = NetworkGetNetworkIdFromEntity
      L18_2 = L4_2
      L17_2 = L17_2(L18_2)
      L18_2 = NetworkGetNetworkIdFromEntity
      L19_2 = L3_2
      L18_2, L19_2, L20_2 = L18_2(L19_2)
      L15_2(L16_2, L17_2, L18_2, L19_2, L20_2)
      L15_2 = DoesEntityExist
      L16_2 = L3_2
      L15_2 = L15_2(L16_2)
      if L15_2 then
        L15_2 = print
        L16_2 = "^1 Failed deleting old stretcher prop"
        L15_2(L16_2)
      end
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:DeleteStretcherCl"
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L0_2 = DetachEntity
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = true
  L3_2 = true
  L0_2(L1_2, L2_2, L3_2)
  instretcher = false
  L0_2 = BodyDamage
  L0_2 = L0_2.inBodyBag
  if L0_2 then
    L0_2 = DetachEntity
    L1_2 = NetworkGetEntityFromNetworkId
    L2_2 = BodyDamage
    L2_2 = L2_2.inBodyBag
    L1_2 = L1_2(L2_2)
    L2_2 = true
    L3_2 = true
    L0_2(L1_2, L2_2, L3_2)
    L0_2 = DeleteEntity
    L1_2 = NetworkGetEntityFromNetworkId
    L2_2 = BodyDamage
    L2_2 = L2_2.inBodyBag
    L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2 = L1_2(L2_2)
    L0_2(L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
    L0_2 = "xm_prop_body_bag"
    L1_2 = PlayerPedId
    L1_2 = L1_2()
    L2_2 = ClearPedTasksImmediately
    L3_2 = L1_2
    L2_2(L3_2)
    L2_2 = lib
    L2_2 = L2_2.requestModel
    L3_2 = L0_2
    L4_2 = 10000
    L2_2(L3_2, L4_2)
    L2_2 = CreateObject
    L3_2 = GetHashKey
    L4_2 = L0_2
    L3_2 = L3_2(L4_2)
    L4_2 = GetEntityCoords
    L5_2 = L1_2
    L4_2 = L4_2(L5_2)
    L5_2 = true
    L6_2 = true
    L7_2 = true
    L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
    bodyBag = L2_2
    L2_2 = SetEntityVisible
    L3_2 = L1_2
    L4_2 = false
    L5_2 = false
    L2_2(L3_2, L4_2, L5_2)
    L2_2 = AttachEntityToEntity
    L3_2 = L1_2
    L4_2 = bodyBag
    L5_2 = 0
    L6_2 = 0.0
    L7_2 = 0.0
    L8_2 = 0.5
    L9_2 = 0.0
    L10_2 = 0.0
    L11_2 = 0.0
    L12_2 = false
    L13_2 = false
    L14_2 = false
    L15_2 = false
    L16_2 = 20
    L17_2 = true
    L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
    L2_2 = PlaceObjectOnGroundProperly
    L3_2 = bodyBag
    L2_2(L3_2)
    L2_2 = SetEntityVisible
    L3_2 = bodyBag
    L4_2 = true
    L5_2 = true
    L2_2(L3_2, L4_2, L5_2)
    L2_2 = BodyDamage
    L3_2 = NetworkGetNetworkIdFromEntity
    L4_2 = bodyBag
    L3_2 = L3_2(L4_2)
    L2_2.inBodyBag = L3_2
    L2_2 = LocalPlayer
    L2_2 = L2_2.state
    L3_2 = L2_2
    L2_2 = L2_2.set
    L4_2 = "BodyDamage"
    L5_2 = BodyDamage
    L6_2 = true
    L2_2(L3_2, L4_2, L5_2, L6_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:DeleteStretcher"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = Config
  L1_2 = L1_2.StretcherLimit
  if L1_2 then
    activeStretcher = false
  end
  L1_2 = Entity
  L2_2 = A0_2.entity
  L1_2 = L1_2(L2_2)
  L2_2 = L1_2.state
  L2_2 = L2_2.HasPlayer
  if L2_2 then
    L3_2 = TriggerServerEvent
    L4_2 = "osp_ambulance:DeleteStretcherSv"
    L5_2 = L2_2
    L3_2(L4_2, L5_2)
  end
  L3_2 = TriggerServerEvent
  L4_2 = "osp_ambulance:addItem"
  L5_2 = "stretcher"
  L6_2 = 1
  L3_2(L4_2, L5_2, L6_2)
  L3_2 = Config
  L3_2 = L3_2.UseTarget
  if not L3_2 then
    L3_2 = deleteStretcherPoly
    L4_2 = A0_2.entity
    L3_2(L4_2)
  end
  L3_2 = DeleteEntity
  L4_2 = A0_2.entity
  L3_2(L4_2)
  L3_2 = Wait
  L4_2 = 100
  L3_2(L4_2)
  L3_2 = DoesEntityExist
  L4_2 = A0_2.entity
  L3_2 = L3_2(L4_2)
  if L3_2 then
    L3_2 = SetEntityCoords
    L4_2 = A0_2.entity
    L5_2 = 0.0
    L6_2 = 0.0
    L7_2 = 0.0
    L3_2(L4_2, L5_2, L6_2, L7_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:AttachStretcherToCarrierCl"
function L2_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L3_2 = DebugPrint
  L4_2 = "Carrier got event to attach stretcher to carrier"
  L3_2(L4_2)
  if A2_2 then
    L3_2 = Config
    L3_2 = L3_2.StretcherModel
    L3_2 = L3_2.folded
    stretcherM = L3_2
    L3_2 = lib
    L3_2 = L3_2.requestModel
    L4_2 = stretcherM
    L5_2 = 10000
    L3_2(L4_2, L5_2)
  else
    L3_2 = Config
    L3_2 = L3_2.StretcherModel
    L3_2 = L3_2.regular
    stretcherM = L3_2
    L3_2 = lib
    L3_2 = L3_2.requestModel
    L4_2 = stretcherM
    L5_2 = 10000
    L3_2(L4_2, L5_2)
  end
  L3_2 = CreateObjectNoOffset
  L4_2 = stretcherM
  L5_2 = GetEntityCoords
  L6_2 = PlayerPedId
  L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2 = L6_2()
  L5_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
  L5_2 = L5_2 - 3
  L6_2 = 1
  L7_2 = 1
  L8_2 = 0
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
  L4_2 = DebugPrint
  L5_2 = "stretcher created "
  L6_2 = L3_2
  L7_2 = stretcherM
  L4_2(L5_2, L6_2, L7_2)
  if A1_2 then
    L4_2 = Entity
    L5_2 = L3_2
    L4_2 = L4_2(L5_2)
    L4_2 = L4_2.state
    L5_2 = L4_2
    L4_2 = L4_2.set
    L6_2 = "HasPlayer"
    L7_2 = A1_2
    L8_2 = true
    L4_2(L5_2, L6_2, L7_2, L8_2)
  end
  L4_2 = TriggerServerEvent
  L5_2 = "osp_ambulance:AttachPlayerToStretcherSv"
  L6_2 = A0_2
  L7_2 = NetworkGetNetworkIdFromEntity
  L8_2 = L3_2
  L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2 = L7_2(L8_2)
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
  L4_2 = Config
  L4_2 = L4_2.UseTarget
  if L4_2 then
    L4_2 = creatingStretcherInteraction
    L5_2 = L3_2
    L4_2(L5_2)
  end
  L4_2 = Wait
  L5_2 = 150
  L4_2(L5_2)
  L4_2 = GetEntityModel
  L5_2 = PlayerPedId
  L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2 = L5_2()
  L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
  L5_2 = GetHashKey
  L6_2 = "mp_m_freemode_01"
  L5_2 = L5_2(L6_2)
  if L4_2 ~= L5_2 then
    L4_2 = GetEntityModel
    L5_2 = PlayerPedId
    L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2 = L5_2()
    L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
    L5_2 = GetHashKey
    L6_2 = "mp_f_freemode_01"
    L5_2 = L5_2(L6_2)
    if L4_2 ~= L5_2 then
      goto lbl_113
    end
  end
  L4_2 = AttachEntityToEntity
  L5_2 = L3_2
  L6_2 = PlayerPedId
  L6_2 = L6_2()
  L7_2 = GetPedBoneIndex
  L8_2 = PlayerPedId
  L8_2 = L8_2()
  L9_2 = 64654
  L7_2 = L7_2(L8_2, L9_2)
  L8_2 = Config
  L8_2 = L8_2.StretcherAttach
  L8_2 = L8_2.playerOnStretcherOffset
  L8_2 = L8_2.freemode
  L9_2 = Config
  L9_2 = L9_2.StretcherAttach
  L9_2 = L9_2.playerOnStretcherRotation
  L9_2 = L9_2.freemode
  L10_2 = true
  L11_2 = true
  L12_2 = false
  L13_2 = true
  L14_2 = 1
  L15_2 = true
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
  goto lbl_137
  ::lbl_113::
  L4_2 = AttachEntityToEntity
  L5_2 = L3_2
  L6_2 = PlayerPedId
  L6_2 = L6_2()
  L7_2 = GetPedBoneIndex
  L8_2 = PlayerPedId
  L8_2 = L8_2()
  L9_2 = 64654
  L7_2 = L7_2(L8_2, L9_2)
  L8_2 = Config
  L8_2 = L8_2.StretcherAttach
  L8_2 = L8_2.playerOnStretcherOffset
  L8_2 = L8_2.ped
  L9_2 = Config
  L9_2 = L9_2.StretcherAttach
  L9_2 = L9_2.playerOnStretcherRotation
  L9_2 = L9_2.ped
  L10_2 = true
  L11_2 = true
  L12_2 = false
  L13_2 = true
  L14_2 = 1
  L15_2 = true
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
  ::lbl_137::
  L4_2 = lib
  L4_2 = L4_2.requestAnimDict
  L5_2 = "anim@heists@box_carry@"
  L6_2 = 1000
  L4_2(L5_2, L6_2)
  L4_2 = TaskPlayAnim
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  L6_2 = "anim@heists@box_carry@"
  L7_2 = "idle"
  L8_2 = 8.0
  L9_2 = 8.0
  L10_2 = -1
  L11_2 = 50
  L12_2 = 0
  L13_2 = false
  L14_2 = false
  L15_2 = false
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
  L4_2 = DebugPrint
  L5_2 = "attached stretcher to carrier and patient to stretcher. Playing animation"
  L4_2(L5_2)
  L4_2 = CreateThread
  function L5_2()
    local L0_3, L1_3, L2_3
    while true do
      L0_3 = IsControlJustPressed
      L1_3 = 0
      L2_3 = 46
      L0_3 = L0_3(L1_3, L2_3)
      if L0_3 then
        L0_3 = ClearPedTasks
        L1_3 = PlayerPedId
        L1_3, L2_3 = L1_3()
        L0_3(L1_3, L2_3)
        L0_3 = DetachEntity
        L1_3 = L3_2
        L0_3(L1_3)
        L0_3 = PlaceObjectOnGroundProperly
        L1_3 = L3_2
        L0_3(L1_3)
        L0_3 = GetEntityModel
        L1_3 = L3_2
        L0_3 = L0_3(L1_3)
        L1_3 = GetHashKey
        L2_3 = Config
        L2_3 = L2_3.StretcherModel
        L2_3 = L2_3.folded
        L1_3 = L1_3(L2_3)
        if L0_3 == L1_3 then
          L0_3 = SetEntityCollision
          L1_3 = L3_2
          L2_3 = true
          L0_3(L1_3, L2_3)
          L0_3 = FreezeEntityPosition
          L1_3 = L3_2
          L2_3 = true
          L0_3(L1_3, L2_3)
        end
        L0_3 = Config
        L0_3 = L0_3.UseTarget
        if not L0_3 then
          L0_3 = Wait
          L1_3 = 500
          L0_3(L1_3)
          L0_3 = creatingStretcherPoly
          L1_3 = L3_2
          L0_3(L1_3)
        end
        break
      end
      L0_3 = Wait
      L1_3 = 3
      L0_3(L1_3)
    end
  end
  L4_2(L5_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:AttachPlayerToStretcherCl"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L1_2 = Wait
  L2_2 = 100
  L1_2(L2_2)
  while true do
    L1_2 = NetworkDoesEntityExistWithNetworkId
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = Wait
    L2_2 = 1
    L1_2(L2_2)
  end
  L1_2 = DebugPrint
  L2_2 = "attach player to stretcher event, stretcherid: "
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
  L1_2 = NetworkGetEntityFromNetworkId
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = DetachEntity
  L4_2 = L2_2
  L5_2 = true
  L6_2 = true
  L3_2(L4_2, L5_2, L6_2)
  L3_2 = ClearPedTasks
  L4_2 = L2_2
  L3_2(L4_2)
  L3_2 = ClearPedTasksImmediately
  L4_2 = L2_2
  L3_2(L4_2)
  L3_2 = GetEntityModel
  L4_2 = L1_2
  L3_2 = L3_2(L4_2)
  L4_2 = GetHashKey
  L5_2 = Config
  L5_2 = L5_2.StretcherModel
  L5_2 = L5_2.regular
  L4_2 = L4_2(L5_2)
  if L3_2 == L4_2 then
    L3_2 = AttachEntityToEntity
    L4_2 = L2_2
    L5_2 = L1_2
    L6_2 = nil
    L7_2 = 0.0
    L8_2 = 0.0
    L9_2 = 2.1
    L10_2 = 0.0
    L11_2 = 0.0
    L12_2 = 100.0
    L13_2 = true
    L14_2 = true
    L15_2 = false
    L16_2 = true
    L17_2 = 1
    L18_2 = true
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
    L3_2 = lib
    L3_2 = L3_2.requestAnimDict
    L4_2 = "timetable@jimmy@mics3_ig_15@"
    L5_2 = 100
    L3_2(L4_2, L5_2)
    L3_2 = TaskPlayAnim
    L4_2 = L2_2
    L5_2 = "timetable@jimmy@mics3_ig_15@"
    L6_2 = "mics3_15_base_jimmy"
    L7_2 = 8.0
    L8_2 = 8.0
    L9_2 = -1
    L10_2 = 69
    L11_2 = 1
    L12_2 = false
    L13_2 = false
    L14_2 = false
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
    L3_2 = CreateThread
    function L4_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
      while true do
        L0_3 = instretcher
        if not L0_3 then
          break
        end
        L0_3 = inAmbo
        if L0_3 then
          break
        end
        L0_3 = IsEntityPlayingAnim
        L1_3 = L2_2
        L2_3 = "timetable@jimmy@mics3_ig_15@"
        L3_3 = "mics3_15_base_jimmy"
        L4_3 = 3
        L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3)
        if not L0_3 then
          L0_3 = TaskPlayAnim
          L1_3 = L2_2
          L2_3 = "timetable@jimmy@mics3_ig_15@"
          L3_3 = "mics3_15_base_jimmy"
          L4_3 = 2.0
          L5_3 = 2.0
          L6_3 = -1
          L7_3 = 1
          L8_3 = 0
          L9_3 = 0
          L10_3 = 0
          L11_3 = 0
          L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
        end
        L0_3 = IsEntityAttachedToEntity
        L1_3 = L2_2
        L2_3 = entity
        L0_3 = L0_3(L1_3, L2_3)
        if not L0_3 then
          L0_3 = AttachEntityToEntity
          L1_3 = L2_2
          L2_3 = entity
          L3_3 = nil
          L4_3 = 0.0
          L5_3 = 0.0
          L6_3 = 2.1
          L7_3 = 0.0
          L8_3 = 0.0
          L9_3 = 100.0
          L10_3 = true
          L11_3 = true
          L12_3 = false
          L13_3 = true
          L14_3 = 1
          L15_3 = true
          L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
        end
        L0_3 = BodyDamage
        L0_3 = L0_3.isDead
        if not L0_3 then
          L0_3 = BodyDamage
          L0_3 = L0_3.inLastStand
          if not L0_3 then
            goto lbl_82
          end
        end
        L0_3 = IsEntityPlayingAnim
        L1_3 = L2_2
        L2_3 = "mp_sleep"
        L3_3 = "sleep_loop"
        L4_3 = 3
        L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3)
        if not L0_3 then
          L0_3 = TaskPlayAnim
          L1_3 = L2_2
          L2_3 = "mp_sleep"
          L3_3 = "sleep_loop"
          L4_3 = 2.0
          L5_3 = 2.0
          L6_3 = -1
          L7_3 = 51
          L8_3 = 0
          L9_3 = 0
          L10_3 = 0
          L11_3 = 0
          L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
          goto lbl_82
          break
        end
        ::lbl_82::
        L0_3 = Wait
        L1_3 = 40
        L0_3(L1_3)
      end
    end
    L3_2(L4_2)
  else
    L3_2 = GetEntityModel
    L4_2 = L1_2
    L3_2 = L3_2(L4_2)
    L4_2 = GetHashKey
    L5_2 = Config
    L5_2 = L5_2.StretcherModel
    L5_2 = L5_2.folded
    L4_2 = L4_2(L5_2)
    if L3_2 == L4_2 then
      L3_2 = BodyDamage
      L3_2 = L3_2.inBodyBag
      if L3_2 then
        L3_2 = AttachEntityToEntity
        L4_2 = NetworkGetEntityFromNetworkId
        L5_2 = BodyDamage
        L5_2 = L5_2.inBodyBag
        L4_2 = L4_2(L5_2)
        L5_2 = L2_2
        L6_2 = nil
        L7_2 = 0.03
        L8_2 = 0.0
        L9_2 = -0.35
        L10_2 = -77.0
        L11_2 = -4.0
        L12_2 = -5.0
        L13_2 = false
        L14_2 = false
        L15_2 = false
        L16_2 = false
        L17_2 = 1
        L18_2 = true
        L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
        L3_2 = AttachEntityToEntity
        L4_2 = L2_2
        L5_2 = L1_2
        L6_2 = nil
        L7_2 = 0.0
        L8_2 = 0.0
        L9_2 = 2.1
        L10_2 = 0.0
        L11_2 = 0.0
        L12_2 = 90.0
        L13_2 = true
        L14_2 = true
        L15_2 = false
        L16_2 = true
        L17_2 = 1
        L18_2 = true
        L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
      else
        L3_2 = AttachEntityToEntity
        L4_2 = L2_2
        L5_2 = L1_2
        L6_2 = nil
        L7_2 = 0.0
        L8_2 = 0.0
        L9_2 = 2.1
        L10_2 = 0.0
        L11_2 = 0.0
        L12_2 = 90.0
        L13_2 = true
        L14_2 = true
        L15_2 = false
        L16_2 = true
        L17_2 = 1
        L18_2 = true
        L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
      end
      L3_2 = lib
      L3_2 = L3_2.requestAnimDict
      L4_2 = "anim@gangops@morgue@table@"
      L5_2 = 100
      L3_2(L4_2, L5_2)
      L3_2 = TaskPlayAnim
      L4_2 = L2_2
      L5_2 = "anim@gangops@morgue@table@"
      L6_2 = "body_search"
      L7_2 = 8.0
      L8_2 = 8.0
      L9_2 = -1
      L10_2 = 69
      L11_2 = 1
      L12_2 = false
      L13_2 = false
      L14_2 = false
      L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
      L3_2 = CreateThread
      function L4_2()
        local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
        while true do
          L0_3 = instretcher
          if not L0_3 then
            break
          end
          L0_3 = inAmbo
          if not L0_3 then
            L0_3 = IsEntityPlayingAnim
            L1_3 = L2_2
            L2_3 = "anim@gangops@morgue@table@"
            L3_3 = "body_search"
            L4_3 = 3
            L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3)
            if not L0_3 then
              L0_3 = TaskPlayAnim
              L1_3 = L2_2
              L2_3 = "anim@gangops@morgue@table@"
              L3_3 = "body_search"
              L4_3 = 1.0
              L5_3 = 1.0
              L6_3 = -1
              L7_3 = 1
              L8_3 = 0
              L9_3 = 0
              L10_3 = 0
              L11_3 = 0
              L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
            end
            L0_3 = IsEntityAttachedToEntity
            L1_3 = L2_2
            L2_3 = entity
            L0_3 = L0_3(L1_3, L2_3)
            if not L0_3 then
              L0_3 = AttachEntityToEntity
              L1_3 = L2_2
              L2_3 = entity
              L3_3 = nil
              L4_3 = 0.15
              L5_3 = 0.0
              L6_3 = 2.1
              L7_3 = 0.0
              L8_3 = 0.0
              L9_3 = 90.0
              L10_3 = true
              L11_3 = true
              L12_3 = false
              L13_3 = true
              L14_3 = 1
              L15_3 = true
              L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
            end
          else
            break
          end
          L0_3 = Wait
          L1_3 = 40
          L0_3(L1_3)
        end
      end
      L3_2(L4_2)
    end
  end
end
L0_1(L1_1, L2_1)
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = IsEntityAVehicle
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if L1_2 then
    return
  end
  L1_2 = Config
  L1_2 = L1_2.UseOxTarget
  if L1_2 then
    L1_2 = TargetEntity
    L2_2 = A0_2
    L3_2 = {}
    L3_2.type = "client"
    L3_2.event = "osp_ambulance:PickupStretcher"
    L3_2.icon = "fa-solid fa-hand"
    L4_2 = lang
    L4_2 = L4_2.stretcher
    L4_2 = L4_2.pickup
    L3_2.label = L4_2
    L4_2 = {}
    L4_2.type = "client"
    L4_2.event = "osp_ambulance:PutPlayerInOutStretcherPrepCl"
    L4_2.icon = "fa-solid fa-person"
    L5_2 = lang
    L5_2 = L5_2.stretcher
    L5_2 = L5_2.putin
    L4_2.label = L5_2
    L4_2.manual = true
    L5_2 = {}
    L5_2.type = "client"
    L5_2.event = "osp_ambulance:DeleteStretcher"
    L5_2.icon = "fa-solid fa-trash-can"
    L6_2 = lang
    L6_2 = L6_2.stretcher
    L6_2 = L6_2.delete
    L5_2.label = L6_2
    L6_2 = {}
    L6_2.type = "client"
    L6_2.event = "osp_ambulance:FoldStretcher"
    L6_2.icon = "fa-solid fa-repeat"
    L7_2 = lang
    L7_2 = L7_2.stretcher
    L7_2 = L7_2.fold
    L6_2.label = L7_2
    L7_2 = {}
    L7_2.type = "client"
    L7_2.event = "osp_ambulance:PutStretcherInAmbulance"
    L7_2.icon = "fa-solid fa-right-to-bracket"
    L8_2 = lang
    L8_2 = L8_2.stretcher
    L8_2 = L8_2.inambo
    L7_2.label = L8_2
    L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
  else
    L1_2 = TargetEntity
    L2_2 = A0_2
    L3_2 = {}
    L3_2.name = A0_2
    L3_2.event = "osp_ambulance:PickupStretcher"
    L3_2.icon = "fa-solid fa-hand"
    L4_2 = lang
    L4_2 = L4_2.stretcher
    L4_2 = L4_2.pickup
    L3_2.label = L4_2
    L4_2 = {}
    L4_2.name = A0_2
    L4_2.event = "osp_ambulance:PutPlayerInOutStretcherPrepCl"
    L4_2.icon = "fa-solid fa-person"
    L5_2 = lang
    L5_2 = L5_2.stretcher
    L5_2 = L5_2.putin
    L4_2.label = L5_2
    L4_2.manual = true
    L5_2 = {}
    L5_2.name = A0_2
    L5_2.event = "osp_ambulance:DeleteStretcher"
    L5_2.icon = "fa-solid fa-trash-can"
    L6_2 = lang
    L6_2 = L6_2.stretcher
    L6_2 = L6_2.delete
    L5_2.label = L6_2
    L6_2 = {}
    L6_2.name = A0_2
    L6_2.event = "osp_ambulance:FoldStretcher"
    L6_2.icon = "fa-solid fa-repeat"
    L7_2 = lang
    L7_2 = L7_2.stretcher
    L7_2 = L7_2.fold
    L6_2.label = L7_2
    L7_2 = {}
    L7_2.name = A0_2
    L7_2.event = "osp_ambulance:PutStretcherInAmbulance"
    L7_2.icon = "fa-solid fa-right-to-bracket"
    L8_2 = lang
    L8_2 = L8_2.stretcher
    L8_2 = L8_2.inambo
    L7_2.label = L8_2
    L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
  end
end
creatingStretcherInteraction = L0_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = false
  function L2_2()
    local L0_3, L1_3
    L0_3 = true
    L1_2 = L0_3
  end
  des = L2_2
  L2_2 = GetEntityCoords
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = L1_2
    if L1_3 then
      return
    end
    L1_3 = textUi
    L2_3 = "[E] "
    L3_3 = lang
    L3_3 = L3_3.ecg
    L3_3 = L3_3.options
    L2_3 = L2_3 .. L3_3
    L1_3(L2_3)
  end
  onEnter = L3_2
  function L3_2(A0_3)
    local L1_3, L2_3, L3_3
    L1_3 = L1_2
    if L1_3 then
      return
    end
    L1_3 = IsControlJustPressed
    L2_3 = 0
    L3_3 = 38
    L1_3 = L1_3(L2_3, L3_3)
    if L1_3 then
      L1_3 = stretcherMenu
      L2_3 = A0_2
      L1_3(L2_3)
      L1_3 = Wait
      L2_3 = 100
      L1_3(L2_3)
    end
  end
  inside = L3_2
  function L3_2(A0_3)
    local L1_3
    L1_3 = L1_2
    if L1_3 then
      return
    end
    L1_3 = removeTextUi
    L1_3()
  end
  onExit = L3_2
  L3_2 = lib
  L3_2 = L3_2.zones
  L3_2 = L3_2.box
  L4_2 = {}
  L5_2 = vec3
  L6_2 = L2_2.x
  L7_2 = L2_2.y
  L8_2 = L2_2.z
  L8_2 = L8_2 - 1
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  L4_2.coords = L5_2
  L5_2 = NetworkGetNetworkIdFromEntity
  L6_2 = A0_2
  L5_2 = L5_2(L6_2)
  L4_2.name = L5_2
  L5_2 = vec3
  L6_2 = 5
  L7_2 = 5
  L8_2 = 5
  L5_2 = L5_2(L6_2, L7_2, L8_2)
  L4_2.size = L5_2
  L4_2.rotation = 45
  L4_2.debug = false
  L5_2 = inside
  L4_2.inside = L5_2
  L5_2 = onEnter
  L4_2.onEnter = L5_2
  L5_2 = onExit
  L4_2.onExit = L5_2
  L3_2 = L3_2(L4_2)
  L4_2 = table
  L4_2 = L4_2.insert
  L5_2 = stretcherPolyList
  L6_2 = L3_2
  L4_2(L5_2, L6_2)
end
creatingStretcherPoly = L0_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = Config
  L1_2 = L1_2.UseTarget
  if not L1_2 then
    L1_2 = pairs
    L2_2 = stretcherPolyList
    L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
    for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
      L7_2 = string
      L7_2 = L7_2.match
      L8_2 = tostring
      L9_2 = NetworkGetNetworkIdFromEntity
      L10_2 = A0_2
      L9_2, L10_2 = L9_2(L10_2)
      L8_2 = L8_2(L9_2, L10_2)
      L9_2 = tostring
      L10_2 = L6_2.name
      L9_2, L10_2 = L9_2(L10_2)
      L7_2 = L7_2(L8_2, L9_2, L10_2)
      if L7_2 then
        L8_2 = L6_2
        L7_2 = L6_2.remove
        L7_2(L8_2)
        L7_2 = removeTextUi
        L7_2()
        L7_2 = stretcherPolyList
        L7_2[L5_2] = nil
        L7_2 = des
        L7_2()
      end
    end
  end
end
deleteStretcherPoly = L0_1
function L0_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = IsEntityAVehicle
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if L1_2 then
    return
  end
  L1_2 = registerContext
  L2_2 = {}
  L3_2 = "menu"
  L4_2 = A0_2
  L3_2 = L3_2 .. L4_2
  L2_2.id = L3_2
  L2_2.title = "Strecher Options"
  L3_2 = {}
  L4_2 = {}
  L5_2 = lang
  L5_2 = L5_2.stretcher
  L5_2 = L5_2.pickup
  L4_2.title = L5_2
  L4_2.icon = "fa-solid fa-hand"
  L4_2.event = "osp_ambulance:PickupStretcher"
  L4_2.arrow = true
  L5_2 = {}
  L5_2.entity = A0_2
  L4_2.args = L5_2
  L5_2 = {}
  L6_2 = lang
  L6_2 = L6_2.stretcher
  L6_2 = L6_2.putin
  L5_2.title = L6_2
  L5_2.icon = "fa-solid fa-person"
  L5_2.event = "osp_ambulance:PutPlayerInOutStretcherPrepCl"
  L5_2.arrow = true
  L6_2 = {}
  L6_2.entity = A0_2
  L6_2.manual = true
  L5_2.args = L6_2
  L6_2 = {}
  L7_2 = lang
  L7_2 = L7_2.stretcher
  L7_2 = L7_2.delete
  L6_2.title = L7_2
  L6_2.icon = "fa-solid fa-trash-can"
  L6_2.event = "osp_ambulance:DeleteStretcher"
  L6_2.arrow = true
  L7_2 = {}
  L7_2.entity = A0_2
  L6_2.args = L7_2
  L7_2 = {}
  L8_2 = lang
  L8_2 = L8_2.stretcher
  L8_2 = L8_2.fold
  L7_2.title = L8_2
  L7_2.icon = "fa-solid fa-repeat"
  L7_2.event = "osp_ambulance:FoldStretcher"
  L7_2.arrow = true
  L8_2 = {}
  L8_2.entity = A0_2
  L7_2.args = L8_2
  L8_2 = {}
  L9_2 = lang
  L9_2 = L9_2.stretcher
  L9_2 = L9_2.inambo
  L8_2.title = L9_2
  L8_2.icon = "fa-solid fa-right-to-bracket"
  L8_2.event = "osp_ambulance:PutStretcherInAmbulance"
  L8_2.arrow = true
  L9_2 = {}
  L9_2.entity = A0_2
  L8_2.args = L9_2
  L3_2[1] = L4_2
  L3_2[2] = L5_2
  L3_2[3] = L6_2
  L3_2[4] = L7_2
  L3_2[5] = L8_2
  L2_2.options = L3_2
  L1_2(L2_2)
  L1_2 = showContext
  L2_2 = "menu"
  L3_2 = A0_2
  L2_2 = L2_2 .. L3_2
  L1_2(L2_2)
end
stretcherMenu = L0_1
function L0_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2, A6_2, A7_2, A8_2)
  local L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2
  L9_2 = A4_2 / A5_2
  L10_2 = easeInOutQuad
  L11_2 = L9_2
  L12_2 = A1_2.x
  L13_2 = A2_2.x
  L14_2 = A1_2.x
  L13_2 = L13_2 - L14_2
  L14_2 = 1
  L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2)
  L11_2 = easeInOutQuad
  L12_2 = L9_2
  L13_2 = A1_2.y
  L14_2 = A2_2.y
  L15_2 = A1_2.y
  L14_2 = L14_2 - L15_2
  L15_2 = 1
  L11_2 = L11_2(L12_2, L13_2, L14_2, L15_2)
  L12_2 = easeInOutQuad
  L13_2 = L9_2
  L14_2 = A1_2.z
  L15_2 = A2_2.z
  L16_2 = A1_2.z
  L15_2 = L15_2 - L16_2
  L16_2 = 1
  L12_2 = L12_2(L13_2, L14_2, L15_2, L16_2)
  L13_2 = vector3
  L14_2 = L10_2
  L15_2 = L11_2
  L16_2 = L12_2
  L13_2 = L13_2(L14_2, L15_2, L16_2)
  L14_2 = AttachEntityToEntity
  L15_2 = A6_2
  L16_2 = A0_2
  L17_2 = nil
  L18_2 = L13_2.x
  L19_2 = L13_2.y
  L20_2 = L13_2.z
  L21_2 = A3_2.x
  L22_2 = A3_2.y
  L23_2 = A3_2.z
  L24_2 = true
  L25_2 = true
  L26_2 = false
  L27_2 = true
  L28_2 = 1
  L29_2 = true
  L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2)
  if A7_2 then
    L14_2 = AttachEntityToEntity
    L15_2 = A7_2
    L16_2 = A0_2
    L17_2 = nil
    L18_2 = L13_2.x
    L19_2 = L13_2.y
    L20_2 = L13_2.z
    L20_2 = L20_2 + 1.7
    L21_2 = 0.0
    L22_2 = 0.0
    L23_2 = 180.0
    L24_2 = true
    L25_2 = true
    L26_2 = false
    L27_2 = true
    L28_2 = 1
    L29_2 = true
    L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2, L29_2)
  end
end
updateAmbulancePosition = L0_1
function L0_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2
  L4_2 = A3_2 / 2
  A0_2 = A0_2 / L4_2
  if A0_2 < 1 then
    L4_2 = A2_2 / 2
    L4_2 = L4_2 * A0_2
    L4_2 = L4_2 * A0_2
    L4_2 = L4_2 + A1_2
    return L4_2
  else
    A0_2 = A0_2 - 1
    L4_2 = -A2_2
    L4_2 = L4_2 / 2
    L5_2 = A0_2 - 2
    L5_2 = A0_2 * L5_2
    L5_2 = L5_2 - 1
    L4_2 = L4_2 * L5_2
    L4_2 = L4_2 + A1_2
    return L4_2
  end
end
easeInOutQuad = L0_1
L0_1 = CreateThread
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  while true do
    L0_2 = pairs
    L1_2 = stretcherInVehicle
    L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
    for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
      L6_2 = NetworkDoesEntityExistWithNetworkId
      L7_2 = L4_2
      L6_2 = L6_2(L7_2)
      if not L6_2 then
        L6_2 = DoesEntityExist
        L7_2 = NetworkGetEntityFromNetworkId
        L8_2 = L4_2
        L7_2, L8_2, L9_2, L10_2, L11_2 = L7_2(L8_2)
        L6_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2)
        if not L6_2 then
          L6_2 = NetworkGetEntityFromNetworkId
          L7_2 = L5_2.stretcherId
          L6_2 = L6_2(L7_2)
          L7_2 = DoesEntityExist
          L8_2 = L6_2
          L7_2 = L7_2(L8_2)
          if L7_2 then
            L7_2 = Config
            L7_2 = L7_2.StretcherLimit
            if L7_2 then
              activeStretcher = false
            end
            L7_2 = Entity
            L8_2 = L6_2
            L7_2 = L7_2(L8_2)
            L8_2 = L7_2.state
            L8_2 = L8_2.HasPlayer
            if L8_2 then
              L9_2 = TriggerServerEvent
              L10_2 = "osp_ambulance:DeleteStretcherSv"
              L11_2 = L8_2
              L9_2(L10_2, L11_2)
            end
            L9_2 = Config
            L9_2 = L9_2.UseTarget
            if not L9_2 then
              L9_2 = deleteStretcherPoly
              L10_2 = L6_2
              L9_2(L10_2)
            end
            L9_2 = DeleteEntity
            L10_2 = L6_2
            L9_2(L10_2)
            L9_2 = stretcherInVehicle
            L9_2[L4_2] = nil
          end
        end
      end
    end
    L0_2 = Wait
    L1_2 = 1000
    L0_2(L1_2)
  end
end
L0_1(L1_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:deleteStretcherAtEntityOwnerCl"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = NetworkGetEntityFromNetworkId
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  L3_2 = NetworkHasControlOfEntity
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if L3_2 then
    L3_2 = NetworkRequestControlOfEntity
    L4_2 = L2_2
    L3_2(L4_2)
    L3_2 = NetworkRequestControlOfNetworkId
    L4_2 = NetworkGetNetworkIdFromEntity
    L5_2 = L2_2
    L4_2, L5_2 = L4_2(L5_2)
    L3_2(L4_2, L5_2)
    L3_2 = DeleteEntity
    L4_2 = L2_2
    L3_2(L4_2)
  end
end
L0_1(L1_1, L2_1)
