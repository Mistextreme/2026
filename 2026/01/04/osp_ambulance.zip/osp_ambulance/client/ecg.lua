local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1, L9_1, L10_1, L11_1, L12_1, L13_1, L14_1, L15_1, L16_1, L17_1, L18_1, L19_1, L20_1, L21_1
L0_1 = "NSR"
L1_1 = 3
L2_1 = RegisterNUICallback
L3_1 = "duiIsReady"
function L4_1(A0_2, A1_2)
  local L2_2, L3_2
  duiIsReady = true
  L2_2 = A1_2
  L3_2 = {}
  L3_2.ok = true
  L2_2(L3_2)
end
L2_1(L3_1, L4_1)
function L2_1(A0_2)
  local L1_2, L2_2
  L1_2 = RequestStreamedTextureDict
  L2_2 = A0_2
  L1_2(L2_2)
  while true do
    L1_2 = HasStreamedTextureDictLoaded
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = Wait
    L2_2 = 0
    L1_2(L2_2)
  end
  return A0_2
end
RequestTextureDictionary = L2_1
function L2_1(A0_2)
  local L1_2, L2_2
  L1_2 = IsModelInCdimage
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    return
  end
  L1_2 = RequestModel
  L2_2 = A0_2
  L1_2(L2_2)
  while true do
    L1_2 = HasModelLoaded
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = Wait
    L2_2 = 0
    L1_2(L2_2)
  end
  return A0_2
end
LoadModel = L2_1
L2_1 = 1280
L3_1 = 720
L4_1 = {}
L5_1 = {}
L6_1 = false
L7_1 = 0.028
L8_1 = "nui://osp_ambulance/html/index.html"
L9_1 = {}
L10_1 = {}
L11_1 = false
function L12_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = DebugPrint
  L2_2 = "Loading scaleform: "
  L3_2 = A0_2
  L2_2 = L2_2 .. L3_2
  L1_2(L2_2)
  L1_2 = RequestScaleformMovie
  L2_2 = A0_2
  L1_2 = L1_2(L2_2)
  L2_2 = DebugPrint
  L3_2 = "Scaleform handle: "
  L4_2 = L1_2
  L2_2(L3_2, L4_2)
  L2_2 = DebugPrint
  L3_2 = "start loading scaleform"
  L2_2(L3_2)
  L2_2 = 500
  while true do
    L3_2 = HasScaleformMovieLoaded
    L4_2 = L1_2
    L3_2 = L3_2(L4_2)
    if L3_2 then
      break
    end
    L3_2 = Wait
    L4_2 = 1
    L3_2(L4_2)
    L3_2 = RequestScaleformMovie
    L4_2 = A0_2
    L3_2 = L3_2(L4_2)
    L1_2 = L3_2
    L2_2 = L2_2 - 1
    if L2_2 <= 0 then
      L3_2 = print
      L4_2 = "^1Scaleform failed to load, please restart the server"
      L3_2(L4_2)
      L3_2 = nil
      return L3_2
    end
  end
  L3_2 = DebugPrint
  L4_2 = "stop loading scaleform"
  L3_2(L4_2)
  return L1_2
end
loadScaleform = L12_1
L12_1 = 0
function L13_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L4_2 = NetworkGetNetworkIdFromEntity
  L5_2 = A1_2
  L4_2 = L4_2(L5_2)
  L5_2 = L9_1
  L6_2 = "generic_texture_renderer_ekg"
  L7_2 = A3_2
  L6_2 = L6_2 .. L7_2
  L5_2[L4_2] = L6_2
  L5_2 = L5_1
  L6_2 = loadScaleform
  L7_2 = L9_1
  L7_2 = L7_2[L4_2]
  L6_2 = L6_2(L7_2)
  L5_2[L4_2] = L6_2
  L5_2 = false
  runtimeTxd = "osp_b_dict"
  L6_2 = CreateRuntimeTxd
  L7_2 = "osp_b_dict"
  L6_2 = L6_2(L7_2)
  L7_2 = L4_1
  L8_2 = CreateDui
  L9_2 = L8_1
  L10_2 = L2_1
  L11_2 = L3_1
  L8_2 = L8_2(L9_2, L10_2, L11_2)
  L7_2[L4_2] = L8_2
  L7_2 = GetDuiHandle
  L8_2 = L4_1
  L8_2 = L8_2[L4_2]
  L7_2 = L7_2(L8_2)
  L8_2 = CreateRuntimeTextureFromDuiHandle
  L9_2 = L6_2
  L10_2 = "osp_b_txd"
  L11_2 = L7_2
  L8_2 = L8_2(L9_2, L10_2, L11_2)
  L9_2 = Wait
  L10_2 = 10
  L9_2(L10_2)
  L9_2 = PushScaleformMovieFunction
  L10_2 = L5_1
  L10_2 = L10_2[L4_2]
  L11_2 = "SET_TEXTURE"
  L9_2(L10_2, L11_2)
  L9_2 = PushScaleformMovieMethodParameterString
  L10_2 = "osp_b_dict"
  L9_2(L10_2)
  L9_2 = PushScaleformMovieMethodParameterString
  L10_2 = "osp_b_txd"
  L9_2(L10_2)
  L9_2 = PushScaleformMovieFunctionParameterInt
  L10_2 = 0
  L9_2(L10_2)
  L9_2 = PushScaleformMovieFunctionParameterInt
  L10_2 = 0
  L9_2(L10_2)
  L9_2 = PushScaleformMovieFunctionParameterInt
  L10_2 = L2_1
  L9_2(L10_2)
  L9_2 = PushScaleformMovieFunctionParameterInt
  L10_2 = L3_1
  L9_2(L10_2)
  L9_2 = PopScaleformMovieFunctionVoid
  L9_2()
  L9_2 = GetFrameTime
  L9_2 = L9_2()
  L10_2 = 0.02
  if L9_2 > L10_2 then
    wt = 5
  else
    L10_2 = 0.011
    if L9_2 > L10_2 then
      wt = 3
    else
      wt = 1
    end
  end
  L10_2 = CreateThread
  function L11_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3
    while true do
      L1_3 = L4_2
      L0_3 = L4_1
      L0_3 = L0_3[L1_3]
      if not L0_3 then
        break
      end
      L1_3 = L4_2
      L0_3 = L4_1
      L0_3 = L0_3[L1_3]
      if L0_3 then
        L1_3 = L4_2
        L0_3 = L5_1
        L0_3 = L0_3[L1_3]
        if nil ~= L0_3 then
          L0_3 = HasScaleformMovieLoaded
          L2_3 = L4_2
          L1_3 = L5_1
          L1_3 = L1_3[L2_3]
          L0_3 = L0_3(L1_3)
          if L0_3 then
            L0_3 = DrawScaleformMovie_3dSolid
            L2_3 = L4_2
            L1_3 = L5_1
            L1_3 = L1_3[L2_3]
            L2_3 = A0_2.x
            L3_3 = A0_2.y
            L4_3 = A0_2.z
            L5_3 = A2_2.x
            L5_3 = L5_3 - 7
            L6_3 = A2_2.y
            L7_3 = A2_2.z
            L8_3 = 2.0
            L9_3 = 2.0
            L10_3 = 2.0
            L11_3 = L7_1
            L11_3 = L11_3 * 1
            L12_3 = L7_1
            L12_3 = L12_3 * 0.5625
            L13_3 = 2
            L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
          end
        end
      end
      L0_3 = Wait
      L1_3 = wt
      L0_3(L1_3)
    end
  end
  L10_2(L11_2)
  L10_2 = {}
  L11_2 = L9_1
  L11_2 = L11_2[L4_2]
  L12_2 = L12_1
  L10_2[1] = L11_2
  L10_2[2] = L12_2
  return L10_2
end
ShowScreen = L13_1
function L13_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  CURRENT_SCREEN = nil
  L0_2 = L4_1
  if L0_2 then
    L0_2 = pairs
    L1_2 = L4_1
    L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
    for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
      L6_2 = DestroyDui
      L7_2 = L5_2
      L6_2(L7_2)
    end
    L0_2 = pairs
    L1_2 = L5_1
    L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
    for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
      L6_2 = SetScaleformMovieAsNoLongerNeeded
      L7_2 = L5_2
      L6_2(L7_2)
    end
    L0_2 = {}
    L4_1 = L0_2
    L0_2 = {}
    L5_1 = L0_2
  end
end
HideScreen = L13_1
L13_1 = AddEventHandler
L14_1 = "onResourceStop"
function L15_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  if A0_2 == L1_2 then
    L1_2 = 1
    L2_2 = L1_1
    L3_2 = 1
    for L4_2 = L1_2, L2_2, L3_2 do
      L5_2 = TriggerServerEvent
      L6_2 = "osp_ambulance:DeleteLoop"
      L7_2 = L4_2
      L5_2(L6_2, L7_2)
      L5_2 = Wait
      L6_2 = 50
      L5_2(L6_2)
    end
    L1_2 = HideScreen
    L1_2()
  end
end
L13_1(L14_1, L15_1)
L13_1 = AddEventHandler
L14_1 = "onResourceStart"
function L15_1(A0_2)
  local L1_2, L2_2
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  if A0_2 == L1_2 then
    L1_2 = TriggerServerEvent
    L2_2 = "osp_ambulance:wipeECGTable"
    L1_2(L2_2)
    L1_2 = HideScreen
    L1_2()
  end
end
L13_1(L14_1, L15_1)
L13_1 = AddEventHandler
L14_1 = "onResourceRestart"
function L15_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = GetCurrentResourceName
  L1_2 = L1_2()
  if A0_2 == L1_2 then
    L1_2 = 1
    L2_2 = L1_1
    L3_2 = 1
    for L4_2 = L1_2, L2_2, L3_2 do
      L5_2 = TriggerServerEvent
      L6_2 = "osp_ambulance:DeleteLoop"
      L7_2 = L4_2
      L5_2(L6_2, L7_2)
      L5_2 = Wait
      L6_2 = 50
      L5_2(L6_2)
    end
    L1_2 = HideScreen
    L1_2()
  end
end
L13_1(L14_1, L15_1)
function L13_1(A0_2)
  local L1_2, L2_2
  L1_2 = CreateThread
  function L2_2()
    local L0_3, L1_3, L2_3, L3_3
    L0_3 = Wait
    L1_3 = Config
    L1_3 = L1_3.AutoDeleteTime
    L1_3 = L1_3 * 1000
    L0_3(L1_3)
    L0_3 = DoesEntityExist
    L1_3 = A0_2
    L0_3 = L0_3(L1_3)
    if L0_3 then
      L0_3 = TriggerEvent
      L1_3 = "osp_ambulance:delete"
      L2_3 = {}
      L3_3 = A0_2
      L2_3.prop = L3_3
      L0_3(L1_3, L2_3)
    end
  end
  L1_2(L2_2)
end
AutoDeleter = L13_1
L13_1 = RegisterNetEvent
L14_1 = "osp_ambulance:activate"
L13_1(L14_1)
L13_1 = AddEventHandler
L14_1 = "osp_ambulance:activate"
function L15_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = Config
  L1_2 = L1_2.Prop
  L2_2 = RequestModel
  L3_2 = L1_2
  L2_2(L3_2)
  while true do
    L2_2 = HasModelLoaded
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    if L2_2 then
      break
    end
    L2_2 = Wait
    L3_2 = 10
    L2_2(L3_2)
  end
  L2_2 = CreateObjectNoOffset
  L3_2 = L1_2
  L4_2 = GetEntityCoords
  L5_2 = PlayerPedId
  L5_2, L6_2, L7_2 = L5_2()
  L4_2 = L4_2(L5_2, L6_2, L7_2)
  L4_2 = L4_2 - 1
  L5_2 = 1
  L6_2 = 1
  L7_2 = 0
  L2_2 = L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
  L3_2 = SetNetworkIdExistsOnAllMachines
  L4_2 = NetworkGetNetworkIdFromEntity
  L5_2 = L2_2
  L4_2 = L4_2(L5_2)
  L5_2 = true
  L3_2(L4_2, L5_2)
  L3_2 = L2_2
  L4_2 = SetEntityHeading
  L5_2 = L3_2
  L6_2 = 0.0
  L4_2(L5_2, L6_2)
  L4_2 = SetEntityCollision
  L5_2 = L3_2
  L6_2 = true
  L7_2 = true
  L4_2(L5_2, L6_2, L7_2)
  L4_2 = FreezeEntityPosition
  L5_2 = L3_2
  L6_2 = true
  L4_2(L5_2, L6_2)
  L4_2 = SetModelAsNoLongerNeeded
  L5_2 = L1_2
  L4_2(L5_2)
  L4_2 = TriggerEvent
  L5_2 = "osp_ambulance:pickup"
  L6_2 = {}
  L6_2.prop = L3_2
  L4_2(L5_2, L6_2)
  L4_2 = TriggerServerEvent
  L5_2 = "osp_ambulance:removeItem"
  L6_2 = "ecg"
  L7_2 = 1
  L4_2(L5_2, L6_2, L7_2)
end
L13_1(L14_1, L15_1)
function L13_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = {}
  L2_2 = math
  L2_2 = L2_2.pi
  L2_2 = L2_2 / 180
  L3_2 = A0_2.x
  L2_2 = L2_2 * L3_2
  L1_2.x = L2_2
  L2_2 = math
  L2_2 = L2_2.pi
  L2_2 = L2_2 / 180
  L3_2 = A0_2.y
  L2_2 = L2_2 * L3_2
  L1_2.y = L2_2
  L2_2 = math
  L2_2 = L2_2.pi
  L2_2 = L2_2 / 180
  L3_2 = A0_2.z
  L2_2 = L2_2 * L3_2
  L1_2.z = L2_2
  L2_2 = {}
  L3_2 = math
  L3_2 = L3_2.sin
  L4_2 = L1_2.z
  L3_2 = L3_2(L4_2)
  L3_2 = -L3_2
  L4_2 = math
  L4_2 = L4_2.abs
  L5_2 = math
  L5_2 = L5_2.cos
  L6_2 = L1_2.x
  L5_2, L6_2 = L5_2(L6_2)
  L4_2 = L4_2(L5_2, L6_2)
  L3_2 = L3_2 * L4_2
  L2_2.x = L3_2
  L3_2 = math
  L3_2 = L3_2.cos
  L4_2 = L1_2.z
  L3_2 = L3_2(L4_2)
  L4_2 = math
  L4_2 = L4_2.abs
  L5_2 = math
  L5_2 = L5_2.cos
  L6_2 = L1_2.x
  L5_2, L6_2 = L5_2(L6_2)
  L4_2 = L4_2(L5_2, L6_2)
  L3_2 = L3_2 * L4_2
  L2_2.y = L3_2
  L3_2 = math
  L3_2 = L3_2.sin
  L4_2 = L1_2.x
  L3_2 = L3_2(L4_2)
  L2_2.z = L3_2
  return L2_2
end
function L14_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L1_2 = GetGameplayCamRot
  L1_2 = L1_2()
  L2_2 = GetGameplayCamCoord
  L2_2 = L2_2()
  L3_2 = L13_1
  L4_2 = L1_2
  L3_2 = L3_2(L4_2)
  L4_2 = {}
  L5_2 = L2_2.x
  L6_2 = L3_2.x
  L6_2 = L6_2 * A0_2
  L5_2 = L5_2 + L6_2
  L4_2.x = L5_2
  L5_2 = L2_2.y
  L6_2 = L3_2.y
  L6_2 = L6_2 * A0_2
  L5_2 = L5_2 + L6_2
  L4_2.y = L5_2
  L5_2 = L2_2.z
  L6_2 = L3_2.z
  L6_2 = L6_2 * A0_2
  L5_2 = L5_2 + L6_2
  L4_2.z = L5_2
  L5_2 = GetShapeTestResult
  L6_2 = StartShapeTestRay
  L7_2 = L2_2.x
  L8_2 = L2_2.y
  L9_2 = L2_2.z
  L10_2 = L4_2.x
  L11_2 = L4_2.y
  L12_2 = L4_2.z
  L13_2 = -1
  L14_2 = -1
  L15_2 = 1
  L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
  L5_2, L6_2, L7_2, L8_2, L9_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
  L10_2 = L6_2
  L11_2 = L7_2
  L12_2 = L9_2
  return L10_2, L11_2, L12_2
end
L15_1 = {}
function L16_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2)
  local L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2
  L6_2 = NetworkGetEntityFromNetworkId
  L7_2 = A0_2
  L6_2 = L6_2(L7_2)
  L7_2 = "prop_cs_stock_book"
  L8_2 = RequestModel
  L9_2 = L7_2
  L8_2(L9_2)
  while true do
    L8_2 = HasModelLoaded
    L9_2 = L7_2
    L8_2 = L8_2(L9_2)
    if L8_2 then
      break
    end
    L8_2 = Wait
    L9_2 = 100
    L8_2(L9_2)
  end
  L8_2 = SetEntityHeading
  L9_2 = L6_2
  L10_2 = A5_2
  L8_2(L9_2, L10_2)
  L8_2 = CreateObjectNoOffset
  L9_2 = L7_2
  L10_2 = 757.7009
  L11_2 = 2560.5835
  L12_2 = 76.1088
  L13_2 = 0
  L14_2 = 1
  L15_2 = 0
  L8_2 = L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
  L9_2 = AttachEntityToEntity
  L10_2 = L8_2
  L11_2 = L6_2
  L12_2 = nil
  L13_2 = 0.0
  L14_2 = 0.0
  L15_2 = 0.0
  L16_2 = ecgScreenRotation
  L17_2 = false
  L18_2 = false
  L19_2 = false
  L20_2 = false
  L21_2 = false
  L22_2 = true
  L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
  L9_2 = SetModelAsNoLongerNeeded
  L10_2 = L7_2
  L9_2(L10_2)
  L9_2 = GetOffsetFromEntityInWorldCoords
  L10_2 = L6_2
  L11_2 = ecgScreenOffset
  L9_2 = L9_2(L10_2, L11_2)
  L10_2 = GetEntityRotation
  L11_2 = L8_2
  L10_2 = L10_2(L11_2)
  L11_2 = GetEntityCoords
  L12_2 = L6_2
  L11_2 = L11_2(L12_2)
  L12_2 = GetEntityRotation
  L13_2 = L6_2
  L12_2 = L12_2(L13_2)
  L13_2 = DeleteEntity
  L14_2 = L8_2
  L13_2(L14_2)
  function L13_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3
    L1_3 = "prop_"
    L2_3 = A4_2
    L1_3 = L1_3 .. L2_3
    L2_3 = _G
    L3_3 = L6_2
    L2_3[L1_3] = L3_3
    L2_3 = DeleteEntity
    L3_3 = L8_2
    L2_3(L3_3)
    L2_3 = ShowScreen
    L3_3 = L9_2
    L4_3 = L6_2
    L5_3 = L10_2
    L6_3 = A4_2
    L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3)
    content = L2_3
    L2_3 = Wait
    L3_3 = 100
    L2_3(L3_3)
    L2_3 = CreateThread
    function L3_3()
      local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4
      L0_4 = Player
      L1_4 = A3_2
      L0_4 = L0_4(L1_4)
      L1_4 = nil
      while true do
        L2_4 = L0_4.state
        L2_4 = L2_4.BodyDamage
        if nil ~= L2_4 then
          L3_4 = L2_4.Pulse
          if L3_4 ~= L1_4 then
            L1_4 = L2_4.Pulse
            L3_4 = SendEKGStatus
            L4_4 = L2_4
            L5_4 = L9_2
            L6_4 = L6_2
            L3_4(L4_4, L5_4, L6_4)
          end
        end
        L3_4 = Wait
        L4_4 = 1000
        L3_4(L4_4)
      end
    end
    L2_3(L3_3)
    L2_3 = RegisterNUICallback
    L3_3 = "beat"
    function L4_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4
      L1_4 = TriggerSound
      L2_4 = "norm"
      L3_4 = L9_2
      L4_4 = 5.0
      L1_4(L2_4, L3_4, L4_4)
      L1_4 = Config
      L1_4 = L1_4.UseXsound
      if L1_4 then
        L1_4 = xSound
        L2_4 = L1_4
        L1_4 = L1_4.PlayUrlPos
        L3_4 = "nsrbeat"
        L4_4 = "norm.mp3"
        L5_4 = 0.1
        L6_4 = L9_2
        L7_4 = false
        L1_4(L2_4, L3_4, L4_4, L5_4, L6_4, L7_4)
        L1_4 = xSound
        L2_4 = L1_4
        L1_4 = L1_4.Distance
        L3_4 = "nsrbeat"
        L4_4 = 5
        L1_4(L2_4, L3_4, L4_4)
        L1_4 = xSound
        L2_4 = L1_4
        L1_4 = L1_4.destroyOnFinish
        L3_4 = "nsrbeat"
        L4_4 = true
        L1_4(L2_4, L3_4, L4_4)
      end
    end
    L2_3(L3_3, L4_3)
  end
  onEnter = L13_2
  function L13_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3
    L1_3 = Config
    L1_3 = L1_3.UseXsound
    if L1_3 then
      L1_3 = xSound
      L2_3 = L1_3
      L1_3 = L1_3.Destroy
      L3_3 = "nsrbeat"
      L1_3(L2_3, L3_3)
      L1_3 = xSound
      L2_3 = L1_3
      L1_3 = L1_3.Destroy
      L3_3 = "crash"
      L1_3(L2_3, L3_3)
    end
    L1_3 = pairs
    L2_3 = soundTable
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      if "norm" == L6_3 or "crashingflat" == L6_3 then
        L7_3 = StopSound
        L8_3 = L5_3
        L7_3(L8_3)
        L7_3 = ReleaseSoundId
        L8_3 = L5_3
        L7_3(L8_3)
        L7_3 = soundTable
        L7_3[L5_3] = nil
      end
    end
    L1_3 = pairs
    L2_3 = L4_1
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = string
      L7_3 = L7_3.match
      L8_3 = tostring
      L9_3 = L5_3
      L8_3 = L8_3(L9_3)
      L9_3 = NetworkGetNetworkIdFromEntity
      L10_3 = L6_2
      L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3 = L9_3(L10_3)
      L7_3 = L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3)
      if L7_3 then
        L7_3 = TriggerServerEvent
        L8_3 = "osp_ambulance:DeleteId"
        L9_3 = NetworkGetNetworkIdFromEntity
        L10_3 = L6_2
        L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3 = L9_3(L10_3)
        L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3)
        L7_3 = DestroyDui
        L8_3 = L6_3
        L7_3(L8_3)
        L7_3 = L4_1
        L7_3[L5_3] = nil
        L7_3 = pairs
        L8_3 = L5_1
        L7_3, L8_3, L9_3, L10_3 = L7_3(L8_3)
        for L11_3, L12_3 in L7_3, L8_3, L9_3, L10_3 do
          L13_3 = string
          L13_3 = L13_3.match
          L14_3 = tostring
          L15_3 = L11_3
          L14_3 = L14_3(L15_3)
          L15_3 = NetworkGetNetworkIdFromEntity
          L16_3 = L6_2
          L15_3, L16_3 = L15_3(L16_3)
          L13_3 = L13_3(L14_3, L15_3, L16_3)
          if L13_3 then
            L13_3 = SetScaleformMovieAsNoLongerNeeded
            L14_3 = L12_3
            L13_3(L14_3)
            L13_3 = L5_1
            L13_3[L11_3] = nil
          end
        end
      end
    end
  end
  onExit = L13_2
  L13_2 = lib
  L13_2 = L13_2.zones
  L13_2 = L13_2.box
  L14_2 = {}
  L15_2 = vec3
  L16_2 = L9_2.x
  L17_2 = L9_2.y
  L18_2 = L9_2.z
  L18_2 = L18_2 - 1
  L15_2 = L15_2(L16_2, L17_2, L18_2)
  L14_2.coords = L15_2
  L15_2 = NetworkGetNetworkIdFromEntity
  L16_2 = L6_2
  L15_2 = L15_2(L16_2)
  L14_2.name = L15_2
  L15_2 = vec3
  L16_2 = Config
  L16_2 = L16_2.RenderDistance
  L17_2 = Config
  L17_2 = L17_2.RenderDistance
  L18_2 = Config
  L18_2 = L18_2.RenderDistance
  L15_2 = L15_2(L16_2, L17_2, L18_2)
  L14_2.size = L15_2
  L14_2.rotation = 45
  L14_2.debug = false
  L15_2 = inside
  L14_2.inside = L15_2
  L15_2 = onEnter
  L14_2.onEnter = L15_2
  L15_2 = onExit
  L14_2.onExit = L15_2
  L13_2 = L13_2(L14_2)
  ekgPoly = L13_2
  L13_2 = table
  L13_2 = L13_2.insert
  L14_2 = L15_1
  L15_2 = ekgPoly
  L13_2(L14_2, L15_2)
end
ekgpoly = L16_1
L16_1 = RegisterNetEvent
L17_1 = "osp_ambulance:RemoveZoneCl"
L16_1(L17_1)
L16_1 = AddEventHandler
L17_1 = "osp_ambulance:RemoveZoneCl"
function L18_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L1_2 = Wait
  L2_2 = 50
  L1_2(L2_2)
  if 0 == A0_2 then
    return
  end
  L1_2 = pairs
  L2_2 = L4_1
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = string
    L7_2 = L7_2.match
    L8_2 = tostring
    L9_2 = L5_2
    L8_2 = L8_2(L9_2)
    L9_2 = A0_2
    L7_2 = L7_2(L8_2, L9_2)
    if L7_2 then
      L7_2 = pairs
      L8_2 = L15_1
      L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
      for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
        L13_2 = string
        L13_2 = L13_2.match
        L14_2 = tostring
        L15_2 = L5_2
        L14_2 = L14_2(L15_2)
        L15_2 = tostring
        L16_2 = L12_2.name
        L15_2, L16_2 = L15_2(L16_2)
        L13_2 = L13_2(L14_2, L15_2, L16_2)
        if L13_2 then
          L14_2 = L12_2
          L13_2 = L12_2.remove
          L13_2(L14_2)
        end
      end
      L7_2 = DestroyDui
      L8_2 = L6_2
      L7_2(L8_2)
      L7_2 = L4_1
      L7_2[L5_2] = nil
      L7_2 = pairs
      L8_2 = L5_1
      L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
      for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
        L13_2 = string
        L13_2 = L13_2.match
        L14_2 = tostring
        L15_2 = L11_2
        L14_2 = L14_2(L15_2)
        L15_2 = A0_2
        L13_2 = L13_2(L14_2, L15_2)
        if L13_2 then
          L13_2 = SetScaleformMovieAsNoLongerNeeded
          L14_2 = L12_2
          L13_2(L14_2)
          L13_2 = L5_1
          L13_2[L11_2] = nil
        end
      end
    end
  end
end
L16_1(L17_1, L18_1)
L16_1 = RegisterNetEvent
L17_1 = "osp_ambulance:delete"
L16_1(L17_1)
L16_1 = AddEventHandler
L17_1 = "osp_ambulance:delete"
function L18_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = Wait
  L2_2 = 50
  L1_2(L2_2)
  L1_2 = Config
  L1_2 = L1_2.UseXsound
  if L1_2 then
    L1_2 = xSound
    L2_2 = L1_2
    L1_2 = L1_2.Destroy
    L3_2 = "crash"
    L1_2(L2_2, L3_2)
    L1_2 = xSound
    L2_2 = L1_2
    L1_2 = L1_2.Destroy
    L3_2 = "nsrbeat"
    L1_2(L2_2, L3_2)
    L1_2 = xSound
    L2_2 = L1_2
    L1_2 = L1_2.Destroy
    L3_2 = "chock"
    L1_2(L2_2, L3_2)
  end
  L1_2 = pairs
  L2_2 = soundTable
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    if "norm" == L6_2 or "crashingflat" == L6_2 or "chock" == L6_2 then
      L7_2 = StopSound
      L8_2 = L5_2
      L7_2(L8_2)
      L7_2 = ReleaseSoundId
      L8_2 = L5_2
      L7_2(L8_2)
      L7_2 = soundTable
      L7_2[L5_2] = nil
    end
  end
  L1_2 = Config
  L1_2 = L1_2.UseTarget
  if L1_2 then
    L1_2 = Config
    L1_2 = L1_2.UseOxTarget
    if not L1_2 then
      L1_2 = RemoveTargetZone
      L2_2 = "ekg"
      L3_2 = A0_2.prop
      L2_2 = L2_2 .. L3_2
      L1_2(L2_2)
    else
      L1_2 = exports
      L1_2 = L1_2.ox_target
      L2_2 = L1_2
      L1_2 = L1_2.removeLocalEntity
      L3_2 = A0_2.prop
      L4_2 = A0_2.prop
      L1_2(L2_2, L3_2, L4_2)
    end
  end
  L1_2 = TriggerServerEvent
  L2_2 = "osp_ambulance:DeleteId"
  L3_2 = NetworkGetNetworkIdFromEntity
  L4_2 = A0_2.prop
  L3_2, L4_2, L5_2, L6_2, L7_2, L8_2 = L3_2(L4_2)
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
  L1_2 = Wait
  L2_2 = 100
  L1_2(L2_2)
  L1_2 = NetworkRegisterEntityAsNetworked
  L2_2 = A0_2.prop
  L1_2(L2_2)
  L1_2 = NetworkGetNetworkIdFromEntity
  L2_2 = A0_2.prop
  L1_2 = L1_2(L2_2)
  L2_2 = SetNetworkIdExistsOnAllMachines
  L3_2 = L1_2
  L4_2 = true
  L2_2(L3_2, L4_2)
  L2_2 = SetNetworkIdCanMigrate
  L3_2 = L1_2
  L4_2 = true
  L2_2(L3_2, L4_2)
  L2_2 = TriggerServerEvent
  L3_2 = "osp_ambulance:RemoveZoneSv"
  L4_2 = L1_2
  L2_2(L3_2, L4_2)
  L2_2 = DeleteEntity
  L3_2 = A0_2.prop
  L2_2(L3_2)
  L2_2 = Wait
  L3_2 = 100
  L2_2(L3_2)
  L2_2 = DoesEntityExist
  L3_2 = A0_2.prop
  L2_2 = L2_2(L3_2)
  if L2_2 then
    L2_2 = DeleteEntity
    L3_2 = A0_2.prop
    L2_2(L3_2)
    L2_2 = SetEntityCoords
    L3_2 = A0_2.prop
    L4_2 = 0.0
    L5_2 = 0.0
    L6_2 = 0.0
    L2_2(L3_2, L4_2, L5_2, L6_2)
  end
  L2_2 = TriggerServerEvent
  L3_2 = "osp_ambulance:addItem"
  L4_2 = "ecg"
  L5_2 = 1
  L2_2(L3_2, L4_2, L5_2)
end
L16_1(L17_1, L18_1)
L16_1 = RegisterNetEvent
L17_1 = "osp_ambulance:pickup"
L16_1(L17_1)
L16_1 = AddEventHandler
L17_1 = "osp_ambulance:pickup"
function L18_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L1_2 = Config
  L1_2 = L1_2.UseXsound
  if L1_2 then
    L1_2 = xSound
    L2_2 = L1_2
    L1_2 = L1_2.Destroy
    L3_2 = "crash"
    L1_2(L2_2, L3_2)
    L1_2 = xSound
    L2_2 = L1_2
    L1_2 = L1_2.Destroy
    L3_2 = "nsrbeat"
    L1_2(L2_2, L3_2)
    L1_2 = xSound
    L2_2 = L1_2
    L1_2 = L1_2.Destroy
    L3_2 = "chock"
    L1_2(L2_2, L3_2)
  end
  L1_2 = pairs
  L2_2 = soundTable
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    if "crashingflat" == L6_2 or "norm" == L6_2 or "chock" == L6_2 then
      L7_2 = StopSound
      L8_2 = L5_2
      L7_2(L8_2)
      L7_2 = ReleaseSoundId
      L8_2 = L5_2
      L7_2(L8_2)
      L7_2 = soundTable
      L7_2[L5_2] = nil
    end
  end
  L1_2 = Config
  L1_2 = L1_2.UseTarget
  if L1_2 then
    L1_2 = Config
    L1_2 = L1_2.UseOxTarget
    if not L1_2 then
      L1_2 = RemoveTargetZone
      L2_2 = "ekg"
      L3_2 = A0_2.prop
      L2_2 = L2_2 .. L3_2
      L1_2(L2_2)
    else
      L1_2 = exports
      L1_2 = L1_2.ox_target
      L2_2 = L1_2
      L1_2 = L1_2.removeLocalEntity
      L3_2 = A0_2.prop
      L4_2 = A0_2.prop
      L1_2(L2_2, L3_2, L4_2)
    end
  end
  L1_2 = TriggerServerEvent
  L2_2 = "osp_ambulance:RemoveZoneSv"
  L3_2 = NetworkGetNetworkIdFromEntity
  L4_2 = A0_2.prop
  L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L3_2(L4_2)
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
  L1_2 = Wait
  L2_2 = 50
  L1_2(L2_2)
  L1_2 = pairs
  L2_2 = L4_1
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = string
    L7_2 = L7_2.match
    L8_2 = tostring
    L9_2 = L5_2
    L8_2 = L8_2(L9_2)
    L9_2 = NetworkGetNetworkIdFromEntity
    L10_2 = A0_2.prop
    L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L9_2(L10_2)
    L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
    if L7_2 then
      L7_2 = TriggerServerEvent
      L8_2 = "osp_ambulance:DeleteId"
      L9_2 = NetworkGetNetworkIdFromEntity
      L10_2 = A0_2.prop
      L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L9_2(L10_2)
      L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
    end
  end
  L1_2 = RequestAnimDict
  L2_2 = "move_weapon@jerrycan@generic"
  L1_2(L2_2)
  while true do
    L1_2 = HasAnimDictLoaded
    L2_2 = "move_weapon@jerrycan@generic"
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = Wait
    L2_2 = 0
    L1_2(L2_2)
  end
  L1_2 = AttachEntityToEntity
  L2_2 = A0_2.prop
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = GetPedBoneIndex
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  L6_2 = 57005
  L4_2 = L4_2(L5_2, L6_2)
  L5_2 = ecgPedOffset
  L6_2 = ecgPedRotation
  L7_2 = true
  L8_2 = true
  L9_2 = false
  L10_2 = true
  L11_2 = 1
  L12_2 = true
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L1_2 = TaskPlayAnim
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = "move_weapon@jerrycan@generic"
  L4_2 = "idle"
  L5_2 = 8.0
  L6_2 = -8.0
  L7_2 = -1
  L8_2 = 51
  L9_2 = 0
  L10_2 = false
  L11_2 = false
  L12_2 = false
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L1_2 = Config
  L1_2 = L1_2.Prop
  L2_2 = RequestModel
  L3_2 = L1_2
  L2_2(L3_2)
  while true do
    L2_2 = HasModelLoaded
    L3_2 = L1_2
    L2_2 = L2_2(L3_2)
    if L2_2 then
      break
    end
    L2_2 = Wait
    L3_2 = 100
    L2_2(L3_2)
  end
  L2_2 = "prop_cs_stock_book"
  L3_2 = RequestModel
  L4_2 = L2_2
  L3_2(L4_2)
  while true do
    L3_2 = HasModelLoaded
    L4_2 = L2_2
    L3_2 = L3_2(L4_2)
    if L3_2 then
      break
    end
    L3_2 = Wait
    L4_2 = 100
    L3_2(L4_2)
  end
  while true do
    L3_2 = L14_1
    L4_2 = 1000.0
    L3_2, L4_2, L5_2 = L3_2(L4_2)
    L6_2 = PlayerPedId
    L6_2 = L6_2()
    if L5_2 ~= L6_2 then
      L6_2 = GetEntityCoords
      L7_2 = PlayerPedId
      L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L7_2()
      L6_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
      L7_2 = CreateObjectNoOffset
      L8_2 = L1_2
      L9_2 = L4_2.x
      L10_2 = L4_2.y
      L11_2 = L4_2.z
      L12_2 = 0
      L13_2 = 1
      L14_2 = 0
      L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
      L8_2 = SetEntityCollision
      L9_2 = L7_2
      L10_2 = false
      L11_2 = false
      L8_2(L9_2, L10_2, L11_2)
      L8_2 = SetEntityHeading
      L9_2 = L7_2
      L10_2 = GetEntityHeading
      L11_2 = PlayerPedId
      L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L11_2()
      L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
      L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
      L8_2 = PlaceObjectOnGroundProperly
      L9_2 = L7_2
      L8_2(L9_2)
      L8_2 = SetEntityCoords
      L9_2 = L7_2
      L10_2 = L4_2.x
      L11_2 = L4_2.y
      L12_2 = L4_2.z
      L8_2(L9_2, L10_2, L11_2, L12_2)
      L8_2 = SetEntityAlpha
      L9_2 = L7_2
      L10_2 = Config
      L10_2 = L10_2.Alpha
      L11_2 = 0
      L8_2(L9_2, L10_2, L11_2)
      L8_2 = Wait
      L9_2 = 10
      L8_2(L9_2)
      L8_2 = DeleteEntity
      L9_2 = L7_2
      L8_2(L9_2)
    else
      L6_2 = Wait
      L7_2 = 5
      L6_2(L7_2)
    end
    L6_2 = IsControlJustPressed
    L7_2 = 0
    L8_2 = 38
    L6_2 = L6_2(L7_2, L8_2)
    if L6_2 then
      L6_2 = DeleteEntity
      L7_2 = holo
      L6_2(L7_2)
      L6_2 = ClearPedTasks
      L7_2 = PlayerPedId
      L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L7_2()
      L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
      L6_2 = GetEntityCoords
      L7_2 = PlayerPedId
      L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L7_2()
      L6_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
      L7_2 = GetClosestObjectOfType
      L8_2 = L6_2
      L9_2 = 0.9
      L10_2 = GetHashKey
      L11_2 = Config
      L11_2 = L11_2.Prop
      L10_2 = L10_2(L11_2)
      L11_2 = false
      L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2)
      L8_2 = DetachEntity
      L9_2 = A0_2.prop
      L8_2(L9_2)
      L8_2 = DeleteEntity
      L9_2 = L7_2
      L8_2(L9_2)
      L8_2 = DeleteEntity
      L9_2 = A0_2.prop
      L8_2(L9_2)
      L8_2 = GetEntityHeading
      L9_2 = PlayerPedId
      L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2 = L9_2()
      L8_2 = L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
      L9_2 = Wait
      L10_2 = 100
      L9_2(L10_2)
      L9_2 = CreateObjectNoOffset
      L10_2 = L1_2
      L11_2 = L4_2.x
      L12_2 = L4_2.y
      L13_2 = L4_2.z
      L14_2 = 1
      L15_2 = 1
      L16_2 = 0
      L9_2 = L9_2(L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2)
      L10_2 = Wait
      L11_2 = 50
      L10_2(L11_2)
      ekg = L9_2
      L10_2 = SetEntityHeading
      L11_2 = ekg
      L12_2 = L8_2
      L10_2(L11_2, L12_2)
      L10_2 = FreezeEntityPosition
      L11_2 = ekg
      L12_2 = true
      L10_2(L11_2, L12_2)
      L10_2 = SetModelAsNoLongerNeeded
      L11_2 = L1_2
      L10_2(L11_2)
      L10_2 = SetModelAsNoLongerNeeded
      L11_2 = L2_2
      L10_2(L11_2)
      L10_2 = GetOffsetFromEntityInWorldCoords
      L11_2 = ekg
      L12_2 = ecgScreenOffset
      L10_2 = L10_2(L11_2, L12_2)
      L11_2 = AutoDeleter
      L12_2 = ekg
      L11_2(L12_2)
      L11_2 = Config
      L11_2 = L11_2.UseTarget
      if L11_2 then
        L11_2 = Config
        L11_2 = L11_2.UseOxTarget
        if not L11_2 then
          L11_2 = TargetEntity
          L12_2 = ekg
          L13_2 = {}
          L13_2.type = "client"
          L13_2.event = "osp_ambulance:pickup"
          L13_2.icon = "fa-solid fa-hand"
          L14_2 = lang
          L14_2 = L14_2.ecg
          L14_2 = L14_2.pickup
          L13_2.label = L14_2
          L14_2 = ekg
          L13_2.prop = L14_2
          L14_2 = {}
          L14_2.type = "client"
          L14_2.event = "osp_ambulance:attach"
          L14_2.icon = "fa-solid fa-repeat"
          L15_2 = lang
          L15_2 = L15_2.ecg
          L15_2 = L15_2.attach
          L14_2.label = L15_2
          L15_2 = ekg
          L14_2.prop = L15_2
          L15_2 = rotish
          L14_2.rot = L15_2
          L15_2 = poscord
          L14_2.pos = L15_2
          L14_2.coord = L10_2
          L14_2.head = L8_2
          L15_2 = ekgrot
          L14_2.proprot = L15_2
          L15_2 = {}
          L15_2.type = "client"
          L15_2.event = "osp_ambulance:delete"
          L15_2.icon = "fa-solid fa-ban"
          L16_2 = lang
          L16_2 = L16_2.ecg
          L16_2 = L16_2.delete
          L15_2.label = L16_2
          L16_2 = ekg
          L15_2.prop = L16_2
          L11_2(L12_2, L13_2, L14_2, L15_2)
          break
        end
        L11_2 = TargetEntity
        L12_2 = ekg
        L13_2 = {}
        L14_2 = ekg
        L13_2.name = L14_2
        L13_2.event = "osp_ambulance:pickup"
        L13_2.icon = "fa-solid fa-hand"
        L14_2 = lang
        L14_2 = L14_2.ecg
        L14_2 = L14_2.pickup
        L13_2.label = L14_2
        L14_2 = ekg
        L13_2.prop = L14_2
        L14_2 = {}
        L15_2 = ekg
        L14_2.name = L15_2
        L14_2.event = "osp_ambulance:attach"
        L14_2.icon = "fa-solid fa-repeat"
        L15_2 = lang
        L15_2 = L15_2.ecg
        L15_2 = L15_2.attach
        L14_2.label = L15_2
        L15_2 = ekg
        L14_2.prop = L15_2
        L15_2 = rotish
        L14_2.rot = L15_2
        L15_2 = poscord
        L14_2.pos = L15_2
        L14_2.coord = L10_2
        L14_2.head = L8_2
        L15_2 = ekgrot
        L14_2.proprot = L15_2
        L15_2 = {}
        L16_2 = ekg
        L15_2.name = L16_2
        L15_2.event = "osp_ambulance:delete"
        L15_2.icon = "fa-solid fa-ban"
        L16_2 = lang
        L16_2 = L16_2.ecg
        L16_2 = L16_2.delete
        L15_2.label = L16_2
        L16_2 = ekg
        L15_2.prop = L16_2
        L11_2(L12_2, L13_2, L14_2, L15_2)
        break
      end
      L11_2 = CreateThread
      function L12_2()
        local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
        while true do
          L0_3 = GetEntityCoords
          L1_3 = ekg
          L0_3 = L0_3(L1_3)
          L1_3 = GetEntityCoords
          L2_3 = PlayerPedId
          L2_3, L3_3, L4_3, L5_3 = L2_3()
          L1_3 = L1_3(L2_3, L3_3, L4_3, L5_3)
          L1_3 = L0_3 - L1_3
          L1_3 = #L1_3
          L2_3 = 3.5
          if L1_3 < L2_3 then
            L1_3 = drawtext3d
            L2_3 = L0_3.x
            L3_3 = L0_3.y
            L4_3 = L0_3.z
            L4_3 = L4_3 + 0.7
            L5_3 = lang
            L5_3 = L5_3.ecg
            L5_3 = L5_3.pickup_button
            L1_3(L2_3, L3_3, L4_3, L5_3)
            L1_3 = drawtext3d
            L2_3 = L0_3.x
            L3_3 = L0_3.y
            L4_3 = L0_3.z
            L4_3 = L4_3 + 0.6
            L5_3 = lang
            L5_3 = L5_3.ecg
            L5_3 = L5_3.attach_button
            L1_3(L2_3, L3_3, L4_3, L5_3)
            L1_3 = drawtext3d
            L2_3 = L0_3.x
            L3_3 = L0_3.y
            L4_3 = L0_3.z
            L4_3 = L4_3 + 0.5
            L5_3 = lang
            L5_3 = L5_3.ecg
            L5_3 = L5_3.delete_button
            L1_3(L2_3, L3_3, L4_3, L5_3)
            L1_3 = IsControlJustPressed
            L2_3 = 0
            L3_3 = Config
            L3_3 = L3_3.PickupButton
            L1_3 = L1_3(L2_3, L3_3)
            if L1_3 then
              L1_3 = Wait
              L2_3 = 100
              L1_3(L2_3)
              L1_3 = TriggerEvent
              L2_3 = "osp_ambulance:pickup"
              L3_3 = {}
              L4_3 = ekg
              L3_3.prop = L4_3
              L1_3(L2_3, L3_3)
              break
            else
              L1_3 = IsControlJustPressed
              L2_3 = 0
              L3_3 = Config
              L3_3 = L3_3.AttachButton
              L1_3 = L1_3(L2_3, L3_3)
              if L1_3 then
                L1_3 = Wait
                L2_3 = 100
                L1_3(L2_3)
                L1_3 = TriggerEvent
                L2_3 = "osp_ambulance:attach"
                L3_3 = {}
                L4_3 = ekg
                L3_3.prop = L4_3
                L4_3 = rotish
                L3_3.rot = L4_3
                L4_3 = poscord
                L3_3.pos = L4_3
                L4_3 = L10_2
                L3_3.coord = L4_3
                L4_3 = GetEntityHeading
                L5_3 = ekg
                L4_3 = L4_3(L5_3)
                L3_3.head = L4_3
                L4_3 = ekgrot
                L3_3.proprot = L4_3
                L1_3(L2_3, L3_3)
                break
              else
                L1_3 = IsControlJustPressed
                L2_3 = 0
                L3_3 = Config
                L3_3 = L3_3.DeleteButton
                L1_3 = L1_3(L2_3, L3_3)
                if L1_3 then
                  L1_3 = Wait
                  L2_3 = 100
                  L1_3(L2_3)
                  L1_3 = TriggerEvent
                  L2_3 = "osp_ambulance:delete"
                  L3_3 = {}
                  L4_3 = ekg
                  L3_3.prop = L4_3
                  L1_3(L2_3, L3_3)
                  break
                end
              end
            end
          end
          L1_3 = Wait
          L2_3 = 3
          L1_3(L2_3)
        end
      end
      L11_2(L12_2)
      break
    end
  end
end
L16_1(L17_1, L18_1)
L16_1 = RegisterNetEvent
L17_1 = "osp_ambulance:attach"
L16_1(L17_1)
L16_1 = AddEventHandler
L17_1 = "osp_ambulance:attach"
function L18_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L1_2 = DebugPrint
  L2_2 = "open attach menu"
  L1_2(L2_2)
  L1_2 = {}
  L2_2 = GetNearbyPlayers
  L2_2 = L2_2()
  L3_2 = pairs
  L4_2 = L2_2.PlayerName
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
    L9_2 = DebugPrint
    L10_2 = L2_2.ServerId
    L10_2 = L10_2[L7_2]
    L9_2(L10_2)
    L9_2 = Player
    L10_2 = L2_2.ServerId
    L10_2 = L10_2[L7_2]
    L9_2 = L9_2(L10_2)
    L9_2 = L9_2.state
    L10_2 = DebugPrint
    L11_2 = "playerstatebagattach: "
    L12_2 = L9_2
    L10_2(L11_2, L12_2)
    while not L9_2 do
      L10_2 = Wait
      L11_2 = 1
      L10_2(L11_2)
    end
    L10_2 = L9_2.BodyDamage
    if nil ~= L10_2 then
      L10_2 = L9_2.BodyDamage
      L10_2 = L10_2.playerName
      if nil == L10_2 then
        L10_2 = print
        L11_2 = "^1Playername returned nil!, unable to get max player count. Edit the maxplayer variable in the GetPlayers() function in client_open.lua"
        L10_2(L11_2)
        return
      end
      L10_2 = #L1_2
      L10_2 = L10_2 + 1
      L11_2 = {}
      L12_2 = L9_2.BodyDamage
      L12_2 = L12_2.playerName
      L11_2.title = L12_2
      L11_2.event = "osp_ambulance:attachToPlayer"
      L12_2 = lang
      L12_2 = L12_2.update1
      L12_2 = L12_2.server_id
      L13_2 = L2_2.ServerId
      L13_2 = L13_2[L7_2]
      L14_2 = "\n"
      L15_2 = L2_2.PlayerName
      L15_2 = L15_2[L7_2]
      L12_2 = L12_2 .. L13_2 .. L14_2 .. L15_2
      L11_2.description = L12_2
      L12_2 = {}
      L13_2 = A0_2.prop
      L12_2.prop = L13_2
      L13_2 = A0_2.head
      L12_2.head = L13_2
      L13_2 = A0_2.pos
      L12_2.pos = L13_2
      L13_2 = A0_2.rot
      L12_2.rot = L13_2
      L13_2 = A0_2.proprot
      L12_2.proprot = L13_2
      L13_2 = L2_2.ServerId
      L13_2 = L13_2[L7_2]
      L12_2.playerid = L13_2
      L11_2.args = L12_2
      L1_2[L10_2] = L11_2
    end
  end
  L3_2 = registerContext
  L4_2 = {}
  L4_2.id = "players"
  L5_2 = lang
  L5_2 = L5_2.update1
  L5_2 = L5_2.select_player
  L4_2.title = L5_2
  L4_2.options = L1_2
  L3_2(L4_2)
  L3_2 = showContext
  L4_2 = "players"
  L3_2(L4_2)
end
L16_1(L17_1, L18_1)
L16_1 = RegisterNetEvent
L17_1 = "osp_ambulance:attachToPlayer"
L16_1(L17_1)
L16_1 = AddEventHandler
L17_1 = "osp_ambulance:attachToPlayer"
function L18_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "osp_ambulance:GetGfxId"
  L3_2 = 1000
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    L2_2 = 1
    L3_2 = {}
    L4_2 = L2_2
    L5_2 = L1_1
    L6_2 = 1
    for L7_2 = L4_2, L5_2, L6_2 do
      L3_2[L7_2] = true
    end
    L4_2 = ipairs
    L5_2 = L1_2
    L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
    for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
      L3_2[L9_2] = nil
    end
    L4_2 = {}
    L5_2 = pairs
    L6_2 = L3_2
    L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
    for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
      L11_2 = table
      L11_2 = L11_2.insert
      L12_2 = L4_2
      L13_2 = L9_2
      L11_2(L12_2, L13_2)
    end
    L5_2 = tonumber
    L6_2 = #L4_2
    L5_2 = L5_2(L6_2)
    if 0 == L5_2 then
      L5_2 = SendTextMessage
      L6_2 = lang
      L6_2 = L6_2.interactions
      L6_2 = L6_2.medicalHeader
      L7_2 = lang
      L7_2 = L7_2.ecg
      L7_2 = L7_2.limit
      L8_2 = 4000
      L9_2 = "error"
      L5_2(L6_2, L7_2, L8_2, L9_2)
      return
    else
      L5_2 = tonumber
      L6_2 = #L4_2
      L5_2 = L5_2(L6_2)
      if L5_2 > 0 then
        L5_2 = ipairs
        L6_2 = L4_2
        L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
        for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
        end
      end
      L5_2 = tonumber
      L6_2 = #L4_2
      L5_2 = L5_2(L6_2)
      if L5_2 then
        L5_2 = L4_2[1]
        ekgid = L5_2
      end
    end
  else
    ekgid = 1
  end
  L2_2 = A0_2.prop
  L3_2 = Config
  L3_2 = L3_2.UseTarget
  if L3_2 then
    L3_2 = Config
    L3_2 = L3_2.UseOxTarget
    if not L3_2 then
      L3_2 = RemoveTargetZone
      L4_2 = L2_2
      L3_2(L4_2)
    else
      L3_2 = exports
      L3_2 = L3_2.ox_target
      L4_2 = L3_2
      L3_2 = L3_2.removeLocalEntity
      L5_2 = L2_2
      L6_2 = L2_2
      L3_2(L4_2, L5_2, L6_2)
    end
  end
  L3_2 = SetEntityHeading
  L4_2 = A0_2.prop
  L5_2 = A0_2.head
  L3_2(L4_2, L5_2)
  L3_2 = A0_2.coord
  L4_2 = A0_2.rot
  L5_2 = A0_2.pos
  L6_2 = A0_2.proprot
  L7_2 = {}
  L8_2 = GetEntityCoords
  L9_2 = A0_2.prop
  L8_2 = L8_2(L9_2)
  L9_2 = A0_2.playerid
  L10_2 = Config
  L10_2 = L10_2.UseTarget
  if L10_2 then
    L10_2 = Config
    L10_2 = L10_2.UseOxTarget
    if not L10_2 then
      L10_2 = TargetEntity
      L11_2 = L2_2
      L12_2 = {}
      L12_2.type = "client"
      L12_2.event = "osp_ambulance:pickup"
      L12_2.icon = "fa-solid fa-hand"
      L13_2 = lang
      L13_2 = L13_2.ecg
      L13_2 = L13_2.pickup
      L12_2.label = L13_2
      L12_2.prop = L2_2
      L13_2 = {}
      L13_2.type = "client"
      L13_2.event = "osp_ambulance:OpenOptionsMenu"
      L13_2.icon = "fa-regular fa-newspaper"
      L14_2 = lang
      L14_2 = L14_2.ecg
      L14_2 = L14_2.options
      L13_2.label = L14_2
      L13_2.prop = L2_2
      L13_2.playerid = L9_2
      L14_2 = {}
      L14_2.type = "client"
      L14_2.event = "osp_ambulance:delete"
      L14_2.icon = "fa-solid fa-ban"
      L15_2 = lang
      L15_2 = L15_2.ecg
      L15_2 = L15_2.delete
      L14_2.label = L15_2
      L14_2.prop = L2_2
      L10_2(L11_2, L12_2, L13_2, L14_2)
    else
      L10_2 = {}
      L11_2 = {}
      L11_2.name = L2_2
      L11_2.event = "osp_ambulance:pickup"
      L11_2.icon = "fa-solid fa-hand"
      L12_2 = lang
      L12_2 = L12_2.ecg
      L12_2 = L12_2.pickup
      L11_2.label = L12_2
      L11_2.prop = L2_2
      L12_2 = {}
      L12_2.name = L2_2
      L12_2.event = "osp_ambulance:OpenOptionsMenu"
      L12_2.icon = "fa-regular fa-newspaper"
      L13_2 = lang
      L13_2 = L13_2.ecg
      L13_2 = L13_2.options
      L12_2.label = L13_2
      L12_2.prop = L2_2
      L12_2.playerid = L9_2
      L13_2 = {}
      L13_2.name = L2_2
      L13_2.event = "osp_ambulance:delete"
      L13_2.icon = "fa-solid fa-ban"
      L14_2 = lang
      L14_2 = L14_2.ecg
      L14_2 = L14_2.delete
      L13_2.label = L14_2
      L13_2.prop = L2_2
      L10_2[1] = L11_2
      L10_2[2] = L12_2
      L10_2[3] = L13_2
      L11_2 = exports
      L11_2 = L11_2.ox_target
      L12_2 = L11_2
      L11_2 = L11_2.addLocalEntity
      L13_2 = L2_2
      L14_2 = L10_2
      L11_2(L12_2, L13_2, L14_2)
    end
  else
    L10_2 = CreateThread
    function L11_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
      while true do
        L0_3 = GetEntityCoords
        L1_3 = ekg
        L0_3 = L0_3(L1_3)
        L1_3 = GetEntityCoords
        L2_3 = PlayerPedId
        L2_3, L3_3, L4_3, L5_3 = L2_3()
        L1_3 = L1_3(L2_3, L3_3, L4_3, L5_3)
        L1_3 = L0_3 - L1_3
        L1_3 = #L1_3
        if L1_3 < 2 then
          L1_3 = drawtext3d
          L2_3 = L0_3.x
          L3_3 = L0_3.y
          L4_3 = L0_3.z
          L4_3 = L4_3 + 0.7
          L5_3 = lang
          L5_3 = L5_3.ecg
          L5_3 = L5_3.pickup_button
          L1_3(L2_3, L3_3, L4_3, L5_3)
          L1_3 = drawtext3d
          L2_3 = L0_3.x
          L3_3 = L0_3.y
          L4_3 = L0_3.z
          L4_3 = L4_3 + 0.6
          L5_3 = lang
          L5_3 = L5_3.ecg
          L5_3 = L5_3.options_button
          L1_3(L2_3, L3_3, L4_3, L5_3)
          L1_3 = drawtext3d
          L2_3 = L0_3.x
          L3_3 = L0_3.y
          L4_3 = L0_3.z
          L4_3 = L4_3 + 0.5
          L5_3 = lang
          L5_3 = L5_3.ecg
          L5_3 = L5_3.delete_button
          L1_3(L2_3, L3_3, L4_3, L5_3)
          L1_3 = IsControlJustPressed
          L2_3 = 0
          L3_3 = Config
          L3_3 = L3_3.PickupButton
          L1_3 = L1_3(L2_3, L3_3)
          if L1_3 then
            L1_3 = Wait
            L2_3 = 100
            L1_3(L2_3)
            L1_3 = TriggerEvent
            L2_3 = "osp_ambulance:pickup"
            L3_3 = {}
            L4_3 = ekg
            L3_3.prop = L4_3
            L1_3(L2_3, L3_3)
            break
          else
            L1_3 = IsControlJustPressed
            L2_3 = 0
            L3_3 = Config
            L3_3 = L3_3.OptionsButton
            L1_3 = L1_3(L2_3, L3_3)
            if L1_3 then
              L1_3 = Wait
              L2_3 = 100
              L1_3(L2_3)
              L1_3 = TriggerEvent
              L2_3 = "osp_ambulance:OpenOptionsMenu"
              L3_3 = {}
              L4_3 = ekg
              L3_3.prop = L4_3
              L4_3 = L9_2
              L3_3.playerid = L4_3
              L1_3(L2_3, L3_3)
            else
              L1_3 = IsControlJustPressed
              L2_3 = 0
              L3_3 = Config
              L3_3 = L3_3.DeleteButton
              L1_3 = L1_3(L2_3, L3_3)
              if L1_3 then
                L1_3 = Wait
                L2_3 = 100
                L1_3(L2_3)
                L1_3 = TriggerEvent
                L2_3 = "osp_ambulance:delete"
                L3_3 = {}
                L4_3 = ekg
                L3_3.prop = L4_3
                L1_3(L2_3, L3_3)
                break
              end
            end
          end
        end
        L1_3 = Wait
        L2_3 = 3
        L1_3(L2_3)
      end
    end
    L10_2(L11_2)
  end
  L10_2 = Wait
  L11_2 = 50
  L10_2(L11_2)
  L10_2 = DebugPrint
  L11_2 = "attach to"
  L12_2 = A0_2.playerid
  L10_2(L11_2, L12_2)
  L10_2 = TriggerServerEvent
  L11_2 = "osp_ambulance:SendAttachSv"
  L12_2 = A0_2.playerid
  L13_2 = NetworkGetNetworkIdFromEntity
  L14_2 = GetPlayerPed
  L15_2 = GetPlayerFromServerId
  L16_2 = A0_2.playerid
  L15_2, L16_2, L17_2 = L15_2(L16_2)
  L14_2, L15_2, L16_2, L17_2 = L14_2(L15_2, L16_2, L17_2)
  L13_2 = L13_2(L14_2, L15_2, L16_2, L17_2)
  L14_2 = L3_2
  L10_2(L11_2, L12_2, L13_2, L14_2)
  while true do
    L10_2 = ekgid
    if L10_2 then
      break
    end
    L10_2 = Wait
    L11_2 = 10
    L10_2(L11_2)
  end
  L10_2 = TriggerServerEvent
  L11_2 = "osp_ambulance:InsertId"
  L12_2 = ekgid
  L13_2 = "generic_texture_renderer_ekg"
  L14_2 = ekgid
  L13_2 = L13_2 .. L14_2
  L14_2 = NetworkGetNetworkIdFromEntity
  L15_2 = A0_2.prop
  L14_2, L15_2, L16_2, L17_2 = L14_2(L15_2)
  L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
  L10_2 = TriggerServerEvent
  L11_2 = "osp_ambulance:SendEKGZoneSv"
  L12_2 = NetworkGetNetworkIdFromEntity
  L13_2 = A0_2.prop
  L12_2 = L12_2(L13_2)
  L13_2 = L3_2
  L14_2 = L4_2
  L15_2 = A0_2.playerid
  L16_2 = ekgid
  L17_2 = A0_2.head
  L10_2(L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
  ekgid = nil
end
L16_1(L17_1, L18_1)
L16_1 = RegisterNetEvent
L17_1 = "osp_ambulance:SendEKGZoneCl"
L16_1(L17_1)
L16_1 = AddEventHandler
L17_1 = "osp_ambulance:SendEKGZoneCl"
function L18_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2)
  local L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L6_2 = ekgpoly
  L7_2 = A0_2
  L8_2 = A1_2
  L9_2 = A2_2
  L10_2 = A3_2
  L11_2 = A4_2
  L12_2 = A5_2
  L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
end
L16_1(L17_1, L18_1)
L16_1 = RegisterNetEvent
L17_1 = "osp_ambulance:CPR"
L16_1(L17_1)
L16_1 = AddEventHandler
L17_1 = "osp_ambulance:CPR"
function L18_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = TriggerServerEvent
  L2_2 = "osp_ambulance:CprSv"
  L3_2 = GetPlayerServerId
  L4_2 = NetworkGetPlayerIndexFromPed
  L5_2 = A0_2.pedid
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L4_2(L5_2)
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L4_2 = true
  L5_2 = GetPlayerServerId
  L6_2 = NetworkGetPlayerIndexFromPed
  L7_2 = PlayerPedId
  L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L7_2()
  L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L1_2 = RequestAnimDict
  L2_2 = "mini@cpr@char_a@cpr_str"
  L1_2(L2_2)
  while true do
    L1_2 = HasAnimDictLoaded
    L2_2 = "mini@cpr@char_a@cpr_str"
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = Wait
    L2_2 = 0
    L1_2(L2_2)
  end
  L1_2 = TaskPlayAnim
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = "mini@cpr@char_a@cpr_str"
  L4_2 = "cpr_pumpchest"
  L5_2 = 8.0
  L6_2 = -8.0
  L7_2 = -1
  L8_2 = 1
  L9_2 = 0
  L10_2 = false
  L11_2 = false
  L12_2 = false
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  while true do
    L1_2 = IsControlJustPressed
    L2_2 = 0
    L3_2 = 73
    L1_2 = L1_2(L2_2, L3_2)
    if L1_2 then
      L1_2 = TriggerServerEvent
      L2_2 = "osp_ambulance:CprSv"
      L3_2 = GetPlayerServerId
      L4_2 = NetworkGetPlayerIndexFromPed
      L5_2 = A0_2.pedid
      L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L4_2(L5_2)
      L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
      L4_2 = false
      L5_2 = GetPlayerServerId
      L6_2 = NetworkGetPlayerIndexFromPed
      L7_2 = PlayerPedId
      L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L7_2()
      L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
      L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
      L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
      break
    end
    L1_2 = Wait
    L2_2 = 3
    L1_2(L2_2)
  end
end
L16_1(L17_1, L18_1)
L16_1 = RegisterNetEvent
L17_1 = "osp_ambulance:KillCl"
L16_1(L17_1)
L16_1 = AddEventHandler
L17_1 = "osp_ambulance:KillCl"
function L18_1()
  local L0_2, L1_2, L2_2
  L0_2 = SetEntityHealth
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = 0
  L0_2(L1_2, L2_2)
end
L16_1(L17_1, L18_1)
L16_1 = false
L17_1 = true
L18_1 = 0
L19_1 = RegisterNetEvent
L20_1 = "osp_ambulance:OpenOptionsMenu"
L19_1(L20_1)
L19_1 = AddEventHandler
L20_1 = "osp_ambulance:OpenOptionsMenu"
function L21_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = L18_1
  if L1_2 > 0 then
    L1_2 = L18_1
    prog = L1_2
  end
  L1_2 = L16_1
  if L1_2 then
    L1_2 = registerContext
    L2_2 = {}
    L3_2 = "menu"
    L4_2 = A0_2.prop
    L3_2 = L3_2 .. L4_2
    L2_2.id = L3_2
    L3_2 = lang
    L3_2 = L3_2.update1
    L3_2 = L3_2.ekg_options
    L2_2.title = L3_2
    L3_2 = {}
    L4_2 = {}
    L5_2 = lang
    L5_2 = L5_2.ecg
    L5_2 = L5_2.defib
    L4_2.title = L5_2
    L5_2 = lang
    L5_2 = L5_2.ecg
    L5_2 = L5_2.charge
    L4_2.description = L5_2
    L4_2.icon = "fa-heart-circle-bolt"
    L4_2.event = "osp_ambulance:Charge"
    L5_2 = prog
    L4_2.progress = L5_2
    L5_2 = A0_2.prop
    L4_2.args = L5_2
    L4_2.disabled = true
    L4_2.arrow = true
    L5_2 = {}
    L6_2 = lang
    L6_2 = L6_2.ecg
    L6_2 = L6_2.defib
    L5_2.title = L6_2
    L6_2 = lang
    L6_2 = L6_2.ecg
    L6_2 = L6_2.chock
    L5_2.description = L6_2
    L5_2.icon = "fa-regular fa-wave-pulse"
    L6_2 = {}
    L7_2 = A0_2.prop
    L8_2 = A0_2.playerid
    L6_2[1] = L7_2
    L6_2[2] = L8_2
    L5_2.args = L6_2
    function L6_2()
      local L0_3, L1_3
      L0_3 = 0
      L18_1 = L0_3
    end
    L5_2.onSelect = L6_2
    L5_2.event = "osp_ambulance:Chock"
    L6_2 = L17_1
    L5_2.disabled = L6_2
    L5_2.arrow = true
    L3_2[1] = L4_2
    L3_2[2] = L5_2
    L2_2.options = L3_2
    L1_2(L2_2)
    L1_2 = showContext
    L2_2 = "menu"
    L3_2 = A0_2.prop
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
  else
    L1_2 = registerContext
    L2_2 = {}
    L3_2 = "menu"
    L4_2 = A0_2.prop
    L3_2 = L3_2 .. L4_2
    L2_2.id = L3_2
    L3_2 = lang
    L3_2 = L3_2.update1
    L3_2 = L3_2.ekg_options
    L2_2.title = L3_2
    L3_2 = {}
    L4_2 = {}
    L5_2 = lang
    L5_2 = L5_2.ecg
    L5_2 = L5_2.defib
    L4_2.title = L5_2
    L5_2 = lang
    L5_2 = L5_2.ecg
    L5_2 = L5_2.charge
    L4_2.description = L5_2
    L4_2.icon = "fa-heart-circle-bolt"
    L4_2.event = "osp_ambulance:Charge"
    L5_2 = prog
    L4_2.progress = L5_2
    L5_2 = A0_2.prop
    L4_2.args = L5_2
    L5_2 = {}
    L6_2 = {}
    L7_2 = lang
    L7_2 = L7_2.ecg
    L7_2 = L7_2.charge_time
    L6_2.label = L7_2
    L7_2 = lang
    L7_2 = L7_2.ecg
    L7_2 = L7_2.sec
    L6_2.value = L7_2
    L5_2[1] = L6_2
    L4_2.metadata = L5_2
    L4_2.arrow = true
    L5_2 = {}
    L6_2 = lang
    L6_2 = L6_2.ecg
    L6_2 = L6_2.defib
    L5_2.title = L6_2
    L6_2 = lang
    L6_2 = L6_2.ecg
    L6_2 = L6_2.chock
    L5_2.description = L6_2
    L5_2.icon = "fa-regular fa-wave-pulse"
    L6_2 = {}
    L7_2 = A0_2.prop
    L8_2 = A0_2.playerid
    L6_2[1] = L7_2
    L6_2[2] = L8_2
    L5_2.args = L6_2
    function L6_2()
      local L0_3, L1_3
      L0_3 = 0
      L18_1 = L0_3
    end
    L5_2.onSelect = L6_2
    L5_2.event = "osp_ambulance:Chock"
    L6_2 = L17_1
    L5_2.disabled = L6_2
    L5_2.arrow = true
    L3_2[1] = L4_2
    L3_2[2] = L5_2
    L2_2.options = L3_2
    L1_2(L2_2)
    L1_2 = showContext
    L2_2 = "menu"
    L3_2 = A0_2.prop
    L2_2 = L2_2 .. L3_2
    L1_2(L2_2)
  end
end
L19_1(L20_1, L21_1)
L19_1 = RegisterNetEvent
L20_1 = "osp_ambulance:Charge"
L19_1(L20_1)
L19_1 = AddEventHandler
L20_1 = "osp_ambulance:Charge"
function L21_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = lib
  L1_2 = L1_2.inputDialog
  L2_2 = lang
  L2_2 = L2_2.ecg
  L2_2 = L2_2.power_setting
  L3_2 = {}
  L4_2 = {}
  L4_2.type = "slider"
  L5_2 = lang
  L5_2 = L5_2.ecg
  L5_2 = L5_2.joule
  L4_2.label = L5_2
  L4_2.required = true
  L4_2.min = 0
  L4_2.max = 200
  L4_2.default = 50
  L4_2.step = 1
  L4_2.icon = "fa-heart-circle-bolt"
  L3_2[1] = L4_2
  L1_2 = L1_2(L2_2, L3_2)
  if not L1_2 then
    return
  end
  L2_2 = TriggerServerEvent
  L3_2 = "osp_ambulance:SoundSv"
  L4_2 = "charge"
  L5_2 = "charge.mp3"
  L6_2 = GetEntityCoords
  L7_2 = A0_2
  L6_2, L7_2 = L6_2(L7_2)
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
  L2_2 = true
  L16_1 = L2_2
  L2_2 = CreateThread
  function L3_2()
    local L0_3, L1_3
    while true do
      L0_3 = L18_1
      L0_3 = L0_3 + 10
      L18_1 = L0_3
      L0_3 = Wait
      L1_3 = 750
      L0_3(L1_3)
      L0_3 = L18_1
      if L0_3 > 100 then
        L0_3 = false
        L17_1 = L0_3
        break
      end
    end
  end
  L2_2(L3_2)
  L2_2 = lib
  L2_2 = L2_2.progressCircle
  L3_2 = {}
  L4_2 = lang
  L4_2 = L4_2.ecg
  L4_2 = L4_2.charging
  L3_2.label = L4_2
  L3_2.duration = 8000
  L3_2.position = "bottom"
  L3_2.useWhileDead = true
  L3_2.canCancel = false
  L2_2 = L2_2(L3_2)
  if L2_2 then
  end
  L2_2 = L1_2[1]
  currentjoule = L2_2
end
L19_1(L20_1, L21_1)
L19_1 = RegisterNetEvent
L20_1 = "osp_ambulance:Chock"
L19_1(L20_1)
L19_1 = AddEventHandler
L20_1 = "osp_ambulance:Chock"
function L21_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = Wait
  L2_2 = 50
  L1_2(L2_2)
  L1_2 = TriggerServerEvent
  L2_2 = "osp_ambulance:SoundSv"
  L3_2 = "chock"
  L4_2 = "chock.mp3"
  L5_2 = GetEntityCoords
  L6_2 = A0_2[1]
  L5_2, L6_2 = L5_2(L6_2)
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  L1_2 = false
  L16_1 = L1_2
  L1_2 = true
  L17_1 = L1_2
  L1_2 = 0
  L18_1 = L1_2
  prog = ""
  L1_2 = Wait
  L2_2 = 1500
  L1_2(L2_2)
  L1_2 = TriggerServerEvent
  L2_2 = "osp_ambulance:ChockSv"
  L3_2 = A0_2[2]
  L4_2 = currentjoule
  L1_2(L2_2, L3_2, L4_2)
end
L19_1(L20_1, L21_1)
L19_1 = RegisterNetEvent
L20_1 = "osp_ambulance:SoundCl"
L19_1(L20_1)
L19_1 = AddEventHandler
L20_1 = "osp_ambulance:SoundCl"
function L21_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L3_2 = Config
  L3_2 = L3_2.UseXsound
  if L3_2 then
    L3_2 = xSound
    L4_2 = L3_2
    L3_2 = L3_2.PlayUrlPos
    L5_2 = "chock"
    L6_2 = A1_2
    L7_2 = 1.0
    L8_2 = A2_2
    L9_2 = false
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
    L3_2 = xSound
    L4_2 = L3_2
    L3_2 = L3_2.Distance
    L5_2 = "chock"
    L6_2 = 20
    L3_2(L4_2, L5_2, L6_2)
    L3_2 = xSound
    L4_2 = L3_2
    L3_2 = L3_2.destroyOnFinish
    L5_2 = "chock"
    L6_2 = true
    L3_2(L4_2, L5_2, L6_2)
  else
    L3_2 = TriggerSound
    L4_2 = A0_2
    L5_2 = A2_2
    L6_2 = 20.0
    L3_2(L4_2, L5_2, L6_2)
  end
end
L19_1(L20_1, L21_1)
function L19_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2
  L3_2 = CreateThread
  function L4_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L0_3 = pairs
    L1_3 = L4_1
    L0_3, L1_3, L2_3, L3_3 = L0_3(L1_3)
    for L4_3, L5_3 in L0_3, L1_3, L2_3, L3_3 do
      L6_3 = string
      L6_3 = L6_3.match
      L7_3 = tostring
      L8_3 = L4_3
      L7_3 = L7_3(L8_3)
      L8_3 = NetworkGetNetworkIdFromEntity
      L9_3 = A2_2
      L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L8_3(L9_3)
      L6_3 = L6_3(L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
      if L6_3 then
        L6_3 = L5_3
        L7_3 = SendDuiMessage
        L8_3 = L6_3
        L9_3 = json
        L9_3 = L9_3.encode
        L10_3 = {}
        L11_3 = json
        L11_3 = L11_3.encode
        L12_3 = A0_2
        L11_3 = L11_3(L12_3)
        L10_3.BodyData = L11_3
        L11_3 = A0_2.cardiacState
        L10_3.rythm = L11_3
        L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L9_3(L10_3)
        L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
        L7_3 = Wait
        L8_3 = 300
        L7_3(L8_3)
        L7_3 = SendDuiMessage
        L8_3 = L6_3
        L9_3 = json
        L9_3 = L9_3.encode
        L10_3 = {}
        L11_3 = json
        L11_3 = L11_3.encode
        L12_3 = A0_2
        L11_3 = L11_3(L12_3)
        L10_3.BodyData = L11_3
        L11_3 = A0_2.cardiacState
        L10_3.rythm = L11_3
        L11_3 = A1_2.x
        L10_3.coordsx = L11_3
        L11_3 = A1_2.y
        L10_3.coordsy = L11_3
        L11_3 = A1_2.z
        L10_3.coordsz = L11_3
        L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L9_3(L10_3)
        L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
        L7_3 = A0_2.cardiacState
        if "vFib" ~= L7_3 then
          L7_3 = A0_2.cardiacState
          if "vTach" ~= L7_3 then
            L7_3 = A0_2.cardiacState
            if "torsades" ~= L7_3 then
              goto lbl_161
            end
          end
        end
        L7_3 = pairs
        L8_3 = soundTable
        L7_3, L8_3, L9_3, L10_3 = L7_3(L8_3)
        for L11_3, L12_3 in L7_3, L8_3, L9_3, L10_3 do
          if "crashingflat" == L12_3 or "flat" == L12_3 or "norm" == L12_3 then
            L13_3 = StopSound
            L14_3 = L11_3
            L13_3(L14_3)
            L13_3 = ReleaseSoundId
            L14_3 = L11_3
            L13_3(L14_3)
            L13_3 = soundTable
            L13_3[L11_3] = nil
          end
        end
        L7_3 = Config
        L7_3 = L7_3.UseXsound
        if L7_3 then
          L7_3 = xSound
          L8_3 = L7_3
          L7_3 = L7_3.PlayUrlPos
          L9_3 = "crash"
          L10_3 = "crashingflat.mp3"
          L11_3 = 0.1
          L12_3 = A1_2
          L13_3 = false
          L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
          L7_3 = xSound
          L8_3 = L7_3
          L7_3 = L7_3.Distance
          L9_3 = "crash"
          L10_3 = 15
          L7_3(L8_3, L9_3, L10_3)
          L7_3 = xSound
          L8_3 = L7_3
          L7_3 = L7_3.destroyOnFinish
          L9_3 = "crash"
          L10_3 = true
          L7_3(L8_3, L9_3, L10_3)
        end
        L7_3 = TriggerSound
        L8_3 = "crashingflat"
        L9_3 = A1_2
        L10_3 = 15.0
        L7_3(L8_3, L9_3, L10_3)
        L7_3 = Wait
        L8_3 = 28000
        L7_3(L8_3)
        L7_3 = A0_2.cardiacState
        if "vFib" ~= L7_3 then
          L7_3 = A0_2.cardiacState
          if "vTach" ~= L7_3 then
            L7_3 = A0_2.cardiacState
            if "torsades" ~= L7_3 then
              goto lbl_135
            end
          end
        end
        L7_3 = SendDuiMessage
        L8_3 = L6_3
        L9_3 = json
        L9_3 = L9_3.encode
        L10_3 = {}
        L10_3.rythm = "asystole"
        L9_3, L10_3, L11_3, L12_3, L13_3, L14_3 = L9_3(L10_3)
        L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
        goto lbl_244
        ::lbl_135::
        L7_3 = pairs
        L8_3 = soundTable
        L7_3, L8_3, L9_3, L10_3 = L7_3(L8_3)
        for L11_3, L12_3 in L7_3, L8_3, L9_3, L10_3 do
          if "crashingflat" == L12_3 then
            L13_3 = StopSound
            L14_3 = L11_3
            L13_3(L14_3)
            L13_3 = ReleaseSoundId
            L14_3 = L11_3
            L13_3(L14_3)
            L13_3 = soundTable
            L13_3[L11_3] = nil
          end
        end
        L7_3 = Config
        L7_3 = L7_3.UseXsound
        if L7_3 then
          L7_3 = xSound
          L8_3 = L7_3
          L7_3 = L7_3.Destroy
          L9_3 = "crash"
          L7_3(L8_3, L9_3)
          goto lbl_244
          ::lbl_161::
          L7_3 = A0_2.cardiacState
          if "asystole" == L7_3 then
            L7_3 = TriggerSound
            L8_3 = "flat"
            L9_3 = A1_2
            L10_3 = 15.0
            L7_3(L8_3, L9_3, L10_3)
            L7_3 = Config
            L7_3 = L7_3.UseXsound
            if L7_3 then
              L7_3 = xSound
              L8_3 = L7_3
              L7_3 = L7_3.PlayUrlPos
              L9_3 = "crash"
              L10_3 = "flat.mp3"
              L11_3 = 0.1
              L12_3 = A1_2
              L13_3 = false
              L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
              L7_3 = xSound
              L8_3 = L7_3
              L7_3 = L7_3.Distance
              L9_3 = "crash"
              L10_3 = 15
              L7_3(L8_3, L9_3, L10_3)
              L7_3 = xSound
              L8_3 = L7_3
              L7_3 = L7_3.destroyOnFinish
              L9_3 = "crash"
              L10_3 = true
              L7_3(L8_3, L9_3, L10_3)
            end
          else
            L7_3 = pairs
            L8_3 = soundTable
            L7_3, L8_3, L9_3, L10_3 = L7_3(L8_3)
            for L11_3, L12_3 in L7_3, L8_3, L9_3, L10_3 do
              if "crashingflat" == L12_3 or "flat" == L12_3 or "norm" == L12_3 then
                L13_3 = StopSound
                L14_3 = L11_3
                L13_3(L14_3)
                L13_3 = ReleaseSoundId
                L14_3 = L11_3
                L13_3(L14_3)
                L13_3 = soundTable
                L13_3[L11_3] = nil
              end
            end
            L7_3 = Config
            L7_3 = L7_3.UseXsound
            if L7_3 then
              L7_3 = xSound
              L8_3 = L7_3
              L7_3 = L7_3.Destroy
              L9_3 = "crash"
              L7_3(L8_3, L9_3)
              L7_3 = xSound
              L8_3 = L7_3
              L7_3 = L7_3.PlayUrlPos
              L9_3 = "nsrbeat"
              L10_3 = "norm.mp3"
              L11_3 = 0.1
              L12_3 = A1_2
              L13_3 = false
              L7_3(L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
              L7_3 = xSound
              L8_3 = L7_3
              L7_3 = L7_3.Distance
              L9_3 = "nsrbeat"
              L10_3 = 15
              L7_3(L8_3, L9_3, L10_3)
              L7_3 = xSound
              L8_3 = L7_3
              L7_3 = L7_3.destroyOnFinish
              L9_3 = "nsrbeat"
              L10_3 = true
              L7_3(L8_3, L9_3, L10_3)
            end
            L7_3 = TriggerSound
            L8_3 = "norm"
            L9_3 = A1_2
            L10_3 = 15.0
            L7_3(L8_3, L9_3, L10_3)
          end
        end
      end
      ::lbl_244::
    end
  end
  L3_2(L4_2)
end
SendEKGStatus = L19_1
