local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1, L6_1, L7_1, L8_1
L0_1 = BodyDamage
if not L0_1 then
  L0_1 = {}
end
BodyDamage = L0_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
if not L1_1 then
  L1_1 = {}
end
L0_1.BodyPartDamage = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.BloodLevel
if not L1_1 then
  L1_1 = {}
end
L0_1.BloodLevel = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.DamageType
if not L1_1 then
  L1_1 = {}
end
L0_1.DamageType = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.appliedTourniquets
if not L1_1 then
  L1_1 = {}
end
L0_1.appliedTourniquets = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.appliedSplints
if not L1_1 then
  L1_1 = {}
end
L0_1.appliedSplints = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.Triage
if not L1_1 then
  L1_1 = {}
end
L0_1.Triage = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.Bleeding
if not L1_1 then
  L1_1 = {}
end
L0_1.Bleeding = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.Wounds
if not L1_1 then
  L1_1 = {}
end
L0_1.Wounds = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.Fractures
if not L1_1 then
  L1_1 = {}
end
L0_1.Fractures = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.CosmeticFractures
if not L1_1 then
  L1_1 = {}
end
L0_1.CosmeticFractures = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.FractureTime
if not L1_1 then
  L1_1 = {}
end
L0_1.FractureTime = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.NeedSewed
if not L1_1 then
  L1_1 = {}
end
L0_1.NeedSewed = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.Pain
if not L1_1 then
  L1_1 = {}
end
L0_1.Pain = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.ServerId
if not L1_1 then
  L1_1 = {}
end
L0_1.ServerId = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.Conscious
if not L1_1 then
  L1_1 = {}
end
L0_1.Conscious = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.Pulse
if not L1_1 then
  L1_1 = {}
end
L0_1.Pulse = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.BloodPressure
if not L1_1 then
  L1_1 = {}
end
L0_1.BloodPressure = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.Temp
if not L1_1 then
  L1_1 = {}
end
L0_1.Temp = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.MessageLog
if not L1_1 then
  L1_1 = {}
end
L0_1.MessageLog = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.isDead
if not L1_1 then
  L1_1 = {}
end
L0_1.isDead = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.inLastStand
if not L1_1 then
  L1_1 = {}
end
L0_1.inLastStand = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.oxygenSaturation
if not L1_1 then
  L1_1 = {}
end
L0_1.oxygenSaturation = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.cardiacState
if not L1_1 then
  L1_1 = {}
end
L0_1.cardiacState = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.inBodybag
if not L1_1 then
  L1_1 = {}
end
L0_1.inBodybag = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.isCarried
if not L1_1 then
  L1_1 = {}
end
L0_1.isCarried = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.hrIncrease
if not L1_1 then
  L1_1 = {}
end
L0_1.hrIncrease = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.hrDecrease
if not L1_1 then
  L1_1 = {}
end
L0_1.hrDecrease = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.playerName
if not L1_1 then
  L1_1 = {}
end
L0_1.playerName = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.playerArmour
if not L1_1 then
  L1_1 = {}
end
L0_1.playerArmour = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.playerHealth
if not L1_1 then
  L1_1 = {}
end
L0_1.playerHealth = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.skellyWidth
if not L1_1 then
  L1_1 = {}
end
L0_1.skellyWidth = L1_1
L0_1 = BodyDamage
L1_1 = BodyDamage
L1_1 = L1_1.skellyPos
if not L1_1 then
  L1_1 = {}
end
L0_1.skellyPos = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.TotalBloodFill
if not L1_1 then
  L1_1 = {}
end
L0_1.TotalBloodFill = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.RefillBloodLeft
if not L1_1 then
  L1_1 = {}
end
L0_1.RefillBloodLeft = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.TotalInfusionFill
if not L1_1 then
  L1_1 = {}
end
L0_1.TotalInfusionFill = L1_1
L0_1 = BodyDamage
L0_1 = L0_1.BodyPartDamage
L1_1 = BodyDamage
L1_1 = L1_1.BodyPartDamage
L1_1 = L1_1.RefillInfusionLeft
if not L1_1 then
  L1_1 = {}
end
L0_1.RefillInfusionLeft = L1_1
L0_1 = false
canLeaveBed = true
bedOccupying = nil
bedObject = nil
bedOccupyingData = nil
closestBed = nil
doctorCount = 0
cam = nil
playerArmor = nil
inBedDict = "anim@gangops@morgue@table@"
inBedAnim = "body_search"
isInHospitalBed = false
playerHealth = nil
isStatusChecking = false
L1_1 = {}
statusChecks = L1_1
statusCheckTime = 0
healAnimDict = "mini@cpr@char_a@cpr_str"
healAnim = "cpr_pumpchest"
L1_1 = {}
injured = L1_1
time = 0
isCarrying = false
L1_1 = CreateThread
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = BodyDamage
  L0_2.hrIncrease = 0
  L0_2 = BodyDamage
  L0_2.hrDecrease = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2.BloodLevel = 6.0
  L0_2 = BodyDamage
  L1_2 = GetPlayerServerId
  L2_2 = NetworkGetPlayerIndexFromPed
  L3_2 = PlayerPedId
  L3_2, L4_2 = L3_2()
  L2_2, L3_2, L4_2 = L2_2(L3_2, L4_2)
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L0_2.ServerId = L1_2
  L0_2 = DebugPrint
  L1_2 = "server id:"
  L2_2 = BodyDamage
  L2_2 = L2_2.ServerId
  L0_2(L1_2, L2_2)
  L0_2 = BodyDamage
  L0_2.Pain = 0
  L0_2 = BodyDamage
  L0_2.Conscious = true
  L0_2 = BodyDamage
  L0_2.Pulse = 80
  L0_2 = BodyDamage
  L0_2.Temp = 37.0
  L0_2 = BodyDamage
  L0_2.isDead = false
  L0_2 = BodyDamage
  L0_2.inLastStand = false
  L0_2 = BodyDamage
  L0_2.oxygenSaturation = 99
  L0_2 = BodyDamage
  L0_2 = L0_2.BloodPressure
  L0_2[1] = 120
  L0_2 = BodyDamage
  L0_2 = L0_2.BloodPressure
  L0_2[2] = 80
  L0_2 = BodyDamage
  L0_2.cardiacState = "NSR"
  L0_2 = BodyDamage
  L0_2.inBodybag = false
  L0_2 = BodyDamage
  L0_2.isInBodybag = false
  L0_2 = BodyDamage
  L0_2.isCarried = false
  L0_2 = BodyDamage
  L1_2 = GetPlayerName
  L2_2 = PlayerId
  L2_2, L3_2, L4_2 = L2_2()
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L0_2.playerName = L1_2
  L0_2 = BodyDamage
  L1_2 = GetEntityHealth
  L2_2 = PlayerPedId
  L2_2, L3_2, L4_2 = L2_2()
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L0_2.playerHealth = L1_2
  L0_2 = BodyDamage
  L1_2 = GetPedArmour
  L2_2 = PlayerPedId
  L2_2, L3_2, L4_2 = L2_2()
  L1_2 = L1_2(L2_2, L3_2, L4_2)
  L0_2.playerArmour = L1_2
  L0_2 = BodyDamage
  L0_2.beingPerformedCPROn = false
  L0_2 = BodyDamage
  L0_2.skellyWidth = "20vh"
  L0_2 = BodyDamage
  L0_2.skellyPos = nil
  L0_2 = BodyDamage
  L0_2.stashSetup = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.appliedTourniquets
  L0_2.Rarm = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.appliedTourniquets
  L0_2.Larm = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.appliedTourniquets
  L0_2.Rleg = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.appliedTourniquets
  L0_2.Lleg = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Wounds
  L1_2 = {}
  L0_2.Rarm = L1_2
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Wounds
  L1_2 = {}
  L0_2.Larm = L1_2
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Wounds
  L1_2 = {}
  L0_2.Rleg = L1_2
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Wounds
  L1_2 = {}
  L0_2.Lleg = L1_2
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Wounds
  L1_2 = {}
  L0_2.Torso = L1_2
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Wounds
  L1_2 = {}
  L0_2.Head = L1_2
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Fractures
  L0_2.Rarm = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Fractures
  L0_2.Larm = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Fractures
  L0_2.Rleg = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Fractures
  L0_2.Lleg = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Fractures
  L0_2.Torso = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Fractures
  L0_2.Head = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L1_2 = BodyDamage
  L1_2 = L1_2.BodyPartDamage
  L1_2 = L1_2.CosmeticFractures
  if not L1_2 then
    L1_2 = {}
  end
  L0_2.CosmeticFractures = L1_2
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.CosmeticFractures
  L0_2.Rarm = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.CosmeticFractures
  L0_2.Larm = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.CosmeticFractures
  L0_2.Rleg = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.CosmeticFractures
  L0_2.Lleg = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.CosmeticFractures
  L0_2.Torso = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.CosmeticFractures
  L0_2.Head = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.FractureTime
  L0_2.Rarm = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.FractureTime
  L0_2.Larm = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.FractureTime
  L0_2.Rleg = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.FractureTime
  L0_2.Lleg = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.FractureTime
  L0_2.Torso = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.FractureTime
  L0_2.Head = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.NeedSewed
  L0_2.Rarm = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.NeedSewed
  L0_2.Larm = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.NeedSewed
  L0_2.Rleg = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.NeedSewed
  L0_2.Lleg = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.NeedSewed
  L0_2.Torso = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.NeedSewed
  L0_2.Head = false
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Bleeding
  L0_2.Rarm = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Bleeding
  L0_2.Larm = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Bleeding
  L0_2.Rleg = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Bleeding
  L0_2.Lleg = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Bleeding
  L0_2.Torso = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.Bleeding
  L0_2.Head = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.DamageType
  L0_2.Rarm = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.DamageType
  L0_2.Larm = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.DamageType
  L0_2.Rleg = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.DamageType
  L0_2.Lleg = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.DamageType
  L0_2.Torso = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2 = L0_2.DamageType
  L0_2.Head = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2.TotalBloodFill = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2.RefillBloodLeft = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2.TotalInfusionFill = 0
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2.RefillInfusionLeft = 0
  L0_2 = BodyDamage
  L1_2 = {}
  L0_2.MessageLog = L1_2
  L0_2 = BodyDamage
  L0_2 = L0_2.BodyPartDamage
  L0_2.Triage = "None"
  L0_2 = LocalPlayer
  L0_2 = L0_2.state
  L1_2 = L0_2
  L0_2 = L0_2.set
  L2_2 = "BodyDamage"
  L3_2 = BodyDamage
  L4_2 = true
  L0_2(L1_2, L2_2, L3_2, L4_2)
  L0_2 = DebugPrint
  L1_2 = time
  L0_2(L1_2)
  L0_2 = Wait
  L1_2 = 1500
  L0_2(L1_2)
  L0_2 = lib
  L0_2 = L0_2.callback
  L0_2 = L0_2.await
  L1_2 = "osp_ambulance:GetTime"
  L2_2 = 1000
  L0_2 = L0_2(L1_2, L2_2)
  if L0_2 then
    time = L0_2
  end
  L1_2 = BodyDamage
  L2_2 = GetCharacterName
  L2_2 = L2_2()
  L1_2.playerName = L2_2
end
L1_1(L2_1)
L1_1 = CreateThread
function L2_1()
  local L0_2, L1_2, L2_2
  while true do
    L0_2 = PlayerLoaded
    if L0_2 then
      L0_2 = TriggerServerEvent
      L1_2 = "osp_ambulance:RetreivePlayerDamageData"
      L2_2 = BodyDamage
      L0_2(L1_2, L2_2)
      L0_2 = TriggerServerEvent
      L1_2 = "hospital:server:SetArmourStatus"
      L2_2 = BodyDamage
      L2_2 = L2_2.playerArmour
      L0_2(L1_2, L2_2)
    end
    L0_2 = Wait
    L1_2 = Config
    L1_2 = L1_2.SavePlayerDataTimer
    L0_2(L1_2)
  end
end
L1_1(L2_1)
L1_1 = CreateThread
function L2_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  function L0_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = ipairs
    L2_3 = Config
    L2_3 = L2_3.AmbulanceJobs
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      if L6_3 == A0_3 then
        L7_3 = true
        return L7_3
      end
    end
    L1_3 = false
    return L1_3
  end
  L1_2 = pairs
  L2_2 = Config
  L2_2 = L2_2.Hospitals
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = pairs
    L8_2 = L6_2.jobs
    L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
    for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
      L13_2 = L0_2
      L14_2 = L12_2
      L13_2 = L13_2(L14_2)
      if not L13_2 then
        L13_2 = table
        L13_2 = L13_2.insert
        L14_2 = Config
        L14_2 = L14_2.AmbulanceJobs
        L15_2 = L12_2
        L13_2(L14_2, L15_2)
      end
    end
  end
end
L1_1(L2_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:CreateProp"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "osp_ambulance:CreateProp"
function L3_1(A0_2, A1_2, A2_2, A3_2, A4_2)
  local L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L5_2 = RequestModel
  L6_2 = GetHashKey
  L7_2 = A4_2
  L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L6_2(L7_2)
  L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  while true do
    L5_2 = HasModelLoaded
    L6_2 = GetHashKey
    L7_2 = A4_2
    L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L6_2(L7_2)
    L5_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
    if L5_2 then
      break
    end
    L5_2 = Wait
    L6_2 = 1
    L5_2(L6_2)
  end
  L5_2 = CreateObject
  L6_2 = GetHashKey
  L7_2 = A4_2
  L6_2 = L6_2(L7_2)
  L7_2 = A0_2
  L8_2 = A1_2
  L9_2 = A2_2
  L10_2 = true
  L11_2 = true
  L12_2 = true
  L5_2 = L5_2(L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L6_2 = SetEntityHeading
  L7_2 = L5_2
  L8_2 = A3_2
  L6_2(L7_2, L8_2)
  if "p_bloodsplat_s" == A4_2 then
    L6_2 = PlaceObjectOnGroundProperly
    L7_2 = L5_2
    L6_2(L7_2)
    L6_2 = SetEntityRotation
    L7_2 = L5_2
    L8_2 = -90.0
    L9_2 = 0.0
    L10_2 = 0.0
    L11_2 = 2
    L12_2 = false
    L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
    L6_2 = SetEntityCollision
    L7_2 = L5_2
    L8_2 = false
    L9_2 = true
    L6_2(L7_2, L8_2, L9_2)
    L6_2 = GetEntityCoords
    L7_2 = L5_2
    L6_2 = L6_2(L7_2)
    L7_2 = SetEntityCoords
    L8_2 = L5_2
    L9_2 = L6_2.x
    L10_2 = L6_2.y
    L11_2 = L6_2.z
    L11_2 = L11_2 - 0.3
    L7_2(L8_2, L9_2, L10_2, L11_2)
  end
  L6_2 = Wait
  L7_2 = Config
  L7_2 = L7_2.PropDespawnTimer
  L6_2(L7_2)
  L6_2 = DeleteEntity
  L7_2 = L5_2
  L6_2(L7_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:SendVitalMessageLogCl"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "osp_ambulance:SendVitalMessageLogCl"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  if "conscious" == A0_2 then
    L1_2 = BodyDamage
    L1_2 = L1_2.Conscious
    if L1_2 then
      L1_2 = table
      L1_2 = L1_2.insert
      L2_2 = BodyDamage
      L2_2 = L2_2.MessageLog
      L3_2 = time
      L4_2 = " | "
      L5_2 = lang
      L5_2 = L5_2.vitals
      L5_2 = L5_2.conscious
      L3_2 = L3_2 .. L4_2 .. L5_2
      L1_2(L2_2, L3_2)
    else
      L1_2 = table
      L1_2 = L1_2.insert
      L2_2 = BodyDamage
      L2_2 = L2_2.MessageLog
      L3_2 = time
      L4_2 = " | "
      L5_2 = lang
      L5_2 = L5_2.vitals
      L5_2 = L5_2.unconscious
      L3_2 = L3_2 .. L4_2 .. L5_2
      L1_2(L2_2, L3_2)
    end
  elseif "pulse" == A0_2 then
    L1_2 = BodyDamage
    L1_2 = L1_2.Pulse
    if L1_2 > 0 then
      L1_2 = BodyDamage
      L1_2 = L1_2.Pulse
      if L1_2 <= 50 then
        L1_2 = table
        L1_2 = L1_2.insert
        L2_2 = BodyDamage
        L2_2 = L2_2.MessageLog
        L3_2 = time
        L4_2 = " | "
        L5_2 = lang
        L5_2 = L5_2.vitals
        L5_2 = L5_2.weak_pulse
        L3_2 = L3_2 .. L4_2 .. L5_2
        L1_2(L2_2, L3_2)
      else
        L1_2 = BodyDamage
        L1_2 = L1_2.Pulse
        if L1_2 >= 50 then
          L1_2 = BodyDamage
          L1_2 = L1_2.Pulse
          if L1_2 <= 90 then
            L1_2 = table
            L1_2 = L1_2.insert
            L2_2 = BodyDamage
            L2_2 = L2_2.MessageLog
            L3_2 = time
            L4_2 = " | "
            L5_2 = lang
            L5_2 = L5_2.vitals
            L5_2 = L5_2.normal_pulse
            L3_2 = L3_2 .. L4_2 .. L5_2
            L1_2(L2_2, L3_2)
        end
        else
          L1_2 = BodyDamage
          L1_2 = L1_2.Pulse
          if L1_2 >= 90 then
            L1_2 = table
            L1_2 = L1_2.insert
            L2_2 = BodyDamage
            L2_2 = L2_2.MessageLog
            L3_2 = time
            L4_2 = " | "
            L5_2 = lang
            L5_2 = L5_2.vitals
            L5_2 = L5_2.elevated_pulse
            L3_2 = L3_2 .. L4_2 .. L5_2
            L1_2(L2_2, L3_2)
          end
        end
      end
    else
      L1_2 = table
      L1_2 = L1_2.insert
      L2_2 = BodyDamage
      L2_2 = L2_2.MessageLog
      L3_2 = time
      L4_2 = " | "
      L5_2 = lang
      L5_2 = L5_2.vitals
      L5_2 = L5_2.no_pulse
      L3_2 = L3_2 .. L4_2 .. L5_2
      L1_2(L2_2, L3_2)
    end
  elseif "temp" == A0_2 then
    L1_2 = BodyDamage
    L1_2 = L1_2.Temp
    if L1_2 >= 35 then
      L1_2 = BodyDamage
      L1_2 = L1_2.Temp
      if L1_2 <= 37 then
        L1_2 = table
        L1_2 = L1_2.insert
        L2_2 = BodyDamage
        L2_2 = L2_2.MessageLog
        L3_2 = time
        L4_2 = " | "
        L5_2 = lang
        L5_2 = L5_2.vitals
        L5_2 = L5_2.normal_body_temp
        L3_2 = L3_2 .. L4_2 .. L5_2
        L1_2(L2_2, L3_2)
    end
    else
      L1_2 = BodyDamage
      L1_2 = L1_2.Temp
      if L1_2 < 35 then
        L1_2 = table
        L1_2 = L1_2.insert
        L2_2 = BodyDamage
        L2_2 = L2_2.MessageLog
        L3_2 = time
        L4_2 = " | "
        L5_2 = lang
        L5_2 = L5_2.vitals
        L5_2 = L5_2.low_body_temp
        L3_2 = L3_2 .. L4_2 .. L5_2
        L1_2(L2_2, L3_2)
      else
        L1_2 = BodyDamage
        L1_2 = L1_2.Temp
        if L1_2 > 37 then
          L1_2 = table
          L1_2 = L1_2.insert
          L2_2 = BodyDamage
          L2_2 = L2_2.MessageLog
          L3_2 = time
          L4_2 = " | "
          L5_2 = lang
          L5_2 = L5_2.vitals
          L5_2 = L5_2.elevated_body_temp
          L3_2 = L3_2 .. L4_2 .. L5_2
          L1_2(L2_2, L3_2)
        end
      end
    end
  end
  L1_2 = Wait
  L2_2 = 100
  L1_2(L2_2)
  L1_2 = LocalPlayer
  L1_2 = L1_2.state
  L2_2 = L1_2
  L1_2 = L1_2.set
  L3_2 = "BodyDamage"
  L4_2 = BodyDamage
  L5_2 = true
  L1_2(L2_2, L3_2, L4_2, L5_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "focusOff"
function L3_1()
  local L0_2, L1_2, L2_2
  L0_2 = SetNuiFocus
  L1_2 = false
  L2_2 = false
  L0_2(L1_2, L2_2)
  openMedicalMenu = false
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "RetrieveNearbyPlayers"
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2
  L0_2 = lib
  L0_2 = L0_2.getNearbyPlayers
  L1_2 = GetEntityCoords
  L2_2 = PlayerPedId
  L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2 = L2_2()
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2)
  L2_2 = Config
  L2_2 = L2_2.MedicalMenuMaxDistance
  L3_2 = true
  L0_2 = L0_2(L1_2, L2_2, L3_2)
  while not L0_2 do
    L1_2 = Wait
    L2_2 = 1
    L1_2(L2_2)
  end
  L1_2 = {}
  L2_2 = pairs
  L3_2 = L0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = IsEntityVisible
    L9_2 = L7_2.ped
    L8_2 = L8_2(L9_2)
    if L8_2 then
      L8_2 = GetPlayerName
      L9_2 = L7_2.id
      L8_2 = L8_2(L9_2)
      L9_2 = GetPlayerServerId
      L10_2 = L7_2.id
      L9_2 = L9_2(L10_2)
      L10_2 = {}
      L10_2.name = L8_2
      L10_2.id = L9_2
      L11_2 = table
      L11_2 = L11_2.insert
      L12_2 = L1_2
      L13_2 = L10_2
      L11_2(L12_2, L13_2)
    end
  end
  L2_2 = lib
  L2_2 = L2_2.callback
  L2_2 = L2_2.await
  L3_2 = "osp_ambulance:getPlayerNames"
  L4_2 = 1000
  L5_2 = L1_2
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  players = L2_2
  L2_2 = Wait
  L3_2 = 200
  L2_2(L3_2)
  L2_2 = SendNUIMessage
  L3_2 = {}
  L4_2 = json
  L4_2 = L4_2.encode
  L5_2 = players
  L4_2 = L4_2(L5_2)
  L3_2.players = L4_2
  L2_2(L3_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "LoadPlayer"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = A0_2.PlayerId
  cachedPlayer = L1_2
  L1_2 = Player
  L2_2 = A0_2.PlayerId
  L1_2 = L1_2(L2_2)
  L2_2 = L1_2.state
  L2_2 = L2_2.BodyDamage
  while not L2_2 do
    L3_2 = Wait
    L4_2 = 1
    L3_2(L4_2)
  end
  L3_2 = SendNUIMessage
  L4_2 = {}
  L5_2 = json
  L5_2 = L5_2.encode
  L6_2 = L2_2
  L5_2 = L5_2(L6_2)
  L4_2.damageStatus = L5_2
  L4_2.display = true
  L3_2(L4_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "SaveData"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerEvent
  L2_2 = "osp_ambulance:SaveDataSv"
  L3_2 = A0_2.PlayerId
  L4_2 = A0_2.data
  L1_2(L2_2, L3_2, L4_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "UsedMedication"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "osp_ambulance:GetTime"
  L3_2 = 1000
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    time = L1_2
  end
  L2_2 = A0_2.item
  L3_2 = pairs
  L4_2 = Config
  L4_2 = L4_2.Medication
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
    L9_2 = L8_2.itemName
    if L2_2 == L9_2 then
      L9_2 = L8_2.lockAccess
      if L9_2 then
        L9_2 = IsAuthorized
        L9_2 = L9_2()
        if not L9_2 then
          L9_2 = SendTextMessage
          L10_2 = lang
          L10_2 = L10_2.interactions
          L10_2 = L10_2.medicalHeader
          L11_2 = lang
          L11_2 = L11_2.error
          L11_2 = L11_2.not_authorized
          L12_2 = 5000
          L13_2 = "error"
          L9_2(L10_2, L11_2, L12_2, L13_2)
          return
        end
      end
    end
  end
  L3_2 = getPlayerDistance
  L4_2 = A0_2.PlayerId
  L3_2 = L3_2(L4_2)
  L4_2 = Config
  L4_2 = L4_2.MedicalMenuMaxDistance
  if L3_2 >= L4_2 then
    L4_2 = SendTextMessage
    L5_2 = lang
    L5_2 = L5_2.interactions
    L5_2 = L5_2.medicalHeader
    L6_2 = lang
    L6_2 = L6_2.error
    L6_2 = L6_2.player_too_far_away
    L7_2 = 5000
    L8_2 = "error"
    L4_2(L5_2, L6_2, L7_2, L8_2)
    return
  end
  L4_2 = Player
  L5_2 = A0_2.PlayerId
  L4_2 = L4_2(L5_2)
  L5_2 = L4_2.state
  L5_2 = L5_2.BodyDamage
  L6_2 = A0_2.BodyPart
  L7_2 = DebugPrint
  L8_2 = "Got PlayerId: "
  L9_2 = A0_2.PlayerId
  L7_2(L8_2, L9_2)
  L7_2 = A0_2.PlayerId
  if not L7_2 then
    L7_2 = print
    L8_2 = "UNABLE TO GET PLAYERID, REPORT THIS ISSUE!"
    L7_2(L8_2)
    return
  end
  L7_2 = SetNuiFocus
  L8_2 = false
  L9_2 = false
  L7_2(L8_2, L9_2)
  L7_2 = SendNUIMessage
  L8_2 = {}
  L8_2.display = false
  L7_2(L8_2)
  L7_2 = DebugPrint
  L8_2 = "Closed NUI"
  L7_2(L8_2)
  L7_2 = pairs
  L8_2 = Config
  L8_2 = L8_2.Medication
  L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
  for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
    L13_2 = L12_2.itemName
    if L2_2 == L13_2 then
      L13_2 = L12_2.type
      if "bandage" == L13_2 then
        L13_2 = DebugPrint
        L14_2 = "used bandage"
        L13_2(L14_2)
        L13_2 = ProgressBar
        L14_2 = L12_2.lang
        L15_2 = L12_2.time
        L16_2 = L12_2.anim
        L16_2 = L16_2.dict
        L17_2 = L12_2.anim
        L17_2 = L17_2.name
        L13_2(L14_2, L15_2, L16_2, L17_2)
        L13_2 = L12_2.removeItem
        if L13_2 then
          L13_2 = TriggerServerEvent
          L14_2 = "osp_ambulance:removeItem"
          L15_2 = L12_2.itemName
          L16_2 = 1
          L13_2(L14_2, L15_2, L16_2)
        end
        L13_2 = table
        L13_2 = L13_2.insert
        L14_2 = L5_2.MessageLog
        L15_2 = time
        L16_2 = " | "
        L17_2 = L12_2.langUsed
        L18_2 = BodyPartTranslations
        L19_2 = A0_2.BodyPart
        L18_2 = L18_2[L19_2]
        L15_2 = L15_2 .. L16_2 .. L17_2 .. L18_2
        L13_2(L14_2, L15_2)
        L13_2 = pairs
        L14_2 = L5_2.BodyPartDamage
        L14_2 = L14_2.Wounds
        L14_2 = L14_2[L6_2]
        L13_2, L14_2, L15_2, L16_2 = L13_2(L14_2)
        for L17_2, L18_2 in L13_2, L14_2, L15_2, L16_2 do
          if "contusion" == L18_2 then
            L19_2 = L5_2.BodyPartDamage
            L19_2 = L19_2.Wounds
            L19_2 = L19_2[L6_2]
            L19_2[L17_2] = nil
          end
        end
        L13_2 = DebugPrint
        L14_2 = "inserted message log, removed item, removed all contusion wounds"
        L13_2(L14_2)
        L13_2 = L5_2.BodyPartDamage
        L13_2 = L13_2.Wounds
        L13_2 = L13_2[L6_2]
        L13_2 = #L13_2
        L14_2 = {}
        if L13_2 >= 7 then
          L15_2 = {}
          L16_2 = L5_2.BodyPartDamage
          L16_2 = L16_2.Wounds
          L16_2 = L16_2[L6_2]
          L16_2 = L16_2[L13_2]
          L17_2 = L5_2.BodyPartDamage
          L17_2 = L17_2.Wounds
          L17_2 = L17_2[L6_2]
          L18_2 = L13_2 - 1
          L17_2 = L17_2[L18_2]
          L15_2[1] = L16_2
          L15_2[2] = L17_2
          L14_2 = L15_2
          L15_2 = L5_2.BodyPartDamage
          L15_2 = L15_2.Wounds
          L15_2 = L15_2[L6_2]
          L15_2[L13_2] = nil
          L15_2 = L5_2.BodyPartDamage
          L15_2 = L15_2.Wounds
          L15_2 = L15_2[L6_2]
          L16_2 = L13_2 - 1
          L15_2[L16_2] = nil
        elseif L13_2 >= 3 then
          L15_2 = math
          L15_2 = L15_2.ceil
          L16_2 = L13_2 / 2
          L15_2 = L15_2(L16_2)
          L16_2 = {}
          L17_2 = table
          L17_2 = L17_2.unpack
          L18_2 = L5_2.BodyPartDamage
          L18_2 = L18_2.Wounds
          L18_2 = L18_2[L6_2]
          L19_2 = 1
          L20_2 = L15_2
          L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L17_2(L18_2, L19_2, L20_2)
          L16_2[1] = L17_2
          L16_2[2] = L18_2
          L16_2[3] = L19_2
          L16_2[4] = L20_2
          L16_2[5] = L21_2
          L16_2[6] = L22_2
          L16_2[7] = L23_2
          L16_2[8] = L24_2
          L16_2[9] = L25_2
          L16_2[10] = L26_2
          L16_2[11] = L27_2
          L16_2[12] = L28_2
          L14_2 = L16_2
        elseif L13_2 <= 2 then
          L15_2 = L5_2.BodyPartDamage
          L15_2 = L15_2.Wounds
          L14_2 = L15_2[L6_2]
        else
          L15_2 = {}
          L14_2 = L15_2
        end
        L15_2 = DebugPrint
        L16_2 = "calculated wound removal"
        L15_2(L16_2)
        L15_2 = false
        if nil ~= L14_2 then
          L16_2 = pairs
          L17_2 = L14_2
          L16_2, L17_2, L18_2, L19_2 = L16_2(L17_2)
          for L20_2, L21_2 in L16_2, L17_2, L18_2, L19_2 do
            L22_2 = L5_2.BodyPartDamage
            L22_2 = L22_2.Wounds
            L22_2 = L22_2[L6_2]
            L23_2 = L5_2.BodyPartDamage
            L23_2 = L23_2.Wounds
            L23_2 = L23_2[L6_2]
            L23_2 = #L23_2
            L22_2[L23_2] = nil
            L22_2 = Config
            L22_2 = L22_2.Wounds
            L22_2 = L22_2[L21_2]
            L22_2 = L22_2.needSewing
            if L22_2 then
              L15_2 = true
              L22_2 = calculateReopeningTime
              L23_2 = L21_2
              L24_2 = L12_2.effectivenessModifiers
              L22_2 = L22_2(L23_2, L24_2)
              if L22_2 then
                L23_2 = TriggerServerEvent
                L24_2 = "osp_ambulance:ReopenTimerSv"
                L25_2 = A0_2.PlayerId
                L26_2 = L22_2
                L27_2 = L21_2
                L28_2 = L6_2
                L23_2(L24_2, L25_2, L26_2, L27_2, L28_2)
              end
            end
          end
        end
        L16_2 = DebugPrint
        L17_2 = "applied wound calc and started wound reopen timer"
        L16_2(L17_2)
        L16_2 = L5_2.BodyPartDamage
        L16_2 = L16_2.Bleeding
        L16_2 = L16_2[L6_2]
        L17_2 = 0.5
        if L16_2 >= L17_2 then
          L16_2 = L5_2.BodyPartDamage
          L16_2 = L16_2.Bleeding
          L16_2[L6_2] = 0.2
        else
          L16_2 = L5_2.BodyPartDamage
          L16_2 = L16_2.Bleeding
          L16_2[L6_2] = 0.0
          L16_2 = L5_2.BodyPartDamage
          L16_2 = L16_2.DamageType
          L16_2 = L16_2[L6_2]
          if 3 == L16_2 then
            L16_2 = L5_2.BodyPartDamage
            L16_2 = L16_2.DamageType
            L16_2[L6_2] = 2
          end
        end
        L16_2 = L5_2.BodyPartDamage
        L16_2 = L16_2.Wounds
        L16_2 = L16_2[L6_2]
        L16_2 = #L16_2
        if L16_2 <= 0 then
          L17_2 = L5_2.BodyPartDamage
          L17_2 = L17_2.Bleeding
          L17_2 = L17_2[L6_2]
          if 0.0 == L17_2 then
            L17_2 = L5_2.BodyPartDamage
            L17_2 = L17_2.DamageType
            L17_2[L6_2] = 0
          end
        end
        if L16_2 <= 0 then
          L17_2 = L5_2.BodyPartDamage
          L17_2 = L17_2.Bleeding
          L17_2 = L17_2[L6_2]
          if L17_2 <= 0.0 and L15_2 then
            L17_2 = L5_2.BodyPartDamage
            L17_2 = L17_2.NeedSewed
            L17_2[L6_2] = true
          end
        end
        L17_2 = DebugPrint
        L18_2 = "sending new data to target player to store"
        L19_2 = L5_2
        L17_2(L18_2, L19_2)
        L17_2 = Wait
        L18_2 = Config
        L18_2 = L18_2.ServerDelay
        L17_2(L18_2)
        L17_2 = TriggerServerEvent
        L18_2 = "osp_ambulance:SaveDataSv"
        L19_2 = A0_2.PlayerId
        L20_2 = L5_2
        L17_2(L18_2, L19_2, L20_2)
      else
        L13_2 = L12_2.type
        if "sewing" == L13_2 then
          L13_2 = ProgressBar
          L14_2 = L12_2.lang
          L15_2 = L12_2.time
          L16_2 = L12_2.anim
          L16_2 = L16_2.dict
          L17_2 = L12_2.anim
          L17_2 = L17_2.name
          L13_2(L14_2, L15_2, L16_2, L17_2)
          L13_2 = L12_2.removeItem
          if L13_2 then
            L13_2 = TriggerServerEvent
            L14_2 = "osp_ambulance:removeItem"
            L15_2 = L12_2.itemName
            L16_2 = 1
            L13_2(L14_2, L15_2, L16_2)
          end
          L13_2 = table
          L13_2 = L13_2.insert
          L14_2 = L5_2.MessageLog
          L15_2 = time
          L16_2 = " | "
          L17_2 = L12_2.langUsed
          L18_2 = BodyPartTranslations
          L18_2 = L18_2[L6_2]
          L15_2 = L15_2 .. L16_2 .. L17_2 .. L18_2
          L13_2(L14_2, L15_2)
          L13_2 = TriggerEvent
          L14_2 = "osp_ambulance:CreateProp"
          L15_2 = GetEntityCoords
          L16_2 = PlayerPedId
          L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L16_2()
          L15_2 = L15_2(L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L15_2 = L15_2.x
          L16_2 = GetEntityCoords
          L17_2 = PlayerPedId
          L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L17_2()
          L16_2 = L16_2(L17_2, L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L16_2 = L16_2.y
          L17_2 = GetEntityCoords
          L18_2 = PlayerPedId
          L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L18_2()
          L17_2 = L17_2(L18_2, L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L17_2 = L17_2.z
          L17_2 = L17_2 - 1
          L18_2 = GetEntityHeading
          L19_2 = PlayerPedId
          L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2 = L19_2()
          L18_2 = L18_2(L19_2, L20_2, L21_2, L22_2, L23_2, L24_2, L25_2, L26_2, L27_2, L28_2)
          L19_2 = "p_bloodsplat_s"
          L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
          L13_2 = L5_2.BodyPartDamage
          L13_2 = L13_2.NeedSewed
          L13_2[L6_2] = false
          L13_2 = Wait
          L14_2 = Config
          L14_2 = L14_2.ServerDelay
          L13_2(L14_2)
          L13_2 = TriggerServerEvent
          L14_2 = "osp_ambulance:SaveDataSv"
          L15_2 = A0_2.PlayerId
          L16_2 = L5_2
          L13_2(L14_2, L15_2, L16_2)
        else
          L13_2 = L12_2.type
          if "medication" == L13_2 then
            L13_2 = ProgressBar
            L14_2 = L12_2.lang
            L15_2 = L12_2.time
            L16_2 = L12_2.anim
            L16_2 = L16_2.dict
            L17_2 = L12_2.anim
            L17_2 = L17_2.name
            L13_2(L14_2, L15_2, L16_2, L17_2)
            L13_2 = L12_2.removeItem
            if L13_2 then
              L13_2 = TriggerServerEvent
              L14_2 = "osp_ambulance:removeItem"
              L15_2 = L12_2.itemName
              L16_2 = 1
              L13_2(L14_2, L15_2, L16_2)
            end
            L13_2 = table
            L13_2 = L13_2.insert
            L14_2 = L5_2.MessageLog
            L15_2 = time
            L16_2 = " | "
            L17_2 = L12_2.langUsed
            L15_2 = L15_2 .. L16_2 .. L17_2
            L13_2(L14_2, L15_2)
            L13_2 = Wait
            L14_2 = Config
            L14_2 = L14_2.ServerDelay
            L13_2(L14_2)
            L13_2 = TriggerServerEvent
            L14_2 = "osp_ambulance:SaveDataSv"
            L15_2 = A0_2.PlayerId
            L16_2 = L5_2
            L13_2(L14_2, L15_2, L16_2)
            L13_2 = TriggerServerEvent
            L14_2 = "osp_ambulance:medicationSv"
            L15_2 = A0_2.PlayerId
            L16_2 = L12_2.itemName
            L17_2 = L12_2
            L13_2(L14_2, L15_2, L16_2, L17_2)
          else
            L13_2 = L12_2.type
            if "infusion" == L13_2 then
              L13_2 = ProgressBar
              L14_2 = L12_2.lang
              L15_2 = L12_2.time
              L16_2 = L12_2.anim
              L16_2 = L16_2.dict
              L17_2 = L12_2.anim
              L17_2 = L17_2.name
              L13_2(L14_2, L15_2, L16_2, L17_2)
              L13_2 = L12_2.removeItem
              if L13_2 then
                L13_2 = TriggerServerEvent
                L14_2 = "osp_ambulance:removeItem"
                L15_2 = L12_2.itemName
                L16_2 = 1
                L13_2(L14_2, L15_2, L16_2)
              end
              L13_2 = TriggerServerEvent
              L14_2 = "osp_ambulance:infusionSv"
              L15_2 = A0_2.PlayerId
              L16_2 = L12_2.itemName
              L17_2 = L12_2
              L13_2(L14_2, L15_2, L16_2, L17_2)
            else
              L13_2 = L12_2.type
              if "tourniquet" == L13_2 then
                L13_2 = A0_2.apply
                if L13_2 then
                  L14_2 = L5_2.BodyPartDamage
                  L14_2 = L14_2.appliedTourniquets
                  L14_2[L6_2] = true
                  L14_2 = L5_2.Pain
                  L15_2 = L12_2.pain
                  L14_2 = L14_2 + L15_2
                  L5_2.Pain = L14_2
                else
                  L14_2 = L5_2.BodyPartDamage
                  L14_2 = L14_2.appliedTourniquets
                  L14_2[L6_2] = false
                  L14_2 = L5_2.Pain
                  L15_2 = L12_2.pain
                  if L14_2 >= L15_2 then
                    L14_2 = L5_2.Pain
                    L15_2 = L12_2.pain
                    L14_2 = L14_2 - L15_2
                    L5_2.Pain = L14_2
                  end
                end
                L14_2 = table
                L14_2 = L14_2.insert
                L15_2 = L5_2.MessageLog
                L16_2 = time
                L17_2 = " | "
                L18_2 = L12_2.langUsed
                L19_2 = BodyPartTranslations
                L19_2 = L19_2[L6_2]
                L20_2 = ""
                L16_2 = L16_2 .. L17_2 .. L18_2 .. L19_2 .. L20_2
                L14_2(L15_2, L16_2)
                L14_2 = Wait
                L15_2 = Config
                L15_2 = L15_2.ServerDelay
                L14_2(L15_2)
                L14_2 = TriggerServerEvent
                L15_2 = "osp_ambulance:SaveDataSv"
                L16_2 = A0_2.PlayerId
                L17_2 = L5_2
                L14_2(L15_2, L16_2, L17_2)
                if L13_2 then
                  L14_2 = ProgressBar
                  L15_2 = L12_2.lang
                  L16_2 = L12_2.time
                  L17_2 = L12_2.anim
                  L17_2 = L17_2.dict
                  L18_2 = L12_2.anim
                  L18_2 = L18_2.name
                  L14_2(L15_2, L16_2, L17_2, L18_2)
                else
                  L14_2 = ProgressBar
                  L15_2 = L12_2.removeLang
                  L16_2 = L12_2.time
                  L17_2 = L12_2.anim
                  L17_2 = L17_2.dict
                  L18_2 = L12_2.anim
                  L18_2 = L18_2.name
                  L14_2(L15_2, L16_2, L17_2, L18_2)
                end
                if L13_2 then
                  L14_2 = TriggerServerEvent
                  L15_2 = "osp_ambulance:removeItem"
                  L16_2 = L12_2.itemName
                  L17_2 = 1
                  L14_2(L15_2, L16_2, L17_2)
                else
                  L14_2 = TriggerServerEvent
                  L15_2 = "osp_ambulance:addItem"
                  L16_2 = L12_2.itemName
                  L17_2 = 1
                  L14_2(L15_2, L16_2, L17_2)
                end
              else
                L13_2 = L12_2.type
                if "custom" == L13_2 then
                  L13_2 = ProgressBar
                  L14_2 = L12_2.lang
                  L15_2 = L12_2.time
                  L16_2 = L12_2.anim
                  L16_2 = L16_2.dict
                  L17_2 = L12_2.anim
                  L17_2 = L17_2.name
                  L13_2(L14_2, L15_2, L16_2, L17_2)
                  L13_2 = L12_2.removeItem
                  if L13_2 then
                    L13_2 = TriggerServerEvent
                    L14_2 = "osp_ambulance:removeItem"
                    L15_2 = L12_2.itemName
                    L16_2 = 1
                    L13_2(L14_2, L15_2, L16_2)
                  end
                  L13_2 = table
                  L13_2 = L13_2.insert
                  L14_2 = L5_2.MessageLog
                  L15_2 = time
                  L16_2 = " | "
                  L17_2 = L12_2.langUsed
                  L15_2 = L15_2 .. L16_2 .. L17_2
                  L13_2(L14_2, L15_2)
                  L13_2 = Wait
                  L14_2 = Config
                  L14_2 = L14_2.ServerDelay
                  L13_2(L14_2)
                  L13_2 = TriggerServerEvent
                  L14_2 = "osp_ambulance:SaveDataSv"
                  L15_2 = A0_2.PlayerId
                  L16_2 = L5_2
                  L13_2(L14_2, L15_2, L16_2)
                  L13_2 = TriggerServerEvent
                  L14_2 = "osp_ambulance:medicationSv"
                  L15_2 = A0_2.PlayerId
                  L16_2 = L12_2.itemName
                  L17_2 = L12_2
                  L13_2(L14_2, L15_2, L16_2, L17_2)
                end
              end
            end
          end
        end
      end
    end
  end
  L7_2 = Wait
  L8_2 = 500
  L7_2(L8_2)
  L7_2 = Player
  L8_2 = A0_2.PlayerId
  L7_2 = L7_2(L8_2)
  L8_2 = L7_2.state
  L8_2 = L8_2.BodyDamage
  L9_2 = GetMedicalInventoryItems
  L9_2()
  L9_2 = SetNuiFocus
  L10_2 = true
  L11_2 = true
  L9_2(L10_2, L11_2)
  L9_2 = SendNUIMessage
  L10_2 = {}
  L10_2.display = true
  L11_2 = json
  L11_2 = L11_2.encode
  L12_2 = L8_2
  L11_2 = L11_2(L12_2)
  L10_2.damageStatus = L11_2
  L11_2 = json
  L11_2 = L11_2.encode
  L12_2 = invItems
  L11_2 = L11_2(L12_2)
  L10_2.invItems = L11_2
  L9_2(L10_2)
end
L1_1(L2_1, L3_1)
L1_1 = {}
itemsInjected = L1_1
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:medicationCl"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "osp_ambulance:medicationCl"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = itemsInjected
  L2_2 = L2_2[A0_2]
  if nil ~= L2_2 then
    L2_2 = itemsInjected
    L3_2 = itemsInjected
    L3_2 = L3_2[A0_2]
    L3_2 = L3_2 + 1
    L2_2[A0_2] = L3_2
  else
    L2_2 = itemsInjected
    L2_2[A0_2] = 1
  end
  L2_2 = itemsInjected
  L2_2 = L2_2[A0_2]
  L3_2 = A1_2.maxDose
  if L2_2 > L3_2 then
    L2_2 = pairs
    L3_2 = Config
    L3_2 = L3_2.Medication
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = L7_2.itemName
      if L8_2 == A0_2 then
        L8_2 = L7_2.onOverDose
        L9_2 = L7_2
        L8_2(L9_2)
      end
    end
  end
  L2_2 = A1_2.type
  if "custom" == L2_2 then
    L2_2 = pairs
    L3_2 = Config
    L3_2 = L3_2.Medication
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = L7_2.itemName
      if L8_2 == A0_2 then
        L8_2 = L7_2.onUse
        L9_2 = L7_2
        L8_2(L9_2)
        return
      end
    end
  end
  L2_2 = BodyDamage
  L3_2 = BodyDamage
  L3_2 = L3_2.Pain
  L4_2 = A1_2.painReduce
  L3_2 = L3_2 - L4_2
  L2_2.Pain = L3_2
  L2_2 = BodyDamage
  L2_2 = L2_2.Pain
  if L2_2 < 0 then
    L2_2 = BodyDamage
    L2_2.Pain = 0
  end
  L2_2 = BodyDamage
  L3_2 = BodyDamage
  L3_2 = L3_2.hrDecrease
  L4_2 = A1_2.hrDecrease
  L3_2 = L3_2 + L4_2
  L2_2.hrDecrease = L3_2
  L2_2 = BodyDamage
  L3_2 = BodyDamage
  L3_2 = L3_2.hrIncrease
  L4_2 = A1_2.hrIncrease
  L3_2 = L3_2 + L4_2
  L2_2.hrIncrease = L3_2
  L2_2 = updatePulse
  L2_2()
  L2_2 = CreateThread
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    while true do
      L0_3 = LocalPlayer
      L0_3 = L0_3.state
      L1_3 = L0_3
      L0_3 = L0_3.set
      L2_3 = "BodyDamage"
      L3_3 = BodyDamage
      L4_3 = true
      L0_3(L1_3, L2_3, L3_3, L4_3)
      L0_3 = BodyDamage
      L1_3 = BodyDamage
      L1_3 = L1_3.hrDecrease
      L1_3 = L1_3 - 1
      L0_3.hrDecrease = L1_3
      L0_3 = BodyDamage
      L0_3 = L0_3.hrDecrease
      if L0_3 <= 0 then
        L0_3 = BodyDamage
        L0_3.hrDecrease = 0
        L0_3 = updatePulse
        L0_3()
        break
      end
      L0_3 = Wait
      L1_3 = 5000
      L0_3(L1_3)
    end
  end
  L2_2(L3_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:infusionCl"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "osp_ambulance:infusionCl"
function L3_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = CreateThread
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3
    L0_3 = A1_2.volume
    L1_3 = A1_2.injectingTime
    L0_3 = L0_3 / L1_3
    L1_3 = A0_2
    if "blood250ml" ~= L1_3 then
      L1_3 = A0_2
      if "blood500ml" ~= L1_3 then
        goto lbl_30
      end
    end
    L1_3 = BodyDamage
    L1_3 = L1_3.BodyPartDamage
    L2_3 = BodyDamage
    L2_3 = L2_3.BodyPartDamage
    L2_3 = L2_3.TotalBloodFill
    L3_3 = A1_2.volume
    L2_3 = L2_3 + L3_3
    L1_3.TotalBloodFill = L2_3
    L1_3 = BodyDamage
    L1_3 = L1_3.BodyPartDamage
    L2_3 = BodyDamage
    L2_3 = L2_3.BodyPartDamage
    L2_3 = L2_3.RefillBloodLeft
    L3_3 = A1_2.volume
    L2_3 = L2_3 + L3_3
    L1_3.RefillBloodLeft = L2_3
    goto lbl_48
    ::lbl_30::
    L1_3 = BodyDamage
    L1_3 = L1_3.BodyPartDamage
    L2_3 = BodyDamage
    L2_3 = L2_3.BodyPartDamage
    L2_3 = L2_3.TotalInfusionFill
    L3_3 = A1_2.volume
    L2_3 = L2_3 + L3_3
    L1_3.TotalInfusionFill = L2_3
    L1_3 = BodyDamage
    L1_3 = L1_3.BodyPartDamage
    L2_3 = BodyDamage
    L2_3 = L2_3.BodyPartDamage
    L2_3 = L2_3.RefillInfusionLeft
    L3_3 = A1_2.volume
    L2_3 = L2_3 + L3_3
    L1_3.RefillInfusionLeft = L2_3
    ::lbl_48::
    L1_3 = pairs
    L2_3 = Config
    L2_3 = L2_3.Medication
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = L6_3.itemName
      L8_3 = A0_2
      if L7_3 == L8_3 then
        L7_3 = L6_3.onUse
        L8_3 = L6_3
        L7_3(L8_3)
      end
    end
    L1_3 = A1_2.injectingTime
    L2_3 = A1_2.volume
    L3_3 = LocalPlayer
    L3_3 = L3_3.state
    L4_3 = L3_3
    L3_3 = L3_3.set
    L5_3 = "BodyDamage"
    L6_3 = BodyDamage
    L7_3 = true
    L3_3(L4_3, L5_3, L6_3, L7_3)
    while true do
      L3_3 = pairs
      L4_3 = Config
      L4_3 = L4_3.Medication
      L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
      for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
        L9_3 = L8_3.itemName
        L10_3 = A0_2
        if L9_3 == L10_3 then
          L9_3 = L8_3.onTick
          L10_3 = L8_3
          L9_3(L10_3)
        end
      end
      L3_3 = L2_3 - L0_3
      if L3_3 >= 0 then
        L3_3 = L0_3 * 1000
        L2_3 = L2_3 - L3_3
        L3_3 = A0_2
        if "blood250ml" ~= L3_3 then
          L3_3 = A0_2
          if "blood500ml" ~= L3_3 then
            goto lbl_112
          end
        end
        L3_3 = BodyDamage
        L3_3 = L3_3.BodyPartDamage
        L4_3 = BodyDamage
        L4_3 = L4_3.BodyPartDamage
        L4_3 = L4_3.RefillBloodLeft
        L5_3 = L0_3 * 1000
        L4_3 = L4_3 - L5_3
        L3_3.RefillBloodLeft = L4_3
        goto lbl_124
        ::lbl_112::
        L3_3 = BodyDamage
        L3_3 = L3_3.BodyPartDamage
        L4_3 = BodyDamage
        L4_3 = L4_3.BodyPartDamage
        L4_3 = L4_3.RefillInfusionLeft
        L5_3 = L0_3 * 1000
        L4_3 = L4_3 - L5_3
        L3_3.RefillInfusionLeft = L4_3
      else
        L2_3 = 0
      end
      ::lbl_124::
      if 0 == L1_3 then
        L2_3 = 0
        L3_3 = A0_2
        if "blood250ml" ~= L3_3 then
          L3_3 = A0_2
          if "blood500ml" ~= L3_3 then
            goto lbl_143
          end
        end
        L3_3 = BodyDamage
        L3_3 = L3_3.BodyPartDamage
        L4_3 = BodyDamage
        L4_3 = L4_3.BodyPartDamage
        L4_3 = L4_3.TotalBloodFill
        L5_3 = A1_2.volume
        L4_3 = L4_3 - L5_3
        L3_3.TotalBloodFill = L4_3
        goto lbl_152
        ::lbl_143::
        L3_3 = BodyDamage
        L3_3 = L3_3.BodyPartDamage
        L4_3 = BodyDamage
        L4_3 = L4_3.BodyPartDamage
        L4_3 = L4_3.TotalInfusionFill
        L5_3 = A1_2.volume
        L4_3 = L4_3 - L5_3
        L3_3.TotalInfusionFill = L4_3
        ::lbl_152::
        L3_3 = pairs
        L4_3 = Config
        L4_3 = L4_3.Medication
        L3_3, L4_3, L5_3, L6_3 = L3_3(L4_3)
        for L7_3, L8_3 in L3_3, L4_3, L5_3, L6_3 do
          L9_3 = L8_3.itemName
          L10_3 = A0_2
          if L9_3 == L10_3 then
            L9_3 = L8_3.onFinish
            L10_3 = L8_3
            L9_3(L10_3)
          end
        end
        L3_3 = table
        L3_3 = L3_3.insert
        L4_3 = BodyDamage
        L4_3 = L4_3.MessageLog
        L5_3 = time
        L6_3 = " | "
        L7_3 = A1_2.langUsed
        L5_3 = L5_3 .. L6_3 .. L7_3
        L3_3(L4_3, L5_3)
        L3_3 = SendNUIMessage
        L4_3 = {}
        L5_3 = json
        L5_3 = L5_3.encode
        L6_3 = BodyDamage
        L5_3 = L5_3(L6_3)
        L4_3.damageStatus = L5_3
        L3_3(L4_3)
        break
      end
      L1_3 = L1_3 - 1000
      L3_3 = Wait
      L4_3 = 1000
      L3_3(L4_3)
      L3_3 = LocalPlayer
      L3_3 = L3_3.state
      L4_3 = L3_3
      L3_3 = L3_3.set
      L5_3 = "BodyDamage"
      L6_3 = BodyDamage
      L7_3 = true
      L3_3(L4_3, L5_3, L6_3, L7_3)
      L3_3 = SendNUIMessage
      L4_3 = {}
      L5_3 = json
      L5_3 = L5_3.encode
      L6_3 = BodyDamage
      L5_3 = L5_3(L6_3)
      L4_3.damageStatus = L5_3
      L3_3(L4_3)
    end
  end
  L2_2(L3_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "CheckConsciousness"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "osp_ambulance:GetTime"
  L3_2 = 1000
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    time = L1_2
  end
  L2_2 = DebugPrint
  L3_2 = "Got CheckConsciousness in lua"
  L2_2(L3_2)
  L2_2 = Config
  L2_2 = L2_2.ModularAccessLocks
  L2_2 = L2_2.quickChecks
  if L2_2 then
    L2_2 = IsAuthorized
    L2_2 = L2_2()
    if not L2_2 then
      L2_2 = SendTextMessage
      L3_2 = lang
      L3_2 = L3_2.interactions
      L3_2 = L3_2.medicalHeader
      L4_2 = lang
      L4_2 = L4_2.error
      L4_2 = L4_2.not_authorized
      L5_2 = 5000
      L6_2 = "error"
      L2_2(L3_2, L4_2, L5_2, L6_2)
      return
    end
  end
  L2_2 = getPlayerDistance
  L3_2 = A0_2.PlayerId
  L2_2 = L2_2(L3_2)
  L3_2 = Config
  L3_2 = L3_2.MedicalMenuMaxDistance
  if L2_2 >= L3_2 then
    L3_2 = SendTextMessage
    L4_2 = lang
    L4_2 = L4_2.interactions
    L4_2 = L4_2.medicalHeader
    L5_2 = lang
    L5_2 = L5_2.error
    L5_2 = L5_2.player_too_far_away
    L6_2 = 5000
    L7_2 = "error"
    L3_2(L4_2, L5_2, L6_2, L7_2)
    return
  end
  L3_2 = Player
  L4_2 = A0_2.PlayerId
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2.state
  L4_2 = L4_2.BodyDamage
  L5_2 = SetNuiFocus
  L6_2 = false
  L7_2 = false
  L5_2(L6_2, L7_2)
  L5_2 = SendNUIMessage
  L6_2 = {}
  L6_2.display = false
  L5_2(L6_2)
  L5_2 = DebugPrint
  L6_2 = "closed ui"
  L7_2 = L4_2
  L8_2 = L3_2
  L9_2 = A0_2.PlayerId
  L10_2 = L4_2.Conscious
  L5_2(L6_2, L7_2, L8_2, L9_2, L10_2)
  L5_2 = Config
  L5_2 = L5_2.InteractionDict
  L6_2 = Config
  L6_2 = L6_2.InteractionAnim
  L7_2 = ProgressBar
  L8_2 = lang
  L8_2 = L8_2.progress
  L8_2 = L8_2.checking_consciousness
  L9_2 = Config
  L9_2 = L9_2.QuickCheckVitalsTime
  L10_2 = L5_2
  L11_2 = L6_2
  L7_2(L8_2, L9_2, L10_2, L11_2)
  L7_2 = DebugPrint
  L8_2 = "finished progbar"
  L9_2 = L5_2
  L10_2 = L6_2
  L7_2(L8_2, L9_2, L10_2)
  L7_2 = L4_2.Conscious
  if L7_2 then
    L7_2 = SendTextMessage
    L8_2 = lang
    L8_2 = L8_2.interactions
    L8_2 = L8_2.medicalHeader
    L9_2 = lang
    L9_2 = L9_2.interactions
    L9_2 = L9_2.conscious
    L10_2 = 5000
    L11_2 = "success"
    L7_2(L8_2, L9_2, L10_2, L11_2)
  else
    L7_2 = SendTextMessage
    L8_2 = lang
    L8_2 = L8_2.interactions
    L8_2 = L8_2.medicalHeader
    L9_2 = lang
    L9_2 = L9_2.interactions
    L9_2 = L9_2.unconscious
    L10_2 = 5000
    L11_2 = "error"
    L7_2(L8_2, L9_2, L10_2, L11_2)
  end
  L7_2 = TriggerServerEvent
  L8_2 = "osp_ambulance:SendVitalMessageLogSv"
  L9_2 = A0_2.PlayerId
  L10_2 = "conscious"
  L7_2(L8_2, L9_2, L10_2)
  L7_2 = DebugPrint
  L8_2 = "has got the player consiousness and updated ui, now reopening ui"
  L7_2(L8_2)
  L7_2 = Wait
  L8_2 = 500
  L7_2(L8_2)
  L7_2 = Player
  L8_2 = A0_2.PlayerId
  L7_2 = L7_2(L8_2)
  L8_2 = L7_2.state
  L8_2 = L8_2.BodyDamage
  L9_2 = SetNuiFocus
  L10_2 = true
  L11_2 = true
  L9_2(L10_2, L11_2)
  L9_2 = SendNUIMessage
  L10_2 = {}
  L10_2.display = true
  L11_2 = json
  L11_2 = L11_2.encode
  L12_2 = L8_2
  L11_2 = L11_2(L12_2)
  L10_2.damageStatus = L11_2
  L9_2(L10_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "CheckPulse"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "osp_ambulance:GetTime"
  L3_2 = 1000
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    time = L1_2
  end
  L2_2 = Config
  L2_2 = L2_2.ModularAccessLocks
  L2_2 = L2_2.quickChecks
  if L2_2 then
    L2_2 = IsAuthorized
    L2_2 = L2_2()
    if not L2_2 then
      L2_2 = SendTextMessage
      L3_2 = lang
      L3_2 = L3_2.interactions
      L3_2 = L3_2.medicalHeader
      L4_2 = lang
      L4_2 = L4_2.error
      L4_2 = L4_2.not_authorized
      L5_2 = 5000
      L6_2 = "error"
      L2_2(L3_2, L4_2, L5_2, L6_2)
      return
    end
  end
  L2_2 = getPlayerDistance
  L3_2 = A0_2.PlayerId
  L2_2 = L2_2(L3_2)
  L3_2 = Config
  L3_2 = L3_2.MedicalMenuMaxDistance
  if L2_2 >= L3_2 then
    L3_2 = SendTextMessage
    L4_2 = lang
    L4_2 = L4_2.interactions
    L4_2 = L4_2.medicalHeader
    L5_2 = lang
    L5_2 = L5_2.error
    L5_2 = L5_2.player_too_far_away
    L6_2 = 5000
    L7_2 = "error"
    L3_2(L4_2, L5_2, L6_2, L7_2)
    return
  end
  L3_2 = DebugPrint
  L4_2 = "check pulse nui callback"
  L5_2 = A0_2.PlayerId
  L3_2(L4_2, L5_2)
  L3_2 = Player
  L4_2 = A0_2.PlayerId
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2.state
  L4_2 = L4_2.BodyDamage
  L5_2 = DebugPrint
  L6_2 = L4_2
  L7_2 = L4_2.Pulse
  L5_2(L6_2, L7_2)
  L5_2 = SetNuiFocus
  L6_2 = false
  L7_2 = false
  L5_2(L6_2, L7_2)
  L5_2 = SendNUIMessage
  L6_2 = {}
  L6_2.display = false
  L5_2(L6_2)
  L5_2 = Config
  L5_2 = L5_2.InteractionDict
  L6_2 = Config
  L6_2 = L6_2.InteractionAnim
  L7_2 = ProgressBar
  L8_2 = lang
  L8_2 = L8_2.progress
  L8_2 = L8_2.checking_pulse
  L9_2 = Config
  L9_2 = L9_2.QuickCheckVitalsTime
  L10_2 = L5_2
  L11_2 = L6_2
  L7_2(L8_2, L9_2, L10_2, L11_2)
  L7_2 = L4_2.Pulse
  if L7_2 > 0 then
    L7_2 = L4_2.Pulse
    if L7_2 <= 50 then
      L7_2 = SendTextMessage
      L8_2 = lang
      L8_2 = L8_2.interactions
      L8_2 = L8_2.medicalHeader
      L9_2 = lang
      L9_2 = L9_2.interactions
      L9_2 = L9_2.weak_pulse
      L10_2 = 5000
      L11_2 = "error"
      L7_2(L8_2, L9_2, L10_2, L11_2)
    else
      L7_2 = L4_2.Pulse
      if L7_2 >= 50 then
        L7_2 = L4_2.Pulse
        if L7_2 <= 90 then
          L7_2 = SendTextMessage
          L8_2 = lang
          L8_2 = L8_2.interactions
          L8_2 = L8_2.medicalHeader
          L9_2 = lang
          L9_2 = L9_2.interactions
          L9_2 = L9_2.normal_pulse
          L10_2 = 5000
          L11_2 = "success"
          L7_2(L8_2, L9_2, L10_2, L11_2)
      end
      else
        L7_2 = L4_2.Pulse
        if L7_2 >= 90 then
          L7_2 = SendTextMessage
          L8_2 = lang
          L8_2 = L8_2.interactions
          L8_2 = L8_2.medicalHeader
          L9_2 = lang
          L9_2 = L9_2.interactions
          L9_2 = L9_2.elevated_pulse
          L10_2 = 5000
          L11_2 = "success"
          L7_2(L8_2, L9_2, L10_2, L11_2)
        end
      end
    end
  else
    L7_2 = SendTextMessage
    L8_2 = lang
    L8_2 = L8_2.interactions
    L8_2 = L8_2.medicalHeader
    L9_2 = lang
    L9_2 = L9_2.interactions
    L9_2 = L9_2.no_pulse
    L10_2 = 5000
    L11_2 = "error"
    L7_2(L8_2, L9_2, L10_2, L11_2)
  end
  L7_2 = TriggerServerEvent
  L8_2 = "osp_ambulance:SendVitalMessageLogSv"
  L9_2 = A0_2.PlayerId
  L10_2 = "pulse"
  L7_2(L8_2, L9_2, L10_2)
  L7_2 = Wait
  L8_2 = 500
  L7_2(L8_2)
  L7_2 = Player
  L8_2 = A0_2.PlayerId
  L7_2 = L7_2(L8_2)
  L8_2 = L7_2.state
  L8_2 = L8_2.BodyDamage
  L9_2 = GetMedicalInventoryItems
  L9_2()
  L9_2 = SetNuiFocus
  L10_2 = true
  L11_2 = true
  L9_2(L10_2, L11_2)
  L9_2 = SendNUIMessage
  L10_2 = {}
  L10_2.display = true
  L11_2 = json
  L11_2 = L11_2.encode
  L12_2 = L8_2
  L11_2 = L11_2(L12_2)
  L10_2.damageStatus = L11_2
  L11_2 = json
  L11_2 = L11_2.encode
  L12_2 = invItems
  L11_2 = L11_2(L12_2)
  L10_2.invItems = L11_2
  L9_2(L10_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "CheckBodyTemp"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "osp_ambulance:GetTime"
  L3_2 = 1000
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    time = L1_2
  end
  L2_2 = Config
  L2_2 = L2_2.ModularAccessLocks
  L2_2 = L2_2.quickChecks
  if L2_2 then
    L2_2 = IsAuthorized
    L2_2 = L2_2()
    if not L2_2 then
      L2_2 = SendTextMessage
      L3_2 = lang
      L3_2 = L3_2.interactions
      L3_2 = L3_2.medicalHeader
      L4_2 = lang
      L4_2 = L4_2.error
      L4_2 = L4_2.not_authorized
      L5_2 = 5000
      L6_2 = "error"
      L2_2(L3_2, L4_2, L5_2, L6_2)
      return
    end
  end
  L2_2 = getPlayerDistance
  L3_2 = A0_2.PlayerId
  L2_2 = L2_2(L3_2)
  L3_2 = Config
  L3_2 = L3_2.MedicalMenuMaxDistance
  if L2_2 >= L3_2 then
    L3_2 = SendTextMessage
    L4_2 = lang
    L4_2 = L4_2.interactions
    L4_2 = L4_2.medicalHeader
    L5_2 = lang
    L5_2 = L5_2.error
    L5_2 = L5_2.player_too_far_away
    L6_2 = 5000
    L7_2 = "error"
    L3_2(L4_2, L5_2, L6_2, L7_2)
    return
  end
  L3_2 = Player
  L4_2 = A0_2.PlayerId
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2.state
  L4_2 = L4_2.BodyDamage
  L5_2 = SetNuiFocus
  L6_2 = false
  L7_2 = false
  L5_2(L6_2, L7_2)
  L5_2 = SendNUIMessage
  L6_2 = {}
  L6_2.display = false
  L5_2(L6_2)
  L5_2 = Config
  L5_2 = L5_2.InteractionDict
  L6_2 = Config
  L6_2 = L6_2.InteractionAnim
  L7_2 = ProgressBar
  L8_2 = lang
  L8_2 = L8_2.progress
  L8_2 = L8_2.checking_body_temp
  L9_2 = Config
  L9_2 = L9_2.QuickCheckVitalsTime
  L10_2 = L5_2
  L11_2 = L6_2
  L7_2(L8_2, L9_2, L10_2, L11_2)
  L7_2 = L4_2.Temp
  if L7_2 >= 35 then
    L7_2 = L4_2.Temp
    if L7_2 <= 37 then
      L7_2 = SendTextMessage
      L8_2 = lang
      L8_2 = L8_2.interactions
      L8_2 = L8_2.medicalHeader
      L9_2 = lang
      L9_2 = L9_2.interactions
      L9_2 = L9_2.normal_body_temp
      L10_2 = 5000
      L11_2 = "success"
      L7_2(L8_2, L9_2, L10_2, L11_2)
  end
  else
    L7_2 = L4_2.Temp
    if L7_2 < 35 then
      L7_2 = SendTextMessage
      L8_2 = lang
      L8_2 = L8_2.interactions
      L8_2 = L8_2.medicalHeader
      L9_2 = lang
      L9_2 = L9_2.interactions
      L9_2 = L9_2.low_body_temp
      L10_2 = 5000
      L11_2 = "error"
      L7_2(L8_2, L9_2, L10_2, L11_2)
    else
      L7_2 = L4_2.Temp
      if L7_2 > 37 then
        L7_2 = SendTextMessage
        L8_2 = lang
        L8_2 = L8_2.interactions
        L8_2 = L8_2.medicalHeader
        L9_2 = lang
        L9_2 = L9_2.interactions
        L9_2 = L9_2.elevated_body_temp
        L10_2 = 5000
        L11_2 = "error"
        L7_2(L8_2, L9_2, L10_2, L11_2)
      end
    end
  end
  L7_2 = TriggerServerEvent
  L8_2 = "osp_ambulance:SendVitalMessageLogSv"
  L9_2 = A0_2.PlayerId
  L10_2 = "temp"
  L7_2(L8_2, L9_2, L10_2)
  L7_2 = Wait
  L8_2 = 500
  L7_2(L8_2)
  L7_2 = Player
  L8_2 = A0_2.PlayerId
  L7_2 = L7_2(L8_2)
  L8_2 = L7_2.state
  L8_2 = L8_2.BodyDamage
  L9_2 = GetMedicalInventoryItems
  L9_2()
  L9_2 = SetNuiFocus
  L10_2 = true
  L11_2 = true
  L9_2(L10_2, L11_2)
  L9_2 = SendNUIMessage
  L10_2 = {}
  L10_2.display = true
  L11_2 = json
  L11_2 = L11_2.encode
  L12_2 = L8_2
  L11_2 = L11_2(L12_2)
  L10_2.damageStatus = L11_2
  L11_2 = json
  L11_2 = L11_2.encode
  L12_2 = invItems
  L11_2 = L11_2(L12_2)
  L10_2.invItems = L11_2
  L9_2(L10_2)
end
L1_1(L2_1, L3_1)
function L1_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L2_2 = Config
  L2_2 = L2_2.Wounds
  L2_2 = L2_2[A0_2]
  L2_2 = L2_2.reopeningTime
  L3_2 = A1_2
  if L2_2 and L3_2 then
    L4_2 = L2_2
    L5_2 = L3_2[A0_2]
    L6_2 = L4_2 * L5_2
    L7_2 = math
    L7_2 = L7_2.random
    L8_2 = 0
    L9_2 = 100
    L7_2 = L7_2(L8_2, L9_2)
    L8_2 = L7_2 / 100
    if L5_2 <= L8_2 then
      return L6_2
    else
      L8_2 = nil
      return L8_2
    end
  end
  L4_2 = nil
  return L4_2
end
calculateReopeningTime = L1_1
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:ReopenTimerCl"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "osp_ambulance:ReopenTimerCl"
function L3_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2
  L3_2 = Wait
  L4_2 = 100
  L3_2(L4_2)
  L3_2 = CreateThread
  function L4_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3
    while true do
      L0_3 = A0_2
      L0_3 = L0_3 - 1
      A0_2 = L0_3
      L0_3 = A0_2
      if 0 == L0_3 then
        L0_3 = SendTextMessage
        L1_3 = lang
        L1_3 = L1_3.interactions
        L1_3 = L1_3.medicalHeader
        L2_3 = lang
        L2_3 = L2_3.info
        L2_3 = L2_3.wound_reopened
        L3_3 = L2_3
        L2_3 = L2_3.format
        L4_3 = A1_2
        L2_3 = L2_3(L3_3, L4_3)
        L3_3 = 6000
        L4_3 = "error"
        L0_3(L1_3, L2_3, L3_3, L4_3)
        L0_3 = table
        L0_3 = L0_3.insert
        L1_3 = BodyDamage
        L1_3 = L1_3.BodyPartDamage
        L1_3 = L1_3.Wounds
        L2_3 = A2_2
        L1_3 = L1_3[L2_3]
        L2_3 = A1_2
        L0_3(L1_3, L2_3)
        L0_3 = BodyDamage
        L0_3 = L0_3.BodyPartDamage
        L0_3 = L0_3.DamageType
        L1_3 = A2_2
        L0_3 = L0_3[L1_3]
        if L0_3 <= 1 then
          L0_3 = BodyDamage
          L0_3 = L0_3.BodyPartDamage
          L0_3 = L0_3.DamageType
          L1_3 = A2_2
          L2_3 = BodyDamage
          L2_3 = L2_3.BodyPartDamage
          L2_3 = L2_3.DamageType
          L3_3 = A2_2
          L2_3 = L2_3[L3_3]
          L2_3 = L2_3 + 1
          L0_3[L1_3] = L2_3
        end
        L0_3 = LocalPlayer
        L0_3 = L0_3.state
        L1_3 = L0_3
        L0_3 = L0_3.set
        L2_3 = "BodyDamage"
        L3_3 = BodyDamage
        L4_3 = true
        L0_3(L1_3, L2_3, L3_3, L4_3)
        break
      end
      L0_3 = BodyDamage
      L0_3 = L0_3.BodyPartDamage
      L0_3 = L0_3.Wounds
      L1_3 = A2_2
      L0_3 = L0_3[L1_3]
      L0_3 = #L0_3
      if nil ~= L0_3 and L0_3 <= 0 then
        L1_3 = BodyDamage
        L1_3 = L1_3.BodyPartDamage
        L1_3 = L1_3.Bleeding
        L2_3 = A2_2
        L1_3 = L1_3[L2_3]
        if L1_3 <= 0.0 then
          L1_3 = BodyDamage
          L1_3 = L1_3.BodyPartDamage
          L1_3 = L1_3.NeedSewed
          L2_3 = A2_2
          L1_3 = L1_3[L2_3]
          if false == L1_3 then
            break
          end
        end
      end
      L1_3 = Wait
      L2_3 = 1000
      L1_3(L2_3)
    end
  end
  L3_2(L4_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:SaveDataCl"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "osp_ambulance:SaveDataCl"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  BodyDamage = A0_2
  L1_2 = LocalPlayer
  L1_2 = L1_2.state
  L2_2 = L1_2
  L1_2 = L1_2.set
  L3_2 = "BodyDamage"
  L4_2 = BodyDamage
  L5_2 = true
  L1_2(L2_2, L3_2, L4_2, L5_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "CPR"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "osp_ambulance:GetTime"
  L3_2 = 1000
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    time = L1_2
  end
  L2_2 = Config
  L2_2 = L2_2.ModularAccessLocks
  L2_2 = L2_2.cpr
  if L2_2 then
    L2_2 = IsAuthorized
    L2_2 = L2_2()
    if not L2_2 then
      L2_2 = SendTextMessage
      L3_2 = lang
      L3_2 = L3_2.interactions
      L3_2 = L3_2.medicalHeader
      L4_2 = lang
      L4_2 = L4_2.error
      L4_2 = L4_2.not_authorized
      L5_2 = 5000
      L6_2 = "error"
      L2_2(L3_2, L4_2, L5_2, L6_2)
      return
    end
  end
  L2_2 = getPlayerDistance
  L3_2 = A0_2.PlayerId
  L2_2 = L2_2(L3_2)
  L3_2 = Config
  L3_2 = L3_2.MedicalMenuMaxDistance
  if L2_2 >= L3_2 then
    L3_2 = SendTextMessage
    L4_2 = lang
    L4_2 = L4_2.interactions
    L4_2 = L4_2.medicalHeader
    L5_2 = lang
    L5_2 = L5_2.error
    L5_2 = L5_2.player_too_far_away
    L6_2 = 5000
    L7_2 = "error"
    L3_2(L4_2, L5_2, L6_2, L7_2)
    return
  end
  L3_2 = SetNuiFocus
  L4_2 = false
  L5_2 = false
  L3_2(L4_2, L5_2)
  L3_2 = SendNUIMessage
  L4_2 = {}
  L4_2.display = false
  L3_2(L4_2)
  L3_2 = Player
  L4_2 = A0_2.PlayerId
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2.state
  L4_2 = L4_2.BodyDamage
  L5_2 = A0_2.PlayerId
  L6_2 = GetPlayerServerId
  L7_2 = NetworkGetPlayerIndexFromPed
  L8_2 = PlayerPedId
  L8_2, L9_2 = L8_2()
  L7_2, L8_2, L9_2 = L7_2(L8_2, L9_2)
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  if L5_2 == L6_2 then
    L5_2 = SendTextMessage
    L6_2 = lang
    L6_2 = L6_2.interactions
    L6_2 = L6_2.medicalHeader
    L7_2 = lang
    L7_2 = L7_2.interactions
    L7_2 = L7_2.cannot_perform_cpr
    L8_2 = 5000
    L9_2 = "error"
    L5_2(L6_2, L7_2, L8_2, L9_2)
    L5_2 = Wait
    L6_2 = 1000
    L5_2(L6_2)
    L5_2 = SetNuiFocus
    L6_2 = true
    L7_2 = true
    L5_2(L6_2, L7_2)
    L5_2 = SendNUIMessage
    L6_2 = {}
    L6_2.display = true
    L7_2 = json
    L7_2 = L7_2.encode
    L8_2 = L4_2
    L7_2 = L7_2(L8_2)
    L6_2.damageStatus = L7_2
    L5_2(L6_2)
  else
    L5_2 = L4_2.isDead
    if L5_2 then
      L5_2 = CPRFunction
      L6_2 = A0_2
      L5_2(L6_2)
    else
      L5_2 = SendTextMessage
      L6_2 = lang
      L6_2 = L6_2.interactions
      L6_2 = L6_2.medicalHeader
      L7_2 = lang
      L7_2 = L7_2.update1
      L7_2 = L7_2.not_dead
      L8_2 = 5000
      L9_2 = "error"
      L5_2(L6_2, L7_2, L8_2, L9_2)
      L5_2 = Wait
      L6_2 = 1000
      L5_2(L6_2)
      L5_2 = SetNuiFocus
      L6_2 = true
      L7_2 = true
      L5_2(L6_2, L7_2)
      L5_2 = SendNUIMessage
      L6_2 = {}
      L6_2.display = true
      L7_2 = json
      L7_2 = L7_2.encode
      L8_2 = L4_2
      L7_2 = L7_2(L8_2)
      L6_2.damageStatus = L7_2
      L5_2(L6_2)
    end
  end
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:StopCarryCl"
L1_1(L2_1)
L1_1 = AddEventHandler
L2_1 = "osp_ambulance:StopCarryCl"
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = BodyDamage
  L0_2.isCarried = false
  L0_2 = ClearPedSecondaryTask
  L1_2 = PlayerPedId
  L1_2, L2_2, L3_2, L4_2 = L1_2()
  L0_2(L1_2, L2_2, L3_2, L4_2)
  L0_2 = DetachEntity
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = true
  L3_2 = false
  L0_2(L1_2, L2_2, L3_2)
  L0_2 = LocalPlayer
  L0_2 = L0_2.state
  L1_2 = L0_2
  L0_2 = L0_2.set
  L2_2 = "BodyDamage"
  L3_2 = BodyDamage
  L4_2 = true
  L0_2(L1_2, L2_2, L3_2, L4_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:CarryCl"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L1_2 = BodyDamage
  L1_2.isCarried = true
  L1_2 = LocalPlayer
  L1_2 = L1_2.state
  L2_2 = L1_2
  L1_2 = L1_2.set
  L3_2 = "BodyDamage"
  L4_2 = BodyDamage
  L5_2 = true
  L1_2(L2_2, L3_2, L4_2, L5_2)
  L1_2 = Wait
  L2_2 = 50
  L1_2(L2_2)
  L1_2 = ClearPedTasksImmediately
  L2_2 = PlayerPedId
  L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2 = L2_2()
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
  L1_2 = PlayerPedId
  L1_2 = L1_2()
  L2_2 = loadAnimDict
  L3_2 = "nm"
  L2_2(L3_2)
  L2_2 = AttachEntityToEntity
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = GetPlayerPed
  L5_2 = GetPlayerFromServerId
  L6_2 = A0_2
  L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2 = L5_2(L6_2)
  L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
  L5_2 = 0
  L6_2 = 0.15
  L7_2 = 0.27
  L8_2 = 0.63
  L9_2 = 0.0
  L10_2 = 0.0
  L11_2 = 0.0
  L12_2 = false
  L13_2 = false
  L14_2 = false
  L15_2 = false
  L16_2 = 2
  L17_2 = false
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2)
  L2_2 = CreateThread
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
    while true do
      L0_3 = IsEntityPlayingAnim
      L1_3 = L1_2
      L2_3 = "nm"
      L3_3 = "firemans_carry"
      L4_3 = 3
      L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3)
      if not L0_3 then
        L0_3 = TaskPlayAnim
        L1_3 = L1_2
        L2_3 = "nm"
        L3_3 = "firemans_carry"
        L4_3 = 8.0
        L5_3 = 1.0
        L6_3 = -1
        L7_3 = 1
        L8_3 = 0
        L9_3 = 0
        L10_3 = 0
        L11_3 = 0
        L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
      end
      L0_3 = BodyDamage
      L0_3 = L0_3.isCarried
      if false == L0_3 then
        L0_3 = ClearPedTasksImmediately
        L1_3 = PlayerPedId
        L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3 = L1_3()
        L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
        L0_3 = DetachEntity
        L1_3 = PlayerPedId
        L1_3 = L1_3()
        L2_3 = true
        L3_3 = false
        L0_3(L1_3, L2_3, L3_3)
        break
      end
      L0_3 = Wait
      L1_3 = 25
      L0_3(L1_3)
    end
  end
  L2_2(L3_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "Carry"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "osp_ambulance:GetTime"
  L3_2 = 1000
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    time = L1_2
  end
  L2_2 = Config
  L2_2 = L2_2.ModularAccessLocks
  L2_2 = L2_2.transportation
  if L2_2 then
    L2_2 = IsAuthorized
    L2_2 = L2_2()
    if not L2_2 then
      L2_2 = SendTextMessage
      L3_2 = lang
      L3_2 = L3_2.interactions
      L3_2 = L3_2.medicalHeader
      L4_2 = lang
      L4_2 = L4_2.error
      L4_2 = L4_2.not_authorized
      L5_2 = 5000
      L6_2 = "error"
      L2_2(L3_2, L4_2, L5_2, L6_2)
      return
    end
  end
  L2_2 = getPlayerDistance
  L3_2 = A0_2.PlayerId
  L2_2 = L2_2(L3_2)
  L3_2 = Config
  L3_2 = L3_2.MedicalMenuMaxDistance
  if L2_2 >= L3_2 then
    L3_2 = SendTextMessage
    L4_2 = lang
    L4_2 = L4_2.interactions
    L4_2 = L4_2.medicalHeader
    L5_2 = lang
    L5_2 = L5_2.error
    L5_2 = L5_2.player_too_far_away
    L6_2 = 5000
    L7_2 = "error"
    L3_2(L4_2, L5_2, L6_2, L7_2)
    return
  end
  L3_2 = Player
  L4_2 = A0_2.PlayerId
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2.state
  L4_2 = L4_2.BodyDamage
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  L6_2 = SetNuiFocus
  L7_2 = false
  L8_2 = false
  L6_2(L7_2, L8_2)
  L6_2 = SendNUIMessage
  L7_2 = {}
  L7_2.display = false
  L6_2(L7_2)
  L6_2 = A0_2.PlayerId
  L7_2 = GetPlayerServerId
  L8_2 = PlayerId
  L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L8_2()
  L7_2 = L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
  if L6_2 == L7_2 then
    L6_2 = SendTextMessage
    L7_2 = lang
    L7_2 = L7_2.interactions
    L7_2 = L7_2.medicalHeader
    L8_2 = lang
    L8_2 = L8_2.error
    L8_2 = L8_2.you_cant_interact_with_yourself
    L9_2 = 5000
    L10_2 = "error"
    L6_2(L7_2, L8_2, L9_2, L10_2)
    return
  end
  L6_2 = isCarrying
  if not L6_2 then
    L6_2 = L4_2.inBodybag
    if not L6_2 then
      isCarrying = true
      L6_2 = lib
      L6_2 = L6_2.getClosestPlayer
      L7_2 = GetEntityCoords
      L8_2 = L5_2
      L7_2 = L7_2(L8_2)
      L8_2 = 3.0
      L9_2 = false
      L6_2 = L6_2(L7_2, L8_2, L9_2)
      L7_2 = A0_2.PlayerId
      if L7_2 then
        L7_2 = TriggerServerEvent
        L8_2 = "osp_ambulance:CarrySv"
        L9_2 = A0_2.PlayerId
        L7_2(L8_2, L9_2)
        L7_2 = loadAnimDict
        L8_2 = "missfinale_c2mcs_1"
        L7_2(L8_2)
        L7_2 = TaskPlayAnim
        L8_2 = L5_2
        L9_2 = "missfinale_c2mcs_1"
        L10_2 = "fin_c2_mcs_1_camman"
        L11_2 = 8.0
        L12_2 = 1.0
        L13_2 = -1
        L14_2 = 51
        L15_2 = 0
        L16_2 = 0
        L17_2 = 0
        L18_2 = 0
        L7_2(L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
        L7_2 = CreateThread
        function L8_2()
          local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
          while true do
            L0_3 = IsEntityPlayingAnim
            L1_3 = L5_2
            L2_3 = "missfinale_c2mcs_1"
            L3_3 = "fin_c2_mcs_1_camman"
            L4_3 = 3
            L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3)
            if not L0_3 then
              L0_3 = TaskPlayAnim
              L1_3 = L5_2
              L2_3 = "missfinale_c2mcs_1"
              L3_3 = "fin_c2_mcs_1_camman"
              L4_3 = 8.0
              L5_3 = 1.0
              L6_3 = -1
              L7_3 = 51
              L8_3 = 0
              L9_3 = 0
              L10_3 = 0
              L11_3 = 0
              L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
            end
            L0_3 = isCarrying
            if false == L0_3 then
              L0_3 = ClearPedTasksImmediately
              L1_3 = PlayerPedId
              L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3 = L1_3()
              L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
              L0_3 = DetachEntity
              L1_3 = PlayerPedId
              L1_3 = L1_3()
              L2_3 = true
              L3_3 = false
              L0_3(L1_3, L2_3, L3_3)
              break
            end
            L0_3 = IsControlJustPressed
            L1_3 = 0
            L2_3 = 73
            L0_3 = L0_3(L1_3, L2_3)
            if L0_3 then
              isCarrying = false
              L0_3 = ClearPedTasksImmediately
              L1_3 = PlayerPedId
              L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3 = L1_3()
              L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3)
              L0_3 = DetachEntity
              L1_3 = L5_2
              L2_3 = true
              L3_3 = false
              L0_3(L1_3, L2_3, L3_3)
              L0_3 = lib
              L0_3 = L0_3.getClosestPlayer
              L1_3 = GetEntityCoords
              L2_3 = L5_2
              L1_3 = L1_3(L2_3)
              L2_3 = 3.0
              L3_3 = false
              L0_3 = L0_3(L1_3, L2_3, L3_3)
              L1_3 = A0_2.PlayerId
              if L1_3 then
                L1_3 = TriggerServerEvent
                L2_3 = "osp_ambulance:StopCarrySv"
                L3_3 = A0_2.PlayerId
                L1_3(L2_3, L3_3)
              end
              break
            end
            L0_3 = Wait
            L1_3 = 25
            L0_3(L1_3)
          end
        end
        L7_2(L8_2)
      else
        L7_2 = SendTextMessage
        L8_2 = lang
        L8_2 = L8_2.interactions
        L8_2 = L8_2.medicalHeader
        L9_2 = lang
        L9_2 = L9_2.error
        L9_2 = L9_2.no_player
        L10_2 = 5000
        L11_2 = "error"
        L7_2(L8_2, L9_2, L10_2, L11_2)
      end
    end
  else
    isCarrying = false
    L6_2 = ClearPedTasksImmediately
    L7_2 = PlayerPedId
    L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L7_2()
    L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
    L6_2 = DetachEntity
    L7_2 = L5_2
    L8_2 = true
    L9_2 = false
    L6_2(L7_2, L8_2, L9_2)
    L6_2 = lib
    L6_2 = L6_2.getClosestPlayer
    L7_2 = GetEntityCoords
    L8_2 = L5_2
    L7_2 = L7_2(L8_2)
    L8_2 = 3.0
    L9_2 = false
    L6_2 = L6_2(L7_2, L8_2, L9_2)
    L7_2 = A0_2.PlayerId
    if L7_2 then
      L7_2 = TriggerServerEvent
      L8_2 = "osp_ambulance:StopCarrySv"
      L9_2 = A0_2.PlayerId
      L7_2(L8_2, L9_2)
    end
  end
end
L1_1(L2_1, L3_1)
putInVehicle = false
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:PutInCl"
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = GetEntityCoords
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  L2_2 = lib
  L2_2 = L2_2.getClosestVehicle
  L3_2 = L1_2
  L4_2 = 5.0
  L5_2 = true
  L2_2 = L2_2(L3_2, L4_2, L5_2)
  L3_2 = DoesEntityExist
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if L3_2 then
    L3_2 = GetVehicleMaxNumberOfPassengers
    L4_2 = L2_2
    L3_2, L4_2 = L3_2(L4_2)
    L5_2 = 1
    L6_2 = 0
    L7_2 = -1
    for L8_2 = L5_2, L6_2, L7_2 do
      L9_2 = IsVehicleSeatFree
      L10_2 = L2_2
      L11_2 = L8_2
      L9_2 = L9_2(L10_2, L11_2)
      if L9_2 then
        L4_2 = L8_2
        break
      end
    end
    if L4_2 then
      L5_2 = TaskWarpPedIntoVehicle
      L6_2 = L0_2
      L7_2 = L2_2
      L8_2 = L4_2
      L5_2(L6_2, L7_2, L8_2)
      putInVehicle = true
    end
  end
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "PutIn"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "osp_ambulance:GetTime"
  L3_2 = 1000
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    time = L1_2
  end
  L2_2 = Config
  L2_2 = L2_2.ModularAccessLocks
  L2_2 = L2_2.transportation
  if L2_2 then
    L2_2 = IsAuthorized
    L2_2 = L2_2()
    if not L2_2 then
      L2_2 = SendTextMessage
      L3_2 = lang
      L3_2 = L3_2.interactions
      L3_2 = L3_2.medicalHeader
      L4_2 = lang
      L4_2 = L4_2.error
      L4_2 = L4_2.not_authorized
      L5_2 = 5000
      L6_2 = "error"
      L2_2(L3_2, L4_2, L5_2, L6_2)
      return
    end
  end
  L2_2 = getPlayerDistance
  L3_2 = A0_2.PlayerId
  L2_2 = L2_2(L3_2)
  L3_2 = Config
  L3_2 = L3_2.MedicalMenuMaxDistance
  if L2_2 >= L3_2 then
    L3_2 = SendTextMessage
    L4_2 = lang
    L4_2 = L4_2.interactions
    L4_2 = L4_2.medicalHeader
    L5_2 = lang
    L5_2 = L5_2.error
    L5_2 = L5_2.player_too_far_away
    L6_2 = 5000
    L7_2 = "error"
    L3_2(L4_2, L5_2, L6_2, L7_2)
    return
  end
  L3_2 = Player
  L4_2 = A0_2.PlayerId
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2.state
  L4_2 = L4_2.BodyDamage
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  L6_2 = SetNuiFocus
  L7_2 = false
  L8_2 = false
  L6_2(L7_2, L8_2)
  L6_2 = SendNUIMessage
  L7_2 = {}
  L7_2.display = false
  L6_2(L7_2)
  L6_2 = A0_2.PlayerId
  L7_2 = GetPlayerServerId
  L8_2 = PlayerId
  L8_2, L9_2, L10_2 = L8_2()
  L7_2 = L7_2(L8_2, L9_2, L10_2)
  if L6_2 == L7_2 then
    L6_2 = SendTextMessage
    L7_2 = lang
    L7_2 = L7_2.interactions
    L7_2 = L7_2.medicalHeader
    L8_2 = lang
    L8_2 = L8_2.error
    L8_2 = L8_2.you_cant_interact_with_yourself
    L9_2 = 5000
    L10_2 = "error"
    L6_2(L7_2, L8_2, L9_2, L10_2)
    return
  end
  L6_2 = L4_2.Conscious
  if not L6_2 then
    L6_2 = L4_2.inBodybag
    if not L6_2 then
      L6_2 = lib
      L6_2 = L6_2.getClosestPlayer
      L7_2 = GetEntityCoords
      L8_2 = L5_2
      L7_2 = L7_2(L8_2)
      L8_2 = 3.0
      L9_2 = true
      L6_2 = L6_2(L7_2, L8_2, L9_2)
      L7_2 = A0_2.PlayerId
      if L7_2 then
        L7_2 = isCarrying
        if L7_2 then
          isCarrying = false
          L7_2 = ClearPedTasksImmediately
          L8_2 = PlayerPedId
          L8_2, L9_2, L10_2 = L8_2()
          L7_2(L8_2, L9_2, L10_2)
          L7_2 = DetachEntity
          L8_2 = L5_2
          L9_2 = true
          L10_2 = false
          L7_2(L8_2, L9_2, L10_2)
          L7_2 = lib
          L7_2 = L7_2.getClosestPlayer
          L8_2 = GetEntityCoords
          L9_2 = L5_2
          L8_2 = L8_2(L9_2)
          L9_2 = 3.0
          L10_2 = false
          L7_2 = L7_2(L8_2, L9_2, L10_2)
          L8_2 = A0_2.PlayerId
          if L8_2 then
            L8_2 = TriggerServerEvent
            L9_2 = "osp_ambulance:StopCarrySv"
            L10_2 = A0_2.PlayerId
            L8_2(L9_2, L10_2)
          end
        end
        L7_2 = Wait
        L8_2 = 200
        L7_2(L8_2)
        L7_2 = TriggerServerEvent
        L8_2 = "osp_ambulance:PutInSv"
        L9_2 = A0_2.PlayerId
        L7_2(L8_2, L9_2)
      end
  end
  else
    L6_2 = SendTextMessage
    L7_2 = lang
    L7_2 = L7_2.interactions
    L7_2 = L7_2.medicalHeader
    L8_2 = lang
    L8_2 = L8_2.error
    L8_2 = L8_2.not_conscious
    L9_2 = 5000
    L10_2 = "error"
    L6_2(L7_2, L8_2, L9_2, L10_2)
  end
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:GetOutCl"
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  putInVehicle = false
  L1_2 = IsPedSittingInAnyVehicle
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if L1_2 then
    L1_2 = GetVehiclePedIsIn
    L2_2 = L0_2
    L3_2 = false
    L1_2 = L1_2(L2_2, L3_2)
    L2_2 = TaskLeaveVehicle
    L3_2 = L0_2
    L4_2 = L1_2
    L5_2 = 16
    L2_2(L3_2, L4_2, L5_2)
    L2_2 = Wait
    L3_2 = 100
    L2_2(L3_2)
    L2_2 = GetEntityCoords
    L3_2 = L0_2
    L2_2 = L2_2(L3_2)
    L3_2 = NetworkResurrectLocalPlayer
    L4_2 = L2_2.x
    L5_2 = L2_2.y
    L6_2 = L2_2.z
    L7_2 = GetEntityHeading
    L8_2 = L0_2
    L7_2 = L7_2(L8_2)
    L8_2 = true
    L9_2 = false
    L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  end
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "GetOut"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "osp_ambulance:GetTime"
  L3_2 = 1000
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    time = L1_2
  end
  L2_2 = Config
  L2_2 = L2_2.ModularAccessLocks
  L2_2 = L2_2.transportation
  if L2_2 then
    L2_2 = IsAuthorized
    L2_2 = L2_2()
    if not L2_2 then
      L2_2 = SendTextMessage
      L3_2 = lang
      L3_2 = L3_2.interactions
      L3_2 = L3_2.medicalHeader
      L4_2 = lang
      L4_2 = L4_2.error
      L4_2 = L4_2.not_authorized
      L5_2 = 5000
      L6_2 = "error"
      L2_2(L3_2, L4_2, L5_2, L6_2)
      return
    end
  end
  L2_2 = getPlayerDistance
  L3_2 = A0_2.PlayerId
  L2_2 = L2_2(L3_2)
  L3_2 = Config
  L3_2 = L3_2.MedicalMenuMaxDistance
  if L2_2 >= L3_2 then
    L3_2 = SendTextMessage
    L4_2 = lang
    L4_2 = L4_2.interactions
    L4_2 = L4_2.medicalHeader
    L5_2 = lang
    L5_2 = L5_2.error
    L5_2 = L5_2.player_too_far_away
    L6_2 = 5000
    L7_2 = "error"
    L3_2(L4_2, L5_2, L6_2, L7_2)
    return
  end
  L3_2 = Player
  L4_2 = A0_2.PlayerId
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2.state
  L4_2 = L4_2.BodyDamage
  L5_2 = PlayerPedId
  L5_2 = L5_2()
  L6_2 = SetNuiFocus
  L7_2 = false
  L8_2 = false
  L6_2(L7_2, L8_2)
  L6_2 = SendNUIMessage
  L7_2 = {}
  L7_2.display = false
  L6_2(L7_2)
  L6_2 = L4_2.Conscious
  if not L6_2 then
    L6_2 = L4_2.inBodybag
    if not L6_2 then
      L6_2 = lib
      L6_2 = L6_2.getClosestPlayer
      L7_2 = GetEntityCoords
      L8_2 = L5_2
      L7_2 = L7_2(L8_2)
      L8_2 = 3.0
      L9_2 = true
      L6_2 = L6_2(L7_2, L8_2, L9_2)
      L7_2 = A0_2.PlayerId
      if L7_2 then
        L7_2 = TriggerServerEvent
        L8_2 = "osp_ambulance:GetOutSv"
        L9_2 = A0_2.PlayerId
        L7_2(L8_2, L9_2)
      end
  end
  else
    L6_2 = SendTextMessage
    L7_2 = lang
    L7_2 = L7_2.interactions
    L7_2 = L7_2.medicalHeader
    L8_2 = lang
    L8_2 = L8_2.error
    L8_2 = L8_2.not_conscious
    L9_2 = 5000
    L10_2 = "error"
    L6_2(L7_2, L8_2, L9_2, L10_2)
  end
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "Bodybag"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "osp_ambulance:GetTime"
  L3_2 = 1000
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    time = L1_2
  end
  L2_2 = Config
  L2_2 = L2_2.ModularAccessLocks
  L2_2 = L2_2.bodybag
  if L2_2 then
    L2_2 = IsAuthorized
    L2_2 = L2_2()
    if not L2_2 then
      L2_2 = SendTextMessage
      L3_2 = lang
      L3_2 = L3_2.interactions
      L3_2 = L3_2.medicalHeader
      L4_2 = lang
      L4_2 = L4_2.error
      L4_2 = L4_2.not_authorized
      L5_2 = 5000
      L6_2 = "error"
      L2_2(L3_2, L4_2, L5_2, L6_2)
      return
    end
  end
  L2_2 = getPlayerDistance
  L3_2 = A0_2.PlayerId
  L2_2 = L2_2(L3_2)
  L3_2 = Config
  L3_2 = L3_2.MedicalMenuMaxDistance
  if L2_2 >= L3_2 then
    L3_2 = SendTextMessage
    L4_2 = lang
    L4_2 = L4_2.interactions
    L4_2 = L4_2.medicalHeader
    L5_2 = lang
    L5_2 = L5_2.error
    L5_2 = L5_2.player_too_far_away
    L6_2 = 5000
    L7_2 = "error"
    L3_2(L4_2, L5_2, L6_2, L7_2)
    return
  end
  L3_2 = Player
  L4_2 = A0_2.PlayerId
  L3_2 = L3_2(L4_2)
  L4_2 = L3_2.state
  L4_2 = L4_2.BodyDamage
  L5_2 = L4_2.isDead
  if not L5_2 then
    L5_2 = SendTextMessage
    L6_2 = lang
    L6_2 = L6_2.interactions
    L6_2 = L6_2.medicalHeader
    L7_2 = lang
    L7_2 = L7_2.update1
    L7_2 = L7_2.not_dead
    L8_2 = 5000
    L9_2 = "error"
    L5_2(L6_2, L7_2, L8_2, L9_2)
    return
  end
  L5_2 = SetNuiFocus
  L6_2 = false
  L7_2 = false
  L5_2(L6_2, L7_2)
  L5_2 = SendNUIMessage
  L6_2 = {}
  L6_2.display = false
  L5_2(L6_2)
  L5_2 = L4_2.isInBodybag
  if L5_2 then
    L5_2 = TriggerServerEvent
    L6_2 = "osp_ambulance:RemoveBodybagSv"
    L7_2 = A0_2.PlayerId
    L5_2(L6_2, L7_2)
  else
    L5_2 = L4_2.isDead
    if L5_2 then
      L5_2 = TriggerServerEvent
      L6_2 = "osp_ambulance:removeItem"
      L7_2 = "bodybag"
      L8_2 = 1
      L5_2(L6_2, L7_2, L8_2)
      L5_2 = Config
      L5_2 = L5_2.InteractionDict
      L6_2 = Config
      L6_2 = L6_2.InteractionAnim
      L7_2 = ProgressBar
      L8_2 = lang
      L8_2 = L8_2.update1
      L8_2 = L8_2.stowing_bodybag
      L9_2 = Config
      L9_2 = L9_2.BodybagTime
      L10_2 = L5_2
      L11_2 = L6_2
      L7_2(L8_2, L9_2, L10_2, L11_2)
      L7_2 = SetCurrentPedWeapon
      L8_2 = PlayerPedId
      L8_2 = L8_2()
      L9_2 = GetHashKey
      L10_2 = "WEAPON_UNARMED"
      L9_2 = L9_2(L10_2)
      L10_2 = true
      L7_2(L8_2, L9_2, L10_2)
      L7_2 = TriggerServerEvent
      L8_2 = "osp_ambulance:BodybagSv"
      L9_2 = A0_2.PlayerId
      L7_2(L8_2, L9_2)
    end
  end
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:BodybagCl"
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2
  L0_2 = "xm_prop_body_bag"
  L1_2 = "xm_prop_body_bag"
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = GetEntityCoords
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L4_2 = BodyDamage
  L4_2 = L4_2.inBodyBag
  if not L4_2 then
    L4_2 = ClearPedTasksImmediately
    L5_2 = L2_2
    L4_2(L5_2)
    L4_2 = RequestModel
    L5_2 = L0_2
    L4_2(L5_2)
    while true do
      L4_2 = HasModelLoaded
      L5_2 = L0_2
      L4_2 = L4_2(L5_2)
      if L4_2 then
        break
      end
      L4_2 = Wait
      L5_2 = 1
      L4_2(L5_2)
    end
    L4_2 = CreateObject
    L5_2 = GetHashKey
    L6_2 = L1_2
    L5_2 = L5_2(L6_2)
    L6_2 = L3_2.x
    L7_2 = L3_2.y
    L8_2 = L3_2.z
    L9_2 = true
    L10_2 = true
    L11_2 = true
    L4_2 = L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2)
    bodyBag = L4_2
    L4_2 = SetEntityVisible
    L5_2 = L2_2
    L6_2 = false
    L7_2 = false
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = AttachEntityToEntity
    L5_2 = L2_2
    L6_2 = bodyBag
    L7_2 = 0
    L8_2 = 0.0
    L9_2 = 0.0
    L10_2 = 0.5
    L11_2 = 0.0
    L12_2 = 0.0
    L13_2 = 0.0
    L14_2 = false
    L15_2 = false
    L16_2 = false
    L17_2 = false
    L18_2 = 20
    L19_2 = true
    L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2)
    L4_2 = PlaceObjectOnGroundProperly
    L5_2 = bodyBag
    L4_2(L5_2)
    L4_2 = SetEntityVisible
    L5_2 = bodyBag
    L6_2 = true
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = BodyDamage
    L5_2 = NetworkGetNetworkIdFromEntity
    L6_2 = bodyBag
    L5_2 = L5_2(L6_2)
    L4_2.inBodyBag = L5_2
    L4_2 = BodyDamage
    L4_2.isInBodybag = true
    L4_2 = LocalPlayer
    L4_2 = L4_2.state
    L5_2 = L4_2
    L4_2 = L4_2.set
    L6_2 = "BodyDamage"
    L7_2 = BodyDamage
    L8_2 = true
    L4_2(L5_2, L6_2, L7_2, L8_2)
    L4_2 = CreateThread
    function L5_2()
      local L0_3, L1_3
      while true do
        L0_3 = disabledControls
        L0_3()
        L0_3 = BodyDamage
        L0_3 = L0_3.isInBodybag
        if not L0_3 then
          break
        end
        L0_3 = Wait
        L1_3 = 1
        L0_3(L1_3)
      end
    end
    L4_2(L5_2)
  end
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNetEvent
L2_1 = "osp_ambulance:RemoveBodybagCl"
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = SetEntityVisible
  L2_2 = L0_2
  L3_2 = true
  L4_2 = true
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = DetachEntity
  L2_2 = bodyBag
  L1_2(L2_2)
  L1_2 = DeleteEntity
  L2_2 = bodyBag
  L1_2(L2_2)
  L1_2 = ClearPedTasksImmediately
  L2_2 = L0_2
  L1_2(L2_2)
  L1_2 = BodyDamage
  L1_2.inBodyBag = false
  L1_2 = BodyDamage
  L1_2.isInBodybag = false
  L1_2 = LocalPlayer
  L1_2 = L1_2.state
  L2_2 = L1_2
  L1_2 = L1_2.set
  L3_2 = "BodyDamage"
  L4_2 = BodyDamage
  L5_2 = true
  L1_2(L2_2, L3_2, L4_2, L5_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "ReviveKit"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "osp_ambulance:GetTime"
  L3_2 = 1000
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    time = L1_2
  end
  L2_2 = Config
  L2_2 = L2_2.ModularAccessLocks
  L2_2 = L2_2.revivekit
  if L2_2 then
    L2_2 = IsAuthorized
    L2_2 = L2_2()
    if not L2_2 then
      L2_2 = SendTextMessage
      L3_2 = lang
      L3_2 = L3_2.interactions
      L3_2 = L3_2.medicalHeader
      L4_2 = lang
      L4_2 = L4_2.error
      L4_2 = L4_2.not_authorized
      L5_2 = 5000
      L6_2 = "error"
      L2_2(L3_2, L4_2, L5_2, L6_2)
      return
    end
  end
  L2_2 = BodyDamage
  L2_2 = L2_2.isDead
  if not L2_2 then
    L2_2 = BodyDamage
    L2_2 = L2_2.inLastStand
    if not L2_2 then
      goto lbl_48
    end
  end
  L2_2 = SetNuiFocus
  L3_2 = false
  L4_2 = false
  L2_2(L3_2, L4_2)
  L2_2 = SendNUIMessage
  L3_2 = {}
  L3_2.display = false
  L2_2(L3_2)
  do return end
  ::lbl_48::
  L2_2 = SetNuiFocus
  L3_2 = false
  L4_2 = false
  L2_2(L3_2, L4_2)
  L2_2 = SendNUIMessage
  L3_2 = {}
  L3_2.display = false
  L2_2(L3_2)
  L2_2 = TriggerServerEvent
  L3_2 = "osp_ambulance:removeItem"
  L4_2 = "revivekit"
  L5_2 = 1
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = Config
  L2_2 = L2_2.InteractionDict
  L3_2 = Config
  L3_2 = L3_2.InteractionAnim
  L4_2 = ProgressBar
  L5_2 = lang
  L5_2 = L5_2.progress
  L5_2 = L5_2.reviving_player
  L6_2 = Config
  L6_2 = L6_2.ReviveKitTime
  L7_2 = L2_2
  L8_2 = L3_2
  L4_2(L5_2, L6_2, L7_2, L8_2)
  L4_2 = TriggerServerEvent
  L5_2 = "osp_ambulance:revive"
  L6_2 = A0_2.PlayerId
  L4_2(L5_2, L6_2)
end
L1_1(L2_1, L3_1)
L1_1 = RegisterNUICallback
L2_1 = "BlackoutRagdoll"
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L1_2 = lib
  L1_2 = L1_2.callback
  L1_2 = L1_2.await
  L2_2 = "osp_ambulance:GetTime"
  L3_2 = 1000
  L1_2 = L1_2(L2_2, L3_2)
  if L1_2 then
    time = L1_2
  end
  L2_2 = PlayerPedId
  L2_2 = L2_2()
  L3_2 = IsPedRagdoll
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  if not L3_2 then
    L3_2 = IsPedOnFoot
    L4_2 = L2_2
    L3_2 = L3_2(L4_2)
    if L3_2 then
      L3_2 = ShakeGameplayCam
      L4_2 = "SMALL_EXPLOSION_SHAKE"
      L5_2 = Config
      L5_2 = L5_2.CameraShakeIntensity
      L3_2(L4_2, L5_2)
      L3_2 = SetPedToRagdollWithFall
      L4_2 = L2_2
      L5_2 = 1500
      L6_2 = 2000
      L7_2 = 1
      L8_2 = GetEntityForwardVector
      L9_2 = L2_2
      L8_2 = L8_2(L9_2)
      L9_2 = 1.0
      L10_2 = 0.0
      L11_2 = 0.0
      L12_2 = 0.0
      L13_2 = 0.0
      L14_2 = 0.0
      L15_2 = 0.0
      L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2)
    end
  end
  L3_2 = CreateThread
  function L4_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    while true do
      L0_3 = BodyDamage
      L0_3 = L0_3.isDead
      if not L0_3 then
        L0_3 = BodyDamage
        L0_3 = L0_3.inLastStand
        if not L0_3 then
          goto lbl_15
        end
      end
      L0_3 = SendNUIMessage
      L1_3 = {}
      L1_3.blackout = 4
      L0_3(L1_3)
      do break end
      ::lbl_15::
      L0_3 = BodyDamage
      L0_3 = L0_3.BloodPressure
      L0_3 = L0_3[1]
      if not (L0_3 < 80) then
        L0_3 = BodyDamage
        L0_3 = L0_3.BloodPressure
        L0_3 = L0_3[2]
        if not (L0_3 < 50) then
          L0_3 = BodyDamage
          L0_3 = L0_3.BloodPressure
          L0_3 = L0_3[1]
          L1_3 = 140
          if not (L0_3 > L1_3) then
            L0_3 = BodyDamage
            L0_3 = L0_3.BloodPressure
            L0_3 = L0_3[2]
          end
        end
      end
      if L0_3 > 100 then
        L0_3 = BodyDamage
        L0_3.Conscious = false
        L0_3 = IsPedOnFoot
        L1_3 = L2_2
        L0_3 = L0_3(L1_3)
        if L0_3 then
          L0_3 = SetPedToRagdoll
          L1_3 = L2_2
          L2_3 = 1000
          L3_3 = 1000
          L4_3 = 0
          L5_3 = 0
          L6_3 = 0
          L7_3 = 0
          L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
        end
        L0_3 = DisableAllControlActions
        L1_3 = 0
        L0_3(L1_3)
        L0_3 = IsPlayerFreeAiming
        L1_3 = PlayerId
        L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3 = L1_3()
        L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3)
        if L0_3 then
          L0_3 = DisablePlayerFiring
          L1_3 = PlayerId
          L1_3 = L1_3()
          L2_3 = true
          L0_3(L1_3, L2_3)
        end
      else
        break
      end
      L0_3 = Wait
      L1_3 = 10
      L0_3(L1_3)
    end
  end
  L3_2(L4_2)
end
L1_1(L2_1, L3_1)
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2
  L0_2 = NearPlayers
  if not L0_2 then
    L0_2 = {}
  end
  NearPlayers = L0_2
  L0_2 = NearPlayers
  L1_2 = NearPlayers
  L1_2 = L1_2.ServerId
  if not L1_2 then
    L1_2 = {}
  end
  L0_2.ServerId = L1_2
  L0_2 = NearPlayers
  L1_2 = NearPlayers
  L1_2 = L1_2.PlayerName
  if not L1_2 then
    L1_2 = {}
  end
  L0_2.PlayerName = L1_2
  L0_2 = GetPlayers
  L0_2 = L0_2()
  L1_2 = -1
  L2_2 = -1
  L3_2 = PlayerPedId
  L3_2 = L3_2()
  L4_2 = GetEntityCoords
  L5_2 = L3_2
  L4_2 = L4_2(L5_2)
  L5_2 = DebugPrint
  L6_2 = "Getting nearby players"
  L5_2(L6_2)
  L5_2 = ipairs
  L6_2 = L0_2
  L5_2, L6_2, L7_2, L8_2 = L5_2(L6_2)
  for L9_2, L10_2 in L5_2, L6_2, L7_2, L8_2 do
    L11_2 = GetPlayerPed
    L12_2 = L10_2
    L11_2 = L11_2(L12_2)
    L12_2 = GetEntityCoords
    L13_2 = L11_2
    L12_2 = L12_2(L13_2)
    L12_2 = L4_2 - L12_2
    L12_2 = #L12_2
    L13_2 = DebugPrint
    L14_2 = "ecg info: "
    L15_2 = L0_2
    L16_2 = L11_2
    L17_2 = L12_2
    L18_2 = L10_2
    L19_2 = L4_2
    L20_2 = GetEntityCoords
    L21_2 = L11_2
    L20_2 = L20_2(L21_2)
    L21_2 = GetPlayerName
    L22_2 = L10_2
    L21_2, L22_2 = L21_2(L22_2)
    L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
    if L12_2 < 5.0 then
      L13_2 = NearPlayers
      L13_2 = L13_2.ServerId
      L14_2 = GetPlayerServerId
      L15_2 = NetworkGetPlayerIndexFromPed
      L16_2 = L11_2
      L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L15_2(L16_2)
      L14_2 = L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
      L13_2[L9_2] = L14_2
      L13_2 = NearPlayers
      L13_2 = L13_2.PlayerName
      L14_2 = GetPlayerName
      L15_2 = L10_2
      L14_2 = L14_2(L15_2)
      L13_2[L9_2] = L14_2
      L13_2 = DebugPrint
      L14_2 = GetPlayerServerId
      L15_2 = NetworkGetPlayerIndexFromPed
      L16_2 = L11_2
      L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L15_2(L16_2)
      L14_2 = L14_2(L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
      L15_2 = GetPlayerName
      L16_2 = L10_2
      L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2 = L15_2(L16_2)
      L13_2(L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2, L22_2)
    end
  end
  L5_2 = DebugPrint
  L6_2 = "Got all nearby players"
  L7_2 = L0_2
  L8_2 = NearPlayers
  L9_2 = NearPlayers
  L9_2 = L9_2.PlayerName
  L10_2 = NearPlayers
  L10_2 = L10_2.PlayerName
  L10_2 = #L10_2
  L9_2 = L9_2[L10_2]
  L5_2(L6_2, L7_2, L8_2, L9_2)
  L5_2 = NearPlayers
  return L5_2
end
GetNearbyPlayers = L1_1
function L1_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L3_2 = GetEntityCoords
  L4_2 = PlayerPedId
  L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2 = L4_2()
  L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L4_2 = nil
  L5_2 = A1_2
  if A2_2 then
    L6_2 = pairs
    L7_2 = Config
    L7_2 = L7_2.Hospitals
    L7_2 = L7_2[L5_2]
    L7_2 = L7_2.beds
    L6_2, L7_2, L8_2, L9_2 = L6_2(L7_2)
    for L10_2, L11_2 in L6_2, L7_2, L8_2, L9_2 do
      L12_2 = Config
      L12_2 = L12_2.Hospitals
      L12_2 = L12_2[L5_2]
      L12_2 = L12_2.beds
      L12_2 = L12_2[L10_2]
      L12_2 = L12_2.taken
      if not L12_2 then
        L12_2 = Config
        L12_2 = L12_2.Hospitals
        L12_2 = L12_2[L5_2]
        L12_2 = L12_2.beds
        L12_2 = L12_2[L10_2]
        L12_2 = L12_2.lockedBed
        if not L12_2 then
          L4_2 = L10_2
          break
        end
      end
    end
  elseif nil == A0_2 then
    L6_2 = pairs
    L7_2 = Config
    L7_2 = L7_2.Hospitals
    L7_2 = L7_2[L5_2]
    L7_2 = L7_2.beds
    L6_2, L7_2, L8_2, L9_2 = L6_2(L7_2)
    for L10_2, L11_2 in L6_2, L7_2, L8_2, L9_2 do
      L12_2 = Config
      L12_2 = L12_2.Hospitals
      L12_2 = L12_2[L5_2]
      L12_2 = L12_2.beds
      L12_2 = L12_2[L10_2]
      L12_2 = L12_2.taken
      if not L12_2 then
        L4_2 = L10_2
        break
      end
    end
  elseif nil ~= A0_2 then
    L6_2 = Config
    L6_2 = L6_2.Hospitals
    L6_2 = L6_2[L5_2]
    L6_2 = L6_2.beds
    L6_2 = L6_2[A0_2]
    L6_2 = L6_2.taken
    if not L6_2 then
      L4_2 = A0_2
    end
  end
  L6_2 = L4_2
  L7_2 = L5_2
  return L6_2, L7_2
end
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = pairs
  L2_2 = Config
  L2_2 = L2_2.Weapons
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = HasPedBeenDamagedByWeapon
    L8_2 = A0_2
    L9_2 = L5_2
    L10_2 = 0
    L7_2 = L7_2(L8_2, L9_2, L10_2)
    if L7_2 then
      return L6_2
    end
  end
  L1_2 = nil
  return L1_2
end
function L3_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2
  L0_2 = GetEntityCoords
  L1_2 = PlayerPedId
  L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2 = L1_2()
  L0_2 = L0_2(L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2)
  L1_2 = nil
  L2_2 = nil
  L3_2 = pairs
  L4_2 = Config
  L4_2 = L4_2.Hospitals
  L3_2, L4_2, L5_2, L6_2 = L3_2(L4_2)
  for L7_2, L8_2 in L3_2, L4_2, L5_2, L6_2 do
    L9_2 = pairs
    L10_2 = L8_2.beds
    L9_2, L10_2, L11_2, L12_2 = L9_2(L10_2)
    for L13_2, L14_2 in L9_2, L10_2, L11_2, L12_2 do
      L15_2 = vector3
      L16_2 = L8_2.beds
      L16_2 = L16_2[L13_2]
      L16_2 = L16_2.coords
      L16_2 = L16_2.x
      L17_2 = L8_2.beds
      L17_2 = L17_2[L13_2]
      L17_2 = L17_2.coords
      L17_2 = L17_2.y
      L18_2 = L8_2.beds
      L18_2 = L18_2[L13_2]
      L18_2 = L18_2.coords
      L18_2 = L18_2.z
      L15_2 = L15_2(L16_2, L17_2, L18_2)
      L15_2 = L0_2 - L15_2
      L15_2 = #L15_2
      if L1_2 then
        if L2_2 > L15_2 then
          L1_2 = L13_2
          L2_2 = L15_2
        end
      else
        L2_2 = L15_2
        L1_2 = L13_2
      end
    end
  end
  L3_2 = closestBed
  if L1_2 ~= L3_2 then
    L3_2 = isInHospitalBed
    if not L3_2 then
      closestBed = L1_2
    end
  end
end
L4_1 = CreateThread
function L5_1()
  local L0_2, L1_2
  while true do
    L0_2 = ProcessRunStuff
    L0_2()
    L0_2 = Wait
    L1_2 = 5000
    L0_2(L1_2)
  end
end
L4_1(L5_1)
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = "blood_throat"
  L1_2 = "core"
  L2_2 = HasNamedPtfxAssetLoaded
  L3_2 = L0_2
  L2_2 = L2_2(L3_2)
  if not L2_2 then
    L2_2 = RequestNamedPtfxAsset
    L3_2 = L1_2
    L2_2(L3_2)
    while true do
      L2_2 = HasNamedPtfxAssetLoaded
      L3_2 = L1_2
      L2_2 = L2_2(L3_2)
      if L2_2 then
        break
      end
      L2_2 = Wait
      L3_2 = 10
      L2_2(L3_2)
    end
  end
  L2_2 = BodyDamage
  L2_2 = L2_2.BodyPartDamage
  L2_2 = L2_2.Bleeding
  L2_2 = L2_2.Larm
  if not (L2_2 > 0) then
    L2_2 = BodyDamage
    L2_2 = L2_2.BodyPartDamage
    L2_2 = L2_2.Bleeding
    L2_2 = L2_2.Rarm
    if not (L2_2 > 0) then
      L2_2 = BodyDamage
      L2_2 = L2_2.BodyPartDamage
      L2_2 = L2_2.Bleeding
      L2_2 = L2_2.Lleg
      if not (L2_2 > 0) then
        L2_2 = BodyDamage
        L2_2 = L2_2.BodyPartDamage
        L2_2 = L2_2.Bleeding
        L2_2 = L2_2.Rleg
        if not (L2_2 > 0) then
          goto lbl_46
        end
      end
    end
  end
  L2_2 = CreateBloodDropEvidence
  L2_2()
  ::lbl_46::
  L2_2 = BodyDamage
  L2_2 = L2_2.BodyPartDamage
  L2_2 = L2_2.Bleeding
  L2_2 = L2_2.Larm
  if L2_2 > 0 then
    L2_2 = math
    L2_2 = L2_2.random
    L3_2 = 100
    L4_2 = 700
    L2_2 = L2_2(L3_2, L4_2)
    L3_2 = Wait
    L4_2 = L2_2
    L3_2(L4_2)
    L3_2 = CreateThread
    function L4_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
      L0_3 = UseParticleFxAsset
      L1_3 = L1_2
      L0_3(L1_3)
      L0_3 = _ENV
      L1_3 = "StartNetworkedParticleFxNonLoopedOnEntityBone"
      L0_3 = L0_3[L1_3]
      L1_3 = L0_2
      L2_3 = PlayerPedId
      L2_3 = L2_3()
      L3_3 = 0.0
      L4_3 = 0.0
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = -90.0
      L9_3 = GetPedBoneIndex
      L10_3 = PlayerPedId
      L10_3 = L10_3()
      L11_3 = 61163
      L9_3 = L9_3(L10_3, L11_3)
      L10_3 = 0.7
      L11_3 = false
      L12_3 = false
      L13_3 = false
      L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      L1_3 = Wait
      L2_3 = 300
      L1_3(L2_3)
      L1_3 = _ENV
      L2_3 = "StartNetworkedParticleFxNonLoopedOnEntityBone"
      L1_3 = L1_3[L2_3]
      L2_3 = L0_2
      L3_3 = PlayerPedId
      L3_3 = L3_3()
      L4_3 = 0.0
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = 0.0
      L9_3 = -90.0
      L10_3 = GetPedBoneIndex
      L11_3 = PlayerPedId
      L11_3 = L11_3()
      L12_3 = 61163
      L10_3 = L10_3(L11_3, L12_3)
      L11_3 = 0.7
      L12_3 = false
      L13_3 = false
      L14_3 = false
      L1_3 = L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
      L2_3 = Wait
      L3_3 = 300
      L2_3(L3_3)
      L2_3 = _ENV
      L3_3 = "StartNetworkedParticleFxNonLoopedOnEntityBone"
      L2_3 = L2_3[L3_3]
      L3_3 = L0_2
      L4_3 = PlayerPedId
      L4_3 = L4_3()
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = 0.0
      L9_3 = 0.0
      L10_3 = -90.0
      L11_3 = GetPedBoneIndex
      L12_3 = PlayerPedId
      L12_3 = L12_3()
      L13_3 = 61163
      L11_3 = L11_3(L12_3, L13_3)
      L12_3 = 0.7
      L13_3 = false
      L14_3 = false
      L15_3 = false
      L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
    end
    L3_2(L4_2)
  end
  L2_2 = BodyDamage
  L2_2 = L2_2.BodyPartDamage
  L2_2 = L2_2.Bleeding
  L2_2 = L2_2.Rarm
  if L2_2 > 0 then
    L2_2 = math
    L2_2 = L2_2.random
    L3_2 = 100
    L4_2 = 700
    L2_2 = L2_2(L3_2, L4_2)
    L3_2 = Wait
    L4_2 = L2_2
    L3_2(L4_2)
    L3_2 = CreateThread
    function L4_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
      L0_3 = UseParticleFxAsset
      L1_3 = L1_2
      L0_3(L1_3)
      L0_3 = _ENV
      L1_3 = "StartNetworkedParticleFxNonLoopedOnEntityBone"
      L0_3 = L0_3[L1_3]
      L1_3 = L0_2
      L2_3 = PlayerPedId
      L2_3 = L2_3()
      L3_3 = 0.0
      L4_3 = 0.0
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = -90.0
      L9_3 = GetPedBoneIndex
      L10_3 = PlayerPedId
      L10_3 = L10_3()
      L11_3 = 28252
      L9_3 = L9_3(L10_3, L11_3)
      L10_3 = 0.7
      L11_3 = false
      L12_3 = false
      L13_3 = false
      L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      L1_3 = Wait
      L2_3 = 300
      L1_3(L2_3)
      L1_3 = _ENV
      L2_3 = "StartNetworkedParticleFxNonLoopedOnEntityBone"
      L1_3 = L1_3[L2_3]
      L2_3 = L0_2
      L3_3 = PlayerPedId
      L3_3 = L3_3()
      L4_3 = 0.0
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = 0.0
      L9_3 = -90.0
      L10_3 = GetPedBoneIndex
      L11_3 = PlayerPedId
      L11_3 = L11_3()
      L12_3 = 28252
      L10_3 = L10_3(L11_3, L12_3)
      L11_3 = 0.7
      L12_3 = false
      L13_3 = false
      L14_3 = false
      L1_3 = L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
      L2_3 = Wait
      L3_3 = 300
      L2_3(L3_3)
      L2_3 = _ENV
      L3_3 = "StartNetworkedParticleFxNonLoopedOnEntityBone"
      L2_3 = L2_3[L3_3]
      L3_3 = L0_2
      L4_3 = PlayerPedId
      L4_3 = L4_3()
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = 0.0
      L9_3 = 0.0
      L10_3 = -90.0
      L11_3 = GetPedBoneIndex
      L12_3 = PlayerPedId
      L12_3 = L12_3()
      L13_3 = 28252
      L11_3 = L11_3(L12_3, L13_3)
      L12_3 = 0.7
      L13_3 = false
      L14_3 = false
      L15_3 = false
      L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
    end
    L3_2(L4_2)
  end
  L2_2 = BodyDamage
  L2_2 = L2_2.BodyPartDamage
  L2_2 = L2_2.Bleeding
  L2_2 = L2_2.Lleg
  if L2_2 > 0 then
    L2_2 = math
    L2_2 = L2_2.random
    L3_2 = 100
    L4_2 = 700
    L2_2 = L2_2(L3_2, L4_2)
    L3_2 = Wait
    L4_2 = L2_2
    L3_2(L4_2)
    L3_2 = CreateThread
    function L4_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
      L0_3 = UseParticleFxAsset
      L1_3 = L1_2
      L0_3(L1_3)
      L0_3 = _ENV
      L1_3 = "StartNetworkedParticleFxNonLoopedOnEntityBone"
      L0_3 = L0_3[L1_3]
      L1_3 = L0_2
      L2_3 = PlayerPedId
      L2_3 = L2_3()
      L3_3 = 0.0
      L4_3 = 0.0
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = -90.0
      L9_3 = GetPedBoneIndex
      L10_3 = PlayerPedId
      L10_3 = L10_3()
      L11_3 = 58271
      L9_3 = L9_3(L10_3, L11_3)
      L10_3 = 0.7
      L11_3 = false
      L12_3 = false
      L13_3 = false
      L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      L1_3 = Wait
      L2_3 = 300
      L1_3(L2_3)
      L1_3 = _ENV
      L2_3 = "StartNetworkedParticleFxNonLoopedOnEntityBone"
      L1_3 = L1_3[L2_3]
      L2_3 = L0_2
      L3_3 = PlayerPedId
      L3_3 = L3_3()
      L4_3 = 0.0
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = 0.0
      L9_3 = -90.0
      L10_3 = GetPedBoneIndex
      L11_3 = PlayerPedId
      L11_3 = L11_3()
      L12_3 = 58271
      L10_3 = L10_3(L11_3, L12_3)
      L11_3 = 0.7
      L12_3 = false
      L13_3 = false
      L14_3 = false
      L1_3 = L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
      L2_3 = Wait
      L3_3 = 300
      L2_3(L3_3)
      L2_3 = _ENV
      L3_3 = "StartNetworkedParticleFxNonLoopedOnEntityBone"
      L2_3 = L2_3[L3_3]
      L3_3 = L0_2
      L4_3 = PlayerPedId
      L4_3 = L4_3()
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = 0.0
      L9_3 = 0.0
      L10_3 = -90.0
      L11_3 = GetPedBoneIndex
      L12_3 = PlayerPedId
      L12_3 = L12_3()
      L13_3 = 58271
      L11_3 = L11_3(L12_3, L13_3)
      L12_3 = 0.7
      L13_3 = false
      L14_3 = false
      L15_3 = false
      L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
    end
    L3_2(L4_2)
  end
  L2_2 = BodyDamage
  L2_2 = L2_2.BodyPartDamage
  L2_2 = L2_2.Bleeding
  L2_2 = L2_2.Rleg
  if L2_2 > 0 then
    L2_2 = math
    L2_2 = L2_2.random
    L3_2 = 100
    L4_2 = 700
    L2_2 = L2_2(L3_2, L4_2)
    L3_2 = Wait
    L4_2 = L2_2
    L3_2(L4_2)
    L3_2 = CreateThread
    function L4_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3
      L0_3 = UseParticleFxAsset
      L1_3 = L1_2
      L0_3(L1_3)
      L0_3 = _ENV
      L1_3 = "StartNetworkedParticleFxNonLoopedOnEntityBone"
      L0_3 = L0_3[L1_3]
      L1_3 = L0_2
      L2_3 = PlayerPedId
      L2_3 = L2_3()
      L3_3 = 0.0
      L4_3 = 0.0
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = -90.0
      L9_3 = GetPedBoneIndex
      L10_3 = PlayerPedId
      L10_3 = L10_3()
      L11_3 = 51826
      L9_3 = L9_3(L10_3, L11_3)
      L10_3 = 0.7
      L11_3 = false
      L12_3 = false
      L13_3 = false
      L0_3 = L0_3(L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3)
      L1_3 = Wait
      L2_3 = 300
      L1_3(L2_3)
      L1_3 = _ENV
      L2_3 = "StartNetworkedParticleFxNonLoopedOnEntityBone"
      L1_3 = L1_3[L2_3]
      L2_3 = L0_2
      L3_3 = PlayerPedId
      L3_3 = L3_3()
      L4_3 = 0.0
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = 0.0
      L9_3 = -90.0
      L10_3 = GetPedBoneIndex
      L11_3 = PlayerPedId
      L11_3 = L11_3()
      L12_3 = 51826
      L10_3 = L10_3(L11_3, L12_3)
      L11_3 = 0.7
      L12_3 = false
      L13_3 = false
      L14_3 = false
      L1_3 = L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
      L2_3 = Wait
      L3_3 = 300
      L2_3(L3_3)
      L2_3 = _ENV
      L3_3 = "StartNetworkedParticleFxNonLoopedOnEntityBone"
      L2_3 = L2_3[L3_3]
      L3_3 = L0_2
      L4_3 = PlayerPedId
      L4_3 = L4_3()
      L5_3 = 0.0
      L6_3 = 0.0
      L7_3 = 0.0
      L8_3 = 0.0
      L9_3 = 0.0
      L10_3 = -90.0
      L11_3 = GetPedBoneIndex
      L12_3 = PlayerPedId
      L12_3 = L12_3()
      L13_3 = 51826
      L11_3 = L11_3(L12_3, L13_3)
      L12_3 = 0.7
      L13_3 = false
      L14_3 = false
      L15_3 = false
      L2_3 = L2_3(L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3)
    end
    L3_2(L4_2)
  end
end
BleedEffect = L4_1
L4_1 = 0
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = BodyDamage
  L1_2 = L1_2.BodyPartDamage
  L1_2 = L1_2.DamageType
  L1_2 = L1_2.Lleg
  if not (L1_2 > 1) then
    L1_2 = BodyDamage
    L1_2 = L1_2.BodyPartDamage
    L1_2 = L1_2.DamageType
    L1_2 = L1_2.Rleg
    if not (L1_2 > 1) then
      goto lbl_92
    end
  end
  L1_2 = IsPedRagdoll
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if not L1_2 then
    L1_2 = IsPedOnFoot
    L2_2 = L0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      L1_2 = math
      L1_2 = L1_2.random
      L2_2 = 100
      L1_2 = L1_2(L2_2)
      L2_2 = IsPedRunning
      L3_2 = L0_2
      L2_2 = L2_2(L3_2)
      if not L2_2 then
        L2_2 = IsPedSprinting
        L3_2 = L0_2
        L2_2 = L2_2(L3_2)
        if not L2_2 then
          goto lbl_66
        end
      end
      L2_2 = Config
      L2_2 = L2_2.LegInjuryChance
      L2_2 = L2_2.Running
      if L1_2 <= L2_2 then
        L2_2 = ShakeGameplayCam
        L3_2 = "SMALL_EXPLOSION_SHAKE"
        L4_2 = Config
        L4_2 = L4_2.CameraShakeIntensity
        L2_2(L3_2, L4_2)
        L2_2 = SetPedToRagdollWithFall
        L3_2 = L0_2
        L4_2 = 1500
        L5_2 = 2000
        L6_2 = 1
        L7_2 = GetEntityForwardVector
        L8_2 = L0_2
        L7_2 = L7_2(L8_2)
        L8_2 = 1.0
        L9_2 = 0.0
        L10_2 = 0.0
        L11_2 = 0.0
        L12_2 = 0.0
        L13_2 = 0.0
        L14_2 = 0.0
        L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
        goto lbl_92
        ::lbl_66::
        L2_2 = Config
        L2_2 = L2_2.LegInjuryChance
        L2_2 = L2_2.Walking
        if L1_2 <= L2_2 then
          L2_2 = ShakeGameplayCam
          L3_2 = "SMALL_EXPLOSION_SHAKE"
          L4_2 = Config
          L4_2 = L4_2.CameraShakeIntensity
          L2_2(L3_2, L4_2)
          L2_2 = SetPedToRagdollWithFall
          L3_2 = L0_2
          L4_2 = 1500
          L5_2 = 2000
          L6_2 = 1
          L7_2 = GetEntityForwardVector
          L8_2 = L0_2
          L7_2 = L7_2(L8_2)
          L8_2 = 1.0
          L9_2 = 0.0
          L10_2 = 0.0
          L11_2 = 0.0
          L12_2 = 0.0
          L13_2 = 0.0
          L14_2 = 0.0
          L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
        end
      end
    end
  end
  ::lbl_92::
  L1_2 = BodyDamage
  L1_2 = L1_2.BodyPartDamage
  L1_2 = L1_2.DamageType
  L1_2 = L1_2.Larm
  if not (L1_2 > 1) then
    L1_2 = BodyDamage
    L1_2 = L1_2.BodyPartDamage
    L1_2 = L1_2.DamageType
    L1_2 = L1_2.Rarm
    if not (L1_2 > 1) then
      goto lbl_125
    end
  end
  L1_2 = math
  L1_2 = L1_2.random
  L2_2 = 100
  L1_2 = L1_2(L2_2)
  L2_2 = Config
  L2_2 = L2_2.ArmInjuryChance
  if L1_2 <= L2_2 then
    L2_2 = L4_1
    if L2_2 <= 0 then
      L2_2 = 1
      L4_1 = L2_2
      L2_2 = Config
      L2_2 = L2_2.ArmInjuryTimer
      L2_2 = L2_2 * 1000
      L3_2 = CreateThread
      function L4_2()
        local L0_3, L1_3, L2_3, L3_3
        while true do
          L0_3 = IsPedInAnyVehicle
          L1_3 = L0_2
          L2_3 = true
          L0_3 = L0_3(L1_3, L2_3)
          if L0_3 then
            L0_3 = DisableControlAction
            L1_3 = 0
            L2_3 = 63
            L3_3 = true
            L0_3(L1_3, L2_3, L3_3)
            L0_3 = DisableControlAction
            L1_3 = 0
            L2_3 = 64
            L3_3 = true
            L0_3(L1_3, L2_3, L3_3)
          end
          L0_3 = L2_2
          L0_3 = L0_3 - 1
          L2_2 = L0_3
          L0_3 = Wait
          L1_3 = 1
          L0_3(L1_3)
          L0_3 = L2_2
          if L0_3 <= 0 then
            L0_3 = 0
            L4_1 = L0_3
            L0_3 = EnableControlAction
            L1_3 = 0
            L2_3 = 63
            L3_3 = true
            L0_3(L1_3, L2_3, L3_3)
            L0_3 = EnableControlAction
            L1_3 = 0
            L2_3 = 64
            L3_3 = true
            L0_3(L1_3, L2_3, L3_3)
            break
          end
        end
      end
      L3_2(L4_2)
    end
  end
  ::lbl_125::
  L1_2 = BodyDamage
  L1_2 = L1_2.BodyPartDamage
  L1_2 = L1_2.DamageType
  L1_2 = L1_2.Head
  if L1_2 > 1 then
    L1_2 = CreateThread
    function L2_2()
      local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3
      L0_3 = math
      L0_3 = L0_3.random
      L1_3 = 100
      L0_3 = L0_3(L1_3)
      L1_3 = Config
      L1_3 = L1_3.HeadInjuryChance
      if L0_3 <= L1_3 then
        L1_3 = SendNUIMessage
        L2_3 = {}
        L2_3.blackscreen = 1
        L1_3(L2_3)
        L1_3 = IsPedRagdoll
        L2_3 = L0_2
        L1_3 = L1_3(L2_3)
        if not L1_3 then
          L1_3 = IsPedOnFoot
          L2_3 = L0_2
          L1_3 = L1_3(L2_3)
          if L1_3 then
            L1_3 = IsPedSwimming
            L2_3 = L0_2
            L1_3 = L1_3(L2_3)
            if not L1_3 then
              L1_3 = ShakeGameplayCam
              L2_3 = "SMALL_EXPLOSION_SHAKE"
              L3_3 = 0.08
              L1_3(L2_3, L3_3)
              L1_3 = SetPedToRagdoll
              L2_3 = L0_2
              L3_3 = 5000
              L4_3 = 1
              L5_3 = 2
              L1_3(L2_3, L3_3, L4_3, L5_3)
            end
          end
        end
        L1_3 = false
        L2_3 = CreateThread
        function L3_3()
          local L0_4, L1_4
          while true do
            L0_4 = disabledControls
            L0_4()
            L0_4 = Wait
            L1_4 = 3
            L0_4(L1_4)
            L0_4 = L1_3
            if L0_4 then
              break
            end
          end
        end
        L2_3(L3_3)
        L2_3 = Wait
        L3_3 = 5000
        L2_3(L3_3)
        L1_3 = true
        L2_3 = SendNUIMessage
        L3_3 = {}
        L3_3.blackscreen = 2
        L2_3(L3_3)
      end
    end
    L1_2(L2_2)
  end
end
ProcessSideEffects = L5_1
L5_1 = CreateThread
function L6_1()
  local L0_2, L1_2
  while true do
    L0_2 = ProcessSideEffects
    L0_2()
    L0_2 = Wait
    L1_2 = Config
    L1_2 = L1_2.SideEffectsTime
    L0_2(L1_2)
  end
end
L5_1(L6_1)
L5_1 = CreateThread
function L6_1()
  local L0_2, L1_2
  while true do
    L0_2 = Config
    L0_2 = L0_2.BleedEffect
    if L0_2 then
      L0_2 = Config
      L0_2 = L0_2.b2545
      if L0_2 then
        L0_2 = BleedEffect
        L0_2()
      end
    end
    L0_2 = Wait
    L1_2 = Config
    L1_2 = L1_2.BleedTime
    L0_2(L1_2)
  end
end
L5_1(L6_1)
function L5_1(A0_2)
  local L1_2, L2_2
  while true do
    L1_2 = HasAnimDictLoaded
    L2_2 = A0_2
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = RequestAnimDict
    L2_2 = A0_2
    L1_2(L2_2)
    L1_2 = Wait
    L2_2 = 1
    L1_2(L2_2)
  end
end
loadAnimDict = L5_1
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  isInHospitalBed = true
  canLeaveBed = false
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = DoScreenFadeOut
  L2_2 = 1000
  L1_2(L2_2)
  while true do
    L1_2 = IsScreenFadedOut
    L1_2 = L1_2()
    if L1_2 then
      break
    end
    L1_2 = Wait
    L2_2 = 100
    L1_2(L2_2)
  end
  L1_2 = IsPedDeadOrDying
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  if L1_2 then
    L1_2 = GetEntityCoords
    L2_2 = L0_2
    L3_2 = true
    L1_2 = L1_2(L2_2, L3_2)
    L2_2 = NetworkResurrectLocalPlayer
    L3_2 = L1_2.x
    L4_2 = L1_2.y
    L5_2 = L1_2.z
    L6_2 = GetEntityHeading
    L7_2 = L0_2
    L6_2 = L6_2(L7_2)
    L7_2 = true
    L8_2 = false
    L2_2(L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
  end
  L1_2 = GetClosestObjectOfType
  L2_2 = bedOccupyingData
  L2_2 = L2_2.coords
  L2_2 = L2_2.x
  L3_2 = bedOccupyingData
  L3_2 = L3_2.coords
  L3_2 = L3_2.y
  L4_2 = bedOccupyingData
  L4_2 = L4_2.coords
  L4_2 = L4_2.z
  L5_2 = 2.0
  L6_2 = bedOccupyingData
  L6_2 = L6_2.model
  L7_2 = false
  L8_2 = false
  L9_2 = false
  L1_2 = L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2)
  bedObject = L1_2
  L1_2 = FreezeEntityPosition
  L2_2 = bedObject
  L3_2 = true
  L1_2(L2_2, L3_2)
  L1_2 = inBed
  L2_2 = L0_2
  L1_2(L2_2)
  L1_2 = loadAnimDict
  L2_2 = inBedDict
  L1_2(L2_2)
  L1_2 = CreateCam
  L2_2 = "DEFAULT_SCRIPTED_CAMERA"
  L3_2 = 1
  L1_2 = L1_2(L2_2, L3_2)
  cam = L1_2
  L1_2 = SetCamActive
  L2_2 = cam
  L3_2 = true
  L1_2(L2_2, L3_2)
  L1_2 = RenderScriptCams
  L2_2 = true
  L3_2 = false
  L4_2 = 1
  L5_2 = true
  L6_2 = true
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  L1_2 = AttachCamToPedBone
  L2_2 = cam
  L3_2 = L0_2
  L4_2 = 31085
  L5_2 = 0
  L6_2 = 1.0
  L7_2 = 1.0
  L8_2 = true
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2)
  L1_2 = SetCamFov
  L2_2 = cam
  L3_2 = 90.0
  L1_2(L2_2, L3_2)
  L1_2 = GetEntityHeading
  L2_2 = L0_2
  L1_2 = L1_2(L2_2)
  L2_2 = 180
  if L1_2 > L2_2 then
    L2_2 = L1_2 - 180
    if L2_2 then
      goto lbl_104
      L1_2 = L2_2 or L1_2
    end
  end
  L1_2 = L1_2 + 180
  ::lbl_104::
  L2_2 = SetCamRot
  L3_2 = cam
  L4_2 = -45.0
  L5_2 = 0.0
  L6_2 = L1_2
  L7_2 = 2
  L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
  L2_2 = DoScreenFadeIn
  L3_2 = 1000
  L2_2(L3_2)
end
SetBedCam = L5_1
function L5_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2
  L0_2 = PlayerPedId
  L0_2 = L0_2()
  L1_2 = RequestAnimDict
  L2_2 = getOutDict
  L1_2(L2_2)
  while true do
    L1_2 = HasAnimDictLoaded
    L2_2 = getOutDict
    L1_2 = L1_2(L2_2)
    if L1_2 then
      break
    end
    L1_2 = Wait
    L2_2 = 0
    L1_2(L2_2)
  end
  L1_2 = stationaryDuiObj
  L2_2 = MyActiveHospital
  L1_2 = L1_2[L2_2]
  if L1_2 then
    L1_2 = stationaryDuiObj
    L2_2 = MyActiveHospital
    L1_2 = L1_2[L2_2]
    L2_2 = OnECGNumMonitor
    L1_2 = L1_2[L2_2]
    if L1_2 then
      L1_2 = TriggerServerEvent
      L2_2 = "osp_ambulance:DestroySyncScreenSv"
      L3_2 = OnECGNumMonitor
      L4_2 = MyActiveHospital
      L1_2(L2_2, L3_2, L4_2)
    end
  end
  OnECGNumMonitor = false
  L1_2 = FreezeEntityPosition
  L2_2 = L0_2
  L3_2 = false
  L1_2(L2_2, L3_2)
  L1_2 = SetEntityInvincible
  L2_2 = L0_2
  L3_2 = false
  L1_2(L2_2, L3_2)
  L1_2 = SetEntityHeading
  L2_2 = L0_2
  L3_2 = bedOccupyingData
  L3_2 = L3_2.coords
  L3_2 = L3_2.w
  L3_2 = L3_2 + 90
  L1_2(L2_2, L3_2)
  L1_2 = SetEntityCoords
  L2_2 = L0_2
  L3_2 = bedOccupyingData
  L3_2 = L3_2.coords
  L3_2 = L3_2.x
  L4_2 = bedOccupyingData
  L4_2 = L4_2.coords
  L4_2 = L4_2.y
  L5_2 = bedOccupyingData
  L5_2 = L5_2.coords
  L5_2 = L5_2.z
  L1_2(L2_2, L3_2, L4_2, L5_2)
  L1_2 = ClearPedTasks
  L2_2 = L0_2
  L1_2(L2_2)
  L1_2 = ClearPedSecondaryTask
  L2_2 = L0_2
  L1_2(L2_2)
  L1_2 = TaskPlayAnim
  L2_2 = L0_2
  L3_2 = getOutDict
  L4_2 = getOutAnim
  L5_2 = 100.0
  L6_2 = 1.0
  L7_2 = -1
  L8_2 = 8
  L9_2 = -1
  L10_2 = 0
  L11_2 = 0
  L12_2 = 0
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2)
  L1_2 = bedObject
  if L1_2 then
    L1_2 = SetEntityCollision
    L2_2 = bedObject
    L3_2 = false
    L4_2 = false
    L1_2(L2_2, L3_2, L4_2)
    L1_2 = 1.3
    L2_2 = bedOccupyingData
    L2_2 = L2_2.getOutOffset
    if not L2_2 then
      L2_2 = print
      L3_2 = "Config is missing getOutOffset, see default bed config."
      L2_2(L3_2)
    end
    L2_2 = vector3
    L3_2 = bedOccupyingData
    L3_2 = L3_2.coords
    L3_2 = L3_2.x
    L4_2 = bedOccupyingData
    L4_2 = L4_2.coords
    L4_2 = L4_2.y
    L5_2 = bedOccupyingData
    L5_2 = L5_2.coords
    L5_2 = L5_2.z
    L6_2 = bedOccupyingData
    L6_2 = L6_2.getOutOffset
    if not L6_2 then
      L6_2 = L1_2
    end
    L5_2 = L5_2 - L6_2
    L2_2 = L2_2(L3_2, L4_2, L5_2)
    L3_2 = CreateObject
    L4_2 = bedOccupyingData
    L4_2 = L4_2.model
    L5_2 = L2_2.x
    L6_2 = L2_2.y
    L7_2 = L2_2.z
    L8_2 = false
    L9_2 = false
    L10_2 = false
    L3_2 = L3_2(L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
    L4_2 = SetEntityVisible
    L5_2 = L3_2
    L6_2 = false
    L4_2(L5_2, L6_2)
    L4_2 = SetEntityCollision
    L5_2 = L3_2
    L6_2 = true
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = FreezeEntityPosition
    L5_2 = L3_2
    L6_2 = true
    L4_2(L5_2, L6_2)
    L4_2 = Wait
    L5_2 = 5000
    L4_2(L5_2)
    L4_2 = DeleteObject
    L5_2 = L3_2
    L4_2(L5_2)
    L4_2 = SetEntityCollision
    L5_2 = bedObject
    L6_2 = true
    L7_2 = true
    L4_2(L5_2, L6_2, L7_2)
  else
    L1_2 = Wait
    L2_2 = 4000
    L1_2(L2_2)
  end
  L1_2 = FreezeEntityPosition
  L2_2 = L0_2
  L3_2 = false
  L1_2(L2_2, L3_2)
  L1_2 = ClearPedTasks
  L2_2 = L0_2
  L1_2(L2_2)
  L1_2 = TriggerServerEvent
  L2_2 = "hospital:server:LeaveBed"
  L3_2 = bedOccupying
  L4_2 = MyActiveHospital
  L1_2(L2_2, L3_2, L4_2)
  L1_2 = FreezeEntityPosition
  L2_2 = bedObject
  L3_2 = true
  L1_2(L2_2, L3_2)
  L1_2 = RenderScriptCams
  L2_2 = 0
  L3_2 = true
  L4_2 = 200
  L5_2 = true
  L6_2 = true
  L1_2(L2_2, L3_2, L4_2, L5_2, L6_2)
  L1_2 = DestroyCam
  L2_2 = cam
  L3_2 = false
  L1_2(L2_2, L3_2)
  bedOccupying = nil
  bedObject = nil
  bedOccupyingData = nil
  isInHospitalBed = false
  MyActiveHospital = nil
end
LeaveBed = L5_1
L5_1 = RegisterNetEvent
L6_1 = "hospital:client:SendToBed"
function L7_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  bedOccupying = A0_2
  bedOccupyingData = A1_2
  L4_2 = SetBedCam
  L4_2()
  L4_2 = DebugPrint
  L5_2 = "Sending to bed and syncing screen"
  L6_2 = GetPlayerServerId
  L7_2 = PlayerId
  L7_2, L8_2, L9_2, L10_2, L11_2 = L7_2()
  L6_2, L7_2, L8_2, L9_2, L10_2, L11_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2)
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2)
  if A3_2 then
    MyActiveHospital = A3_2
    L4_2 = TriggerServerEvent
    L5_2 = "osp_ambulance:SyncScreenSv"
    L6_2 = GetPlayerServerId
    L7_2 = PlayerId
    L7_2, L8_2, L9_2, L10_2, L11_2 = L7_2()
    L6_2 = L6_2(L7_2, L8_2, L9_2, L10_2, L11_2)
    L7_2 = A3_2
    L4_2(L5_2, L6_2, L7_2)
    L4_2 = pairs
    L5_2 = Config
    L5_2 = L5_2.Hospitals
    L5_2 = L5_2[A3_2]
    L5_2 = L5_2.StationaryECG
    L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
    for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
      L10_2 = GetEntityCoords
      L11_2 = PlayerPedId
      L11_2 = L11_2()
      L10_2 = L10_2(L11_2)
      L11_2 = L9_2.bedcoords
      L10_2 = L10_2 - L11_2
      L10_2 = #L10_2
      L11_2 = 1.5
      if L10_2 < L11_2 then
        L11_2 = stationaryDuiObj
        L11_2 = L11_2[A3_2]
        if L11_2 then
          L11_2 = stationaryDuiObj
          L11_2 = L11_2[A3_2]
          L11_2 = L11_2[L8_2]
          if L11_2 then
            OnECGNumMonitor = L8_2
          end
        end
      end
    end
  end
  L4_2 = CreateThread
  function L5_2()
    local L0_3, L1_3, L2_3
    L0_3 = Wait
    L1_3 = 5
    L0_3(L1_3)
    L0_3 = A2_2
    if L0_3 then
      L0_3 = ProgressBar
      L1_3 = lang
      L1_3 = L1_3.success
      L1_3 = L1_3.being_helped
      L2_3 = Config
      L2_3 = L2_3.AIHealTimer
      L2_3 = L2_3 * 1000
      L0_3(L1_3, L2_3)
      L0_3 = TriggerEvent
      L1_3 = "hospital:client:Revive"
      L0_3(L1_3)
      checkin = false
    else
      canLeaveBed = true
    end
  end
  L4_2(L5_2)
end
L5_1(L6_1, L7_1)
L5_1 = RegisterNetEvent
L6_1 = "hospital:client:SetBed"
function L7_1(A0_2, A1_2, A2_2)
  local L3_2
  L3_2 = Config
  L3_2 = L3_2.Hospitals
  L3_2 = L3_2[A2_2]
  L3_2 = L3_2.beds
  L3_2 = L3_2[A0_2]
  L3_2.taken = A1_2
end
L5_1(L6_1, L7_1)
L5_1 = RegisterNetEvent
L6_1 = "hospital:client:SetBed2"
function L7_1(A0_2, A1_2)
  local L2_2
  L2_2 = Config
  L2_2 = L2_2.JailBeds
  L2_2 = L2_2[A0_2]
  L2_2.taken = A1_2
end
L5_1(L6_1, L7_1)
L5_1 = RegisterNetEvent
L6_1 = "hospital:client:SetDoctorCount"
function L7_1(A0_2)
  local L1_2
  doctorCount = A0_2
end
L5_1(L6_1, L7_1)
L5_1 = CreateThread
function L6_1()
  local L0_2, L1_2, L2_2, L3_2
  while true do
    L0_2 = 1000
    L1_2 = isInHospitalBed
    if L1_2 then
      L1_2 = canLeaveBed
      if L1_2 then
        L0_2 = 3
        L1_2 = textUi
        L2_2 = lang
        L2_2 = L2_2.text
        L2_2 = L2_2.bed_out
        L1_2(L2_2)
        L1_2 = IsControlJustReleased
        L2_2 = 0
        L3_2 = 38
        L1_2 = L1_2(L2_2, L3_2)
        if L1_2 then
          L1_2 = removeTextUi
          L1_2()
          L1_2 = LeaveBed
          L1_2()
        end
      end
    end
    L1_2 = Wait
    L2_2 = L0_2
    L1_2(L2_2)
  end
end
L5_1(L6_1)
L5_1 = CreateThread
function L6_1()
  local L0_2, L1_2
  while true do
    L0_2 = Wait
    L1_2 = 1000
    L0_2(L1_2)
    L0_2 = L3_1
    L0_2()
    L0_2 = isStatusChecking
    if L0_2 then
      L0_2 = statusCheckTime
      L0_2 = L0_2 - 1
      statusCheckTime = L0_2
      L0_2 = statusCheckTime
      if L0_2 <= 0 then
        L0_2 = {}
        statusChecks = L0_2
        isStatusChecking = false
      end
    end
  end
end
L5_1(L6_1)
checkin = false
listen = false
function L5_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = CreateThread
  function L3_2()
    local L0_3, L1_3, L2_3, L3_3
    listen = true
    while true do
      L0_3 = listen
      if not L0_3 then
        break
      end
      L0_3 = IsControlJustPressed
      L1_3 = 0
      L2_3 = 38
      L0_3 = L0_3(L1_3, L2_3)
      if L0_3 then
        L0_3 = A0_2
        if "checkin" == L0_3 then
          L0_3 = TriggerEvent
          L1_3 = "osp_ambulance:checkin"
          L2_3 = {}
          L3_3 = A1_2
          L2_3.hospitalID = L3_3
          L0_3(L1_3, L2_3)
          listen = false
        else
          L0_3 = A0_2
          if "beds" == L0_3 then
            L0_3 = checkin
            if not L0_3 then
              L0_3 = TriggerEvent
              L1_3 = "osp_ambulance:beds"
              L2_3 = {}
              L3_3 = A1_2
              L2_3.hospitalID = L3_3
              L0_3(L1_3, L2_3)
              listen = false
            end
          end
        end
      end
      L0_3 = Wait
      L1_3 = 1
      L0_3(L1_3)
    end
  end
  L2_2(L3_2)
end
CheckInControls = L5_1
L5_1 = false
L6_1 = CreateThread
function L7_1()
  local L0_2, L1_2
  while true do
    L0_2 = L5_1
    if L0_2 then
      L0_2 = Wait
      L1_2 = 4000
      L0_2(L1_2)
      L0_2 = false
      L5_1 = L0_2
    end
    L0_2 = Wait
    L1_2 = 1000
    L0_2(L1_2)
  end
end
L6_1(L7_1)
L6_1 = RegisterNetEvent
L7_1 = "osp_ambulance:checkin"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  L1_2 = A0_2.hospitalID
  L2_2 = L5_1
  if L2_2 then
    return
  end
  L2_2 = doctorCount
  L3_2 = Config
  L3_2 = L3_2.MinimalDoctors
  if L2_2 >= L3_2 then
    L2_2 = SendTextMessage
    L3_2 = lang
    L3_2 = L3_2.interactions
    L3_2 = L3_2.medicalHeader
    L4_2 = lang
    L4_2 = L4_2.update1
    L4_2 = L4_2.doctor_alerted
    L5_2 = 5000
    L6_2 = "success"
    L2_2(L3_2, L4_2, L5_2, L6_2)
    L2_2 = TriggerServerEvent
    L3_2 = "hospital:server:SendDoctorAlert"
    L2_2(L3_2)
  else
    L2_2 = true
    L5_1 = L2_2
    L2_2 = ProgressBar
    L3_2 = lang
    L3_2 = L3_2.progress
    L3_2 = L3_2.checking_in
    L4_2 = 2000
    L5_2 = "missheistdockssetup1clipboard@base"
    L6_2 = "base"
    L2_2(L3_2, L4_2, L5_2, L6_2)
    L2_2 = L1_1
    L3_2 = nil
    L4_2 = L1_2
    L5_2 = true
    L2_2 = L2_2(L3_2, L4_2, L5_2)
    if L2_2 then
      checkin = true
      L3_2 = TriggerServerEvent
      L4_2 = "hospital:server:SendToBed"
      L5_2 = L2_2
      L6_2 = true
      L7_2 = L1_2
      L3_2(L4_2, L5_2, L6_2, L7_2)
    else
      L3_2 = SendTextMessage
      L4_2 = lang
      L4_2 = L4_2.interactions
      L4_2 = L4_2.medicalHeader
      L5_2 = lang
      L5_2 = L5_2.error
      L5_2 = L5_2.beds_taken
      L6_2 = 5000
      L7_2 = "error"
      L3_2(L4_2, L5_2, L6_2, L7_2)
    end
  end
end
L6_1(L7_1, L8_1)
L6_1 = RegisterNetEvent
L7_1 = "osp_ambulance:beds"
function L8_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2
  L1_2 = A0_2.hospitalID
  L2_2 = checkin
  if L2_2 then
    return
  end
  L2_2 = L1_1
  L3_2 = closestBed
  L4_2 = L1_2
  L2_2 = L2_2(L3_2, L4_2)
  if L2_2 then
    L2_2 = TriggerServerEvent
    L3_2 = "hospital:server:SendToBed"
    L4_2 = closestBed
    L5_2 = false
    L6_2 = L1_2
    L2_2(L3_2, L4_2, L5_2, L6_2)
  else
    L2_2 = SendTextMessage
    L3_2 = lang
    L3_2 = L3_2.interactions
    L3_2 = L3_2.medicalHeader
    L4_2 = lang
    L4_2 = L4_2.error
    L4_2 = L4_2.beds_taken
    L5_2 = 5000
    L6_2 = "error"
    L2_2(L3_2, L4_2, L5_2, L6_2)
  end
end
L6_1(L7_1, L8_1)
