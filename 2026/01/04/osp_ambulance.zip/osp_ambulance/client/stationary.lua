local L0_1, L1_1, L2_1
OnECGNumMonitor = false
MyActiveHospital = nil
L0_1 = {}
stationaryDuiObj = L0_1
L0_1 = {}
stationarySfHandle = L0_1
stationaryDuiUrl = "nui://osp_ambulance/html/stationary.html"
L0_1 = {}
stationarySfName = L0_1
L0_1 = {}
usedscreenindex = L0_1
L0_1 = CreateThread
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2
  L0_2 = nil
  while true do
    L1_2 = BodyDamage
    L1_2 = L1_2.cardiacState
    if L0_2 ~= L1_2 then
      L1_2 = OnECGNumMonitor
      if L1_2 then
        L1_2 = MyActiveHospital
        if L1_2 then
          L1_2 = Config
          L1_2 = L1_2.Hospitals
          L2_2 = MyActiveHospital
          L1_2 = L1_2[L2_2]
          L1_2 = L1_2.TurnedOnEcgs
          L2_2 = OnECGNumMonitor
          L1_2 = L1_2[L2_2]
          if L1_2 then
            L1_2 = BodyDamage
            L1_2 = L1_2.cardiacState
            if "NSR" ~= L1_2 then
              L1_2 = TriggerServerEvent
              L2_2 = "osp_ambulance:SyncCodeBlueSv"
              L3_2 = OnECGNumMonitor
              L4_2 = MyActiveHospital
              L1_2(L2_2, L3_2, L4_2)
            end
            L1_2 = BodyDamage
            L0_2 = L1_2.cardiacState
          end
        end
      end
    end
    L1_2 = Wait
    L2_2 = 3000
    L1_2(L2_2)
  end
end
L0_1(L1_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:SyncCodeBlueCl"
L0_1(L1_1)
L0_1 = AddEventHandler
L1_1 = "osp_ambulance:SyncCodeBlueCl"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L2_2 = pairs
  L3_2 = Config
  L3_2 = L3_2.Hospitals
  L3_2 = L3_2[A1_2]
  L3_2 = L3_2.IncomingScreenPos
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = SendDuiMessage
    L9_2 = incomingDuiObj
    L9_2 = L9_2[A1_2]
    L9_2 = L9_2[L6_2]
    L10_2 = json
    L10_2 = L10_2.encode
    L11_2 = {}
    L11_2.type = "code"
    L12_2 = "Monitor "
    L13_2 = A0_2
    L12_2 = L12_2 .. L13_2
    L11_2.room = L12_2
    L10_2, L11_2, L12_2, L13_2, L14_2 = L10_2(L11_2)
    L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
  end
  L2_2 = pairs
  L3_2 = Config
  L3_2 = L3_2.Hospitals
  L3_2 = L3_2[A1_2]
  L3_2 = L3_2.IncomingScreenSoundPos
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = TriggerSound
    L9_2 = "codeblue"
    L10_2 = L7_2
    L11_2 = Config
    L11_2 = L11_2.IncomingScreenSoundRange
    L8_2(L9_2, L10_2, L11_2)
    L8_2 = Config
    L8_2 = L8_2.UseXsound
    if L8_2 then
      L8_2 = xSound
      L9_2 = L8_2
      L8_2 = L8_2.PlayUrlPos
      L10_2 = "codeblue"
      L11_2 = "codeblue.mp3"
      L12_2 = 1.0
      L13_2 = L7_2
      L14_2 = false
      L8_2(L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
      L8_2 = xSound
      L9_2 = L8_2
      L8_2 = L8_2.Distance
      L10_2 = "codeblue"
      L11_2 = Config
      L11_2 = L11_2.IncomingScreenSoundRange
      L8_2(L9_2, L10_2, L11_2)
      L8_2 = xSound
      L9_2 = L8_2
      L8_2 = L8_2.destroyOnFinish
      L10_2 = "codeblue"
      L11_2 = true
      L8_2(L9_2, L10_2, L11_2)
    end
  end
  L2_2 = pairs
  L3_2 = Config
  L3_2 = L3_2.Hospitals
  L3_2 = L3_2[A1_2]
  L3_2 = L3_2.ScreenPropList
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = Config
    L8_2 = L8_2.UseTarget
    if L8_2 then
      L8_2 = RemoveTargetZone
      L9_2 = L7_2
      L8_2(L9_2)
      L8_2 = GetEntityRotation
      L9_2 = L7_2
      L8_2 = L8_2(L9_2)
      L9_2 = GetOffsetFromEntityInWorldCoords
      L10_2 = L7_2
      L11_2 = stationaryScreenOffset
      L9_2 = L9_2(L10_2, L11_2)
      L10_2 = Config
      L10_2 = L10_2.UseOxTarget
      if L10_2 then
        L10_2 = TargetEntity
        L11_2 = L7_2
        L12_2 = {}
        L12_2.name = L7_2
        L12_2.event = "osp_ambulance:TurnOnOffStationaryECGPrep"
        L12_2.icon = "fa-solid fa-power-off"
        L13_2 = lang
        L13_2 = L13_2.ecg
        L13_2 = L13_2.turn_on_off
        L12_2.label = L13_2
        L12_2.coords2 = L9_2
        L12_2.rot = L8_2
        L12_2.id = A0_2
        L12_2.ent = L7_2
        L12_2.hospitalID = A1_2
        L13_2 = {}
        L13_2.name = L7_2
        L13_2.event = "osp_ambulance:TurnOffCodePrepCl"
        L13_2.icon = "fa-solid fa-triangle-exclamation"
        L14_2 = lang
        L14_2 = L14_2.ecg
        L14_2 = L14_2.turn_off_code
        L13_2.label = L14_2
        L13_2.id = A0_2
        L13_2.hospitalID = A1_2
        L10_2(L11_2, L12_2, L13_2)
      else
        L10_2 = TargetEntity
        L11_2 = L7_2
        L12_2 = {}
        L12_2.type = "client"
        L12_2.event = "osp_ambulance:TurnOnOffStationaryECGPrep"
        L12_2.icon = "fa-solid fa-power-off"
        L13_2 = lang
        L13_2 = L13_2.ecg
        L13_2 = L13_2.turn_on_off
        L12_2.label = L13_2
        L12_2.coords2 = L9_2
        L12_2.rot = L8_2
        L12_2.id = A0_2
        L12_2.ent = L7_2
        L12_2.hospitalID = A1_2
        L13_2 = {}
        L13_2.type = "client"
        L13_2.event = "osp_ambulance:TurnOffCodePrepCl"
        L13_2.icon = "fa-solid fa-triangle-exclamation"
        L14_2 = lang
        L14_2 = L14_2.ecg
        L14_2 = L14_2.turn_off_code
        L13_2.label = L14_2
        L13_2.id = A0_2
        L13_2.hospitalID = A1_2
        L10_2(L11_2, L12_2, L13_2)
      end
    else
      L8_2 = CreateThread
      function L9_2()
        local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3
        L0_3 = PlayerPedId
        L0_3 = L0_3()
        while true do
          L1_3 = 1000
          L2_3 = GetEntityCoords
          L3_3 = L7_2
          L2_3 = L2_3(L3_3)
          L3_3 = GetEntityCoords
          L4_3 = L0_3
          L3_3 = L3_3(L4_3)
          L2_3 = L2_3 - L3_3
          L2_3 = #L2_3
          if L2_3 < 3.0 then
            L1_3 = 5
            L3_3 = GetEntityCoords
            L4_3 = L7_2
            L3_3 = L3_3(L4_3)
            L4_3 = drawtext3d
            L5_3 = L3_3.x
            L6_3 = L3_3.y
            L7_3 = L3_3.z
            L7_3 = L7_3 - 1.35
            L8_3 = lang
            L8_3 = L8_3.ecg
            L8_3 = L8_3.turn_off_code_button
            L4_3(L5_3, L6_3, L7_3, L8_3)
            L4_3 = IsControlJustPressed
            L5_3 = 0
            L6_3 = 52
            L4_3 = L4_3(L5_3, L6_3)
            if L4_3 then
              L4_3 = Wait
              L5_3 = 100
              L4_3(L5_3)
              L4_3 = TriggerEvent
              L5_3 = "osp_ambulance:TurnOffCodePrepCl"
              L6_3 = {}
              L7_3 = L7_2
              L6_3.entity = L7_3
              L7_3 = A0_2
              L6_3.id = L7_3
              L7_3 = A1_2
              L6_3.hospitalID = L7_3
              L4_3(L5_3, L6_3)
              L4_3 = Wait
              L5_3 = 100
              L4_3(L5_3)
              break
            end
          end
          L3_3 = Wait
          L4_3 = L1_3
          L3_3(L4_3)
        end
      end
      L8_2(L9_2)
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:TurnOffCodePrepCl"
L0_1(L1_1)
L0_1 = AddEventHandler
L1_1 = "osp_ambulance:TurnOffCodePrepCl"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerServerEvent
  L2_2 = "osp_ambulance:TurnOffCodeSv"
  L3_2 = {}
  L4_2 = A0_2.entity
  L3_2.entity = L4_2
  L4_2 = A0_2.id
  L3_2.id = L4_2
  L4_2 = A0_2.hospitalID
  L3_2.hospitalID = L4_2
  L1_2(L2_2, L3_2)
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:TurnOffCodeCl"
L0_1(L1_1)
L0_1 = AddEventHandler
L1_1 = "osp_ambulance:TurnOffCodeCl"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L1_2 = pairs
  L2_2 = Config
  L2_2 = L2_2.Hospitals
  L3_2 = A0_2.hospitalID
  L2_2 = L2_2[L3_2]
  L2_2 = L2_2.IncomingScreenPos
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = SendDuiMessage
    L8_2 = incomingDuiObj
    L9_2 = A0_2.hospitalID
    L8_2 = L8_2[L9_2]
    L8_2 = L8_2[L5_2]
    L9_2 = json
    L9_2 = L9_2.encode
    L10_2 = {}
    L10_2.type = "default"
    L9_2, L10_2 = L9_2(L10_2)
    L7_2(L8_2, L9_2, L10_2)
  end
  L1_2 = pairs
  L2_2 = soundTable
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    if "codeblue" == L6_2 then
      L7_2 = StopSound
      L8_2 = L5_2
      L7_2(L8_2)
      L7_2 = ReleaseSoundId
      L8_2 = L5_2
      L7_2(L8_2)
      L7_2 = soundTable
      L7_2[L5_2] = nil
    end
  end
  L1_2 = Config
  L1_2 = L1_2.UseTarget
  if L1_2 then
    L1_2 = RemoveTargetZone
    L2_2 = A0_2.entity
    L1_2(L2_2)
    L1_2 = GetEntityRotation
    L2_2 = Config
    L2_2 = L2_2.Hospitals
    L3_2 = A0_2.hospitalID
    L2_2 = L2_2[L3_2]
    L2_2 = L2_2.ScreenPropList
    L3_2 = A0_2.id
    L2_2 = L2_2[L3_2]
    L1_2 = L1_2(L2_2)
    L2_2 = GetOffsetFromEntityInWorldCoords
    L3_2 = Config
    L3_2 = L3_2.Hospitals
    L4_2 = A0_2.hospitalID
    L3_2 = L3_2[L4_2]
    L3_2 = L3_2.ScreenPropList
    L4_2 = A0_2.id
    L3_2 = L3_2[L4_2]
    L4_2 = stationaryScreenOffset
    L2_2 = L2_2(L3_2, L4_2)
    L3_2 = Config
    L3_2 = L3_2.UseOxTarget
    if L3_2 then
      L3_2 = TargetEntity
      L4_2 = Config
      L4_2 = L4_2.Hospitals
      L5_2 = A0_2.hospitalID
      L4_2 = L4_2[L5_2]
      L4_2 = L4_2.ScreenPropList
      L5_2 = A0_2.id
      L4_2 = L4_2[L5_2]
      L5_2 = {}
      L6_2 = Config
      L6_2 = L6_2.Hospitals
      L7_2 = A0_2.hospitalID
      L6_2 = L6_2[L7_2]
      L6_2 = L6_2.ScreenPropList
      L7_2 = A0_2.id
      L6_2 = L6_2[L7_2]
      L5_2.name = L6_2
      L5_2.event = "osp_ambulance:TurnOnOffStationaryECGPrep"
      L5_2.icon = "fa-solid fa-power-off"
      L6_2 = lang
      L6_2 = L6_2.ecg
      L6_2 = L6_2.turn_on_off
      L5_2.label = L6_2
      L5_2.coords2 = L2_2
      L5_2.rot = L1_2
      L6_2 = A0_2.id
      L5_2.id = L6_2
      L6_2 = A0_2.hospitalID
      L5_2.hospitalID = L6_2
      L6_2 = Config
      L6_2 = L6_2.Hospitals
      L7_2 = A0_2.hospitalID
      L6_2 = L6_2[L7_2]
      L6_2 = L6_2.ScreenPropList
      L7_2 = A0_2.id
      L6_2 = L6_2[L7_2]
      L5_2.ent = L6_2
      L3_2(L4_2, L5_2)
    else
      L3_2 = TargetEntity
      L4_2 = Config
      L4_2 = L4_2.Hospitals
      L5_2 = A0_2.hospitalID
      L4_2 = L4_2[L5_2]
      L4_2 = L4_2.ScreenPropList
      L5_2 = A0_2.id
      L4_2 = L4_2[L5_2]
      L5_2 = {}
      L5_2.type = "client"
      L5_2.event = "osp_ambulance:TurnOnOffStationaryECGPrep"
      L5_2.icon = "fa-solid fa-power-off"
      L6_2 = lang
      L6_2 = L6_2.ecg
      L6_2 = L6_2.turn_on_off
      L5_2.label = L6_2
      L5_2.coords2 = L2_2
      L5_2.rot = L1_2
      L6_2 = A0_2.id
      L5_2.id = L6_2
      L6_2 = A0_2.hospitalID
      L5_2.hospitalID = L6_2
      L6_2 = Config
      L6_2 = L6_2.Hospitals
      L7_2 = A0_2.hospitalID
      L6_2 = L6_2[L7_2]
      L6_2 = L6_2.ScreenPropList
      L7_2 = A0_2.id
      L6_2 = L6_2[L7_2]
      L5_2.ent = L6_2
      L3_2(L4_2, L5_2)
    end
  end
end
L0_1(L1_1, L2_1)
function L0_1()
  local L0_2, L1_2
  L0_2 = CreateThread
  function L1_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3, L21_3
    L0_3 = DebugPrint
    L1_3 = "Loading Stationary ECG Screens"
    L0_3(L1_3)
    while true do
      L0_3 = PlayerLoaded
      if L0_3 then
        break
      end
      L0_3 = Wait
      L1_3 = 500
      L0_3(L1_3)
    end
    L0_3 = Wait
    L1_3 = 1000
    L0_3(L1_3)
    L0_3 = Config
    L0_3 = L0_3.StationaryECGProp
    L1_3 = RequestModel
    L2_3 = L0_3
    L1_3(L2_3)
    while true do
      L1_3 = HasModelLoaded
      L2_3 = L0_3
      L1_3 = L1_3(L2_3)
      if L1_3 then
        break
      end
      L1_3 = Wait
      L2_3 = 10
      L1_3(L2_3)
    end
    L1_3 = pairs
    L2_3 = Config
    L2_3 = L2_3.Hospitals
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      L7_3 = DebugPrint
      L8_3 = "Loading stationary screens for hospital: "
      L9_3 = L5_3
      L8_3 = L8_3 .. L9_3
      L7_3(L8_3)
      L7_3 = L6_3.ScreenPropList
      if not L7_3 then
        L7_3 = {}
      end
      L6_3.ScreenPropList = L7_3
      L7_3 = stationarySfHandle
      L8_3 = stationarySfHandle
      L8_3 = L8_3[L5_3]
      if not L8_3 then
        L8_3 = {}
      end
      L7_3[L5_3] = L8_3
      L7_3 = stationaryDuiObj
      L8_3 = stationaryDuiObj
      L8_3 = L8_3[L5_3]
      if not L8_3 then
        L8_3 = {}
      end
      L7_3[L5_3] = L8_3
      L7_3 = L6_3.TurnedOnEcgs
      if not L7_3 then
        L7_3 = {}
      end
      L6_3.TurnedOnEcgs = L7_3
      L7_3 = usedscreenindex
      L8_3 = usedscreenindex
      L8_3 = L8_3[L5_3]
      if not L8_3 then
        L8_3 = {}
      end
      L7_3[L5_3] = L8_3
      L7_3 = stationarySfHandle
      L7_3 = L7_3[L5_3]
      if L7_3 then
        L7_3 = pairs
        L8_3 = stationarySfHandle
        L8_3 = L8_3[L5_3]
        L7_3, L8_3, L9_3, L10_3 = L7_3(L8_3)
        for L11_3, L12_3 in L7_3, L8_3, L9_3, L10_3 do
          L13_3 = SetScaleformMovieAsNoLongerNeeded
          L14_3 = L12_3
          L13_3(L14_3)
        end
      end
      L7_3 = stationaryDuiObj
      L7_3 = L7_3[L5_3]
      if nil == L7_3 then
        L7_3 = json
        L7_3 = L7_3.encode
        L8_3 = stationaryDuiObj
        L8_3 = L8_3[L5_3]
        L7_3 = L7_3(L8_3)
        if "[]" == L7_3 then
          goto lbl_120
        end
      end
      L7_3 = pairs
      L8_3 = stationaryDuiObj
      L8_3 = L8_3[L5_3]
      L7_3, L8_3, L9_3, L10_3 = L7_3(L8_3)
      for L11_3, L12_3 in L7_3, L8_3, L9_3, L10_3 do
        L13_3 = IsDuiAvailable
        L14_3 = L12_3
        L13_3 = L13_3(L14_3)
        if L13_3 then
          L13_3 = DestroyDui
          L14_3 = L12_3
          L13_3(L14_3)
        else
          L13_3 = print
          L14_3 = "^1 Stationary screen not available when destroying"
          L13_3(L14_3)
        end
      end
      ::lbl_120::
      L7_3 = L6_3.ScreenPropList
      if L7_3 then
        L7_3 = pairs
        L8_3 = L6_3.ScreenPropList
        L7_3, L8_3, L9_3, L10_3 = L7_3(L8_3)
        for L11_3, L12_3 in L7_3, L8_3, L9_3, L10_3 do
          L13_3 = DeleteObject
          L14_3 = L12_3
          L13_3(L14_3)
        end
      end
      L7_3 = {}
      L6_3.ScreenPropList = L7_3
      L7_3 = stationarySfHandle
      L8_3 = {}
      L7_3[L5_3] = L8_3
      L7_3 = stationaryDuiObj
      L8_3 = {}
      L7_3[L5_3] = L8_3
      L7_3 = usedscreenindex
      L8_3 = {}
      L7_3[L5_3] = L8_3
      L7_3 = Wait
      L8_3 = 1000
      L7_3(L8_3)
      L7_3 = pairs
      L8_3 = L6_3.StationaryECG
      L7_3, L8_3, L9_3, L10_3 = L7_3(L8_3)
      for L11_3, L12_3 in L7_3, L8_3, L9_3, L10_3 do
        L13_3 = DebugPrint
        L14_3 = "loading stationary screen: "
        L15_3 = L11_3
        L14_3 = L14_3 .. L15_3
        L13_3(L14_3)
        L13_3 = CreateObjectNoOffset
        L14_3 = L0_3
        L15_3 = L12_3.coords
        L15_3 = L15_3.x
        L16_3 = L12_3.coords
        L16_3 = L16_3.y
        L17_3 = L12_3.coords
        L17_3 = L17_3.z
        L18_3 = 0
        L19_3 = 1
        L20_3 = 0
        L13_3 = L13_3(L14_3, L15_3, L16_3, L17_3, L18_3, L19_3, L20_3)
        L14_3 = DoesEntityExist
        L15_3 = L13_3
        L14_3 = L14_3(L15_3)
        if not L14_3 then
          L14_3 = print
          L15_3 = "Could not create ECG monitor at hospital: "
          L16_3 = L5_3
          L17_3 = " ECG: "
          L18_3 = L11_3
          L19_3 = " coords: "
          L20_3 = json
          L20_3 = L20_3.encode
          L21_3 = L12_3.coords
          L20_3 = L20_3(L21_3)
          L15_3 = L15_3 .. L16_3 .. L17_3 .. L18_3 .. L19_3 .. L20_3
          L14_3(L15_3)
        end
        L14_3 = FreezeEntityPosition
        L15_3 = L13_3
        L16_3 = true
        L14_3(L15_3, L16_3)
        L14_3 = L6_3.ScreenPropList
        L14_3[L11_3] = L13_3
        L14_3 = SetEntityHeading
        L15_3 = L13_3
        L16_3 = L12_3.coords
        L16_3 = L16_3.w
        L14_3(L15_3, L16_3)
        L14_3 = SetEntityAsMissionEntity
        L15_3 = L13_3
        L16_3 = true
        L17_3 = true
        L14_3(L15_3, L16_3, L17_3)
        L14_3 = GetEntityRotation
        L15_3 = L13_3
        L14_3 = L14_3(L15_3)
        L15_3 = GetOffsetFromEntityInWorldCoords
        L16_3 = L13_3
        L17_3 = stationaryScreenOffset
        L15_3 = L15_3(L16_3, L17_3)
        L16_3 = Config
        L16_3 = L16_3.UseTarget
        if L16_3 then
          L16_3 = Config
          L16_3 = L16_3.UseOxTarget
          if not L16_3 then
            L16_3 = TargetEntity
            L17_3 = L13_3
            L18_3 = {}
            L18_3.type = "client"
            L18_3.event = "osp_ambulance:TurnOnOffStationaryECGPrep"
            L18_3.icon = "fa-solid fa-power-off"
            L19_3 = lang
            L19_3 = L19_3.ecg
            L19_3 = L19_3.turn_on_off
            L18_3.label = L19_3
            L18_3.coords2 = L15_3
            L18_3.rot = L14_3
            L18_3.id = L11_3
            L18_3.hospitalID = L5_3
            L18_3.ent = L13_3
            L16_3(L17_3, L18_3)
          else
            L16_3 = {}
            L17_3 = {}
            L17_3.name = L13_3
            L17_3.event = "osp_ambulance:TurnOnOffStationaryECGPrep"
            L17_3.icon = "fa-solid fa-power-off"
            L18_3 = lang
            L18_3 = L18_3.ecg
            L18_3 = L18_3.turn_on_off
            L17_3.label = L18_3
            L17_3.coords2 = L15_3
            L17_3.rot = L14_3
            L17_3.id = L11_3
            L17_3.hospitalID = L5_3
            L17_3.ent = L13_3
            L16_3[1] = L17_3
            L17_3 = exports
            L17_3 = L17_3.ox_target
            L18_3 = L17_3
            L17_3 = L17_3.addLocalEntity
            L19_3 = L13_3
            L20_3 = L16_3
            L17_3(L18_3, L19_3, L20_3)
          end
        else
          L16_3 = CreateThread
          function L17_3()
            local L0_4, L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4
            while true do
              L0_4 = PlayerPedId
              L0_4 = L0_4()
              L1_4 = 1000
              L2_4 = L13_3
              if nil == L2_4 then
                break
              end
              L2_4 = GetEntityCoords
              L3_4 = L13_3
              L2_4 = L2_4(L3_4)
              L3_4 = GetEntityCoords
              L4_4 = L0_4
              L3_4 = L3_4(L4_4)
              L2_4 = L2_4 - L3_4
              L2_4 = #L2_4
              if L2_4 < 3.0 then
                L3_4 = IsAuthorized
                L3_4 = L3_4()
                if L3_4 then
                  L1_4 = 5
                  L3_4 = GetEntityCoords
                  L4_4 = L13_3
                  L3_4 = L3_4(L4_4)
                  L4_4 = drawtext3d
                  L5_4 = L3_4.x
                  L6_4 = L3_4.y
                  L7_4 = L3_4.z
                  L7_4 = L7_4 - 1.25
                  L8_4 = lang
                  L8_4 = L8_4.ecg
                  L8_4 = L8_4.turn_on_off_button
                  L4_4(L5_4, L6_4, L7_4, L8_4)
                  L4_4 = IsControlJustPressed
                  L5_4 = 0
                  L6_4 = 58
                  L4_4 = L4_4(L5_4, L6_4)
                  if L4_4 then
                    L4_4 = Wait
                    L5_4 = 100
                    L4_4(L5_4)
                    L4_4 = TriggerEvent
                    L5_4 = "osp_ambulance:TurnOnOffStationaryECGPrep"
                    L6_4 = {}
                    L7_4 = L15_3
                    L6_4.coords2 = L7_4
                    L7_4 = L14_3
                    L6_4.rot = L7_4
                    L7_4 = L11_3
                    L6_4.id = L7_4
                    L7_4 = L13_3
                    L6_4.ent = L7_4
                    L7_4 = L5_3
                    L6_4.hospitalID = L7_4
                    L4_4(L5_4, L6_4)
                  end
                end
              end
              L3_4 = Wait
              L4_4 = L1_4
              L3_4(L4_4)
            end
          end
          L16_3(L17_3)
        end
        L16_3 = Wait
        L17_3 = 100
        L16_3(L17_3)
      end
    end
    L1_3 = SetModelAsNoLongerNeeded
    L2_3 = L0_3
    L1_3(L2_3)
    L1_3 = lib
    L1_3 = L1_3.callback
    L2_3 = "osp_ambulance:getScreenStatus"
    L3_3 = false
    function L4_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4
      L1_4 = pairs
      L2_4 = A0_4
      L1_4, L2_4, L3_4, L4_4 = L1_4(L2_4)
      for L5_4, L6_4 in L1_4, L2_4, L3_4, L4_4 do
        L7_4 = pairs
        L8_4 = L6_4
        L7_4, L8_4, L9_4, L10_4 = L7_4(L8_4)
        for L11_4, L12_4 in L7_4, L8_4, L9_4, L10_4 do
          L13_4 = L12_4.on
          if L13_4 then
            L13_4 = CreateThread
            function L14_4()
              local L0_5, L1_5, L2_5, L3_5, L4_5
              L0_5 = stationaryShowScreen
              L1_5 = L12_4.coords
              L2_5 = L12_4.id
              L3_5 = L12_4.rot
              L4_5 = L5_4
              L0_5(L1_5, L2_5, L3_5, L4_5)
            end
            L13_4(L14_4)
          end
        end
      end
    end
    L1_3(L2_3, L3_3, L4_3)
    L1_3 = lib
    L1_3 = L1_3.callback
    L2_3 = "osp_ambulance:getUsedScreens"
    L3_3 = false
    function L4_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4, L5_4, L6_4, L7_4, L8_4, L9_4, L10_4, L11_4, L12_4, L13_4, L14_4, L15_4, L16_4
      L1_4 = pairs
      L2_4 = A0_4
      L1_4, L2_4, L3_4, L4_4 = L1_4(L2_4)
      for L5_4, L6_4 in L1_4, L2_4, L3_4, L4_4 do
        L7_4 = pairs
        L8_4 = L6_4
        L7_4, L8_4, L9_4, L10_4 = L7_4(L8_4)
        for L11_4, L12_4 in L7_4, L8_4, L9_4, L10_4 do
          L13_4 = TriggerEvent
          L14_4 = "osp_ambulance:SyncScreenCl"
          L15_4 = L12_4
          L16_4 = L5_4
          L13_4(L14_4, L15_4, L16_4)
          L13_4 = Wait
          L14_4 = 500
          L13_4(L14_4)
        end
      end
    end
    L1_3(L2_3, L3_3, L4_3)
  end
  L0_2(L1_2)
end
loadScreens = L0_1
L0_1 = CreateThread
function L1_1()
  local L0_2, L1_2
  L0_2 = Wait
  L1_2 = 1000
  L0_2(L1_2)
  L0_2 = loadScreens
  L0_2()
end
L0_1(L1_1)
L0_1 = CreateThread
function L1_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2, L18_2, L19_2, L20_2, L21_2
  while true do
    L0_2 = PlayerLoaded
    if L0_2 then
      break
    end
    L0_2 = Wait
    L1_2 = 6000
    L0_2(L1_2)
  end
  while true do
    L0_2 = PlayerPedId
    L0_2 = L0_2()
    L1_2 = GetEntityCoords
    L2_2 = L0_2
    L1_2 = L1_2(L2_2)
    L2_2 = pairs
    L3_2 = Config
    L3_2 = L3_2.Hospitals
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = L7_2.ScreenPropList
      if L8_2 then
        L8_2 = pairs
        L9_2 = L7_2.StationaryECG
        L8_2, L9_2, L10_2, L11_2 = L8_2(L9_2)
        for L12_2, L13_2 in L8_2, L9_2, L10_2, L11_2 do
          L14_2 = vector3
          L15_2 = L13_2.coords
          L15_2 = L15_2.x
          L16_2 = L13_2.coords
          L16_2 = L16_2.y
          L17_2 = L13_2.coords
          L17_2 = L17_2.z
          L14_2 = L14_2(L15_2, L16_2, L17_2)
          L14_2 = L1_2 - L14_2
          L14_2 = #L14_2
          L15_2 = L7_2.ScreenPropList
          L15_2 = L15_2[L12_2]
          if L14_2 < 25.0 and L15_2 then
            L16_2 = GetInteriorAtCoords
            L17_2 = L13_2.coords
            L17_2 = L17_2.x
            L18_2 = L13_2.coords
            L18_2 = L18_2.y
            L19_2 = L13_2.coords
            L19_2 = L19_2.z
            L16_2 = L16_2(L17_2, L18_2, L19_2)
            if 0 ~= L16_2 then
              L17_2 = IsValidInterior
              L18_2 = L16_2
              L17_2 = L17_2(L18_2)
              if L17_2 then
                L17_2 = LoadInterior
                L18_2 = L16_2
                L17_2(L18_2)
                while true do
                  L17_2 = IsInteriorReady
                  L18_2 = L16_2
                  L17_2 = L17_2(L18_2)
                  if L17_2 then
                    break
                  end
                  L17_2 = Wait
                  L18_2 = 0
                  L17_2(L18_2)
                end
                L17_2 = Wait
                L18_2 = 10
                L17_2(L18_2)
                L17_2 = GetRoomKeyFromEntity
                L18_2 = L0_2
                L17_2 = L17_2(L18_2)
                if 0 ~= L17_2 then
                  L18_2 = ForceRoomForEntity
                  L19_2 = L15_2
                  L20_2 = L16_2
                  L21_2 = L17_2
                  L18_2(L19_2, L20_2, L21_2)
                end
              end
            end
          end
        end
      end
    end
    L2_2 = Wait
    L3_2 = 1000
    L2_2(L3_2)
  end
end
L0_1(L1_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:TurnOnOffStationaryECGPrep"
L0_1(L1_1)
L0_1 = AddEventHandler
L1_1 = "osp_ambulance:TurnOnOffStationaryECGPrep"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = IsAuthorized
  L1_2 = L1_2()
  if not L1_2 then
    return
  end
  L1_2 = stationaryDuiObj
  L2_2 = A0_2.hospitalID
  L1_2 = L1_2[L2_2]
  L2_2 = A0_2.id
  L1_2 = L1_2[L2_2]
  if L1_2 then
    L1_2 = TriggerServerEvent
    L2_2 = "osp_ambulance:TurnOnOffStationaryECGSv"
    L3_2 = {}
    L4_2 = A0_2.coords2
    L3_2.coords = L4_2
    L4_2 = A0_2.rot
    L3_2.rot = L4_2
    L4_2 = A0_2.id
    L3_2.id = L4_2
    L4_2 = A0_2.ent
    L3_2.ent = L4_2
    L3_2.on = false
    L4_2 = A0_2.hospitalID
    L3_2.hospitalID = L4_2
    L1_2(L2_2, L3_2)
  else
    L1_2 = TriggerServerEvent
    L2_2 = "osp_ambulance:TurnOnOffStationaryECGSv"
    L3_2 = {}
    L4_2 = A0_2.coords2
    L3_2.coords = L4_2
    L4_2 = A0_2.rot
    L3_2.rot = L4_2
    L4_2 = A0_2.id
    L3_2.id = L4_2
    L4_2 = A0_2.ent
    L3_2.ent = L4_2
    L3_2.on = true
    L4_2 = A0_2.hospitalID
    L3_2.hospitalID = L4_2
    L1_2(L2_2, L3_2)
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:TurnOnOffStationaryECGCl"
L0_1(L1_1)
L0_1 = AddEventHandler
L1_1 = "osp_ambulance:TurnOnOffStationaryECGCl"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = Config
  L1_2 = L1_2.Hospitals
  L2_2 = A0_2.hospitalID
  L1_2 = L1_2[L2_2]
  L2_2 = Config
  L2_2 = L2_2.Hospitals
  L3_2 = A0_2.hospitalID
  L2_2 = L2_2[L3_2]
  L2_2 = L2_2.TurnedOnEcgs
  if not L2_2 then
    L2_2 = {}
  end
  L1_2.TurnedOnEcgs = L2_2
  L1_2 = A0_2.on
  if not L1_2 then
    L1_2 = stationarySfHandle
    L2_2 = A0_2.hospitalID
    L1_2 = L1_2[L2_2]
    L2_2 = A0_2.id
    L1_2 = L1_2[L2_2]
    if L1_2 then
      L1_2 = stationaryDuiObj
      L2_2 = A0_2.hospitalID
      L1_2 = L1_2[L2_2]
      L2_2 = A0_2.id
      L1_2 = L1_2[L2_2]
      if L1_2 then
        L1_2 = IsDuiAvailable
        L2_2 = stationaryDuiObj
        L3_2 = A0_2.hospitalID
        L2_2 = L2_2[L3_2]
        L3_2 = A0_2.id
        L2_2 = L2_2[L3_2]
        L1_2 = L1_2(L2_2)
        if L1_2 then
          L1_2 = DestroyDui
          L2_2 = stationaryDuiObj
          L3_2 = A0_2.hospitalID
          L2_2 = L2_2[L3_2]
          L3_2 = A0_2.id
          L2_2 = L2_2[L3_2]
          L1_2(L2_2)
          L1_2 = stationaryDuiObj
          L2_2 = A0_2.hospitalID
          L1_2 = L1_2[L2_2]
          L2_2 = A0_2.id
          L1_2[L2_2] = nil
        else
          L1_2 = print
          L2_2 = "^1 Stationary screen not available when destroying, data: "
          L3_2 = stationaryDuiObj
          L4_2 = A0_2.hospitalID
          L3_2 = L3_2[L4_2]
          L4_2 = A0_2.id
          L3_2 = L3_2[L4_2]
          L4_2 = stationarySfHandle
          L5_2 = A0_2.hospitalID
          L4_2 = L4_2[L5_2]
          L5_2 = A0_2.id
          L4_2 = L4_2[L5_2]
          L1_2(L2_2, L3_2, L4_2)
        end
      end
      L1_2 = SetScaleformMovieAsNoLongerNeeded
      L2_2 = stationarySfHandle
      L3_2 = A0_2.hospitalID
      L2_2 = L2_2[L3_2]
      L3_2 = A0_2.id
      L2_2 = L2_2[L3_2]
      L1_2(L2_2)
      L1_2 = Config
      L1_2 = L1_2.Hospitals
      L2_2 = A0_2.hospitalID
      L1_2 = L1_2[L2_2]
      L1_2 = L1_2.TurnedOnEcgs
      L2_2 = A0_2.id
      L1_2[L2_2] = false
    end
  else
    L1_2 = Config
    L1_2 = L1_2.Hospitals
    L2_2 = A0_2.hospitalID
    L1_2 = L1_2[L2_2]
    L1_2 = L1_2.TurnedOnEcgs
    L2_2 = A0_2.id
    L1_2[L2_2] = true
    L1_2 = stationaryShowScreen
    L2_2 = A0_2.coords
    L3_2 = A0_2.id
    L4_2 = A0_2.rot
    L5_2 = A0_2.hospitalID
    L1_2(L2_2, L3_2, L4_2, L5_2)
    L1_2 = Wait
    L2_2 = 250
    L1_2(L2_2)
    L1_2 = stationaryDuiObj
    L2_2 = A0_2.hospitalID
    L1_2 = L1_2[L2_2]
    if L1_2 then
      L1_2 = stationaryDuiObj
      L2_2 = A0_2.hospitalID
      L1_2 = L1_2[L2_2]
      L2_2 = A0_2.id
      L1_2 = L1_2[L2_2]
      if L1_2 then
        L1_2 = SendDuiMessage
        L2_2 = stationaryDuiObj
        L3_2 = A0_2.hospitalID
        L2_2 = L2_2[L3_2]
        L3_2 = A0_2.id
        L2_2 = L2_2[L3_2]
        L3_2 = json
        L3_2 = L3_2.encode
        L4_2 = {}
        L5_2 = A0_2.id
        L4_2.index = L5_2
        L3_2, L4_2, L5_2 = L3_2(L4_2)
        L1_2(L2_2, L3_2, L4_2, L5_2)
      end
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:SyncScreenCl"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L2_2 = Player
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L3_2 = L2_2.state
  L3_2 = L3_2.BodyDamage
  L4_2 = Wait
  L5_2 = 100
  L4_2(L5_2)
  L4_2 = pairs
  L5_2 = Config
  L5_2 = L5_2.Hospitals
  L5_2 = L5_2[A1_2]
  L5_2 = L5_2.StationaryECG
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
    L10_2 = GetEntityCoords
    L11_2 = GetPlayerPed
    L12_2 = GetPlayerFromServerId
    L13_2 = A0_2
    L12_2, L13_2, L14_2 = L12_2(L13_2)
    L11_2, L12_2, L13_2, L14_2 = L11_2(L12_2, L13_2, L14_2)
    L10_2 = L10_2(L11_2, L12_2, L13_2, L14_2)
    L11_2 = L9_2.bedcoords
    L10_2 = L10_2 - L11_2
    L10_2 = #L10_2
    L11_2 = DebugPrint
    L12_2 = "Stationary ECG"
    L13_2 = L8_2
    L14_2 = L9_2
    L11_2(L12_2, L13_2, L14_2)
    L11_2 = 1.5
    if L10_2 < L11_2 then
      L11_2 = DebugPrint
      L12_2 = "ECG In Range"
      L11_2(L12_2)
      L11_2 = stationaryDuiObj
      L11_2 = L11_2[A1_2]
      if L11_2 then
        L11_2 = stationaryDuiObj
        L11_2 = L11_2[A1_2]
        L11_2 = L11_2[L8_2]
        if L11_2 then
          L11_2 = CreateThread
          function L12_2()
            local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3
            L0_3 = nil
            L1_3 = nil
            L2_3 = nil
            L3_3 = A0_2
            while true do
              L4_3 = stationaryDuiObj
              L5_3 = A1_2
              L4_3 = L4_3[L5_3]
              if L4_3 then
                L4_3 = stationaryDuiObj
                L5_3 = A1_2
                L4_3 = L4_3[L5_3]
                L5_3 = L8_2
                L4_3 = L4_3[L5_3]
                if L4_3 then
                  L4_3 = Player
                  L5_3 = L3_3
                  L4_3 = L4_3(L5_3)
                  L5_3 = L4_3.state
                  L5_3 = L5_3.BodyDamage
                  L6_3 = Wait
                  L7_3 = 100
                  L6_3(L7_3)
                  L6_3 = DebugPrint
                  L7_3 = "Found Stat"
                  L6_3(L7_3)
                  L6_3 = L5_3.Pulse
                  if L6_3 == L0_3 then
                    L6_3 = L5_3.BloodPressure
                    L6_3 = L6_3[1]
                    if L6_3 == L1_3 then
                      L6_3 = L5_3.BloodPressure
                      L6_3 = L6_3[1]
                      if not L6_3 then
                        L6_3 = L5_3.oxygenSaturation
                        if L6_3 == L2_3 then
                          goto lbl_79
                        end
                      end
                    end
                  end
                  L0_3 = L5_3.Pulse
                  L6_3 = L5_3.BloodPressure
                  L1_3 = L6_3[1]
                  L2_3 = L5_3.oxygenSaturation
                  L6_3 = DebugPrint
                  L7_3 = "Sending Data to DUI"
                  L8_3 = L1_3
                  L9_3 = L0_3
                  L6_3(L7_3, L8_3, L9_3)
                  L6_3 = SendDuiMessage
                  L7_3 = stationaryDuiObj
                  L8_3 = A1_2
                  L7_3 = L7_3[L8_3]
                  L8_3 = L8_2
                  L7_3 = L7_3[L8_3]
                  L8_3 = json
                  L8_3 = L8_3.encode
                  L9_3 = {}
                  L10_3 = json
                  L10_3 = L10_3.encode
                  L11_3 = L5_3
                  L10_3 = L10_3(L11_3)
                  L9_3.damageStats = L10_3
                  L10_3 = L8_2
                  L9_3.currenticu = L10_3
                  L10_3 = L5_3.cardiacState
                  L9_3.rythm = L10_3
                  L10_3 = L9_2.bedcoords
                  L10_3 = L10_3.x
                  L9_3.posx = L10_3
                  L10_3 = L9_2.bedcoords
                  L10_3 = L10_3.y
                  L9_3.posy = L10_3
                  L10_3 = L9_2.bedcoords
                  L10_3 = L10_3.z
                  L9_3.posz = L10_3
                  L8_3, L9_3, L10_3, L11_3 = L8_3(L9_3)
                  L6_3(L7_3, L8_3, L9_3, L10_3, L11_3)
                  ::lbl_79::
                  L6_3 = stationaryDuiObj
                  L7_3 = A1_2
                  L6_3 = L6_3[L7_3]
                  L7_3 = L8_2
                  L6_3 = L6_3[L7_3]
                  L7_3 = usedscreenindex
                  L8_3 = A1_2
                  L7_3 = L7_3[L8_3]
                  L8_3 = L8_2
                  L7_3 = L7_3[L8_3]
                  if L6_3 == L7_3 then
                    L6_3 = usedscreenindex
                    L7_3 = A1_2
                    L6_3 = L6_3[L7_3]
                    L7_3 = L8_2
                    L6_3[L7_3] = nil
                    L6_3 = stationaryDuiObj
                    L7_3 = A1_2
                    L6_3 = L6_3[L7_3]
                    L7_3 = L8_2
                    L6_3 = L6_3[L7_3]
                    if not L6_3 then
                      L6_3 = print
                      L7_3 = "^1 Stationary screen not found when destroying"
                      L6_3(L7_3)
                    end
                    L6_3 = IsDuiAvailable
                    L7_3 = stationaryDuiObj
                    L8_3 = A1_2
                    L7_3 = L7_3[L8_3]
                    L8_3 = L8_2
                    L7_3 = L7_3[L8_3]
                    L6_3 = L6_3(L7_3)
                    if not L6_3 then
                      L6_3 = print
                      L7_3 = "^1 Stationary screen not available when destroying"
                      L6_3(L7_3)
                    end
                    L6_3 = SendDuiMessage
                    L7_3 = stationaryDuiObj
                    L8_3 = A1_2
                    L7_3 = L7_3[L8_3]
                    L8_3 = L8_2
                    L7_3 = L7_3[L8_3]
                    L8_3 = json
                    L8_3 = L8_3.encode
                    L9_3 = {}
                    L9_3.reset = true
                    L8_3, L9_3, L10_3, L11_3 = L8_3(L9_3)
                    L6_3(L7_3, L8_3, L9_3, L10_3, L11_3)
                    break
                  end
                  L6_3 = Wait
                  L7_3 = 1000
                  L6_3(L7_3)
              end
              else
                L4_3 = DebugPrint
                L5_3 = "^1 Stationary screen not found, should not affect anything, but will be fixed asap"
                L4_3(L5_3)
                L4_3 = Wait
                L5_3 = 1000
                L4_3(L5_3)
              end
            end
          end
          L11_2(L12_2)
        end
      end
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNetEvent
L1_1 = "osp_ambulance:DestroySyncScreenCl"
function L2_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = usedscreenindex
  L2_2 = L2_2[A1_2]
  L3_2 = stationaryDuiObj
  L3_2 = L3_2[A1_2]
  L3_2 = L3_2[A0_2]
  L2_2[A0_2] = L3_2
end
L0_1(L1_1, L2_1)
function L0_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2
  L4_2 = stationarySfHandle
  L5_2 = stationarySfHandle
  L5_2 = L5_2[A3_2]
  if not L5_2 then
    L5_2 = {}
  end
  L4_2[A3_2] = L5_2
  L4_2 = stationaryDuiObj
  L5_2 = stationaryDuiObj
  L5_2 = L5_2[A3_2]
  if not L5_2 then
    L5_2 = {}
  end
  L4_2[A3_2] = L5_2
  L4_2 = stationarySfName
  L5_2 = stationarySfName
  L5_2 = L5_2[A3_2]
  if not L5_2 then
    L5_2 = {}
  end
  L4_2[A3_2] = L5_2
  L4_2 = stationarySfHandle
  L4_2 = L4_2[A3_2]
  L4_2[A1_2] = nil
  L4_2 = stationaryDuiObj
  L4_2 = L4_2[A3_2]
  L4_2[A1_2] = nil
  L4_2 = stationarySfName
  L4_2 = L4_2[A3_2]
  L5_2 = "generic_texture_renderer_stationary"
  L6_2 = A1_2
  L5_2 = L5_2 .. L6_2
  L4_2[A1_2] = L5_2
  L4_2 = stationarySfHandle
  L4_2 = L4_2[A3_2]
  L5_2 = loadScaleform
  L6_2 = stationarySfName
  L6_2 = L6_2[A3_2]
  L6_2 = L6_2[A1_2]
  L5_2 = L5_2(L6_2)
  L4_2[A1_2] = L5_2
  L4_2 = DebugPrint
  L5_2 = "Stationary Scaleform Screen Name: "
  L6_2 = stationarySfName
  L6_2 = L6_2[A3_2]
  L6_2 = L6_2[A1_2]
  L7_2 = stationarySfHandle
  L7_2 = L7_2[A3_2]
  L7_2 = L7_2[A1_2]
  L4_2(L5_2, L6_2, L7_2)
  L4_2 = stationarySfHandle
  L4_2 = L4_2[A3_2]
  L4_2 = L4_2[A1_2]
  if not L4_2 then
    L4_2 = print
    L5_2 = "^1 Stationay screen handle not found"
    L4_2(L5_2)
  end
  runtimeTxd = "osp_b_dict"
  L4_2 = CreateRuntimeTxd
  L5_2 = "osp_b_dict"
  L4_2 = L4_2(L5_2)
  L5_2 = stationaryDuiObj
  L5_2 = L5_2[A3_2]
  L6_2 = CreateDui
  L7_2 = stationaryDuiUrl
  L8_2 = width
  L9_2 = height
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  L5_2[A1_2] = L6_2
  L5_2 = GetDuiHandle
  L6_2 = stationaryDuiObj
  L6_2 = L6_2[A3_2]
  L6_2 = L6_2[A1_2]
  L5_2 = L5_2(L6_2)
  L6_2 = CreateRuntimeTextureFromDuiHandle
  L7_2 = L4_2
  L8_2 = "osp_b_txd"
  L9_2 = L5_2
  L6_2 = L6_2(L7_2, L8_2, L9_2)
  L7_2 = Wait
  L8_2 = 10
  L7_2(L8_2)
  L7_2 = PushScaleformMovieFunction
  L8_2 = stationarySfHandle
  L8_2 = L8_2[A3_2]
  L8_2 = L8_2[A1_2]
  L9_2 = "SET_TEXTURE"
  L7_2(L8_2, L9_2)
  L7_2 = PushScaleformMovieMethodParameterString
  L8_2 = "osp_b_dict"
  L7_2(L8_2)
  L7_2 = PushScaleformMovieMethodParameterString
  L8_2 = "osp_b_txd"
  L7_2(L8_2)
  L7_2 = PushScaleformMovieFunctionParameterInt
  L8_2 = 0
  L7_2(L8_2)
  L7_2 = PushScaleformMovieFunctionParameterInt
  L8_2 = 0
  L7_2(L8_2)
  L7_2 = PushScaleformMovieFunctionParameterInt
  L8_2 = width
  L7_2(L8_2)
  L7_2 = PushScaleformMovieFunctionParameterInt
  L8_2 = height
  L7_2(L8_2)
  L7_2 = PopScaleformMovieFunctionVoid
  L7_2()
  L7_2 = GetFrameTime
  L7_2 = L7_2()
  L8_2 = 0.02
  if L7_2 > L8_2 then
    wt = 5
  else
    L8_2 = 0.011
    if L7_2 > L8_2 then
      wt = 3
    else
      wt = 1
    end
  end
  L8_2 = false
  function L9_2(A0_3)
    local L1_3
    L1_3 = true
    L8_2 = L1_3
  end
  function L10_2(A0_3)
    local L1_3
    L1_3 = false
    L8_2 = L1_3
  end
  L11_2 = lib
  L11_2 = L11_2.zones
  L11_2 = L11_2.box
  L12_2 = {}
  L13_2 = vec3
  L14_2 = A0_2.x
  L15_2 = A0_2.y
  L16_2 = A0_2.z
  L16_2 = L16_2 - 10
  L13_2 = L13_2(L14_2, L15_2, L16_2)
  L12_2.coords = L13_2
  L13_2 = propdupe
  L12_2.name = L13_2
  L13_2 = vec3
  L14_2 = Config
  L14_2 = L14_2.RenderDistance
  L15_2 = Config
  L15_2 = L15_2.RenderDistance
  L16_2 = Config
  L16_2 = L16_2.RenderDistance
  L13_2 = L13_2(L14_2, L15_2, L16_2)
  L12_2.size = L13_2
  L12_2.rotation = 45
  L12_2.debug = false
  L13_2 = inside
  L12_2.inside = L13_2
  L12_2.onEnter = L9_2
  L12_2.onExit = L10_2
  L11_2(L12_2)
  L11_2 = CreateThread
  function L12_2()
    local L0_3, L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3
    L0_3 = 1000
    while true do
      L1_3 = stationaryDuiObj
      L2_3 = A3_2
      L1_3 = L1_3[L2_3]
      L2_3 = A1_2
      L1_3 = L1_3[L2_3]
      if not L1_3 then
        break
      end
      L0_3 = 1000
      L1_3 = L8_2
      if L1_3 then
        L0_3 = wt
        L1_3 = stationaryDuiObj
        L2_3 = A3_2
        L1_3 = L1_3[L2_3]
        L2_3 = A1_2
        L1_3 = L1_3[L2_3]
        if L1_3 then
          L1_3 = stationarySfHandle
          L2_3 = A3_2
          L1_3 = L1_3[L2_3]
          L2_3 = A1_2
          L1_3 = L1_3[L2_3]
          if nil ~= L1_3 then
            L1_3 = HasScaleformMovieLoaded
            L2_3 = stationarySfHandle
            L3_3 = A3_2
            L2_3 = L2_3[L3_3]
            L3_3 = A1_2
            L2_3 = L2_3[L3_3]
            L1_3 = L1_3(L2_3)
            if L1_3 then
              L1_3 = DrawScaleformMovie_3dSolid
              L2_3 = stationarySfHandle
              L3_3 = A3_2
              L2_3 = L2_3[L3_3]
              L3_3 = A1_2
              L2_3 = L2_3[L3_3]
              L3_3 = A0_2.x
              L4_3 = A0_2.y
              L5_3 = A0_2.z
              L6_3 = A2_2.x
              L7_3 = stationaryScreenRot
              L6_3 = L6_3 + L7_3
              L7_3 = A2_2.y
              L8_3 = A2_2.z
              L9_3 = 2.0
              L10_3 = 2.0
              L11_3 = 2.0
              L12_3 = stationaryScale
              L12_3 = L12_3 * 1
              L13_3 = stationaryScale
              L13_3 = L13_3 * 0.5625
              L14_3 = 2
              L1_3(L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3, L10_3, L11_3, L12_3, L13_3, L14_3)
            end
          end
        end
      end
      L1_3 = Wait
      L2_3 = wt
      L1_3(L2_3)
    end
  end
  L11_2(L12_2)
end
stationaryShowScreen = L0_1
L0_1 = RegisterNUICallback
L1_1 = "beat"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = A0_2.coordx
  if L1_2 then
    L1_2 = TriggerSound
    L2_2 = "norm"
    L3_2 = vector3
    L4_2 = A0_2.coordx
    L5_2 = A0_2.coordy
    L6_2 = A0_2.coordz
    L3_2 = L3_2(L4_2, L5_2, L6_2)
    L4_2 = 5.0
    L1_2(L2_2, L3_2, L4_2)
    L1_2 = Config
    L1_2 = L1_2.UseXsound
    if L1_2 then
      L1_2 = xSound
      L2_2 = L1_2
      L1_2 = L1_2.PlayUrlPos
      L3_2 = "nsrbeat"
      L4_2 = "norm.mp3"
      L5_2 = 0.1
      L6_2 = vector3
      L7_2 = A0_2.coordx
      L8_2 = A0_2.coordy
      L9_2 = A0_2.coordz
      L6_2 = L6_2(L7_2, L8_2, L9_2)
      L7_2 = false
      L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
      L1_2 = xSound
      L2_2 = L1_2
      L1_2 = L1_2.Distance
      L3_2 = "nsrbeat"
      L4_2 = 5
      L1_2(L2_2, L3_2, L4_2)
      L1_2 = xSound
      L2_2 = L1_2
      L1_2 = L1_2.destroyOnFinish
      L3_2 = "nsrbeat"
      L4_2 = true
      L1_2(L2_2, L3_2, L4_2)
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "crash"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = A0_2.coordx
  if L1_2 then
    L1_2 = TriggerSound
    L2_2 = "crashingflat"
    L3_2 = vector3
    L4_2 = A0_2.coordx
    L5_2 = A0_2.coordy
    L6_2 = A0_2.coordz
    L3_2 = L3_2(L4_2, L5_2, L6_2)
    L4_2 = 5.0
    L1_2(L2_2, L3_2, L4_2)
    L1_2 = Config
    L1_2 = L1_2.UseXsound
    if L1_2 then
      L1_2 = xSound
      L2_2 = L1_2
      L1_2 = L1_2.PlayUrlPos
      L3_2 = "crash"
      L4_2 = "crashingflat.mp3"
      L5_2 = 0.1
      L6_2 = vector3
      L7_2 = A0_2.coordx
      L8_2 = A0_2.coordy
      L9_2 = A0_2.coordz
      L6_2 = L6_2(L7_2, L8_2, L9_2)
      L7_2 = false
      L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
      L1_2 = xSound
      L2_2 = L1_2
      L1_2 = L1_2.Distance
      L3_2 = "crash"
      L4_2 = 10
      L1_2(L2_2, L3_2, L4_2)
      L1_2 = xSound
      L2_2 = L1_2
      L1_2 = L1_2.destroyOnFinish
      L3_2 = "crash"
      L4_2 = true
      L1_2(L2_2, L3_2, L4_2)
    end
  end
end
L0_1(L1_1, L2_1)
L0_1 = RegisterNUICallback
L1_1 = "flat"
function L2_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L1_2 = A0_2.coordx
  if L1_2 then
    L1_2 = TriggerSound
    L2_2 = "flat"
    L3_2 = vector3
    L4_2 = A0_2.coordx
    L5_2 = A0_2.coordy
    L6_2 = A0_2.coordz
    L3_2 = L3_2(L4_2, L5_2, L6_2)
    L4_2 = 5.0
    L1_2(L2_2, L3_2, L4_2)
    L1_2 = Config
    L1_2 = L1_2.UseXsound
    if L1_2 then
      L1_2 = xSound
      L2_2 = L1_2
      L1_2 = L1_2.PlayUrlPos
      L3_2 = "crash"
      L4_2 = "flat.mp3"
      L5_2 = 0.1
      L6_2 = vector3
      L7_2 = A0_2.coordx
      L8_2 = A0_2.coordy
      L9_2 = A0_2.coordz
      L6_2 = L6_2(L7_2, L8_2, L9_2)
      L7_2 = false
      L1_2(L2_2, L3_2, L4_2, L5_2, L6_2, L7_2)
      L1_2 = xSound
      L2_2 = L1_2
      L1_2 = L1_2.Distance
      L3_2 = "crash"
      L4_2 = 10
      L1_2(L2_2, L3_2, L4_2)
      L1_2 = xSound
      L2_2 = L1_2
      L1_2 = L1_2.destroyOnFinish
      L3_2 = "crash"
      L4_2 = true
      L1_2(L2_2, L3_2, L4_2)
    end
  end
end
L0_1(L1_1, L2_1)
