Config = Config or {}

Config.webHook = ''
Config.webHookName = 'OSP Development - Ambulance' -- Name of the WebHook bot
Config.webHookLogo = 'https://cdn.discordapp.com/attachments/1102704629025886360/1227748671211180062/image.png?ex=6629890d&is=6617140d&hm=60043a8694fb72acc6cd4b1a7f21194d6dfc5df1ce2c79b34545ab358a3bf8c6&' -- Logo of the WebHook bot
