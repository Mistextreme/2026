Config = Config or {}

-- INCOMINNG INFORMATION SCREENS CONFIGURATION (ER SCREENS)
Config.ScreenProp = 'xm_prop_x17_tv_ceiling_01' -- The prop used for the screen

Config.IncomingRenderDistance = 70 -- The rendering distance of an incoming screen, recommended to keep above 30 to avoid sync issues.

Config.IncomingScreenSoundRange = 50

-- STATIONARY ECG CONFIGURATION (ICU SCREENS)
Config.StationaryECGProp = 'v_med_cor_ceilingmonitor' -- The prop used for the stationary ECG

Config.Hospitals = {
    {
        label = 'Pillbox Hospital',
        blip = {
            enable = true,
            icon = 61,
            color = 25,
            scale = 0.8,
            coords = vector3(304.27, -600.33, 43.28),
        },
        jobs = {
            "ambulance",
            "ambulance2",
        },

        checking = {
            vector3(312.2069, -593.4422, 43.0868),
        },

        duty = {
            vector3(310.3887, -597.3732, 43.2976),
        },

        vehicle = {
            vector4(294.7070, -607.2061, 43.0078, 68.8774),
            vector4(331.9502, -579.1585, 28.5665, 339.8551),
        },

        helicopter = {
            vector4(351.58, -587.45, 74.2, 160.5),
        },

        shop = {
            vector3(311.7910, -564.0659, 43.2841),
        },

        roof = {
            vector4(338.5, -583.85, 74.16, 245.5),
        },

        main = {
            vector4(332.3166, -595.6741, 43.2841, 245.5),
        },

        stash = {
            vector3(308.5978, -562.2446, 43.5902),
        },

        beds = {
            -- Add the xray variables to make it an xray bed
            {coords = vector4(348.7, -579.4, 43.1971, 157.0), taken = false, model = 'v_med_bed1', getOutOffset = 1.3, xray = true, xrayMonitor = vector3(344.79, -578.14, 43.84), xrayMonitorRot = vector3(0.0,0.0,122.0), screenScale = 0.042, lockedBed = true},


            {coords = vector4(319.3530, -580.8159, 43.2039, 157.9544), taken = false, model = 'v_med_bed1', getOutOffset = 1.3, lockedBed = true}, -- You can add the lockedBed = true variable to any bed you'd like to be locked from be used as a checkin bed (eg for surgery)
            {coords = vector4(324.1608, -582.8101, 43.2040, 157.6627), taken = false, model = 'v_med_bed1', getOutOffset = 1.3}, -- This is a normal bed, and is how most of your beds should look like. 
            {coords = vector4(322.6, -586.9601, 43.2040, 340.9906), taken = false, model = 'v_med_bed1', getOutOffset = 1.3},
            {coords = vector4(317.6, -585.3027, 43.2040, 340.0982), taken = false, model = 'v_med_bed1', getOutOffset = 1.3},
            {coords = vector4(314.5, -584.0378, 43.2040, 340.4092), taken = false, model = 'v_med_bed1', getOutOffset = 1.3 },
            {coords = vector4(311.0, -582.7598, 43.2040, 340.4864), taken = false, model = 'v_med_bed1', getOutOffset = 1.3},
            {coords = vector4(307.8, -581.4847, 43.2040, 340.6982), taken = false, model = 'v_med_bed1', getOutOffset = 1.3},
            {coords = vector4(309.1634, -577.5354, 43.2040, 157.5351), taken = false, model = 'v_med_bed1', getOutOffset = 1.3},
            {coords = vector4(313.8121, -579.1085, 43.2040, 157.7460), taken = false, model = 'v_med_bed1', getOutOffset = 1.3},
            {coords = vector4(-247.04, 6317.95, 32.34, 134.64), taken = false, model = 'v_med_bed1', getOutOffset = 1.3},
            {coords = vector4(-255.98, 6315.67, 32.34, 313.91), taken = false, model = 'v_med_bed1', getOutOffset = 1.3},
        },

        IncomingScreenPos = {
            vector4(328.2508, -576.4911, 46.0, 34.4687),
            vector4(300.8384, -582.8441, 46.0, 32.9394),
        },

        IncomingScreenSoundPos = {
            vector3(309.2776, -589.0244, 45.1519),
            vector3(329.5522, -579.1614, 44.6322),
        },

        StationaryECG = { -- IF YOU WANT MORE THAN 6 ECGS YOU NEED TO CREATE MORE GFX FILES. MORE INFO HERE: https://osp-development.gitbook.io/ambulance-job/faq/general
            {
                coords = vector4(318.7118, -579.8219, 45.8, 344.3082),
                bedcoords = vector3(319.2666, -581.1186, 44.2040),
                name = 'ICU 1'
            },
            {
                coords = vector4(323.7489, -581.5202, 45.8, 337.8694),
                bedcoords = vector3(324.2232, -583.0401, 44.2040),
                name = 'ICU 2'
            },
            {
                coords = vector4(321.3699, -587.7664, 45.8, 163.4208),
                bedcoords = vector3(322.6256, -586.7698, 44.2130),
                name = 'ICU 3'
            },
            {
                coords = vector4(316.4125, -586.0515, 45.8, 163.2631),
                bedcoords = vector3(317.5998, -585.4157, 44.2040),
                name = 'ICU 4'
            },
            {
                coords = vector4(313.1407, -584.6058, 45.8, 162.2001),
                bedcoords = vector3(314.5409, -583.9615, 44.2040),
                name = 'ICU 5'
            },
            {
                coords = vector4(309.6808, -583.5556, 45.8, 162.3711),
                bedcoords = vector3(311.2327, -582.8145, 44.2040),
                name = 'ICU 6'
            },
            -- Some people have experienced issues with having a lot of loaded gfx files.
            -- IF YOU WANT MORE THAN 6 ECGS YOU NEED TO CREATE MORE GFX FILES.
            -- MORE INFO HERE: https://osp-development.gitbook.io/ambulance-job/faq/general

            -- {
            --     coords = vector4(308.3385, -582.8965, 45.8, 159.9160),
            --     bedcoords = vector3(307.7694, -581.3610, 44.2049),
            --     name = 'ICU 7'
            -- },
            -- {
            --     coords = vector4(310.4750, -576.9198, 45.8, 340.2058),
            --     bedcoords = vector3(309.2775, -577.7110, 44.2044),
            --     name = 'ICU 8'
            -- },
            -- {
            --     coords = vector4(315.0273, -578.4716, 45.8, 342.0016),
            --     bedcoords = vector3(313.8342, -579.3513, 44.2040),
            --     name = 'ICU 9'
            -- },
        },
        
        -- Following actions only support integration for default esx
        boss = {
            -- vector3(334.7231, -594.4026, 43.2841),
        },
        cloakroom = {
            -- vector3(302.1178, -598.8913, 43.0763),
        },
    }
}

Config.JailBeds = {
    {coords = vector4(1761.96, 2597.74, 45.66, 270.14), taken = false, model = 'v_med_bed1', getOutOffset = 1.3},
    {coords = vector4(1761.96, 2591.51, 45.66, 269.8), taken = false, model = 'v_med_bed1', getOutOffset = 1.3},
    {coords = vector4(1771.8, 2598.02, 45.66, 89.05), taken = false, model = 'v_med_bed1', getOutOffset = 1.3},
    {coords = vector4(1771.85, 2591.85, 45.66, 91.51), taken = false, model = 'v_med_bed1', getOutOffset = 1.3},
}
