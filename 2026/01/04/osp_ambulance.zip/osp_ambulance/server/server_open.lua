if Config.Framework == 'qb' then
    QBCore = exports['qb-core']:GetCoreObject()

    function GetPlayer(source)
        return QBCore.Functions.GetPlayer(tonumber(source))
    end

    function CreateUseableItem(name, cb)
        if Config.UsedInventory == 'qs' then
            exports['qs-inventory']:CreateUsableItem(name, cb)
            -- exports['qs-inventory']:CreateUseableItem(name, cb)
        else
            QBCore.Functions.CreateUseableItem(name, cb)
        end
    end

    function GetIdentifier(source)
        local xPlayer = QBCore.Functions.GetPlayer(source)
        if xPlayer then
            return xPlayer.PlayerData.citizenid
        end
    end

    function ClearInventory(sourcePlayer)
        if Config.UsedInventory == 'qs' then
            exports['qs-inventory']:ClearInventory(sourcePlayer.PlayerData.source, Config.ExcludeItems)
        elseif Config.UsedInventory == 'ox' then
            exports.ox_inventory:ClearInventory(sourcePlayer.PlayerData.source, Config.ExcludeItems)
        elseif Config.UsedInventory == 'codem' then
            exports['codem-inventory']:ClearInventory(sourcePlayer.PlayerData.source, Config.ExcludeItems)
        elseif Config.UsedInventory == 'origen' then
            exports.origen_inventory:ClearInventory(sourcePlayer.PlayerData.source, Config.ExcludeItems)
        else
            if Config.NewQbInventory then 
                exports['qb-inventory']:ClearInventory(sourcePlayer.PlayerData.source, Config.ExcludeItems)
            else
                sourcePlayer.Functions.ClearInventory(Config.ExcludeItems)
            end
        end
        MySQL.update('UPDATE players SET inventory = ? WHERE citizenid = ?', { json.encode({}), sourcePlayer.PlayerData.citizenid })
    end

    RegisterServerEvent("osp_ambulance:addItem")
    AddEventHandler("osp_ambulance:addItem", function(name, amount)
        if amount == nil then amount = 1 end
        local authItem = false
        for k,v in pairs(Config.Casts) do
            for _,x in pairs(v.casts) do
                if x.itemName == name then
                    authItem = true
                end
            end
        end
        if name == 'stretcher' or name == 'tourniquet' or name == 'ecg' then 
            authItem = true
        end
        if not authItem then 
            print('NON AUTHORIZED ITEM SPAWNING BY ID: ', source)
            return
        end
        local src = source
        AddItem(src, name, amount)
    end)

    function AddItem(src, name, amount)
        local sourcePlayer = QBCore.Functions.GetPlayer(src)
        if Config.UsedInventory == 'qs' then
            exports['qs-inventory']:AddItem(src, name, amount)
        elseif Config.UsedInventory == 'ox' then
            exports.ox_inventory:AddItem(src, name, amount)
        elseif Config.UsedInventory == 'chezza' then
            exports.inventory:AddItemToPlayer(src, name, amount)
        elseif Config.UsedInventory == 'codem' then
            exports['codem-inventory']:AddItem(src, name, amount)
        elseif Config.UsedInventory == 'origen' then
            exports.origen_inventory:addItem(src, name, amount)
        else
            if Config.NewQbInventory then
                exports['qb-inventory']:AddItem(src, name, amount, false, false, 'ambulancejob')
            else
                sourcePlayer.Functions.AddItem(name, amount)
            end
        end
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[name], "add")
    end

    function RemoveItem(src, name, amount)
        local sourcePlayer = QBCore.Functions.GetPlayer(src)
        if Config.UsedInventory == 'qs' then
            exports['qs-inventory']:RemoveItem(src, name, amount)
        elseif Config.UsedInventory == 'ox' then
            exports.ox_inventory:RemoveItem(src, name, amount)
        elseif Config.UsedInventory == 'chezza' then
            exports.inventory:RemoveItemFromPlayer(src, name, amount)
        elseif Config.UsedInventory == 'codem' then
            exports['codem-inventory']:RemoveItem(src, name, amount)
        elseif Config.UsedInventory == 'origen' then
            exports.origen_inventory:removeItem(src, name, amount)
        else
            if Config.NewQbInventory then
                exports['qb-inventory']:RemoveItem(src, name, amount, false, 'ambulancejob')
            else
                sourcePlayer.Functions.RemoveItem(name, amount)
            end
        end
        TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[name], "remove")
    end

    RegisterServerEvent("osp_ambulance:removeItem")
    AddEventHandler("osp_ambulance:removeItem", function(name, amount)
        if amount == nil then amount = 1 end
        local src = source
        RemoveItem(src, name, amount)
    end)

    function CheckMoney(source)
        local src = source
        local sourcePlayer = QBCore.Functions.GetPlayer(src)
        local currentCash = sourcePlayer.Functions.GetMoney('bank')
        return currentCash
    end

    function RemoveMoney(source, amount)
        local src = source
        local sourcePlayer = QBCore.Functions.GetPlayer(src)
        if sourcePlayer then
            sourcePlayer.Functions.RemoveMoney('bank', amount)
        end
    end


    -- Commands

    QBCore.Commands.Add('911ems', lang.info.ems_report, {{name = 'message', help = lang.info.message_sent}}, false, function(source, args)
        local src = source
        local message
        if args[1] then message = table.concat(args, " ") else message = lang.info.civ_call end
        local ped = GetPlayerPed(src)
        local coords = GetEntityCoords(ped)
        local players = QBCore.Functions.GetQBPlayers()
        for _, v in pairs(players) do
            for _,x in pairs(Config.AmbulanceJobs) do
                if v.PlayerData.job.name == x and v.PlayerData.job.onduty then
                    TriggerClientEvent('hospital:client:ambulanceAlert', v.PlayerData.source, coords, message)
                end
            end
        end
    end)

    QBCore.Commands.Add("revive", lang.info.revive_player_a, {{name = "id", help = lang.info.player_id}}, false, function(source, args)
        local src = source
        if args[1] then
            local sourcePlayer = GetPlayer(tonumber(args[1]))
            if sourcePlayer then
                TriggerClientEvent('hospital:client:Revive', sourcePlayer.PlayerData.source)
            else
                TriggerClientEvent('osp_ambulance:SendTextMessage', src, 'Chat', 'Player was not online', 3000, 'error')
            end
        else
            TriggerClientEvent('hospital:client:Revive', src)
        end
    end, "admin")


    QBCore.Commands.Add("kill", lang.info.kill, {{name = "id", help = lang.info.player_id}}, false, function(source, args)
        local src = source
        if args[1] then
            local sourcePlayer = GetPlayer(tonumber(args[1]))
            if sourcePlayer then
                TriggerClientEvent('hospital:client:KillPlayer', sourcePlayer.PlayerData.source)
            else
                TriggerClientEvent('osp_ambulance:SendTextMessage', src, 'Chat', 'Player was not online', 3000, 'error')
            end
        else
            TriggerClientEvent('hospital:client:KillPlayer', src)
        end
    end, "admin")

    lib.callback.register('osp_ambulance:getWoundData', function(source, data)
        if source == nil then return end
        local src = source
        local sourcePlayer = QBCore.Functions.GetPlayer(src)
        if not sourcePlayer then
            -- print("Error: Invalid player data or identifier.")
            return
        end
        local sqlQuery = [[
            SELECT `woundData` FROM players WHERE `citizenid` = @citizenid
        ]]
        local callbackData = nil
        local timeout = 5000
        
        MySQL.Async.fetchAll(sqlQuery, {
            ['@citizenid'] = sourcePlayer.PlayerData.citizenid
        },function(response)
            local woundData = nil
            if response[1] and response[1].woundData then
                woundData = json.decode(response[1].woundData)
            else
                woundData = false
            end
            callbackData = woundData
        end)

        while callbackData == nil do
            Wait(10)
            timeout = timeout - 10
            if timeout <= 0 then
                return false
            end
        end
        return callbackData
    end)

    lib.callback.register('osp_ambulance:getInventory', function(source, data)
        local sourcePlayer = GetPlayer(source)
        local inventory = nil
        if Config.UsedInventory == 'qs' then
            inventory = exports['qs-inventory']:GetInventory(source)
        elseif Config.UsedInventory == 'ox' then
            inventory = exports.ox_inventory:GetInventoryItems(source)
        elseif Config.UsedInventory == 'chezza' then
            inventory = exports.inventory:getInventory(sourcePlayer)
        elseif Config.UsedInventory == 'codem' then
            inventory = exports['codem-inventory']:GetInventory(sourcePlayer.PlayerData.citizenid, source)
        else
            inventory = sourcePlayer.PlayerData.items
        end
        while not inventory do Wait(10) end
        return inventory
    end)

    RegisterServerEvent("osp_ambulance:saveWoundDataSv")
    AddEventHandler("osp_ambulance:saveWoundDataSv", function(data)
        local src = source
        local sourcePlayer = QBCore.Functions.GetPlayer(src)
        if sourcePlayer and data then 
            MySQL.Async.execute('UPDATE players SET woundData = @woundData WHERE citizenid = @citizenid', {
                ['@woundData'] = json.encode(data),
                ['@citizenid'] = sourcePlayer.PlayerData.citizenid,
            }, function()
            end)
        end
    end)

    RegisterNetEvent('hospital:server:SetArmourStatus', function(armor) -- Used to set the death status of a player, used by other qbcore scripts for easy intregration
        local src = source
        local sourcePlayer = QBCore.Functions.GetPlayer(src)
        if sourcePlayer then
            sourcePlayer.Functions.SetMetaData("armor", armor)
        end
    end)

    RegisterNetEvent('hospital:server:SetDeathStatus', function(isDead) -- Used to set the death status of a player, used by other qbcore scripts for easy intregration
        local src = source
        local sourcePlayer = QBCore.Functions.GetPlayer(src)
        if sourcePlayer then
            sourcePlayer.Functions.SetMetaData("isdead", isDead)
        end
    end)
    
    RegisterNetEvent('hospital:server:SetLaststandStatus', function(bool) -- Used to set the laststand status of a player, used by other qbcore scripts for easy intregration
        local src = source
        local sourcePlayer = QBCore.Functions.GetPlayer(src)
        if sourcePlayer then
            sourcePlayer.Functions.SetMetaData("inlaststand", bool)
        end
    end)

    RegisterNetEvent('hospital:server:resetHungerThirst', function()
        local sourcePlayer = QBCore.Functions.GetPlayer(source)
    
        if not sourcePlayer then return end
    
        sourcePlayer.Functions.SetMetaData('hunger', 100)
        sourcePlayer.Functions.SetMetaData('thirst', 100)
    
        TriggerClientEvent('hud:client:UpdateNeeds', source, 100, 100)
    end)

    RegisterNetEvent('osp_ambulance:registerStash', function(stashid)
        if Config.UsedInventory == 'ox' then
            exports.ox_inventory:RegisterStash(stashid, 'Ambulance Stash', 20, 20000, true)
        elseif Config.UsedInventory == 'origen' then
            exports.origen_inventory:registerStash(stashid, {
                label = "Ambulance Locker",
                slots = 20,
                weight = 20000
            })
        elseif Config.NewQbInventory then
            local data = { label = 'Ambulance Stash', maxweight = 40000, slots = 50 }
            exports['qb-inventory']:OpenInventory(source, stashid, data)
        end
    end)


elseif Config.Framework == 'esx' then
    ESX = exports["es_extended"]:getSharedObject()

    function GetPlayer(source)
        return ESX.GetPlayerFromId(source)
    end

    if GetResourceState("esx_society") ~= 'missing' then
        TriggerEvent('esx_society:registerSociety', 'ambulance', 'Ambulance', 'society_ambulance', 'society_ambulance', 'society_ambulance', {type = 'public'})
    end

    function CreateUseableItem(name, cb)
        if Config.UsedInventory == 'qs' then
            exports['qs-inventory']:CreateUsableItem(name, cb)
            -- exports['qs-inventory']:CreateUseableItem(name, cb)
        else
            ESX.RegisterUsableItem(name, cb)
        end
    end

    function GetIdentifier(source)
        local xPlayer = ESX.GetPlayerFromId(source)
        if xPlayer then
            return xPlayer.identifier
        end
    end

    function ClearInventory(sourcePlayer)
        if Config.UsedInventory == 'qs' then
            exports['qs-inventory']:ClearInventory(sourcePlayer.source, Config.ExcludeItems)
        elseif Config.UsedInventory == 'ox' then
            exports.ox_inventory:ClearInventory(sourcePlayer.source, Config.ExcludeItems)
        elseif Config.UsedInventory == 'codem' then
            exports['codem-inventory']:ClearInventory(sourcePlayer.source, Config.ExcludeItems)
        elseif Config.UsedInventory == 'origen' then
            exports.origen_inventory:ClearInventory(sourcePlayer.PlayerData.source, Config.ExcludeItems)
        else
            for i = 1, #sourcePlayer.inventory, 1 do
                if sourcePlayer.inventory[i].count > 0 then
                    for k,v in pairs(Config.ExcludeItems) do
                        if v == sourcePlayer.inventory[i].name then return end
                    end
                    sourcePlayer.setInventoryItem(sourcePlayer.inventory[i].name, 0)
                end
            end
        end
    end


    RegisterServerEvent("osp_ambulance:addItem")
    AddEventHandler("osp_ambulance:addItem", function(name, amount)
        if amount == nil then amount = 1 end
        local authItem = false
        for k,v in pairs(Config.Casts) do
            for _,x in pairs(v.casts) do
                if x.itemName == name then
                    authItem = true
                end
            end
        end
        if name == 'stretcher' or name == 'tourniquet' or name == 'ecg' then 
            authItem = true
        end
        if not authItem then 
            print('NON AUTHORIZED ITEM SPAWNING BY ID: ', source)
            return
        end
        local src = source
        AddItem(src, name, amount)
    end)

    function AddItem(src, name, amount)
        local sourcePlayer = GetPlayer(src)
        if Config.UsedInventory == 'qs' then
            exports['qs-inventory']:AddItem(src, name, amount)
        elseif Config.UsedInventory == 'ox' then
            exports.ox_inventory:AddItem(src, name, amount)
        elseif Config.UsedInventory == 'chezza' then
            exports.inventory:AddItemToPlayer(src, name, amount)
        elseif Config.UsedInventory == 'codem' then
            exports['codem-inventory']:AddItem(src, name, amount)
        elseif Config.UsedInventory == 'origen' then
            exports.origen_inventory:addItem(src, name, amount)
        else
            sourcePlayer.addInventoryItem(name, amount)
        end
    end

    function RemoveItem(src, name, amount)
        local sourcePlayer = GetPlayer(src)
        if Config.UsedInventory == 'qs' then
            exports['qs-inventory']:RemoveItem(src, name, amount)
        elseif Config.UsedInventory == 'ox' then
            exports.ox_inventory:RemoveItem(src, name, amount)
        elseif Config.UsedInventory == 'chezza' then
            exports.inventory:RemoveItemFromPlayer(src, name, amount)
        elseif Config.UsedInventory == 'codem' then
            exports['codem-inventory']:RemoveItem(src, name, amount)
        elseif Config.UsedInventory == 'origen' then
            exports.origen_inventory:removeItem(src, name, amount)
        else
            sourcePlayer.removeInventoryItem(name, amount)
        end
    end

    RegisterServerEvent("osp_ambulance:removeItem")
    AddEventHandler("osp_ambulance:removeItem", function(name, amount)
        if amount == nil then amount = 1 end
        local src = source
        RemoveItem(src, name, amount)
    end)

    function CheckMoney(source)
        local src = source
        local sourcePlayer = GetPlayer(source)
        local currentCash = sourcePlayer.getAccount('bank').money
        return currentCash
    end

    function RemoveMoney(source, amount)
        local src = source
        local sourcePlayer = GetPlayer(src)
        if sourcePlayer then
            sourcePlayer.removeAccountMoney('bank', tonumber(amount))
        end
    end


    lib.callback.register('osp_ambulance:getName', function(source, data)
		local sourcePlayer = GetPlayer(source)
        if not sourcePlayer then return end
        if not sourcePlayer.identifier then return end
		local result = MySQL.query.await('SELECT firstname, lastname FROM `users` WHERE identifier = ?', {
		    sourcePlayer.identifier
		})
		if result[1] and result[1].firstname and result[1].lastname then
			return {firstname = result[1].firstname, lastname = result[1].lastname}
        else
            return nil
        end
    end)



    -- lib.callback.register('osp_ambulance:getName', async function(source, data)
    --     local sourcePlayer = GetPlayer(source)
    --     if not sourcePlayer then return end
    --     if not sourcePlayer.identifier then return end
        
    --     local result = await MySQL.query('SELECT firstname, lastname FROM users WHERE identifier = ?', {
    --         sourcePlayer.identifier
    --     })

    --     if result[1] and result[1].firstname and result[1].lastname then
    --         return {firstname = result[1].firstname, lastname = result[1].lastname}
    --     end
    -- end)



    -- Commands

    ESX.RegisterCommand('911ems', 'user', function(xPlayer, args, showError)
        local src = xPlayer.source
        local message
        if args[1] then message = table.concat(args, " ") else message = lang.info.civ_call end
        local ped = GetPlayerPed(src)
        local coords = GetEntityCoords(ped)
        local serverPlayers = GetPlayers()
        for k,v in pairs(serverPlayers) do
            local sourcePlayer = GetPlayer(v)
            if sourcePlayer then
                for _,x in pairs(Config.AmbulanceJobs) do
                    if sourcePlayer.job.name == x then
                        TriggerClientEvent('hospital:client:ambulanceAlert', v, coords, message)
                    end
                end
            end
        end
    end, false, {help = lang.info.message_sent})

    ESX.RegisterCommand('revive', 'admin', function(xPlayer, args, showError)
        if args.id then
            TriggerClientEvent('hospital:client:Revive', args.id)
        else
            TriggerClientEvent('hospital:client:Revive', xPlayer.source)
        end
    end, true, {help = 'revive', validate = true, arguments = {
        {name = 'id', help = lang.info.player_id, type = 'playerId'}
    }})

    -- ESX.RegisterCommand('heal', 'admin', function(xPlayer, args, showError)
    --     if args.id then
    --         TriggerClientEvent('osp_ambulance:heal', args.id)
    --     else
    --         TriggerClientEvent('osp_ambulance:heal', xPlayer.source)
    --     end
    -- end, true, {help = 'heal', validate = true, arguments = {
    --     {name = 'id', help = 'The player id', type = 'number'}
    -- }})

    ESX.RegisterCommand('kill', 'admin', function(xPlayer, args, showError)
        local src = xPlayer.source
        if args.id  then
            local sourcePlayer = GetPlayer(args.id)
            if sourcePlayer then
                TriggerClientEvent('hospital:client:KillPlayer', args.id)
            else
                TriggerClientEvent('osp_ambulance:SendTextMessage', src, 'Chat', 'Player was not online', 3000, 'error')
            end
        else
            TriggerClientEvent('hospital:client:KillPlayer', src)
        end
    end, false, {help = 'kill', validate = false, arguments = {
        {name = 'id',validate = false, help = lang.info.player_id, type = 'playerId'}
    }}) 

    lib.callback.register('osp_ambulance:getWoundData', function(source, data)
        local src = source
        local sourcePlayer = GetPlayer(source)
        if not sourcePlayer then
            -- print("Error: Invalid player data or identifier.")
            return
        end
        local sqlQuery = [[
            SELECT `woundData` FROM users WHERE `identifier` = @identifier
        ]]
        
        local callbackData = nil
        local timeout = 5000
        
        MySQL.Async.fetchAll(sqlQuery, {
            ['@identifier'] = sourcePlayer.identifier
        },function(response)
            local woundData = nil
            if response[1] and response[1].woundData then
                woundData = json.decode(response[1].woundData)
            else
                woundData = false
            end
            callbackData = woundData
        end)

        while callbackData == nil do
            Wait(10)
            timeout = timeout - 10
            if timeout <= 0 then
                return false
            end
        end
        return callbackData
    end)
    
    lib.callback.register('osp_ambulance:getInventory', function(source, data)
        local sourcePlayer = GetPlayer(source)
        local inventory = nil
        if Config.UsedInventory == 'qs' then
            inventory = exports['qs-inventory']:GetInventory(source)
        elseif Config.UsedInventory == 'ox' then
            inventory = exports.ox_inventory:GetInventoryItems(source)
        elseif Config.UsedInventory == 'chezza' then
            inventory = exports.inventory:getInventory(sourcePlayer)
        elseif Config.UsedInventory == 'codem' then
            inventory = exports['codem-inventory']:GetInventory(sourcePlayer, source)
        else
            inventory = sourcePlayer.getInventory()
        end
        return inventory
    end)

    RegisterServerEvent("osp_ambulance:saveWoundDataSv")
    AddEventHandler("osp_ambulance:saveWoundDataSv", function(data)
        local src = source
        local sourcePlayer = GetPlayer(src)
        if not sourcePlayer then
            -- print("Error: Invalid player data or identifier.")
            return
        end
        MySQL.Async.execute('UPDATE users SET woundData = @woundData WHERE identifier = @identifier', {
            ['@woundData'] = json.encode(data),
            ['@identifier'] = sourcePlayer.identifier,
        }, function()
        end)
    end)

    RegisterNetEvent('hospital:server:SetDeathStatus', function(isDead) -- Used to set the death status of a player, used by other qbcore scripts for easy intregration
        local src = source
        if isDead then
            TriggerClientEvent('osp_ambulance:OnPlayerDead', src)
        else
            TriggerClientEvent('osp_ambulance:OnPlayerSpawn', src)
        end 
        -- Player(src).state:set('isDead', isDead, true)
    end)
    
    RegisterNetEvent('hospital:server:SetLaststandStatus', function(bool) -- Used to set the laststand status of a player, used by other qbcore scripts for easy intregration
        local src = source
        if bool then
            TriggerClientEvent('osp_ambulance:OnPlayerDead', src)
        else
            TriggerClientEvent('osp_ambulance:OnPlayerSpawn', src)
        end 
        -- Player(src).state:set('isLastStand', bool, true)
    end)

    RegisterNetEvent('hospital:server:resetHungerThirst', function()
        local sourcePlayer = GetPlayer(source)
        if not sourcePlayer then return end
    
        TriggerClientEvent('esx_status:set', source, 'hunger', 1000000)
        TriggerClientEvent('esx_status:set', source, 'thirst', 1000000)
    end)
    
    RegisterNetEvent('osp_ambulance:registerStash', function(stashid)
        if Config.UsedInventory == 'ox' then
            exports.ox_inventory:RegisterStash(stashid, 'Ambulance Stash', 20, 20000, true)
        elseif Config.UsedInventory == 'origen' then
            exports.origen_inventory:registerStash(stashid, {
                label = "Ambulance Locker",
                slots = 20,
                weight = 20000
            })
        end
    end)

    RegisterNetEvent('osp_amblance:setDeathStatus')
    AddEventHandler('osp_amblance:setDeathStatus', function(isDead)
        local xPlayer = GetPlayer(source)
        if not xPlayer then return end
        if type(isDead) == 'boolean' then
            MySQL.update('UPDATE users SET is_dead = ? WHERE identifier = ?', {isDead, xPlayer.identifier})
            Player(source).state:set('isDead', isDead, true)
        end
    end)

end

function DebugPrint(...)
    if Config.Debug then
        print(...)
    end
end



lib.callback.register('osp_ambulance:GetTime', function(source, data)
    return os.date("%X")
end)

CreateUseableItem('pager', function(source, item)
    TriggerClientEvent('osp_ambulance:incoming', source)
end)

CreateUseableItem('stretcher', function(source, item)
    TriggerClientEvent('osp_ambulance:SpawnStretcher', source)
end)

CreateUseableItem('wheelchair', function(source, item)
    TriggerClientEvent('osp_ambulance:givePlayerWheelChair', source, true)
end)

CreateUseableItem('crutch', function(source, item)
    TriggerClientEvent('osp_ambulance:givePlayerCrutch', source, true)
end)

CreateUseableItem('ecg', function(source, item)
    TriggerClientEvent('osp_ambulance:activate', source)
end)

CreateUseableItem('bandage', function(source, item)
    RemoveItem(source, 'bandage', 1)
    TriggerClientEvent('osp_ambulance:useBandage', source)
end)

CreateUseableItem('temporary_tourniquet', function(source, item)
    RemoveItem(source, 'temporary_tourniquet', 1)
    TriggerClientEvent('osp_ambulance:useTorniquet', source)
end)

CreateUseableItem('painkillers', function(source, item)
    RemoveItem(source, 'painkillers', 1)
    TriggerClientEvent('osp_ambulance:painKillers', source)
end)

CreateUseableItem('ifak', function(source, item)
    TriggerClientEvent('osp_ambulance:useIfak', source)
    RemoveItem(source, 'ifak', 1)
    Wait(4000)
    AddItem(source, 'bandage', 1)
    AddItem(source, 'painkillers', 1)
    AddItem(source, 'temporary_tourniquet', 1)
end)

RegisterNetEvent('osp_ambulance:buyItemSv', function(data, input, price, name)
    local src = source
    if data.amount then
        if data.amount > 0 then
            if data.amount >= input[1] then
                local money = CheckMoney(src)
                if money*input[1] > price*input[1] then
                    RemoveMoney(src, price*input[1])
                    for i=1,input[1] do
                        AddItem(src, name, 1)
                    end
                    if data.index then
                        TriggerEvent('osp_ambulance:RemoveItemFromStock', data.index, input[1])
                    end
                else
                    TriggerClientEvent('osp_ambulance:SendTextMessage', src, lang.interactions.medicalHeader, lang.error.not_enough_money, 5000, "error")
                end
            end
        else
            print('no stock')
        end
    else
        local money = CheckMoney(src)
        if money > price*input[1] then
            RemoveMoney(src, price*input[1])
            for i=1,input[1] do
                AddItem(src, name, 1)
            end
        else
            TriggerClientEvent('osp_ambulance:SendTextMessage', src, lang.interactions.medicalHeader, lang.error.not_enough_money, 5000, "error")
        end
    end
end)



RegisterNetEvent('osp_ambulance:revive', function(player)
    TriggerClientEvent('hospital:client:Revive', player)
end)

RegisterNetEvent('osp_ambulance:partialReviveSv', function(player)
    TriggerClientEvent('osp_ambulance:partialRevive', player)
end)

AddEventHandler('txAdmin:events:healedPlayer', function(eventData)
    if GetInvokingResource() ~= "monitor" or type(eventData) ~= "table" or type(eventData.id) ~= "number" then
        return
    end

    TriggerClientEvent('hospital:client:Revive', eventData.id)
end)

CreateThread(function()
    Wait(1000)
    while true do
        doctorCount = 0
        local serverPlayers = GetPlayers()
        for k,v in pairs(serverPlayers) do
            local sourcePlayer = GetPlayer(v)
            if sourcePlayer then
                if Config.Framework == 'qb' then
                    for _,x in pairs(Config.AmbulanceJobs) do
                        if sourcePlayer.PlayerData.job.name == x and sourcePlayer.PlayerData.job.onduty then
                            doctorCount = doctorCount + 1
                        end
                    end
                else
                    for _,x in pairs(Config.AmbulanceJobs) do
                        if sourcePlayer.job.name == x then
                            doctorCount = doctorCount + 1
                        end
                    end
                end
            end
            Wait(10)
        end
        Wait(2*60*1000)
        TriggerClientEvent("hospital:client:SetDoctorCount", -1, doctorCount)
    end
end)

RegisterNetEvent('hospital:server:SendToBed', function(bedId, isRevive, hospitalID)
    local src = source
    local sourcePlayer = GetPlayer(src)
    local wounds = Player(src).state.BodyDamage.BodyPartDamage.Wounds
    TriggerClientEvent('hospital:client:SendToBed', src, bedId, Config.Hospitals[hospitalID]["beds"][bedId], isRevive, hospitalID)
    TriggerClientEvent('hospital:client:SetBed', -1, bedId, true, hospitalID)
    if isRevive then
        TriggerClientEvent('osp_ambulance:SendBillEmail', src, Config.WoundBills and BillCalculator(wounds) or Config.BillCost)
        if Config.Framework == 'qb' then 
            if Config.NewQbInventory then 
                exports['qb-banking']:AddMoney('ambulance', Config.WoundBills and BillCalculator(wounds) or Config.BillCost, 'Player treatment')
            else
                exports['qb-management']:AddMoney("ambulance", Config.WoundBills and BillCalculator(wounds) or Config.BillCost)
            end
            sourcePlayer.Functions.RemoveMoney("bank", Config.WoundBills and BillCalculator(wounds) or Config.BillCost, "respawned-at-hospital")
        else
            sourcePlayer.removeAccountMoney('bank', tonumber(Config.WoundBills and BillCalculator(wounds) or Config.BillCost))
        end
    end
end)

RegisterNetEvent('osp_ambulance:mutePlayer', function(bool)
    MumbleSetPlayerMuted(source, bool)
    Player(source).state.isDead = bool
    -- exports['saltychat']:SetPlayerAlive(source, not bool) -- Uncomment if using saltychat
end)


function SetClosestBed(src)
    local pos = GetEntityCoords(GetPlayerPed(src), true)
    local current = nil
    local dist = nil
    local hosID = nil
    for id, hospital in pairs(Config.Hospitals) do
        for k, v in pairs(hospital["beds"]) do
            if not v.taken and not v.lockedBed then
                local dist2 = #(pos - vector3(hospital["beds"][k].coords.x, hospital["beds"][k].coords.y, hospital["beds"][k].coords.z))
                if current then
                    if dist2 < dist then
                        current = k
                        dist = dist2
                        hosID = id
                    end
                else
                    dist = dist2
                    current = k
                    hosID = id
                end
            end
        end
    end

    return current, hosID
end

function respawnCode(src)
    local sourcePlayer = GetPlayer(src)
    local wounds = Player(src).state.BodyDamage.BodyPartDamage.Wounds
    if Config.Framework == 'qb' then
        if Config.WipeInventoryOnRespawn then
            ClearInventory(sourcePlayer)
            TriggerClientEvent('osp_ambulance:SendTextMessage', src, lang.interactions.medicalHeader, lang.error.possessions_taken, 3000, 'error')
        end
        sourcePlayer.Functions.RemoveMoney("bank", Config.WoundBills and BillCalculator(wounds) or Config.BillCost, "respawned-at-hospital")
        if Config.NewQbInventory then 
            exports['qb-banking']:AddMoney('ambulance', Config.WoundBills and BillCalculator(wounds) or Config.BillCost, 'Player treatment')
        else
            exports['qb-management']:AddMoney("ambulance", Config.WoundBills and BillCalculator(wounds) or Config.BillCost)
        end
        TriggerClientEvent('osp_ambulance:SendBillEmail', src, Config.WoundBills and BillCalculator(wounds) or Config.BillCost)

    else
        if Config.WipeInventoryOnRespawn then
            ClearInventory(sourcePlayer)
            TriggerClientEvent('osp_ambulance:SendTextMessage', src, lang.interactions.medicalHeader, lang.error.possessions_taken, 3000, 'error')
        end
        sourcePlayer.removeAccountMoney('bank', tonumber(Config.WoundBills and BillCalculator(wounds) or Config.BillCost))
    end
end

RegisterNetEvent('hospital:server:RespawnAtHospital', function()
    local src = source
    local sourcePlayer = GetPlayer(src)
    if Config.Framework == 'qb' then
        if sourcePlayer.PlayerData.metadata["injail"] > 0 then
            for k, v in pairs(Config.JailBeds) do
                if not v.taken then
                    TriggerClientEvent('hospital:client:SendToBed', src, k, v, true)
                    TriggerClientEvent('hospital:client:SetBed2', -1, k, true)
                    respawnCode(src)
                    return
                end
            end
            TriggerClientEvent('hospital:client:SendToBed', src, 1, Config.JailBeds[1], true)
            TriggerClientEvent('hospital:client:SetBed2', -1, 1, true)
            respawnCode(src)
        else
            local bedId, hospitalID = SetClosestBed(src)
            if bedId then
                TriggerClientEvent('hospital:client:SendToBed', src, bedId, Config.Hospitals[hospitalID]["beds"][bedId], true, hospitalID)
                TriggerClientEvent('hospital:client:SetBed', -1, bedId, true, hospitalID)
                respawnCode(src)
                return
            end
            TriggerClientEvent('hospital:client:SendToBed', src, 1, Config.Hospitals[hospitalID]["beds"][1], true, hospitalID)
            TriggerClientEvent('hospital:client:SetBed', -1, Config.Hospitals[hospitalID]["beds"][1], true, hospitalID)
            respawnCode(src)
        end
    else

        local jailTime = 0
		MySQL.Async.fetchAll([[
            SELECT COLUMN_NAME
            FROM information_schema.COLUMNS
            WHERE TABLE_NAME = 'users' AND COLUMN_NAME = 'jail_time'
        ]], {}, function(result)
			if #result ~= 0 then
                MySQL.Async.fetchAll('SELECT jail_time FROM users WHERE identifier = @identifier', {
                    ['@identifier'] = sourcePlayer.identifier
                }, function(result)
                    if result[1] and result[1].jail_time > 0 then
                        jailTime = result[1].jail_time
                    end
                end)
			end
		end)
        if jailTime > 0 then
            for k, v in pairs(Config.JailBeds) do
                if not v.taken then
                    TriggerClientEvent('hospital:client:SendToBed', src, k, v, true)
                    TriggerClientEvent('hospital:client:SetBed2', -1, k, true)
                    respawnCode(src)
                    return
                end
            end
            TriggerClientEvent('hospital:client:SendToBed', src, 1, Config.JailBeds[1], true)
            TriggerClientEvent('hospital:client:SetBed2', -1, 1, true)
            respawnCode(src)
        else
            local bedId, hospitalID = SetClosestBed(src)
            if bedId then
                TriggerClientEvent('hospital:client:SendToBed', src, bedId, Config.Hospitals[hospitalID]["beds"][bedId], true, hospitalID)
                TriggerClientEvent('hospital:client:SetBed', -1, bedId, true, hospitalID)
                respawnCode(src)
                return
            end
    
    
            TriggerClientEvent('hospital:client:SendToBed', src, 1, Config.Hospitals[hospitalID]["beds"][1], true, hospitalID)
            TriggerClientEvent('hospital:client:SetBed', -1, Config.Hospitals[hospitalID]["beds"][1], true, hospitalID)
            respawnCode(src)
        end
    end
end)


RegisterNetEvent('hospital:server:ambulanceAlert', function(text)
    local src = source
    local ped = GetPlayerPed(src)
    local coords = GetEntityCoords(ped)
    local serverPlayers = GetPlayers()
    for k,v in pairs(serverPlayers) do
        local sourcePlayer = GetPlayer(v)
        if sourcePlayer then
            if Config.Framework == 'qb' then 
                for _,x in pairs(Config.AmbulanceJobs) do
                    if sourcePlayer.PlayerData.job.name == x then
                        TriggerClientEvent('hospital:client:ambulanceAlert', sourcePlayer.PlayerData.source, coords, text)
                    end
                end
            else
                for _,x in pairs(Config.AmbulanceJobs) do
                    if sourcePlayer.job.name == x then
                        TriggerClientEvent('hospital:client:ambulanceAlert', v, coords, text)
                    end
                end
            end
        end
    end
end)

AddEventHandler("playerDropped", function(reason)
    local src = source
    local sourcePlayer = GetPlayer(src)
    if Config.Framework == 'qb' then
        if sourcePlayer then
            if PlayerServerData[src] ~= nil then
                MySQL.Async.execute('UPDATE players SET woundData = @woundData WHERE citizenid = @citizenid', {
                    ['@woundData'] = json.encode(PlayerServerData[src]),
                    ['@citizenid'] = sourcePlayer.PlayerData.citizenid,
                }, function()
                end)
            end
        end
    else
        if sourcePlayer then
            if PlayerServerData[src] ~= nil then
                MySQL.Async.execute('UPDATE users SET woundData = @woundData WHERE identifier = @identifer', {
                    ['@woundData'] = json.encode(PlayerServerData[src]),
                    ['@identifer'] = sourcePlayer.identifier,
                }, function()
                end)
            end
        end
    end

    if Doctors[src] then
        doctorCount = doctorCount - 1
        TriggerClientEvent("hospital:client:SetDoctorCount", -1, doctorCount)
        Doctors[src] = nil
    end
end)

lib.callback.register('osp_ambulance:getPlayerNames', function(source, data)
    local newtable = {}
    for k,v in pairs(data) do
        local sourcePlayer = GetPlayer(v.id)
        local charactername = nil
        if Config.Framework == 'qb' then
            local firstname = sourcePlayer.PlayerData.charinfo.firstname
            local lastname = sourcePlayer.PlayerData.charinfo.lastname
            charactername = firstname .. ' ' .. lastname
        elseif Config.Framework == 'esx' then
            charactername = sourcePlayer.name
        end

        local table = {name = v.name, id = v.id, charactername = charactername}
        newtable[k] = table
    end
    return newtable
end)

lib.callback.register('osp_ambulance:getPlayerCoords', function(source, playerid)
    local vector = GetEntityCoords(GetPlayerPed(playerid))
    return vector
end)


RegisterNetEvent('hospital:server:SendDoctorAlert', function()
    local src = source
    if not doctorCalled then
        doctorCalled = true
        local serverPlayers = GetPlayers()
        for k,v in pairs(serverPlayers) do
            local sourcePlayer = GetPlayer(v)
            if sourcePlayer then
                if Config.Framework == 'qb' then
                    for _,x in pairs(Config.AmbulanceJobs) do
                        if sourcePlayer.PlayerData.job.name == x and sourcePlayer.PlayerData.job.onduty then
                            TriggerClientEvent('osp_ambulance:SendTextMessage', sourcePlayer.PlayerData.source, lang.interactions.medicalHeader, lang.info.dr_needed, 3000, 'error')
                        end
                    end
                else
                    for _,x in pairs(Config.AmbulanceJobs) do
                        if sourcePlayer.job.name == x then
                            TriggerClientEvent('osp_ambulance:SendTextMessage', v, lang.interactions.medicalHeader, lang.info.dr_needed, 3000, 'error')
                        end
                    end
                end
            end
        end

        SetTimeout(Config.DocCooldown * 60000, function()
            doctorCalled = false
        end)
    else
        TriggerClientEvent('osp_ambulance:SendTextMessage', src, lang.interactions.medicalHeader, 'Doctor has already been notified', 3000, 'error')
    end
end)



function SendWebHook(title, color, message, img)
    local embedMsg = {}
    timestamp = os.date("%c")
    embedMsg = {
        {
            ["color"] = color,
            ["title"] = title,
            ["description"] =  ""..message.."",
            ["footer"] ={
                ["text"] = timestamp.." (Server Time).",
            },
        }
    }
    PerformHttpRequest(Config.webHook,
    function(err, text, headers)end, 'POST', json.encode({username = Config.webHookName, avatar_url= Config.webHookLogo ,embeds = embedMsg}), { ['Content-Type']= 'application/json' })
end


RegisterNetEvent('osp_ambulance:sendWebhook', function(data)
    title = data.title
    color = data.color
    message = data.message
    SendWebHook(title, color, message, img)
end)

RegisterNetEvent('osp_ambulance:requestScreenshotSv', function(target)
    if target then
        TriggerClientEvent('osp_ambulance:requestScreenshotCl', target, Config.webHook)
    end
end)

RegisterServerEvent("osp_ambulance:wipeECGTable")
AddEventHandler("osp_ambulance:wipeECGTable", function()
    MySQL.Async.execute("DELETE FROM ecg",function()end)
end)



function UpdateBlips()
    local dutyPlayers = {}
    local players = GetPlayers()
    for _, v in pairs(players) do
        local sourcePlayer = GetPlayer(v)
        if sourcePlayer then
            if Config.Framework == 'qb' then 
                for _,x in pairs(Config.AmbulanceJobs) do
                    if sourcePlayer.PlayerData.job.name == x then
                        local coords = GetEntityCoords(GetPlayerPed(v))
                        local heading = GetEntityHeading(GetPlayerPed(v))
                        dutyPlayers[#dutyPlayers+1] = {
                            source = v,
                            label = sourcePlayer.PlayerData.charinfo.firstname .. ' ' .. sourcePlayer.PlayerData.charinfo.lastname,
                            job = sourcePlayer.PlayerData.job.name,
                            location = {
                                x = coords.x,
                                y = coords.y,
                                z = coords.z,
                                w = heading
                            }
                        }
                    end
                end
            else
                for _,x in pairs(Config.AmbulanceJobs) do
                    if sourcePlayer.job.name == x then
                        local coords = GetEntityCoords(GetPlayerPed(v))
                        local heading = GetEntityHeading(GetPlayerPed(v))
                        dutyPlayers[#dutyPlayers+1] = {
                            source = v,
                            label = sourcePlayer.name,
                            job = sourcePlayer.job.name,
                            location = {
                                x = coords.x,
                                y = coords.y,
                                z = coords.z,
                                w = heading
                            }
                        }
                    end
                end
            end
        end
        Wait(100)
    end
    TriggerClientEvent("osp_ambulance:jobBlipsCl", -1, dutyPlayers)
end

CreateThread(function()
    while true do
        Wait(10000)
        if Config.JobBlips then
            UpdateBlips()
        end
    end
end)

exports('GetAmbulanceData', function(playerid)
    if playerid and playerid ~= 0 then
        local ent = Player(playerid)
        local stat = ent.state.BodyDamage
        return stat
    else
        print('^1[ERROR] missing playerID for export function GetAmbulanceData! ^0')
    end
end)
