local L0_1, L1_1, L2_1, L3_1, L4_1, L5_1
L0_1 = {}
L1_1 = {}
doctorCount = 0
L2_1 = false
L3_1 = {}
Doctors = L3_1
L3_1 = {}
L4_1 = {}
activeWheelChair = L4_1
activeCrutch = L3_1
L3_1 = {}
itemamount = L3_1
L3_1 = {}
cachedStationaryStatus = L3_1
L3_1 = {}
connectedStationaryScreens = L3_1
L3_1 = MySQL
L3_1 = L3_1.ready
function L4_1()
  local L0_2, L1_2, L2_2
  L0_2 = MySQL
  L0_2 = L0_2.Async
  L0_2 = L0_2.execute
  L1_2 = [[
        CREATE TABLE IF NOT EXISTS `ecg` (
            `ActiveECG` int(11) DEFAULT NULL,
            `handle` varchar(50) DEFAULT NULL,
            `prop` int(11) DEFAULT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
    ]]
  L2_2 = {}
  L0_2(L1_2, L2_2)
  function L0_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3
    L1_3 = MySQL
    L1_3 = L1_3.Async
    L1_3 = L1_3.fetchScalar
    L2_3 = [[
            SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_NAME = @table
              AND COLUMN_NAME = 'woundData'
              AND TABLE_SCHEMA = DATABASE();
        ]]
    L3_3 = {}
    L3_3["@table"] = A0_3
    function L4_3(A0_4)
      local L1_4, L2_4, L3_4, L4_4
      if 0 == A0_4 then
        L1_4 = MySQL
        L1_4 = L1_4.Async
        L1_4 = L1_4.execute
        L2_4 = string
        L2_4 = L2_4.format
        L3_4 = [[
                    ALTER TABLE `%s` ADD `woundData` TEXT DEFAULT NULL;
                ]]
        L4_4 = A0_3
        L2_4 = L2_4(L3_4, L4_4)
        L3_4 = {}
        L1_4(L2_4, L3_4)
      end
    end
    L1_3(L2_3, L3_3, L4_3)
  end
  L1_2 = Config
  L1_2 = L1_2.Framework
  if "qb" == L1_2 then
    L1_2 = L0_2
    L2_2 = "players"
    L1_2(L2_2)
  else
    L1_2 = Config
    L1_2 = L1_2.Framework
    if "esx" == L1_2 then
      L1_2 = L0_2
      L2_2 = "users"
      L1_2(L2_2)
    else
      L1_2 = print
      L2_2 = "^1[ERROR] FRAMEWORK IS NOT SETUPED!^0"
      L1_2(L2_2)
    end
  end
end
L3_1(L4_1)
function L3_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L1_2 = 0
  L2_2 = pairs
  L3_2 = A0_2
  L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
  for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
    L8_2 = pairs
    L9_2 = L7_2
    L8_2, L9_2, L10_2, L11_2 = L8_2(L9_2)
    for L12_2, L13_2 in L8_2, L9_2, L10_2, L11_2 do
      L14_2 = Config
      L14_2 = L14_2.WoundPrices
      L14_2 = L14_2[L13_2]
      if L14_2 then
        L14_2 = Config
        L14_2 = L14_2.WoundPrices
        L14_2 = L14_2[L13_2]
        if L14_2 then
          goto lbl_23
        end
      end
      L14_2 = Config
      L14_2 = L14_2.WoundPrices
      L14_2 = L14_2.default
      ::lbl_23::
      L1_2 = L1_2 + L14_2
    end
  end
  return L1_2
end
BillCalculator = L3_1
L3_1 = CreateThread
function L4_1()
  local L0_2, L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2
  L0_2 = Wait
  L1_2 = 1000
  L0_2(L1_2)
  L0_2 = pairs
  L1_2 = Config
  L1_2 = L1_2.ItemShop
  L0_2, L1_2, L2_2, L3_2 = L0_2(L1_2)
  for L4_2, L5_2 in L0_2, L1_2, L2_2, L3_2 do
    L6_2 = itemamount
    L7_2 = L5_2.amount
    L6_2[L4_2] = L7_2
  end
  while true do
    L0_2 = Config
    L0_2 = L0_2.AmbulanceJobs
    if L0_2 then
      break
    end
    L0_2 = Wait
    L1_2 = 100
    L0_2(L1_2)
  end
  function L0_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3
    L1_3 = ipairs
    L2_3 = Config
    L2_3 = L2_3.AmbulanceJobs
    L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
    for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
      if L6_3 == A0_3 then
        L7_3 = true
        return L7_3
      end
    end
    L1_3 = false
    return L1_3
  end
  L1_2 = pairs
  L2_2 = Config
  L2_2 = L2_2.Hospitals
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    L7_2 = pairs
    L8_2 = L6_2.jobs
    L7_2, L8_2, L9_2, L10_2 = L7_2(L8_2)
    for L11_2, L12_2 in L7_2, L8_2, L9_2, L10_2 do
      L13_2 = L0_2
      L14_2 = L12_2
      L13_2 = L13_2(L14_2)
      if not L13_2 then
        L13_2 = table
        L13_2 = L13_2.insert
        L14_2 = Config
        L14_2 = L14_2.AmbulanceJobs
        L15_2 = L12_2
        L13_2(L14_2, L15_2)
      end
    end
  end
end
L3_1(L4_1)
L3_1 = lib
L3_1 = L3_1.callback
L3_1 = L3_1.register
L4_1 = "osp_ambulance:GetMedicalStock"
function L5_1(A0_2, A1_2)
  local L2_2
  L2_2 = itemamount
  return L2_2
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:RemoveItemFromStock"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:RemoveItemFromStock"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2
  L2_2 = itemamount
  L3_2 = itemamount
  L3_2 = L3_2[A0_2]
  L3_2 = L3_2 - A1_2
  L2_2[A0_2] = L3_2
end
L3_1(L4_1, L5_1)
L3_1 = lib
L3_1 = L3_1.callback
L3_1 = L3_1.register
L4_1 = "osp_ambulance:getScreenStatus"
function L5_1(A0_2, A1_2)
  local L2_2
  L2_2 = cachedStationaryStatus
  return L2_2
end
L3_1(L4_1, L5_1)
L3_1 = lib
L3_1 = L3_1.callback
L3_1 = L3_1.register
L4_1 = "osp_ambulance:getUsedScreens"
function L5_1(A0_2, A1_2)
  local L2_2
  L2_2 = connectedStationaryScreens
  return L2_2
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:SendVitalMessageLogSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:SendVitalMessageLogSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:SendVitalMessageLogCl"
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2(L3_2, L4_2, L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:ReopenTimerSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:ReopenTimerSv"
function L5_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L4_2 = TriggerClientEvent
  L5_2 = "osp_ambulance:ReopenTimerCl"
  L6_2 = A0_2
  L7_2 = A1_2
  L8_2 = A2_2
  L9_2 = A3_2
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:SaveDataSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:SaveDataSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:SaveDataCl"
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2(L3_2, L4_2, L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:EpinephrineSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:EpinephrineSv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:EpinephrineCl"
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:medicationSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:medicationSv"
function L5_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = TriggerClientEvent
  L4_2 = "osp_ambulance:medicationCl"
  L5_2 = A0_2
  L6_2 = A1_2
  L7_2 = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:applyCastSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:applyCastSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:applyCastCl"
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2(L3_2, L4_2, L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:removeCastSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:removeCastSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:removeCastCl"
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2(L3_2, L4_2, L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:applyCosmeticCastSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:applyCosmeticCastSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:applyCosmeticCastCl"
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2(L3_2, L4_2, L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:infusionSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:infusionSv"
function L5_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = TriggerClientEvent
  L4_2 = "osp_ambulance:infusionCl"
  L5_2 = A0_2
  L6_2 = A1_2
  L7_2 = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:SalinePackSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:SalinePackSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:SalinePackCl"
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2(L3_2, L4_2, L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:triggerXrayScreenSyncSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:triggerXrayScreenSyncSv"
function L5_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L4_2 = TriggerClientEvent
  L5_2 = "osp_ambulance:triggerXrayScreenSyncCl"
  L6_2 = -1
  L7_2 = A0_2
  L8_2 = A1_2
  L9_2 = A2_2
  L10_2 = A3_2
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2, L10_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:triggerXrayScreenSyncDestroySv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:triggerXrayScreenSyncDestroySv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:triggerXrayScreenSyncDestroyCl"
  L3_2 = -1
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:SyncScreenSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:SyncScreenSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:SyncScreenCl"
  L4_2 = -1
  L5_2 = A0_2
  L6_2 = A1_2
  L2_2(L3_2, L4_2, L5_2, L6_2)
  L2_2 = connectedStationaryScreens
  L3_2 = connectedStationaryScreens
  L3_2 = L3_2[A1_2]
  if not L3_2 then
    L3_2 = {}
  end
  L2_2[A1_2] = L3_2
  L2_2 = table
  L2_2 = L2_2.insert
  L3_2 = connectedStationaryScreens
  L3_2 = L3_2[A1_2]
  L4_2 = A0_2
  L2_2(L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:DestroySyncScreenSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:DestroySyncScreenSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:DestroySyncScreenCl"
  L4_2 = -1
  L5_2 = A0_2
  L6_2 = A1_2
  L2_2(L3_2, L4_2, L5_2, L6_2)
  L2_2 = connectedStationaryScreens
  L2_2 = L2_2[A1_2]
  if L2_2 then
    L2_2 = pairs
    L3_2 = connectedStationaryScreens
    L3_2 = L3_2[A1_2]
    L2_2, L3_2, L4_2, L5_2 = L2_2(L3_2)
    for L6_2, L7_2 in L2_2, L3_2, L4_2, L5_2 do
      L8_2 = source
      if L8_2 == L7_2 then
        L8_2 = table
        L8_2 = L8_2.remove
        L9_2 = connectedStationaryScreens
        L9_2 = L9_2[A1_2]
        L10_2 = L6_2
        L8_2(L9_2, L10_2)
      end
    end
  end
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:TurnOnOffStationaryECGSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:TurnOnOffStationaryECGSv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = cachedStationaryStatus
  L2_2 = A0_2.hospitalID
  L3_2 = cachedStationaryStatus
  L4_2 = A0_2.hospitalID
  L3_2 = L3_2[L4_2]
  if not L3_2 then
    L3_2 = {}
  end
  L1_2[L2_2] = L3_2
  L1_2 = cachedStationaryStatus
  L2_2 = A0_2.hospitalID
  L1_2 = L1_2[L2_2]
  L2_2 = A0_2.id
  L1_2[L2_2] = A0_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:TurnOnOffStationaryECGCl"
  L3_2 = -1
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:SyncCodeBlueSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:SyncCodeBlueSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:SyncCodeBlueCl"
  L4_2 = -1
  L5_2 = A0_2
  L6_2 = A1_2
  L2_2(L3_2, L4_2, L5_2, L6_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:TurnOffCodeSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:TurnOffCodeSv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:TurnOffCodeCl"
  L3_2 = -1
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:SyncStationarySv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:SyncStationarySv"
function L5_1()
  local L0_2, L1_2, L2_2
  L0_2 = TriggerClientEvent
  L1_2 = "osp_ambulance:SyncStationaryCl"
  L2_2 = -1
  L0_2(L1_2, L2_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:SyncIncomingSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:SyncIncomingSv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:SyncIncomingCl"
  L3_2 = -1
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:PutPlayerInOutStretcherSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:PutPlayerInOutStretcherSv"
function L5_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = TriggerClientEvent
  L4_2 = "osp_ambulance:PutPlayerInOutStretcherCl"
  L5_2 = A0_2
  L6_2 = A1_2
  L7_2 = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:UpdateStretcherPositionInSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:UpdateStretcherPositionInSv"
function L5_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L3_2 = TriggerClientEvent
  L4_2 = "osp_ambulance:UpdateStretcherPositionInCl"
  L5_2 = A0_2
  L6_2 = source
  L7_2 = A1_2
  L8_2 = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:UpdateStretcherPositionOutSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:UpdateStretcherPositionOutSv"
function L5_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L4_2 = TriggerClientEvent
  L5_2 = "osp_ambulance:UpdateStretcherPositionOutCl"
  L6_2 = A0_2
  L7_2 = A1_2
  L8_2 = A2_2
  L9_2 = A3_2
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:AttachStretcherToCarrierSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:AttachStretcherToCarrierSv"
function L5_1(A0_2, A1_2, A2_2, A3_2)
  local L4_2, L5_2, L6_2, L7_2, L8_2, L9_2
  L4_2 = TriggerClientEvent
  L5_2 = "osp_ambulance:AttachStretcherToCarrierCl"
  L6_2 = A0_2
  L7_2 = A1_2
  L8_2 = A2_2
  L9_2 = A3_2
  L4_2(L5_2, L6_2, L7_2, L8_2, L9_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:AttachPlayerToStretcherSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:AttachPlayerToStretcherSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:AttachPlayerToStretcherCl"
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2(L3_2, L4_2, L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:SyncPulloutTargetSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:SyncPulloutTargetSv"
function L5_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = TriggerClientEvent
  L4_2 = "osp_ambulance:SyncPulloutTargetCl"
  L5_2 = A0_2
  L6_2 = A1_2
  L7_2 = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:DeleteStretcherSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:DeleteStretcherSv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:DeleteStretcherCl"
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:deleteStretcherAtEntityOwnerSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:deleteStretcherAtEntityOwnerSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:deleteStretcherAtEntityOwnerCl"
  L4_2 = -1
  L5_2 = A0_2
  L6_2 = A1_2
  L2_2(L3_2, L4_2, L5_2, L6_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:BodybagSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:BodybagSv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:BodybagCl"
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:RemoveBodybagSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:RemoveBodybagSv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:RemoveBodybagCl"
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:CarrySv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:CarrySv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:CarryCl"
  L3_2 = A0_2
  L4_2 = source
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:StopCarrySv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:StopCarrySv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:StopCarryCl"
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:PutInSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:PutInSv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:PutInCl"
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:GetOutSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:GetOutSv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:GetOutCl"
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:SendAttachSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:SendAttachSv"
function L5_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = TriggerClientEvent
  L4_2 = "osp_ambulance:SendAttachCl"
  L5_2 = A0_2
  L6_2 = A1_2
  L7_2 = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:SendEKGZoneSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:SendEKGZoneSv"
function L5_1(A0_2, A1_2, A2_2, A3_2, A4_2, A5_2)
  local L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2
  L6_2 = TriggerClientEvent
  L7_2 = "osp_ambulance:SendEKGZoneCl"
  L8_2 = -1
  L9_2 = A0_2
  L10_2 = A1_2
  L11_2 = A2_2
  L12_2 = A3_2
  L13_2 = A4_2
  L14_2 = A5_2
  L6_2(L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:AddPedZoneSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:AddPedZoneSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:AddPedZoneCl"
  L4_2 = -1
  L5_2 = A0_2
  L6_2 = A1_2
  L2_2(L3_2, L4_2, L5_2, L6_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:ChockSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:ChockSv"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = TriggerClientEvent
  L3_2 = "osp_ambulance:ChockCl"
  L4_2 = A0_2
  L5_2 = A1_2
  L2_2(L3_2, L4_2, L5_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:RemoveZoneSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:RemoveZoneSv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:RemoveZoneCl"
  L3_2 = -1
  L4_2 = A0_2
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:SoundSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:SoundSv"
function L5_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2, L8_2
  L3_2 = TriggerClientEvent
  L4_2 = "osp_ambulance:SoundCl"
  L5_2 = -1
  L6_2 = A0_2
  L7_2 = A1_2
  L8_2 = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2, L8_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:CprSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:CprSv"
function L5_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2, L7_2
  L3_2 = TriggerClientEvent
  L4_2 = "osp_ambulance:CprCl"
  L5_2 = A0_2
  L6_2 = A1_2
  L7_2 = A2_2
  L3_2(L4_2, L5_2, L6_2, L7_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:KillSv"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:KillSv"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2
  L1_2 = TriggerClientEvent
  L2_2 = "osp_ambulance:KillCl"
  L3_2 = A0_2
  L1_2(L2_2, L3_2)
end
L3_1(L4_1, L5_1)
L3_1 = lib
L3_1 = L3_1.callback
L3_1 = L3_1.register
L4_1 = "osp_ambulance:GetGfxId"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L2_2 = A0_2
  L3_2 = GetPlayer
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L4_2 = [[
        SELECT `ActiveECG` FROM ecg
    ]]
  L5_2 = nil
  L6_2 = nil
  L7_2 = MySQL
  L7_2 = L7_2.Async
  L7_2 = L7_2.fetchAll
  L8_2 = L4_2
  L9_2 = {}
  function L10_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    if A0_3 then
      L1_3 = {}
      L5_2 = L1_3
      L1_3 = pairs
      L2_3 = A0_3
      L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
      for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
        L7_3 = table
        L7_3 = L7_3.insert
        L8_3 = L5_2
        L9_3 = L6_3.ActiveECG
        L7_3(L8_3, L9_3)
      end
      L1_3 = A0_3[1]
      if nil == L1_3 then
        L1_3 = table
        L1_3 = L1_3.insert
        L2_3 = L5_2
        L3_3 = false
        L1_3(L2_3, L3_3)
      end
    end
    L1_3 = L5_2
    L6_2 = L1_3
  end
  L7_2(L8_2, L9_2, L10_2)
  while nil == L6_2 do
    L7_2 = Wait
    L8_2 = 10
    L7_2(L8_2)
  end
  return L6_2
end
L3_1(L4_1, L5_1)
L3_1 = lib
L3_1 = L3_1.callback
L3_1 = L3_1.register
L4_1 = "osp_ambulance:GetHandle"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L2_2 = A0_2
  L3_2 = GetPlayer
  L4_2 = L2_2
  L3_2 = L3_2(L4_2)
  L4_2 = [[
        SELECT `handle` FROM ecg
    ]]
  L5_2 = nil
  L6_2 = nil
  L7_2 = MySQL
  L7_2 = L7_2.Async
  L7_2 = L7_2.fetchAll
  L8_2 = L4_2
  L9_2 = {}
  function L10_2(A0_3)
    local L1_3, L2_3, L3_3, L4_3, L5_3, L6_3, L7_3, L8_3, L9_3
    if A0_3 then
      L1_3 = {}
      L5_2 = L1_3
      L1_3 = pairs
      L2_3 = A0_3
      L1_3, L2_3, L3_3, L4_3 = L1_3(L2_3)
      for L5_3, L6_3 in L1_3, L2_3, L3_3, L4_3 do
        L7_3 = table
        L7_3 = L7_3.insert
        L8_3 = L5_2
        L9_3 = L6_3.handle
        L7_3(L8_3, L9_3)
      end
      L1_3 = A0_3[1]
      if nil == L1_3 then
        L1_3 = table
        L1_3 = L1_3.insert
        L2_3 = L5_2
        L3_3 = false
        L1_3(L2_3, L3_3)
      end
    end
    L1_3 = L5_2
    L6_2 = L1_3
  end
  L7_2(L8_2, L9_2, L10_2)
  while nil == L6_2 do
    L7_2 = Wait
    L8_2 = 10
    L7_2(L8_2)
  end
  return L6_2
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:InsertId"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:InsertId"
function L5_1(A0_2, A1_2, A2_2)
  local L3_2, L4_2, L5_2, L6_2
  L3_2 = MySQL
  L3_2 = L3_2.Async
  L3_2 = L3_2.insert
  L4_2 = "INSERT INTO ecg (ActiveECG, handle, prop) VALUES (@ActiveECG, @handle, @prop)"
  L5_2 = {}
  L5_2["@ActiveECG"] = A0_2
  L5_2["@handle"] = A1_2
  L5_2["@prop"] = A2_2
  function L6_2(A0_3)
    local L1_3
  end
  L3_2(L4_2, L5_2, L6_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:DeleteId"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:DeleteId"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = MySQL
  L1_2 = L1_2.Async
  L1_2 = L1_2.execute
  L2_2 = "DELETE FROM ecg WHERE prop = @prop"
  L3_2 = {}
  L3_2["@prop"] = A0_2
  function L4_2()
    local L0_3, L1_3
  end
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:DeleteLoop"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:DeleteLoop"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2
  L1_2 = MySQL
  L1_2 = L1_2.Async
  L1_2 = L1_2.execute
  L2_2 = "DELETE FROM ecg WHERE ActiveECG = @ActiveECG"
  L3_2 = {}
  L3_2["@ActiveECG"] = A0_2
  function L4_2()
    local L0_3, L1_3
  end
  L1_2(L2_2, L3_2, L4_2)
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "hospital:server:LeaveBed"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2
  if A1_2 then
    L2_2 = TriggerClientEvent
    L3_2 = "hospital:client:SetBed"
    L4_2 = -1
    L5_2 = A0_2
    L6_2 = false
    L7_2 = A1_2
    L2_2(L3_2, L4_2, L5_2, L6_2, L7_2)
  else
    L2_2 = TriggerClientEvent
    L3_2 = "hospital:client:SetBed2"
    L4_2 = -1
    L5_2 = A0_2
    L6_2 = false
    L2_2(L3_2, L4_2, L5_2, L6_2)
  end
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "hospital:server:AddDoctor"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2
  L1_2 = pairs
  L2_2 = Config
  L2_2 = L2_2.AmbulanceJobs
  L1_2, L2_2, L3_2, L4_2 = L1_2(L2_2)
  for L5_2, L6_2 in L1_2, L2_2, L3_2, L4_2 do
    if A0_2 == L6_2 then
      L7_2 = DebugPrint
      L8_2 = "Adding a doctor"
      L7_2(L8_2)
      L7_2 = source
      L8_2 = doctorCount
      L8_2 = L8_2 + 1
      doctorCount = L8_2
      L8_2 = TriggerClientEvent
      L9_2 = "hospital:client:SetDoctorCount"
      L10_2 = -1
      L11_2 = doctorCount
      L8_2(L9_2, L10_2, L11_2)
      L8_2 = Doctors
      L8_2[L7_2] = true
    end
  end
end
L3_1(L4_1, L5_1)
L3_1 = RegisterNetEvent
L4_1 = "hospital:server:RemoveDoctor"
function L5_1(A0_2)
  local L1_2, L2_2, L3_2, L4_2, L5_2
  L1_2 = source
  L2_2 = doctorCount
  L2_2 = L2_2 - 1
  doctorCount = L2_2
  L2_2 = TriggerClientEvent
  L3_2 = "hospital:client:SetDoctorCount"
  L4_2 = -1
  L5_2 = doctorCount
  L2_2(L3_2, L4_2, L5_2)
  L2_2 = Doctors
  L2_2[L1_2] = nil
end
L3_1(L4_1, L5_1)
L3_1 = {}
PlayerServerData = L3_1
L3_1 = RegisterNetEvent
L4_1 = "osp_ambulance:RetreivePlayerDamageData"
function L5_1(A0_2)
  local L1_2, L2_2
  L1_2 = PlayerServerData
  L2_2 = source
  L1_2[L2_2] = A0_2
end
L3_1(L4_1, L5_1)
L3_1 = lib
L3_1 = L3_1.callback
L3_1 = L3_1.register
L4_1 = "hospital:GetDoctors"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2, L11_2, L12_2, L13_2, L14_2, L15_2, L16_2, L17_2
  L2_2 = 0
  L3_2 = GetPlayers
  L3_2 = L3_2()
  L4_2 = pairs
  L5_2 = L3_2
  L4_2, L5_2, L6_2, L7_2 = L4_2(L5_2)
  for L8_2, L9_2 in L4_2, L5_2, L6_2, L7_2 do
    L10_2 = GetPlayer
    L11_2 = L8_2
    L10_2 = L10_2(L11_2)
    L11_2 = Config
    L11_2 = L11_2.Framework
    if "qb" == L11_2 then
      L11_2 = pairs
      L12_2 = Config
      L12_2 = L12_2.AmbulanceJobs
      L11_2, L12_2, L13_2, L14_2 = L11_2(L12_2)
      for L15_2, L16_2 in L11_2, L12_2, L13_2, L14_2 do
        L17_2 = L10_2.PlayerData
        L17_2 = L17_2.job
        L17_2 = L17_2.name
        if L17_2 == L16_2 then
          L17_2 = L10_2.PlayerData
          L17_2 = L17_2.job
          L17_2 = L17_2.onduty
          if L17_2 then
            L2_2 = L2_2 + 1
          end
        end
      end
      L11_2 = DebugPrint
      L12_2 = "Current doctor count "
      L13_2 = L2_2
      L11_2(L12_2, L13_2)
    else
      L11_2 = pairs
      L12_2 = Config
      L12_2 = L12_2.AmbulanceJobs
      L11_2, L12_2, L13_2, L14_2 = L11_2(L12_2)
      for L15_2, L16_2 in L11_2, L12_2, L13_2, L14_2 do
        L17_2 = L10_2.job
        L17_2 = L17_2.name
        if L17_2 == L16_2 then
          L2_2 = L2_2 + 1
        end
      end
      L11_2 = DebugPrint
      L12_2 = "Current doctor count "
      L13_2 = L2_2
      L11_2(L12_2, L13_2)
    end
  end
  return L2_2
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:giveCrutch"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:giveCrutch"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = GetIdentifier
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  if not A1_2 then
    L3_2 = activeCrutch
    L3_2[L2_2] = nil
    L3_2 = TriggerClientEvent
    L4_2 = "osp_ambulance:breakLoop"
    L5_2 = A0_2
    L3_2(L4_2, L5_2)
  else
    L3_2 = activeCrutch
    L3_2[L2_2] = A1_2
    L3_2 = TriggerClientEvent
    L4_2 = "osp_ambulance:giveCrutch"
    L5_2 = A0_2
    L6_2 = A1_2
    L3_2(L4_2, L5_2, L6_2)
  end
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:giveWheelChair"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:giveWheelChair"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2
  L2_2 = GetIdentifier
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  if not A1_2 then
    L3_2 = activeWheelChair
    L3_2[L2_2] = nil
    L3_2 = TriggerClientEvent
    L4_2 = "osp_ambulance:breakLoop"
    L5_2 = A0_2
    L3_2(L4_2, L5_2)
  else
    L3_2 = activeWheelChair
    L3_2[L2_2] = A1_2
    L3_2 = TriggerClientEvent
    L4_2 = "osp_ambulance:giveWheelChair"
    L5_2 = A0_2
    L6_2 = A1_2
    L3_2(L4_2, L5_2, L6_2)
  end
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:updateCrutch"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:updateCrutch"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = GetIdentifier
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  L3_2 = activeWheelChair
  L3_2 = L3_2[L2_2]
  if L3_2 then
    L3_2 = activeWheelChair
    L3_2[L2_2] = nil
  end
  if not A0_2 then
    L3_2 = activeCrutch
    L3_2[L2_2] = nil
    L3_2 = TriggerClientEvent
    L4_2 = "osp_ambulance:breakLoop"
    L5_2 = A1_2
    L3_2(L4_2, L5_2)
    return
  end
  L3_2 = activeCrutch
  L3_2 = L3_2[L2_2]
  if L3_2 then
    L3_2 = activeCrutch
    L4_2 = activeCrutch
    L4_2 = L4_2[L2_2]
    L4_2 = L4_2 - 1
    L3_2[L2_2] = L4_2
    L3_2 = activeCrutch
    L3_2 = L3_2[L2_2]
    if L3_2 < 1 then
      L3_2 = activeCrutch
      L3_2[L2_2] = nil
      L3_2 = TriggerClientEvent
      L4_2 = "osp_ambulance:breakLoop"
      L5_2 = A1_2
      L3_2(L4_2, L5_2)
    end
  else
    L3_2 = TriggerClientEvent
    L4_2 = "osp_ambulance:breakLoop"
    L5_2 = A1_2
    L3_2(L4_2, L5_2)
  end
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:updateWheelChair"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:updateWheelChair"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = GetIdentifier
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  L3_2 = activeCrutch
  L3_2 = L3_2[L2_2]
  if L3_2 then
    L3_2 = activeCrutch
    L3_2[L2_2] = nil
  end
  if not A0_2 then
    L3_2 = activeWheelChair
    L3_2[L2_2] = nil
    L3_2 = TriggerClientEvent
    L4_2 = "osp_ambulance:breakLoop"
    L5_2 = A1_2
    L3_2(L4_2, L5_2)
    return
  end
  L3_2 = activeWheelChair
  L3_2 = L3_2[L2_2]
  if L3_2 then
    L3_2 = activeWheelChair
    L4_2 = activeWheelChair
    L4_2 = L4_2[L2_2]
    L4_2 = L4_2 - 1
    L3_2[L2_2] = L4_2
    L3_2 = activeWheelChair
    L3_2 = L3_2[L2_2]
    if L3_2 < 1 then
      L3_2 = activeWheelChair
      L3_2[L2_2] = nil
      L3_2 = TriggerClientEvent
      L4_2 = "osp_ambulance:breakLoop"
      L5_2 = A1_2
      L3_2(L4_2, L5_2)
    end
  else
    L3_2 = TriggerClientEvent
    L4_2 = "osp_ambulance:breakLoop"
    L5_2 = A1_2
    L3_2(L4_2, L5_2)
  end
end
L3_1(L4_1, L5_1)
L3_1 = lib
L3_1 = L3_1.callback
L3_1 = L3_1.register
L4_1 = "osp_ambulance:getPlayerData"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2, L6_2, L7_2, L8_2, L9_2, L10_2
  L2_2 = nil
  L3_2 = 1
  L4_2 = #A1_2
  L5_2 = 1
  for L6_2 = L3_2, L4_2, L5_2 do
    if not L2_2 then
      L7_2 = {}
      L2_2 = L7_2
    end
    L7_2 = #L2_2
    L7_2 = L7_2 + 1
    L8_2 = {}
    L9_2 = A1_2[L6_2]
    L9_2 = L9_2.id
    L8_2.id = L9_2
    L9_2 = GetPlayerName
    L10_2 = A1_2[L6_2]
    L10_2 = L10_2.id
    L9_2 = L9_2(L10_2)
    L8_2.name = L9_2
    L2_2[L7_2] = L8_2
  end
  while true do
    L3_2 = #L2_2
    L3_2 = not L3_2
    L4_2 = #A1_2
    if L3_2 ~= L4_2 then
      break
    end
    L3_2 = Wait
    L3_2()
  end
  return L2_2
end
L3_1(L4_1, L5_1)
L3_1 = lib
L3_1 = L3_1.callback
L3_1 = L3_1.register
L4_1 = "osp_ambulance:checkInjuryTime"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = GetIdentifier
  L3_2 = A0_2
  L2_2 = L2_2(L3_2)
  L3_2 = {}
  L3_2.chair = false
  L3_2.crutch = false
  L3_2.time = 0
  L4_2 = activeWheelChair
  L4_2 = L4_2[L2_2]
  if L4_2 then
    L4_2 = activeCrutch
    L4_2 = L4_2[L2_2]
    if L4_2 then
      L4_2 = activeWheelChair
      L4_2 = L4_2[L2_2]
      L5_2 = activeCrutch
      L5_2 = L5_2[L2_2]
      if L4_2 >= L5_2 then
        L4_2 = activeCrutch
        L4_2[L2_2] = nil
        L3_2.chair = true
        L4_2 = activeWheelChair
        L4_2 = L4_2[L2_2]
        L3_2.time = L4_2
        return L3_2
      else
        L4_2 = activeWheelChair
        L4_2[L2_2] = nil
        L3_2.crutch = true
        L4_2 = activeCrutch
        L4_2 = L4_2[L2_2]
        L3_2.time = L4_2
        return L3_2
      end
  end
  else
    L4_2 = activeWheelChair
    L4_2 = L4_2[L2_2]
    if L4_2 then
      L3_2.chair = true
      L4_2 = activeWheelChair
      L4_2 = L4_2[L2_2]
      L3_2.time = L4_2
      return L3_2
    else
      L4_2 = activeCrutch
      L4_2 = L4_2[L2_2]
      if L4_2 then
        L3_2.crutch = true
        L4_2 = activeCrutch
        L4_2 = L4_2[L2_2]
        L3_2.time = L4_2
        return L3_2
      end
    end
  end
end
L3_1(L4_1, L5_1)
L3_1 = RegisterServerEvent
L4_1 = "osp_ambulance:updateWheelChair"
L3_1(L4_1)
L3_1 = AddEventHandler
L4_1 = "osp_ambulance:updateWheelChair"
function L5_1(A0_2, A1_2)
  local L2_2, L3_2, L4_2, L5_2
  L2_2 = GetIdentifier
  L3_2 = A1_2
  L2_2 = L2_2(L3_2)
  L3_2 = activeCrutch
  L3_2 = L3_2[L2_2]
  if L3_2 then
    L3_2 = activeCrutch
    L3_2[L2_2] = nil
  end
  if not A0_2 then
    L3_2 = activeWheelChair
    L3_2[L2_2] = nil
    L3_2 = TriggerClientEvent
    L4_2 = "osp_ambulance:breakLoop"
    L5_2 = A1_2
    L3_2(L4_2, L5_2)
    return
  end
  L3_2 = activeWheelChair
  L3_2 = L3_2[L2_2]
  if L3_2 then
    L3_2 = activeWheelChair
    L4_2 = activeWheelChair
    L4_2 = L4_2[L2_2]
    L4_2 = L4_2 - 1
    L3_2[L2_2] = L4_2
    L3_2 = activeWheelChair
    L3_2 = L3_2[L2_2]
    if L3_2 < 1 then
      L3_2 = activeWheelChair
      L3_2[L2_2] = nil
      L3_2 = TriggerClientEvent
      L4_2 = "osp_ambulance:breakLoop"
      L5_2 = A1_2
      L3_2(L4_2, L5_2)
    end
  else
    L3_2 = TriggerClientEvent
    L4_2 = "osp_ambulance:breakLoop"
    L5_2 = A1_2
    L3_2(L4_2, L5_2)
  end
end
L3_1(L4_1, L5_1)
