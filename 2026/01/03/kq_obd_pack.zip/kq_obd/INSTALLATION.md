## INSTALLATION GUIDE

### Dependencies:
Install our KQ_LINK resource if you don't have it installed already
- If you do have it installed, make sure its up-to-date (^1.8.0)

Follow the detailed guide here: https://docs.kuzquality.com/kq-link/kq-link-or-installation-guide

Github: https://github.com/Kuzkay/kq_link

⚠ Make sure that `kq_link` is started **before** this resource and named exactly `kq_link` !
___

### Step 1:
Put the folder into your resources folder

### Step 2:
Ensure the script in your `server.cfg` file.

### Step 3 (optional):
If you wish to require an OBD Dongle item, enable it in the config and import the item to your framework/inventory. You can find the item data and icon in `_installation` folder

```
ensure kq_obd
```

### Done
Enjoy the script

___

- https://docs.kuzquality.com/
- https://kuzquality.com/
- https://discord.gg/fZsyam7Rvz
