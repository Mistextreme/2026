# Crown Job Creator

**Job and grade management for FiveM ESX servers**

[![ESX](https://img.shields.io/badge/ESX-1.2+-blue)](https://github.com/esx-framework/esx-legacy)
[![ox_lib](https://img.shields.io/badge/ox__lib-3.0+-green)](https://github.com/overextended/ox_lib)
[![Version](https://img.shields.io/badge/Version-1.0.0-orange)](https://github.com/crown-development)

Create, edit, and manage jobs through a modern React interface with multiple grades per job, job type classification, and automatic ESX cache refresh.

---

## ✨ Features

- ✅ Create jobs with multiple grades in one form
- ✅ Job type classification (Job, Gang, Protected)
- ✅ Visual job overview with player counts
- ✅ Categorized job display
- ✅ Edit job labels and types
- ✅ Discord logging support
- ✅ Beautiful React UI with Tailwind CSS
- ✅ Database-driven job types
- ✅ Automatic ESX job cache refresh

---

## 📦 Dependencies

**Required:**
- `es_extended` (ESX Framework)
- `ox_lib` (UI & Notifications)
- `oxmysql` (Database)

---

## 🚀 Installation

### 1. Copy Resource
Place the `Crown-jobcreator` folder in your `resources` directory.

### 2. Run SQL Files
Execute these SQL files in order:
```sql
-- First: Create tables (includes crown_jobsettings table)
install.sql

-- Second: Add job_type column (if upgrading from older version)
update_jobs_table.sql

-- Third: Add settings table (if upgrading and don't have it)
create_settings_table.sql
```

**Note:** The `crown_jobsettings` table stores persistent settings for salary limits, grade limits, and protected jobs.

### 3. Add to server.cfg
```
ensure Crown-jobcreator
```

### 4. Configure (Optional)
Edit `config.lua` to set:
- Admin groups
- Discord webhooks
- Salary/grade limits
- UI colors

### 5. **IMPORTANT: Add ESX Export**

To make newly created jobs **immediately usable** without restarting ESX, add this export to your ESX resource.

---

## ⚙️ ESX Export Setup (IMPORTANT!)

This step is **critical** for jobs to work immediately after creation.

### 📋 Quick Summary:
- **Where:** Add to `es_extended` resource (outside this folder)
- **File:** `resources/[esx]/es_extended/server/main.lua`
- **What:** Add export code at the BOTTOM of the file
- **Why:** So Crown-jobcreator can automatically refresh ESX after creating jobs/grades

### ⚠️ Important Note:
If there's **already** a `RefreshJobs` export in your ESX file, **REPLACE** it with this one.

### 📝 The Code to Add:

```lua
-- Export to refresh jobs from database (for job creator scripts)
exports('RefreshJobs', function()
    print('[ESX] Refreshing jobs from database...')
    
    -- Clear existing jobs
    ESX.Jobs = {}
    
    -- Reload jobs from database
    MySQL.query('SELECT * FROM jobs', {}, function(jobs)
        for i = 1, #jobs do
            local jobName = jobs[i].name
            ESX.Jobs[jobName] = jobs[i]
            ESX.Jobs[jobName].grades = {}
        end
        
        -- Load job grades
        MySQL.query('SELECT * FROM job_grades ORDER BY job_name, grade ASC', {}, function(grades)
            for i = 1, #grades do
                local jobName = grades[i].job_name
                local grade = grades[i].grade
                
                if ESX.Jobs[jobName] then
                    ESX.Jobs[jobName].grades[tostring(grade)] = grades[i]
                end
            end
            
            print('[ESX] Jobs refreshed successfully!')
            TriggerEvent('esx:jobsRefreshed')
        end)
    end)
end)
```

## 🛠️ Configuration

Edit `config.lua` to configure:

- **Admin groups** - Who can access the UI
- **Authorized identifiers** - Who can edit limits and protected jobs
- **Salary/grade limits** - Min/max values (defaults loaded from database)
- **UI colors** - Primary accent color
- **Currency** - Display format for money
- **Discord webhooks** - Optional logging configuration

---

## 🔌 Exports Overview

### What You Need to Know

There are **TWO different exports** in two different places:

1. **ESX Export** (you add to `es_extended`) - Already documented in ESX Setup above
2. **Crown-jobcreator Export** (already in this resource) - Documented below

---

## 🔌 Crown-jobcreator Exports

This resource provides exports that **other resources** can use:

### `RefreshESXJobs()`

Call this export from other resources to refresh ESX jobs and grades cache.

**Location:** Already included in `Crown-jobcreator`  
**Returns:** `true` if successful, `false` if failed

**Usage in another resource:**
```lua
local success = exports['Crown-jobcreator']:RefreshESXJobs()
if success then
    print('ESX jobs and grades refreshed successfully!')
else
    print('Failed to refresh ESX jobs')
end
```

**When to use:**
- When another resource needs to manually refresh jobs
- For custom job management integration
- To sync ESX cache after database changes

---

## ⚙️ ESX Export (Important!)

### Location to Add: `es_extended` resource

**File:** `resources/[esx]/es_extended/server/main.lua` (or wherever your ESX is located)  
**Action:** Add at the **BOTTOM** of the file

### What to Add:
See the full export code in the **"ESX Export Setup"** section above (lines 68-126).

This export lets Crown-jobcreator automatically refresh ESX after creating/editing jobs and grades.


## 📊 Database Structure

### Jobs Table
```sql
CREATE TABLE IF NOT EXISTS `jobs` (
  `name` varchar(50) NOT NULL,
  `label` varchar(50) DEFAULT NULL,
  `whitelisted` tinyint(1) NOT NULL DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `job_type` varchar(20) DEFAULT 'job',
  PRIMARY KEY (`name`)
);
```

### Job Grades Table
```sql
CREATE TABLE IF NOT EXISTS `job_grades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_name` varchar(50) DEFAULT NULL,
  `grade` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `label` varchar(50) NOT NULL,
  `salary` int(11) NOT NULL,
  `skin_male` longtext DEFAULT NULL,
  `skin_female` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `job_name` (`job_name`)
);
```

### Settings Table
```sql
CREATE TABLE IF NOT EXISTS `crown_jobsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
);
```



## 🔄 Changelog

### v1.0.0 - Initial Release
- Multi-grade job creation in one form
- Job type system (Job, Gang, Protected)
- Visual overview with categorization
- Player count display per job
- Edit job labels and types
- Protected job system
- Automatic ESX cache refresh support
- Discord webhook logging
- Modern React UI with Tailwind CSS

---

**Support:** Crown Development | **Version:** 1.0.1
