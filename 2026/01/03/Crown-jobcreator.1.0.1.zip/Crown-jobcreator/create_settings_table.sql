-- Create settings table for Crown Job Creator
CREATE TABLE IF NOT EXISTS `crown_jobsettings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(50) NOT NULL,
  `setting_value` text NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert default values
INSERT INTO `crown_jobsettings` (`setting_key`, `setting_value`) VALUES
('salary_min', '0'),
('salary_max', '20000'),
('grade_min', '0'),
('grade_max', '10'),
('protected_jobs', '["unemployed","police","ambulance"]')
ON DUPLICATE KEY UPDATE `setting_key` = `setting_key`;

