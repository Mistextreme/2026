ESX = exports["es_extended"]:getSharedObject()

-- ========================================
-- LOAD SETTINGS FROM DATABASE
-- ========================================

local function LoadSettingsFromDatabase()
    exports.oxmysql:execute('SELECT setting_key, setting_value FROM crown_jobsettings', {}, function(result)
        if result then
            Config.SalaryLimits = {}
            Config.GradeLimits = {}
            Config.ProtectedJobs = {}
            
            for _, row in ipairs(result) do
                if row.setting_key == 'salary_min' then
                    Config.SalaryLimits.min = tonumber(row.setting_value) or 0
                elseif row.setting_key == 'salary_max' then
                    Config.SalaryLimits.max = tonumber(row.setting_value) or 20000
                elseif row.setting_key == 'grade_min' then
                    Config.GradeLimits.min = tonumber(row.setting_value) or 0
                elseif row.setting_key == 'grade_max' then
                    Config.GradeLimits.max = tonumber(row.setting_value) or 10
                elseif row.setting_key == 'protected_jobs' then
                    local success, decoded = pcall(json.decode, row.setting_value)
                    if success and decoded then
                        Config.ProtectedJobs = decoded
                        print('[Crown-JobCreator] Loaded protected jobs from database:', json.encode(decoded))
                    else
                        print('[Crown-JobCreator] Warning: Could not parse protected_jobs from database')
                    end
                end
            end
            print('[Crown-JobCreator] Settings loaded from database')
        else
            print('[Crown-JobCreator] Warning: Could not load settings from database')
        end
    end)
end

local function SaveSettingToDatabase(key, value)
    local valueStr = value
    if type(value) == 'table' then
        valueStr = json.encode(value)
    else
        valueStr = tostring(value)
    end
    
    exports.oxmysql:execute('INSERT INTO crown_jobsettings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?', {
        key, valueStr, valueStr
    }, function(result)
        if not result then
            print('[Crown-JobCreator] Error: Failed to save setting ' .. key .. ' to database')
        end
    end)
end

CreateThread(function()
    Wait(1000)
    LoadSettingsFromDatabase()
end)

RegisterNetEvent('crown-jobcreator:updateProtectedJobs')

RegisterCommand('refreshesx', function(source, args, rawCommand)
    if source == 0 or IsPlayerAdmin(source) then
        ExecuteCommand('ensure es_extended')
        if source ~= 0 then
            SendNotification(source, 'success', 'Succes', 'ESX blev genstartet. Du kan nu bruge /setjob')
        else
            print('[Crown-JobCreator] ESX restarted')
        end
    else
        SendNotification(source, 'error', 'Fejl', 'Du har ikke tilladelse til denne kommando')
    end
end, false)

local function SendNotification(source, type, title, description)
    TriggerClientEvent('ox_lib:notify', source, {
        title = title,
        description = description,
        type = type
    })
end

local function IsPlayerAdmin(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then return false end
    
    for _, group in ipairs(Config.AdminGroups) do
        if xPlayer.getGroup() == group then
            return true
        end
    end
    return false
end

local function CheckAdminAccess(source)
    if not IsPlayerAdmin(source) then
        SendNotification(source, 'error', 'Fejl', 'Du har ikke tilladelse til at udføre denne handling')
        return false
    end
    return true
end

local function IsPlayerAuthorizedForLimits(source)
    local identifiers = GetPlayerIdentifiers(source)
    
    for _, playerIdentifier in ipairs(identifiers) do
        for _, authorizedIdentifier in ipairs(Config.AuthorizedIdentifiers) do
            if playerIdentifier == authorizedIdentifier then
                return true
            end
        end
    end
    return false
end

ESX.RegisterServerCallback('crown-jobcreator:getJobs', function(source, cb)
    if not IsPlayerAdmin(source) then
        cb('Du har ikke tilladelse til at bruge denne menu')
        return
    end
    
    exports.oxmysql:execute('SELECT name, label, whitelisted, image, job_type FROM ' .. Config.Database.jobsTable, {}, function(result)
        cb(result)
    end)
end)

ESX.RegisterServerCallback('crown-jobcreator:getJobGrades', function(source, cb, jobName)
    if not IsPlayerAdmin(source) then
        cb('Du har ikke tilladelse til at bruge denne menu')
        return
    end
    
    exports.oxmysql:execute('SELECT * FROM ' .. Config.Database.jobGradesTable .. ' WHERE job_name = ? ORDER BY grade ASC', {jobName}, function(result)
        cb(result)
    end)
end)

ESX.RegisterServerCallback('crown-jobcreator:getJobPlayerCounts', function(source, cb)
    if not IsPlayerAdmin(source) then
        cb({})
        return
    end
    
    exports.oxmysql:execute('SELECT job, COUNT(*) as count FROM users GROUP BY job', {}, function(result)
        local jobCounts = {}
        for i = 1, #result do
            jobCounts[result[i].job or 'unemployed'] = result[i].count
        end
        cb(jobCounts)
    end)
end)

-- Helper function to process player jobs and get labels
local function processPlayerJobs(playersMap, cb)
    -- Now process all jobs for each player
    local players = {}
    local processed = 0
    local totalPlayers = 0
    
    for identifier, playerData in pairs(playersMap) do
        totalPlayers = totalPlayers + 1
    end
    
    if totalPlayers == 0 then
        cb({})
        return
    end
    
    for identifier, playerData in pairs(playersMap) do
        local playerJobs = {}
        local jobsProcessed = 0
        local totalJobs = #playerData.jobs
        
        if totalJobs == 0 then
            processed = processed + 1
            if processed == totalPlayers then
                cb(players)
            end
        else
            -- Process each job for this player
            for jobIndex, jobData in ipairs(playerData.jobs) do
                local jobName = jobData.job
                local jobGrade = jobData.job_grade
                
                -- Get job label
                exports.oxmysql:execute('SELECT label FROM ' .. Config.Database.jobsTable .. ' WHERE name = ?', {jobName}, function(jobResult)
                    local jobLabel = jobName
                    if #jobResult > 0 then
                        jobLabel = jobResult[1].label
                    end
                    
                    -- Get grade label
                    exports.oxmysql:execute('SELECT label FROM ' .. Config.Database.jobGradesTable .. ' WHERE job_name = ? AND grade = ?', {jobName, jobGrade}, function(gradeResult)
                        local gradeLabel = 'Grade ' .. jobGrade
                        if #gradeResult > 0 then
                            gradeLabel = gradeResult[1].label
                        end
                        
                        table.insert(playerJobs, {
                            job = jobName,
                            job_label = jobLabel,
                            grade = jobGrade,
                            grade_label = gradeLabel,
                            is_primary = (jobIndex == 1) -- First job is primary
                        })
                        
                        jobsProcessed = jobsProcessed + 1
                        
                        -- When all jobs for this player are processed
                        if jobsProcessed == totalJobs then
                            -- Sort jobs: primary first, then alphabetically
                            table.sort(playerJobs, function(a, b)
                                if a.is_primary and not b.is_primary then return true end
                                if not a.is_primary and b.is_primary then return false end
                                return a.job_label < b.job_label
                            end)
                            
                            table.insert(players, {
                                name = playerData.name,
                                identifier = identifier,
                                jobs = playerJobs
                            })
                            
                            processed = processed + 1
                            
                            -- Return when all players are processed
                            if processed == totalPlayers then
                                cb(players)
                            end
                        end
                    end)
                end)
            end
        end
    end
end

ESX.RegisterServerCallback('crown-jobcreator:getPlayers', function(source, cb)
    if not IsPlayerAdmin(source) then
        cb({})
        return
    end
    
    -- Fetch all players from users table (multijob system stores multiple rows per player)
    exports.oxmysql:execute('SELECT firstname, lastname, identifier, job, job_grade FROM users', {}, function(result)
        if #result == 0 then
            cb({})
            return
        end
        
        -- Group players by identifier to handle multiple jobs
        local playersMap = {}
        
        for i = 1, #result do
            local player = result[i]
            local identifier = player.identifier
            
            if not playersMap[identifier] then
                playersMap[identifier] = {
                    name = player.firstname .. ' ' .. player.lastname,
                    identifier = identifier,
                    jobs = {}
                }
            end
            
            local jobName = player.job or 'unemployed'
            local jobGrade = player.job_grade or 0
            
            -- Check if this job/grade combination already exists for this player
            local jobExists = false
            for _, existingJob in ipairs(playersMap[identifier].jobs) do
                if existingJob.job == jobName and existingJob.job_grade == jobGrade then
                    jobExists = true
                    break
                end
            end
            
            -- Only add if it doesn't already exist (avoid duplicates)
            if not jobExists then
                table.insert(playersMap[identifier].jobs, {
                    job = jobName,
                    job_grade = jobGrade
                })
            end
        end
        
        processPlayerJobs(playersMap, cb)
    end)
end)

ESX.RegisterServerCallback('crown-jobcreator:getPlayersByJob', function(source, cb, jobName)
    if not IsPlayerAdmin(source) then
        cb({})
        return
    end
    
    -- First, get all identifiers that have this job
    exports.oxmysql:execute('SELECT DISTINCT identifier FROM users WHERE job = ?', {jobName or 'unemployed'}, function(identifiers)
        if #identifiers == 0 then
            cb({})
            return
        end
        
        -- Build list of identifiers
        local identifierList = {}
        for i = 1, #identifiers do
            table.insert(identifierList, identifiers[i].identifier)
        end
        
        -- Fetch ALL jobs for these players (multijob system)
        local placeholders = {}
        for i = 1, #identifierList do
            table.insert(placeholders, '?')
        end
        
        exports.oxmysql:execute('SELECT firstname, lastname, identifier, job, job_grade FROM users WHERE identifier IN (' .. table.concat(placeholders, ',') .. ')', identifierList, function(result)
            if #result == 0 then
                cb({})
                return
            end
            
            -- Group players by identifier
            local playersMap = {}
            
            for i = 1, #result do
                local player = result[i]
                local identifier = player.identifier
                
                if not playersMap[identifier] then
                    playersMap[identifier] = {
                        name = player.firstname .. ' ' .. player.lastname,
                        identifier = identifier,
                        jobs = {}
                    }
                end
                
                local jobName = player.job or 'unemployed'
                local jobGrade = player.job_grade or 0
                
                -- Check if this job/grade combination already exists for this player
                local jobExists = false
                for _, existingJob in ipairs(playersMap[identifier].jobs) do
                    if existingJob.job == jobName and existingJob.job_grade == jobGrade then
                        jobExists = true
                        break
                    end
                end
                
                -- Only add if it doesn't already exist (avoid duplicates)
                if not jobExists then
                    table.insert(playersMap[identifier].jobs, {
                        job = jobName,
                        job_grade = jobGrade
                    })
                end
            end
            
            processPlayerJobs(playersMap, cb)
        end)
    end)
end)

RegisterNetEvent('crown-jobcreator:createJob')
AddEventHandler('crown-jobcreator:createJob', function(jobData)
    local source = source
    if not IsPlayerAdmin(source) then
        SendNotification(source, 'error', 'Fejl', 'Du har ikke tilladelse til at udføre denne handling')
        return
    end
    
    local jobName = jobData.name
    local jobLabel = jobData.label
    
    if not jobName or jobName == '' or not jobLabel or jobLabel == '' then
        SendNotification(source, 'error', 'Fejl', 'Job navn og label skal udfyldes')
        return
    end
    
    exports.oxmysql:execute('SELECT name FROM ' .. Config.Database.jobsTable .. ' WHERE name = ?', {jobName}, function(result)
        if #result > 0 then
            SendNotification(source, 'error', 'Fejl', 'Et job med dette navn eksisterer allerede')
            return
        end
        
        local jobType = jobData.job_type or 'job'
        local grades = jobData.grades or {}
        
        exports.oxmysql:execute('INSERT INTO ' .. Config.Database.jobsTable .. ' (name, label, whitelisted, job_type) VALUES (?, ?, ?, ?)', {
            jobName, jobLabel, false, jobType
        }, function(result)
            if result and result.insertId then
                -- Create grades from the form
                if #grades > 0 then
                    local gradesCreated = 0
                    local totalGrades = #grades
                    
                    for i = 1, totalGrades do
                        local grade = grades[i]
                        print('[Crown-JobCreator] Creating grade ' .. grade.grade .. ' for job ' .. jobName)
                        print('[Crown-JobCreator] Grade details: name=' .. grade.name .. ', label=' .. grade.label .. ', salary=' .. grade.salary)
                        
                        exports.oxmysql:execute('INSERT INTO ' .. Config.Database.jobGradesTable .. ' (job_name, grade, name, label, salary) VALUES (?, ?, ?, ?, ?)', {
                            jobName, grade.grade, grade.name, grade.label, grade.salary
                        }, function(gradeResult)
                            if gradeResult and gradeResult.insertId then
                                gradesCreated = gradesCreated + 1
                                print('[Crown-JobCreator] Grade ' .. grade.grade .. ' created successfully. Total created: ' .. gradesCreated .. '/' .. totalGrades)
                            else
                                print('[Crown-JobCreator] ERROR: Failed to create grade ' .. grade.grade .. ' for job ' .. jobName)
                            end
                            
                            if gradesCreated == totalGrades then
                                print('[Crown-JobCreator] All grades created for job: ' .. jobName)
                                print('[Crown-JobCreator] Use command: /setjob [id] ' .. jobName .. ' 0')
                                print('[Crown-JobCreator] IMPORTANT: Run /refreshesx first!')
                                
                                -- Wait a moment for database to finish writing
                                Wait(500)
                                
                                -- Refresh ESX jobs cache
                                local success = pcall(function()
                                    exports['es_extended']:RefreshJobs()
                                    print('[Crown-JobCreator] ESX jobs refreshed via export')
                                end)
                                
                                if not success then
                                    print('[Crown-JobCreator] Could not refresh ESX jobs. Please run /refreshesx')
                                end
                                
                                -- If job type is gang, add to visualz_zones
                                if jobType == 'gang' then
                                    local successVisualz = pcall(function()
                                        exports['visualz_zones']:AddGang(jobName, jobLabel)
                                        print('[Crown-JobCreator] Gang "' .. jobName .. '" added to visualz_zones')
                                    end)
                                    
                                    if not successVisualz then
                                        print('[Crown-JobCreator] Warning: Could not add gang to visualz_zones. Make sure visualz_zones resource is running.')
                                    end
                                end
                                
                                SendNotification(source, 'success', 'Succes', 'Job "' .. jobLabel .. '" blev oprettet med ' .. totalGrades .. ' ranks. Brug /setjob nu!')
                                DiscordLogger.LogJobCreated(source, jobName, jobLabel)
                                TriggerClientEvent('crown-jobcreator:refreshJobs', source)
                            end
                        end)
                    end
                else
                    -- Fallback: create default Grade 0 if no grades provided
                    exports.oxmysql:execute('INSERT INTO ' .. Config.Database.jobGradesTable .. ' (job_name, grade, name, label, salary) VALUES (?, ?, ?, ?, ?)', {
                        jobName, 0, 'employee', 'Medarbejder', 0
                    }, function(gradeResult)
                        -- Wait a moment for database to finish writing
                        Wait(500)
                        
                        -- Refresh ESX jobs cache
                        local success = pcall(function()
                            exports['es_extended']:RefreshJobs()
                            print('[Crown-JobCreator] ESX jobs refreshed via export')
                        end)
                        
                        if not success then
                            print('[Crown-JobCreator] Could not refresh ESX jobs. Please run /refreshesx')
                        end
                        
                        -- If job type is gang, add to visualz_zones
                        if jobType == 'gang' then
                            pcall(function()
                                exports['visualz_zones']:AddGang(jobName, jobLabel)
                            end)
                        end
                        
                        SendNotification(source, 'success', 'Succes', 'Job "' .. jobLabel .. '" blev oprettet med Grade 0. Brug /setjob nu!')
                        DiscordLogger.LogJobCreated(source, jobName, jobLabel)
                        TriggerClientEvent('crown-jobcreator:refreshJobs', source)
                    end)
                end
            else
                SendNotification(source, 'error', 'Fejl', 'Kunne ikke oprette job')
            end
        end)
    end)
end)

RegisterNetEvent('crown-jobcreator:updateJob')
AddEventHandler('crown-jobcreator:updateJob', function(jobData)
    local source = source
    if not CheckAdminAccess(source) then return end
    
    local jobName = jobData.name
    local jobLabel = jobData.label
    local jobType = jobData.job_type or 'job'
    
    if not jobName or jobName == '' or not jobLabel or jobLabel == '' then
        SendNotification(source, 'error', 'Fejl', 'Job navn og label skal udfyldes')
        return
    end
    
    exports.oxmysql:execute('UPDATE ' .. Config.Database.jobsTable .. ' SET label = ?, job_type = ? WHERE name = ?', {
        jobLabel, jobType, jobName
    }, function(result)
        if result then
            -- Refresh ESX jobs cache
            pcall(function()
                exports['es_extended']:RefreshJobs()
            end)
            
            -- If job type is gang, add to visualz_zones
            if jobType == 'gang' then
                pcall(function()
                    exports['visualz_zones']:AddGang(jobName, jobLabel)
                end)
            end
            
            SendNotification(source, 'success', 'Succes', 'Job "' .. jobLabel .. '" blev opdateret')
            TriggerClientEvent('crown-jobcreator:refreshJobs', source)
        else
            SendNotification(source, 'error', 'Fejl', 'Kunne ikke opdatere job')
        end
    end)
end)

RegisterNetEvent('crown-jobcreator:deleteJob')
AddEventHandler('crown-jobcreator:deleteJob', function(jobName)
    local source = source
    if not CheckAdminAccess(source) then return end
    
    if not jobName or jobName == '' then
        SendNotification(source, 'error', 'Fejl', 'Job navn skal udfyldes')
        return
    end
    
    -- Check if this job is a gang before deleting
    exports.oxmysql:execute('SELECT job_type FROM ' .. Config.Database.jobsTable .. ' WHERE name = ?', {jobName}, function(jobResult)
        local wasGang = jobResult and #jobResult > 0 and jobResult[1].job_type == 'gang'
        
        exports.oxmysql:execute('DELETE FROM ' .. Config.Database.jobGradesTable .. ' WHERE job_name = ?', {jobName}, function()
            exports.oxmysql:execute('DELETE FROM ' .. Config.Database.jobsTable .. ' WHERE name = ?', {jobName}, function(result)
                if result then
                    -- Refresh ESX jobs cache
                    pcall(function()
                        exports['es_extended']:RefreshJobs()
                    end)
                    
                    -- If this was a gang, remove it from visualz_zones
                    if wasGang then
                        pcall(function()
                            exports['visualz_zones']:RemoveGang(jobName)
                        end)
                    end
                    
                    SendNotification(source, 'success', 'Succes', 'Job "' .. jobName .. '" og alle ranks blev slettet')
                    DiscordLogger.LogJobDeleted(source, jobName)
                    TriggerClientEvent('crown-jobcreator:refreshJobs', source)
                else
                    SendNotification(source, 'error', 'Fejl', 'Kunne ikke slette job')
                end
            end)
        end)
    end)
end)

RegisterNetEvent('crown-jobcreator:createJobGrade')
AddEventHandler('crown-jobcreator:createJobGrade', function(gradeData)
    local source = source
    if not CheckAdminAccess(source) then return end
    
    local jobName = gradeData.job_name
    local grade = gradeData.grade
    local name = gradeData.name
    local label = gradeData.label
    local salary = gradeData.salary
    
    -- Check if job is protected by querying database
    exports.oxmysql:execute('SELECT job_type FROM ' .. Config.Database.jobsTable .. ' WHERE name = ?', {jobName}, function(jobResult)
        if #jobResult > 0 and jobResult[1].job_type == 'protected' then
            SendNotification(source, 'error', 'Fejl', 'Du kan ikke tilføje ranks til beskyttet job')
            return
        end
        
        if not jobName or jobName == '' or not name or name == '' or not label or label == '' then
            SendNotification(source, 'error', 'Fejl', 'Alle felter skal udfyldes')
            return
        end
        
        if grade < Config.GradeLimits.min or grade > Config.GradeLimits.max then
            SendNotification(source, 'error', 'Fejl', 'Grade skal være mellem ' .. Config.GradeLimits.min .. ' og ' .. Config.GradeLimits.max)
            return
        end
        
        if salary < Config.SalaryLimits.min or salary > Config.SalaryLimits.max then
            SendNotification(source, 'error', 'Fejl', 'Løn skal være mellem ' .. Config.SalaryLimits.min .. ' og ' .. Config.SalaryLimits.max)
            return
        end
        
        exports.oxmysql:execute('SELECT id FROM ' .. Config.Database.jobGradesTable .. ' WHERE job_name = ? AND grade = ?', {
            jobName, grade
        }, function(result)
        if #result > 0 then
            SendNotification(source, 'error', 'Fejl', 'En rank med denne grade eksisterer allerede for dette job')
            return
        end
        
        exports.oxmysql:execute('INSERT INTO ' .. Config.Database.jobGradesTable .. ' (job_name, grade, name, label, salary) VALUES (?, ?, ?, ?, ?)', {
            jobName, grade, name, label, salary
        }, function(result)
            if result and result.insertId then
                SendNotification(source, 'success', 'Succes', 'Rank "' .. label .. '" blev oprettet')
                
                DiscordLogger.LogGradeCreated(source, jobName, grade, name, label, salary)
                
                -- Wait for database write to complete
                Wait(500)
                
                -- Refresh ESX jobs cache
                pcall(function()
                    exports['es_extended']:RefreshJobs()
                end)
                
                TriggerClientEvent('crown-jobcreator:refreshJobGrades', source, jobName)
            else
                SendNotification(source, 'error', 'Fejl', 'Kunne ikke oprette rank')
            end
        end)
    end)
    end)
end)

RegisterNetEvent('crown-jobcreator:updateJobGrade')
AddEventHandler('crown-jobcreator:updateJobGrade', function(gradeData)
    local source = source
    if not CheckAdminAccess(source) then return end
    
    local id = gradeData.id
    local name = gradeData.name
    local label = gradeData.label
    local salary = gradeData.salary
    
    exports.oxmysql:execute('SELECT job_name FROM ' .. Config.Database.jobGradesTable .. ' WHERE id = ?', {
        id
    }, function(result)
        if #result == 0 then
            SendNotification(source, 'error', 'Fejl', 'Rank ikke fundet')
            return
        end
        
        local jobName = result[1].job_name
        
        -- Check if job is protected by querying database
        exports.oxmysql:execute('SELECT job_type FROM ' .. Config.Database.jobsTable .. ' WHERE name = ?', {jobName}, function(jobResult)
            local isProtected = #jobResult > 0 and jobResult[1].job_type == 'protected'
            
            if isProtected then
            exports.oxmysql:execute('UPDATE ' .. Config.Database.jobGradesTable .. ' SET salary = ? WHERE id = ?', {
                salary, id
            }, function(result)
                if result then
                    SendNotification(source, 'success', 'Succes', 'Løn blev opdateret for ' .. jobName .. ' rank')
                    
                    DiscordLogger.LogProtectedGradeUpdated(source, jobName, salary)
                    
                    -- Wait for database write to complete
                    Wait(500)
                    
                    -- Refresh ESX jobs cache
                    pcall(function()
                        exports['es_extended']:RefreshJobs()
                    end)
                    
                    TriggerClientEvent('crown-jobcreator:refreshJobGrades', source, jobName)
                else
                    SendNotification(source, 'error', 'Fejl', 'Kunne ikke opdatere løn')
                end
            end)
                return
            end
            
            if not name or name == '' or not label or label == '' then
                TriggerClientEvent('ox_lib:notify', source, {
                    title = 'Fejl',
                    description = 'Alle felter skal udfyldes',
                    type = 'error'
                })
                return
            end
            
            if salary < Config.SalaryLimits.min or salary > Config.SalaryLimits.max then
                TriggerClientEvent('ox_lib:notify', source, {
                    title = 'Fejl',
                    description = 'Løn skal være mellem ' .. Config.SalaryLimits.min .. ' og ' .. Config.SalaryLimits.max,
                    type = 'error'
                })
                return
            end
            
            exports.oxmysql:execute('UPDATE ' .. Config.Database.jobGradesTable .. ' SET name = ?, label = ?, salary = ? WHERE id = ?', {
                name, label, salary, id
            }, function(result)
                if result then
                    SendNotification(source, 'success', 'Succes', 'Rank "' .. label .. '" blev opdateret')
                    
                    DiscordLogger.LogGradeUpdated(source, jobName, name, label, salary)
                    
                    -- Wait for database write to complete
                    Wait(500)
                    
                    -- Refresh ESX jobs cache
                    pcall(function()
                        exports['es_extended']:RefreshJobs()
                    end)
                    
                    TriggerClientEvent('crown-jobcreator:refreshJobGrades', source, jobName)
                else
                    SendNotification(source, 'error', 'Fejl', 'Kunne ikke opdatere rank')
                end
            end)
        end)
    end)
end)

RegisterNetEvent('crown-jobcreator:deleteJobGrade')
AddEventHandler('crown-jobcreator:deleteJobGrade', function(gradeId)
    local source = source
    if not CheckAdminAccess(source) then return end
    
    if not gradeId then
        SendNotification(source, 'error', 'Fejl', 'Rank ID skal udfyldes')
        return
    end
    
    exports.oxmysql:execute('SELECT job_name, label, grade FROM ' .. Config.Database.jobGradesTable .. ' WHERE id = ?', {
        gradeId
    }, function(result)
        if #result == 0 then
            SendNotification(source, 'error', 'Fejl', 'Rank ikke fundet')
            return
        end
        
        local jobName = result[1].job_name
        local label = result[1].label
        local grade = result[1].grade
        
        -- Check if job is protected by querying database
        exports.oxmysql:execute('SELECT job_type FROM ' .. Config.Database.jobsTable .. ' WHERE name = ?', {jobName}, function(jobResult)
            if #jobResult > 0 and jobResult[1].job_type == 'protected' then
                SendNotification(source, 'error', 'Fejl', 'Du kan ikke slette beskyttet job ranks')
                return
            end
            
            exports.oxmysql:execute('DELETE FROM ' .. Config.Database.jobGradesTable .. ' WHERE id = ?', {
                gradeId
            }, function(result)
                if result then
                    SendNotification(source, 'success', 'Succes', 'Rank "' .. label .. '" blev slettet')
                    
                    DiscordLogger.LogGradeDeleted(source, jobName, label, grade)
                    
                    -- Wait for database write to complete
                    Wait(500)
                    
                    -- Refresh ESX jobs cache
                    pcall(function()
                        exports['es_extended']:RefreshJobs()
                    end)
                    
                    TriggerClientEvent('crown-jobcreator:refreshJobGrades', source, jobName)
                else
                    SendNotification(source, 'error', 'Fejl', 'Kunne ikke slette rank')
                end
            end)
        end)
    end)
end)

-- ========================================
-- LIMITS CONFIGURATION
-- ========================================

ESX.RegisterServerCallback('crown-jobcreator:getLimitsConfig', function(source, cb)
    if not IsPlayerAdmin(source) then
        cb(nil)
        return
    end
    
    local isAuthorized = IsPlayerAuthorizedForLimits(source)
    
    cb({
        isAuthorized = isAuthorized,
        salaryLimits = Config.SalaryLimits,
        gradeLimits = Config.GradeLimits,
        protectedJobs = Config.ProtectedJobs or {}
    })
end)

RegisterNetEvent('crown-jobcreator:updateLimits')
AddEventHandler('crown-jobcreator:updateLimits', function(limitData)
    local source = source
    
    if not IsPlayerAdmin(source) or not IsPlayerAuthorizedForLimits(source) then
        SendNotification(source, 'error', 'Fejl', 'Du har ikke tilladelse til at ændre disse indstillinger')
        return
    end
    
    if limitData.type == 'salary' then
        Config.SalaryLimits.min = limitData.min
        Config.SalaryLimits.max = limitData.max
        
        -- Save to database
        SaveSettingToDatabase('salary_min', limitData.min)
        SaveSettingToDatabase('salary_max', limitData.max)
        
        SendNotification(source, 'success', 'Succes', 'Løngrænser blev opdateret og gemt')
    elseif limitData.type == 'grade' then
        Config.GradeLimits.min = limitData.min
        Config.GradeLimits.max = limitData.max
        
        -- Save to database
        SaveSettingToDatabase('grade_min', limitData.min)
        SaveSettingToDatabase('grade_max', limitData.max)
        
        SendNotification(source, 'success', 'Succes', 'Rang grænser blev opdateret og gemt')
    end
    
    -- Notify all admins to refresh their UI
    local xPlayers = ESX.GetExtendedPlayers()
    for _, xPlayer in ipairs(xPlayers) do
        if IsPlayerAdmin(xPlayer.source) then
            TriggerClientEvent('crown-jobcreator:refreshLimits', xPlayer.source)
        end
    end
end)

RegisterNetEvent('crown-jobcreator:updateProtectedJobs')
AddEventHandler('crown-jobcreator:updateProtectedJobs', function(jobs)
    local source = source
    
    if not IsPlayerAdmin(source) or not IsPlayerAuthorizedForLimits(source) then
        SendNotification(source, 'error', 'Fejl', 'Du har ikke tilladelse til at ændre beskyttede jobs')
        return
    end
    
    print('[Crown-JobCreator] updateProtectedJobs called with jobs:', json.encode(jobs))
    
    local oldProtectedJobs = Config.ProtectedJobs or {}
    Config.ProtectedJobs = jobs
    
    print('[Crown-JobCreator] Old protected jobs:', json.encode(oldProtectedJobs))
    
    -- Find jobs that were added to protected list
    local addedJobs = {}
    for _, jobName in ipairs(jobs) do
        local wasProtected = false
        for _, oldJob in ipairs(oldProtectedJobs) do
            if oldJob == jobName then
                wasProtected = true
                break
            end
        end
        if not wasProtected then
            table.insert(addedJobs, jobName)
        end
    end
    
    -- Find jobs that were removed from protected list
    local removedJobs = {}
    for _, jobName in ipairs(oldProtectedJobs) do
        local isStillProtected = false
        for _, newJob in ipairs(jobs) do
            if newJob == jobName then
                isStillProtected = true
                break
            end
        end
        if not isStillProtected then
            table.insert(removedJobs, jobName)
        end
    end
    
    -- Update database for added jobs
    for _, jobName in ipairs(addedJobs) do
        -- First check if job exists
        exports.oxmysql:execute('SELECT name FROM ' .. Config.Database.jobsTable .. ' WHERE name = ?', {jobName}, function(checkResult)
            if checkResult and #checkResult > 0 then
                -- Job exists, update it
                exports.oxmysql:execute('UPDATE ' .. Config.Database.jobsTable .. ' SET job_type = ? WHERE name = ?', {
                    'protected', jobName
                }, function(updateResult)
                    if updateResult and updateResult.affectedRows > 0 then
                        print('[Crown-JobCreator] Job "' .. jobName .. '" marked as protected in database (affected rows: ' .. updateResult.affectedRows .. ')')
                    else
                        print('[Crown-JobCreator] Warning: Could not update job "' .. jobName .. '" to protected')
                    end
                end)
            else
                print('[Crown-JobCreator] Warning: Job "' .. jobName .. '" does not exist in database, cannot mark as protected')
            end
        end)
    end
    
    -- Update database for removed jobs (set back to 'job')
    for _, jobName in ipairs(removedJobs) do
        -- First check if job exists
        exports.oxmysql:execute('SELECT name FROM ' .. Config.Database.jobsTable .. ' WHERE name = ?', {jobName}, function(checkResult)
            if checkResult and #checkResult > 0 then
                -- Job exists, update it
                exports.oxmysql:execute('UPDATE ' .. Config.Database.jobsTable .. ' SET job_type = ? WHERE name = ?', {
                    'job', jobName
                }, function(updateResult)
                    if updateResult and updateResult.affectedRows > 0 then
                        print('[Crown-JobCreator] Job "' .. jobName .. '" unmarked as protected in database (affected rows: ' .. updateResult.affectedRows .. ')')
                    else
                        print('[Crown-JobCreator] Warning: Could not update job "' .. jobName .. '" back to job type')
                    end
                end)
            else
                print('[Crown-JobCreator] Warning: Job "' .. jobName .. '" does not exist in database, cannot unmark as protected')
            end
        end)
    end
    
    -- Save to settings database
    SaveSettingToDatabase('protected_jobs', jobs)
    
    print('[Crown-JobCreator] Final Config.ProtectedJobs after update:', json.encode(Config.ProtectedJobs))
    
    SendNotification(source, 'success', 'Succes', 'Beskyttede jobs blev opdateret og gemt')
    
    -- Notify all admins to refresh their UI
    Wait(500) -- Wait a bit for database to finish writing
    local xPlayers = ESX.GetExtendedPlayers()
    for _, xPlayer in ipairs(xPlayers) do
        if IsPlayerAdmin(xPlayer.source) then
            TriggerClientEvent('crown-jobcreator:refreshLimits', xPlayer.source)
            TriggerClientEvent('crown-jobcreator:refreshJobs', xPlayer.source)
        end
    end
end)

-- ========================================
-- EXPORTS
-- ========================================

-- Export function to refresh ESX jobs cache from external resources
exports('RefreshESXJobs', function()
    local success = pcall(function()
        exports['es_extended']:RefreshJobs()
        return true
    end)
    return success
end)
