Config = {}
Config.Locale = 'da' -- EN / DA

-- ========================================
-- PERMISSIONS
-- ========================================

Config.AdminGroups = {
    'admin',
}

-- Identifiers that can edit salary/grade limits and protected jobs
-- These settings are now stored in the database (crown_jobsettings table)
-- But you still need to add your identifier here to have access
Config.AuthorizedIdentifiers = {
    'discord:YOUR_DISCORD_ID', 
}

-- Default protected jobs (loaded from database on start)
Config.ProtectedJobs = {
    'unemployed',
    'police',
    'ambulance',
}

-- ========================================
-- DATABASE SETTINGS
-- ========================================

Config.Database = {
    jobsTable = 'jobs',
    jobGradesTable = 'job_grades'
}


Config.UIColors = {
    primary = '#FFA500', -- Main accent color (used for buttons, icons, borders - "Se Jobs", "Se Spillere", category icons, etc.)
}

Config.Currency = {
    prefix = '$',
    suffix = '',
    position = 'before' -- Before / After
}

-- ========================================
-- DISCORD LOGS
-- ========================================

Config.Discord = {
    enabled = true,
    webhooks = {
        createJob = 'YOUR_CREATE_JOB_WEBHOOK_URL',
        deleteJob = 'YOUR_DELETE_JOB_WEBHOOK_URL',
        createGrade = 'YOUR_CREATE_GRADE_WEBHOOK_URL',
        updateGrade = 'YOUR_UPDATE_GRADE_WEBHOOK_URL',
        deleteGrade = 'YOUR_DELETE_GRADE_WEBHOOK_URL',
    },
    botName = 'Job Creator',
    botAvatar = 'https://i.imgur.com/ZTluCz6.png',
    colors = {
        create = 0x00ff00,
        update = 0xffaa00,
        delete = 0xff0000,
    }
}
