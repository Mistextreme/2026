-- Add job_type column to jobs table
-- If you get an error that the column already exists, you can ignore it
ALTER TABLE `jobs` ADD COLUMN `job_type` VARCHAR(20) DEFAULT 'job' AFTER `whitelisted`;

-- Update existing jobs: set 'unemployed' to 'protected', others default to 'job' if null
UPDATE `jobs` SET `job_type` = 'protected' WHERE `name` = 'unemployed';
UPDATE `jobs` SET `job_type` = 'job' WHERE `job_type` IS NULL OR `job_type` = '';

